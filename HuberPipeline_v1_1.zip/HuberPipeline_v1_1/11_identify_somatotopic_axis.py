#!/usr/bin/env python3
import argparse, json, sys
from pathlib import Path
import numpy as np
import pandas as pd
import yaml

FINGERS=("thumb","index","middle","ring","little")
LABELS=np.arange(1,6,dtype=float)

def parse_args():
    p=argparse.ArgumentParser()
    p.add_argument("config"); p.add_argument("session")
    p.add_argument("--minimum-axis-support",type=float,default=1.0)
    p.add_argument("--no-figures",action="store_true")
    return p.parse_args()

def load_yaml(p):
    with open(p,"r",encoding="utf-8") as f: return yaml.safe_load(f)

def expand(v,m):
    v=str(v)
    for _ in range(12):
        n=v
        for k,r in m.items(): n=n.replace("${"+k+"}",str(r))
        if n==v: return n
        v=n
    return v

def resolve(cfg_path,session):
    cfg=load_yaml(cfg_path); d=cfg.get("dataset",{}) or {}
    subject=str(cfg.get("subject") or d.get("subject") or "")
    paths=cfg.get("paths",{}) or {}
    pr=str(paths.get("project_root","")); rr=str(paths.get("roi_root","")); pl=str(paths.get("pipeline_root",""))
    m={"dataset.subject":subject,"dataset.session":session,"paths.project_root":pr,"paths.roi_root":rr,"paths.pipeline_root":pl}
    pr=expand(pr,m); m["paths.project_root"]=pr
    rr=expand(rr,m); m["paths.roi_root"]=rr
    pl=expand(pl,m); m["paths.pipeline_root"]=pl
    sr=paths.get("subject_root")
    sr=expand(sr,m) if sr else str(Path(pl)/"outputs"/subject); m["paths.subject_root"]=sr
    sess=paths.get("session_root")
    sess=expand(sess,m) if sess else str(Path(sr)/session)
    rad=float((cfg.get("frozen",{}) or {}).get("multilateration_radius_mm",30))
    root=Path(sess)/f"huber_style_maps_radius{rad:g}"
    return root, root/"somatotopy_qc", rad

def spearman(x,y):
    rx=pd.Series(x).rank(method="average").to_numpy(float)
    ry=pd.Series(y).rank(method="average").to_numpy(float)
    if np.std(rx)==0 or np.std(ry)==0: return np.nan
    return float(np.corrcoef(rx,ry)[0,1])

def inversions(vals,direction):
    v=np.asarray(vals,float)
    if direction=="decreasing": v=-v
    adj=sum(not(v[i]<v[i+1]) for i in range(4))
    pair=sum(not(v[i]<v[j]) for i in range(5) for j in range(i+1,5))
    return int(adj),int(pair),np.diff(v)

def load_axis(root,axis):
    pdir=root/("profiles_u_depth" if axis=="U" else "profiles_v_depth")
    tdir=root/"tables"; suf="u_by_depth" if axis=="U" else "v_by_depth"
    mats={}; sups={}
    for f in FINGERS:
        npy=pdir/f"dominance_fraction_{f}_{suf}.npy"
        csv=tdir/f"dominance_fraction_{f}_{suf}.csv"
        if not npy.is_file() or not csv.is_file(): raise FileNotFoundError(npy if not npy.is_file() else csv)
        m=np.load(npy).astype(float); tab=pd.read_csv(csv)
        s=tab["density_weight"].to_numpy(float).reshape(m.shape)
        mats[f]=m; sups[f]=s
    return mats,sups

def evaluate(root,axis,minsup):
    mats,sups=load_axis(root,axis); rows=[]; cents=[]; profiles={}
    npos=next(iter(mats.values())).shape[0]; pos=np.arange(npos,dtype=float)
    for f in FINGERS:
        m,s=mats[f],sups[f]
        valid=np.isfinite(m)&np.isfinite(s)&(s>0)
        num=np.sum(np.where(valid,m*s,0.0),axis=1)
        den=np.sum(np.where(valid,s,0.0),axis=1)
        prof=np.full(npos,np.nan); np.divide(num,den,out=prof,where=den>0)
        profiles[f]=prof
        v=np.isfinite(prof)&np.isfinite(den)&(den>=minsup)&(prof>=0)
        w=prof[v]*den[v]
        c=float(np.sum(pos[v]*w)/np.sum(w)) if np.sum(w)>0 else np.nan
        cents.append(c)
        rows.append({"axis":axis,"finger":f,"finger_label":FINGERS.index(f)+1,
                     "centroid_position_bin":c,"valid_axis_positions":int(v.sum()),
                     "total_dominance_x_density_weight":float(np.sum(w))})
    cents=np.asarray(cents,float)
    if not np.all(np.isfinite(cents)): raise RuntimeError(f"{axis} centroid failure: {cents}")
    rho=spearman(LABELS,cents); direction="increasing" if rho>=0 else "decreasing"
    adj,pair,diff=inversions(cents,direction)
    metrics={"axis":axis,"centroid_rho":rho,"best_direction_rho":abs(rho),"direction":direction,
             "adjacent_inversions":adj,"all_pair_inversions":pair,
             "minimum_adjacent_centroid_separation_bins":float(np.min(diff)),
             "median_adjacent_centroid_separation_bins":float(np.median(diff)),
             "centroids_bins":cents.tolist()}
    return metrics,pd.DataFrame(rows),profiles

def key(m):
    return (m["all_pair_inversions"],m["adjacent_inversions"],-m["best_direction_rho"],
            -m["minimum_adjacent_centroid_separation_bins"])

def main():
    a=parse_args(); root,out,rad=resolve(Path(a.config),a.session)
    if not root.is_dir(): raise RuntimeError(f"Step-10 output directory not found: {root}")
    out.mkdir(parents=True,exist_ok=True)
    results={}; frames=[]; profiles={}
    for ax in ("U","V"):
        m,df,p=evaluate(root,ax,a.minimum_axis_support); results[ax]=m; frames.append(df); profiles[ax]=p
    cent=pd.concat(frames,ignore_index=True); cent.to_csv(out/"finger_centroids_uv.csv",index=False)
    pd.DataFrame([{k:v for k,v in results[a].items() if k!="centroids_bins"} for a in ("U","V")]).to_csv(out/"axis_metrics.csv",index=False)
    rec=min(("U","V"),key=lambda a:key(results[a])); ambiguous=key(results["U"])==key(results["V"])
    summary={"status":"PASS","session":a.session,"radius_mm":rad,"primary_metric":"dominance_fraction",
             "finger_order":list(FINGERS),"axes":results,"recommended_somatotopic_axis":None if ambiguous else rec,
             "axis_ranking_ambiguous":ambiguous,"coordinate_geometry_modified":False,
             "axis_flipped_on_disk":False,"functional_feedback_to_uv_construction":False}
    (out/"step11_summary.json").write_text(json.dumps(summary,indent=2),encoding="utf-8")
    with (out/"step11_summary.txt").open("w",encoding="utf-8") as f:
        f.write("HuberPipeline Step 11 — somatotopic-axis QC\n\n")
        for ax in ("U","V"):
            m=results[ax]
            f.write(f"{ax}: rho={m['centroid_rho']:.6f}; |rho|={m['best_direction_rho']:.6f}; direction={m['direction']}; adjacent inversions={m['adjacent_inversions']}; all-pair inversions={m['all_pair_inversions']}; min adjacent separation={m['minimum_adjacent_centroid_separation_bins']:.6f} bins\n")
        f.write(f"\nRecommended somatotopic axis: {'AMBIGUOUS' if ambiguous else rec}\n")
        f.write("Coordinate geometry modified: NO\nAxis flipped on disk: NO\nFunctional feedback to UV construction: NO\nHard validation: PASS\n")
    rows=[]
    for ax in ("U","V"):
        for finger in FINGERS:
            p=profiles[ax][finger]
            for i,val in enumerate(p):
                rows.append({"axis":ax,"finger":finger,"finger_label":FINGERS.index(finger)+1,
                             "position_bin":i,"dominance_fraction":float(val) if np.isfinite(val) else np.nan})
    pd.DataFrame(rows).to_csv(out/"axis_profiles_long.csv",index=False)
    if not a.no_figures:
        import matplotlib; matplotlib.use("Agg",force=True)
        import matplotlib.pyplot as plt
        fig,axs=plt.subplots(2,2,figsize=(12,8))
        for col,axname in enumerate(("U","V")):
            ax=axs[0,col]
            for f in FINGERS: ax.plot(profiles[axname][f],label=f.title())
            ax.set_title(f"{axname}: depth-collapsed dominance profiles"); ax.set_xlabel(f"{axname} bin"); ax.set_ylabel("Dominance fraction"); ax.grid(alpha=.2)
            if col==1: ax.legend(frameon=False,fontsize=8)
            ax=axs[1,col]; t=cent[cent.axis==axname].sort_values("finger_label")
            ax.plot(t.finger_label,t.centroid_position_bin,marker="o")
            ax.set_title(f"{axname}: rho={results[axname]['centroid_rho']:.2f}, inversions={results[axname]['all_pair_inversions']}")
            ax.set_xlabel("Finger order (1 thumb → 5 little)"); ax.set_ylabel(f"Weighted {axname} centroid (bin)"); ax.set_xticks(range(1,6)); ax.grid(alpha=.2)
        fig.suptitle("Step 11 — descriptive intrinsic-axis somatotopy"); fig.tight_layout(rect=[0,0,1,.95]); fig.savefig(out/"somatotopic_axis_qc.png",dpi=220,bbox_inches="tight"); plt.close(fig)
    print("============================================================")
    print("HuberPipeline Step 11: Identify candidate somatotopic axis")
    print("============================================================")
    for ax in ("U","V"):
        m=results[ax]
        print(f"{ax}: centroid rho={m['centroid_rho']:.4f}; best-direction rho={m['best_direction_rho']:.4f}; direction={m['direction']}; adjacent inversions={m['adjacent_inversions']}; all-pair inversions={m['all_pair_inversions']}; min adjacent separation={m['minimum_adjacent_centroid_separation_bins']:.3f} bins")
    print()
    print(f"Recommended somatotopic axis: {'AMBIGUOUS' if ambiguous else rec}")
    print(f"Output directory: {out}")
    print("Coordinate geometry modified: NO")
    print("Axis flipped on disk: NO")
    print("Functional feedback to UV construction: NO")
    print("Step 11 validation: PASS")

if __name__=="__main__":
    try: main()
    except (FileNotFoundError,KeyError,RuntimeError,TypeError,ValueError) as exc:
        sys.exit(f"ERROR: {exc}")

