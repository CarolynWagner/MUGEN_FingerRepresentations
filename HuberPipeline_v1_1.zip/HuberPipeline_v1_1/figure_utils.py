#!/usr/bin/env python3
"""
Shared publication-figure utilities for HuberPipeline v1.0.

Designed for:
    15_generate_publication_figures.py

The module centralizes:
- publication styling;
- finger colour definitions;
- panel lettering;
- NIfTI loading and grid validation;
- robust slice selection and extraction;
- 2D flat-map loading;
- figure export to PDF/SVG/high-resolution PNG;
- exact plotted-data export;
- common colour normalization;
- legends and colour bars;
- provenance and manifest writing.

The utilities do not recompute any scientific analysis. They only support
visualization and reproducible export of frozen pipeline outputs.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Dict, Iterable, List, Mapping, Optional, Sequence, Tuple, Union

import matplotlib as mpl
mpl.use("Agg", force=True)
import matplotlib.pyplot as plt
from matplotlib.colors import BoundaryNorm, ListedColormap, Normalize
from matplotlib.patches import Patch
import nibabel as nib
import numpy as np
import pandas as pd


# ---------------------------------------------------------------------
# Frozen figure conventions
# ---------------------------------------------------------------------

FINGERS: Tuple[str, ...] = (
    "thumb",
    "index",
    "middle",
    "ring",
    "little",
)

FINGER_LABELS: Dict[str, int] = {
    "thumb": 1,
    "index": 2,
    "middle": 3,
    "ring": 4,
    "little": 5,
}

LABEL_TO_FINGER: Dict[int, str] = {
    value: key for key, value in FINGER_LABELS.items()
}

# Okabe-Ito-derived, colourblind-conscious palette.
FINGER_COLORS: Dict[str, str] = {
    "thumb": "#E64B35",   # vermillion
    "index": "#F3C300",   # amber/yellow
    "middle": "#00A087",  # green-teal
    "ring": "#3C5488",    # blue
    "little": "#B2479A",  # magenta-purple
}

PANEL_LABELS: Tuple[str, ...] = tuple("ABCDEFGHIJKLMNOPQRSTUVWXYZ")

WTA_CMAP = ListedColormap(
    ["#FFFFFF"] + [FINGER_COLORS[finger] for finger in FINGERS],
    name="finger_wta",
)

WTA_NORM = BoundaryNorm(
    np.arange(-0.5, 6.5, 1.0),
    WTA_CMAP.N,
)

DEFAULT_DPI = 600
DEFAULT_AFFINE_ATOL = 1e-4


# ---------------------------------------------------------------------
# Styling
# ---------------------------------------------------------------------

def configure_publication_style(
    font_family: str = "DejaVu Sans",
    base_font_size: float = 8.0,
) -> None:
    """
    Apply a consistent, vector-friendly publication style.

    DejaVu Sans is the safe default on most HPC systems. Helvetica or Arial
    can be requested when available, but this function never distributes or
    embeds external font files.
    """
    mpl.rcParams.update(
        {
            "font.family": font_family,
            "font.size": base_font_size,
            "axes.titlesize": base_font_size + 1,
            "axes.labelsize": base_font_size,
            "xtick.labelsize": base_font_size - 1,
            "ytick.labelsize": base_font_size - 1,
            "legend.fontsize": base_font_size - 1,
            "figure.titlesize": base_font_size + 3,
            "axes.linewidth": 0.8,
            "lines.linewidth": 1.4,
            "lines.markersize": 4.0,
            "axes.spines.top": False,
            "axes.spines.right": False,
            "axes.grid": False,
            "legend.frameon": False,
            "pdf.fonttype": 42,
            "ps.fonttype": 42,
            "svg.fonttype": "none",
            "savefig.bbox": "tight",
            "savefig.pad_inches": 0.05,
            "figure.constrained_layout.use": False,
        }
    )


def add_panel_label(
    axis: mpl.axes.Axes,
    label: str,
    x: float = -0.08,
    y: float = 1.05,
    fontsize: float = 11,
) -> None:
    """Place a bold panel label in consistent figure-relative coordinates."""
    axis.text(
        x,
        y,
        label,
        transform=axis.transAxes,
        ha="left",
        va="bottom",
        fontsize=fontsize,
        fontweight="bold",
        clip_on=False,
    )


def hide_image_ticks(axis: mpl.axes.Axes) -> None:
    """Remove image ticks without disabling the axis itself."""
    axis.set_xticks([])
    axis.set_yticks([])


def finger_legend_handles() -> List[Patch]:
    """Return standard legend handles for the five finger identities."""
    return [
        Patch(
            facecolor=FINGER_COLORS[finger],
            edgecolor="none",
            label=finger.capitalize(),
        )
        for finger in FINGERS
    ]


def add_finger_legend(
    axis: mpl.axes.Axes,
    *,
    location: str = "best",
    ncol: int = 1,
    bbox_to_anchor: Optional[Tuple[float, float]] = None,
) -> mpl.legend.Legend:
    """Add the standard five-finger legend to an axis."""
    kwargs = {
        "handles": finger_legend_handles(),
        "loc": location,
        "ncol": ncol,
        "frameon": False,
    }
    if bbox_to_anchor is not None:
        kwargs["bbox_to_anchor"] = bbox_to_anchor
    return axis.legend(**kwargs)


# ---------------------------------------------------------------------
# NIfTI loading and geometry
# ---------------------------------------------------------------------

def load_nifti(
    path: Union[str, Path],
    dtype: np.dtype = np.float32,
) -> Tuple[nib.Nifti1Image, np.ndarray]:
    """Load a NIfTI image and return the image plus floating-point data."""
    path = Path(path)
    if not path.is_file():
        raise FileNotFoundError(path)

    image = nib.load(str(path))
    data = image.get_fdata(dtype=dtype)
    return image, data


def validate_same_grid(
    reference: nib.Nifti1Image,
    moving: nib.Nifti1Image,
    *,
    reference_name: str = "reference",
    moving_name: str = "moving",
    affine_atol: float = DEFAULT_AFFINE_ATOL,
) -> None:
    """Require matching 3D shape and affine."""
    if reference.shape[:3] != moving.shape[:3]:
        raise RuntimeError(
            "NIfTI shape mismatch:\n"
            f"  {reference_name}: {reference.shape[:3]}\n"
            f"  {moving_name}: {moving.shape[:3]}"
        )

    if not np.allclose(
        reference.affine,
        moving.affine,
        atol=affine_atol,
        rtol=0.0,
    ):
        raise RuntimeError(
            "NIfTI affine mismatch:\n"
            f"  {reference_name}\n"
            f"  {moving_name}"
        )


def validate_many_grids(
    reference: nib.Nifti1Image,
    moving: Iterable[Tuple[str, nib.Nifti1Image]],
    *,
    reference_name: str = "reference",
    affine_atol: float = DEFAULT_AFFINE_ATOL,
) -> None:
    """Validate several images against one reference image."""
    for name, image in moving:
        validate_same_grid(
            reference,
            image,
            reference_name=reference_name,
            moving_name=name,
            affine_atol=affine_atol,
        )


def load_flat_map_2d(path: Union[str, Path]) -> np.ndarray:
    """
    Load a 2D flattened map.

    A singleton third dimension is accepted and removed.
    """
    _, data = load_nifti(path)

    if data.ndim == 2:
        return data

    if data.ndim == 3 and data.shape[2] == 1:
        return data[:, :, 0]

    raise RuntimeError(
        f"Expected a 2D or singleton-3D flat map, found {data.shape}: {path}"
    )


# ---------------------------------------------------------------------
# Slice selection and extraction
# ---------------------------------------------------------------------

def robust_slice_index(
    mask: np.ndarray,
    axis: int = 2,
) -> int:
    """
    Select the slice containing the largest number of nonzero mask voxels.

    This is deterministic and more defensible than selecting a hand-entered
    slice number for a reproducible figure.
    """
    if mask.ndim != 3:
        raise ValueError(
            f"Expected a 3D mask, found shape {mask.shape}."
        )
    if axis not in (0, 1, 2):
        raise ValueError("axis must be 0, 1, or 2.")

    summed_axes = tuple(
        dimension for dimension in range(3) if dimension != axis
    )
    counts = np.sum(mask.astype(bool), axis=summed_axes)

    if not np.any(counts > 0):
        return mask.shape[axis] // 2

    return int(np.argmax(counts))


def extract_slice(
    data: np.ndarray,
    axis: int,
    index: int,
    *,
    rotate_k: int = 1,
) -> np.ndarray:
    """
    Extract a 2D slice and rotate it for conventional display.

    The rotation is display-only and does not alter source data.
    """
    if data.ndim < 3:
        raise ValueError(
            f"Expected at least 3 dimensions, found {data.shape}."
        )

    if axis == 0:
        output = data[index, ...]
    elif axis == 1:
        output = data[:, index, ...]
    elif axis == 2:
        output = data[:, :, index, ...]
    else:
        raise ValueError("axis must be 0, 1, or 2.")

    return np.rot90(output, k=rotate_k, axes=(0, 1))


def mask_crop_bounds(
    mask: np.ndarray,
    padding: int = 4,
) -> Tuple[slice, ...]:
    """Return tight crop slices around a nonzero N-dimensional mask."""
    coordinates = np.argwhere(mask.astype(bool))
    if coordinates.size == 0:
        raise RuntimeError("Cannot crop an empty mask.")

    lower = np.maximum(coordinates.min(axis=0) - padding, 0)
    upper = np.minimum(
        coordinates.max(axis=0) + padding + 1,
        np.asarray(mask.shape),
    )

    return tuple(
        slice(int(start), int(stop))
        for start, stop in zip(lower, upper)
    )


def apply_crop(
    array: np.ndarray,
    bounds: Sequence[slice],
) -> np.ndarray:
    """Apply crop bounds returned by mask_crop_bounds."""
    return array[tuple(bounds)]


# ---------------------------------------------------------------------
# Colour scaling
# ---------------------------------------------------------------------

def finite_percentile_limits(
    arrays: Iterable[np.ndarray],
    lower: float = 2.0,
    upper: float = 98.0,
    *,
    fallback: Tuple[float, float] = (0.0, 1.0),
) -> Tuple[float, float]:
    """Compute shared robust colour limits from one or more arrays."""
    finite_parts = [
        np.asarray(array)[np.isfinite(array)]
        for array in arrays
        if np.any(np.isfinite(array))
    ]

    if not finite_parts:
        return fallback

    values = np.concatenate(finite_parts)
    minimum, maximum = np.percentile(values, [lower, upper])

    if not np.isfinite(minimum) or not np.isfinite(maximum):
        return fallback

    if np.isclose(minimum, maximum):
        epsilon = max(abs(float(minimum)) * 0.01, 1e-6)
        return float(minimum - epsilon), float(maximum + epsilon)

    return float(minimum), float(maximum)


def symmetric_limits(
    arrays: Iterable[np.ndarray],
    percentile: float = 98.0,
    *,
    fallback: float = 1.0,
) -> Tuple[float, float]:
    """Return symmetric limits around zero for signed maps."""
    finite_parts = [
        np.abs(np.asarray(array)[np.isfinite(array)])
        for array in arrays
        if np.any(np.isfinite(array))
    ]

    if not finite_parts:
        return -fallback, fallback

    maximum = float(np.percentile(np.concatenate(finite_parts), percentile))
    if not np.isfinite(maximum) or maximum <= 0:
        maximum = fallback

    return -maximum, maximum


def masked_image(
    data: np.ndarray,
    mask: np.ndarray,
) -> np.ma.MaskedArray:
    """Return a masked array limited to a Boolean support mask."""
    if data.shape != mask.shape:
        raise ValueError(
            f"Shape mismatch: data={data.shape}, mask={mask.shape}"
        )
    return np.ma.masked_where(~mask.astype(bool), data)


# ---------------------------------------------------------------------
# Colour bars
# ---------------------------------------------------------------------

def add_colorbar(
    figure: mpl.figure.Figure,
    image: mpl.cm.ScalarMappable,
    axes: Union[mpl.axes.Axes, Sequence[mpl.axes.Axes]],
    *,
    label: Optional[str] = None,
    orientation: str = "vertical",
    fraction: float = 0.046,
    pad: float = 0.02,
) -> mpl.colorbar.Colorbar:
    """Add a consistently styled colour bar."""
    colorbar = figure.colorbar(
        image,
        ax=axes,
        orientation=orientation,
        fraction=fraction,
        pad=pad,
    )
    if label:
        colorbar.set_label(label)
    return colorbar


# ---------------------------------------------------------------------
# Figure and data export
# ---------------------------------------------------------------------

def export_figure(
    figure: mpl.figure.Figure,
    output_directory: Union[str, Path],
    stem: str,
    *,
    png_dpi: int = DEFAULT_DPI,
    transparent: bool = False,
    close: bool = True,
) -> List[Path]:
    """
    Export one figure as PDF, SVG, and high-resolution PNG.

    PDF and SVG retain vector elements. Raster image panels remain rasterized
    within those containers, as expected for NIfTI image displays.
    """
    output_directory = Path(output_directory)
    output_directory.mkdir(parents=True, exist_ok=True)

    outputs = [
        output_directory / f"{stem}.pdf",
        output_directory / f"{stem}.svg",
        output_directory / f"{stem}.png",
    ]

    figure.savefig(outputs[0], transparent=transparent)
    figure.savefig(outputs[1], transparent=transparent)
    figure.savefig(
        outputs[2],
        dpi=png_dpi,
        transparent=transparent,
    )

    if close:
        plt.close(figure)

    return outputs


def write_dataframe(
    dataframe: pd.DataFrame,
    path: Union[str, Path],
) -> Path:
    """Write a CSV with a guaranteed parent directory."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    dataframe.to_csv(path, index=False)
    return path


def array_to_long_dataframe(
    array: np.ndarray,
    value_name: str,
    axis_names: Sequence[str],
    *,
    metadata: Optional[Mapping[str, object]] = None,
) -> pd.DataFrame:
    """Convert an N-dimensional array to an exact long-format table."""
    if array.ndim != len(axis_names):
        raise ValueError(
            "The number of axis names must equal array.ndim."
        )

    rows: List[Dict[str, object]] = []

    for index in np.ndindex(array.shape):
        row: Dict[str, object] = {
            axis_names[dimension]: int(index[dimension])
            for dimension in range(array.ndim)
        }
        value = array[index]
        row[value_name] = (
            float(value) if np.isfinite(value) else np.nan
        )
        if metadata:
            row.update(metadata)
        rows.append(row)

    return pd.DataFrame(rows)


def write_array_long(
    array: np.ndarray,
    path: Union[str, Path],
    value_name: str,
    axis_names: Sequence[str],
    *,
    metadata: Optional[Mapping[str, object]] = None,
) -> Path:
    """Convert an array to long format and write it as CSV."""
    dataframe = array_to_long_dataframe(
        array,
        value_name,
        axis_names,
        metadata=metadata,
    )
    return write_dataframe(dataframe, path)


def append_manifest_entries(
    manifest: List[Dict[str, object]],
    *,
    figure_id: str,
    files: Iterable[Union[str, Path]],
    description: str,
    metadata: Optional[Mapping[str, object]] = None,
) -> None:
    """Append standardized entries for figure products."""
    for file_path in files:
        row: Dict[str, object] = {
            "figure": figure_id,
            "file": str(file_path),
            "description": description,
        }
        if metadata:
            row.update(metadata)
        manifest.append(row)


def write_manifest(
    manifest: Iterable[Mapping[str, object]],
    path: Union[str, Path],
) -> Path:
    """Write the figure-manifest table."""
    return write_dataframe(pd.DataFrame(list(manifest)), path)


def write_provenance_json(
    provenance: Mapping[str, object],
    path: Union[str, Path],
) -> Path:
    """Write human-readable JSON provenance."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)

    with path.open("w", encoding="utf-8") as stream:
        json.dump(dict(provenance), stream, indent=2, sort_keys=True)

    return path


# ---------------------------------------------------------------------
# Common pipeline-data loaders
# ---------------------------------------------------------------------

def load_depth_averaged_finger_maps(
    huber_maps_directory: Union[str, Path],
) -> Dict[str, np.ndarray]:
    """Load Step-10 depth-averaged dominance-fraction maps."""
    huber_maps_directory = Path(huber_maps_directory)
    output: Dict[str, np.ndarray] = {}

    for finger in FINGERS:
        path = (
            huber_maps_directory
            / "depth_averaged_uv"
            / f"dominance_fraction_{finger}_uv_mean.nii.gz"
        )
        output[finger] = load_flat_map_2d(path)

    return output


def load_u_by_depth_matrices(
    huber_maps_directory: Union[str, Path],
) -> Dict[str, np.ndarray]:
    """Load Step-10 U × depth matrices for all fingers."""
    huber_maps_directory = Path(huber_maps_directory)
    output: Dict[str, np.ndarray] = {}

    for finger in FINGERS:
        path = (
            huber_maps_directory
            / "profiles_u_depth"
            / f"dominance_fraction_{finger}_u_by_depth.npy"
        )
        if not path.is_file():
            raise FileNotFoundError(path)

        matrix = np.load(path)
        if matrix.ndim != 2:
            raise RuntimeError(
                f"Expected a 2D U×depth matrix, found {matrix.shape}: {path}"
            )
        output[finger] = matrix

    return output


def load_v_by_depth_matrices(
    huber_maps_directory: Union[str, Path],
) -> Dict[str, np.ndarray]:
    """Load Step-10 V × depth matrices for all fingers."""
    huber_maps_directory = Path(huber_maps_directory)
    output: Dict[str, np.ndarray] = {}

    for finger in FINGERS:
        path = (
            huber_maps_directory
            / "profiles_v_depth"
            / f"dominance_fraction_{finger}_v_by_depth.npy"
        )
        if not path.is_file():
            raise FileNotFoundError(path)

        matrix = np.load(path)
        if matrix.ndim != 2:
            raise RuntimeError(
                f"Expected a 2D V×depth matrix, found {matrix.shape}: {path}"
            )
        output[finger] = matrix

    return output


def load_wta_products(
    huber_maps_directory: Union[str, Path],
) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Load flattened WTA, winner margin, and winning dominance maps."""
    huber_maps_directory = Path(huber_maps_directory)
    wta_directory = huber_maps_directory / "wta"

    wta = load_flat_map_2d(
        wta_directory / "finger_wta_uv.nii.gz"
    )
    margin = load_flat_map_2d(
        wta_directory / "finger_wta_margin_uv.nii.gz"
    )
    maximum = load_flat_map_2d(
        wta_directory / "finger_wta_maximum_fraction_uv.nii.gz"
    )

    return wta, margin, maximum


def load_depth_pooled_u_profiles(
    huber_maps_directory: Union[str, Path],
) -> pd.DataFrame:
    """
    Load Step-11 pooled U profiles or derive them from Step-10 long data.

    The derivation is density-weighted and uses only finite raw values.
    """
    huber_maps_directory = Path(huber_maps_directory)

    preferred = (
        huber_maps_directory
        / "somatotopy_qc"
        / "depth_pooled_profiles.csv"
    )
    if preferred.is_file():
        data = pd.read_csv(preferred)
        return data[data["profile_axis"] == "U"].copy()

    source = (
        huber_maps_directory
        / "tables"
        / "dominance_fraction_profiles_long.csv"
    )
    if not source.is_file():
        raise FileNotFoundError(source)

    data = pd.read_csv(source)
    data = data[data["profile_axis"] == "U"].copy()
    data = data[
        np.isfinite(data["dominance_fraction"])
        & np.isfinite(data["density_weight"])
        & (data["density_weight"] > 0)
    ]

    rows: List[Dict[str, object]] = []

    for (finger, position), group in data.groupby(
        ["finger", "position_bin"]
    ):
        weights = group["density_weight"].to_numpy(dtype=float)
        values = group["dominance_fraction"].to_numpy(dtype=float)

        rows.append(
            {
                "profile_axis": "U",
                "finger": finger,
                "position_bin": int(position),
                "dominance_fraction": float(
                    np.sum(values * weights) / np.sum(weights)
                ),
                "density_support": float(np.sum(weights)),
            }
        )

    return pd.DataFrame(rows)


def load_robust_laminar_tables(
    robust_directory: Union[str, Path],
) -> Dict[str, pd.DataFrame]:
    """Load all Step-13 tables needed for Figure S18-4."""
    robust_directory = Path(robust_directory)

    files = {
        "ordering": "sliding_window_ordering_summary.csv",
        "specificity": "sliding_window_axis_specificity.csv",
        "finger_metrics": "sliding_window_finger_metrics.csv",
        "overlap": "sliding_window_adjacent_overlap.csv",
        "support": "single_bin_support_qc.csv",
        "intervals": "contiguous_interval_summary.csv",
    }

    output: Dict[str, pd.DataFrame] = {}

    for key, filename in files.items():
        path = robust_directory / filename
        if not path.is_file():
            raise FileNotFoundError(path)
        output[key] = pd.read_csv(path)

    return output


# ---------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------

__all__ = [
    "DEFAULT_AFFINE_ATOL",
    "DEFAULT_DPI",
    "FINGERS",
    "FINGER_COLORS",
    "FINGER_LABELS",
    "LABEL_TO_FINGER",
    "PANEL_LABELS",
    "WTA_CMAP",
    "WTA_NORM",
    "add_colorbar",
    "add_finger_legend",
    "add_panel_label",
    "append_manifest_entries",
    "apply_crop",
    "array_to_long_dataframe",
    "configure_publication_style",
    "export_figure",
    "extract_slice",
    "finger_legend_handles",
    "finite_percentile_limits",
    "hide_image_ticks",
    "load_depth_averaged_finger_maps",
    "load_depth_pooled_u_profiles",
    "load_flat_map_2d",
    "load_nifti",
    "load_robust_laminar_tables",
    "load_u_by_depth_matrices",
    "load_v_by_depth_matrices",
    "load_wta_products",
    "mask_crop_bounds",
    "masked_image",
    "robust_slice_index",
    "symmetric_limits",
    "validate_many_grids",
    "validate_same_grid",
    "write_array_long",
    "write_dataframe",
    "write_manifest",
    "write_provenance_json",
]
