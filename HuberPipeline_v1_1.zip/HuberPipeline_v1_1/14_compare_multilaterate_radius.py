#!/usr/bin/env python3
"""
HuberPipeline Step 14 — Multilateration-radius sensitivity analysis

This step is sensitivity analysis only. The production radius remains the
radius frozen in 00_config.yaml (30 mm in v1.0); functional results are not
used to choose a new radius.

The script compares completed, cleaned radius-specific Steps 08–13.
"""

import argparse
import json
import re
import sys
from pathlib import Path

import matplotlib
matplotlib.use("Agg", force=True)
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import yaml


def parse_args():
    p = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )
    p.add_argument("config")
    p.add_argument("session")
    p.add_argument("--radii", nargs="+", type=float, default=None)
    p.add_argument("--auto-detect", action="store_true")
    p.add_argument("--no-figures", action="store_true")
    return p.parse_args()


def expand(value, mapping):
    value = str(value)
    for _ in range(12):
        new = value
        for key, repl in mapping.items():
            new = new.replace("${" + key + "}", str(repl))
        if new == value:
            return new
        value = new
    return value


def resolve(config_path, session):
    with Path(config_path).open("r", encoding="utf-8") as f:
        cfg = yaml.safe_load(f)
    if not isinstance(cfg, dict):
        raise ValueError("YAML root must be a mapping.")

    dataset = cfg.get("dataset", {}) or {}
    subject = str(cfg.get("subject") or dataset.get("subject") or "")
    if not subject:
        raise ValueError("Could not resolve subject.")

    paths = cfg.get("paths", {}) or {}
    project_root = str(paths.get("project_root", ""))
    roi_root = str(paths.get("roi_root", ""))
    pipeline_root = str(paths.get("pipeline_root", ""))

    mapping = {
        "dataset.subject": subject,
        "dataset.session": session,
        "paths.project_root": project_root,
        "paths.roi_root": roi_root,
        "paths.pipeline_root": pipeline_root,
    }

    project_root = expand(project_root, mapping)
    mapping["paths.project_root"] = project_root
    roi_root = expand(roi_root, mapping)
    mapping["paths.roi_root"] = roi_root
    pipeline_root = expand(pipeline_root, mapping)
    mapping["paths.pipeline_root"] = pipeline_root

    subject_root = paths.get("subject_root")
    subject_root = (
        expand(subject_root, mapping)
        if subject_root
        else str(Path(pipeline_root) / "outputs" / subject)
    )
    mapping["paths.subject_root"] = subject_root

    session_root = paths.get("session_root")
    session_root = (
        expand(session_root, mapping)
        if session_root
        else str(Path(subject_root) / session)
    )

    frozen = cfg.get("frozen", {}) or {}
    reference_radius = float(
        frozen.get("multilateration_radius_mm", 30)
    )
    return Path(session_root), reference_radius, subject


def rtag(radius):
    return f"{float(radius):g}"


def auto_detect(session_root):
    out = []
    pat = re.compile(r"^huber_style_maps_radius(.+)$")
    for p in session_root.glob("huber_style_maps_radius*"):
        if not p.is_dir():
            continue
        m = pat.match(p.name)
        if not m:
            continue
        try:
            out.append(float(m.group(1)))
        except ValueError:
            pass
    return sorted(set(out))


def read_json(path):
    path = Path(path)
    if not path.is_file():
        raise FileNotFoundError(path)
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)


def read_csv(path):
    path = Path(path)
    if not path.is_file():
        raise FileNotFoundError(path)
    return pd.read_csv(path)


def interval_overlap(a0, a1, b0, b1):
    inter = max(0.0, min(a1, b1) - max(a0, b0))
    union = max(a1, b1) - min(a0, b0)
    return {
        "depth_overlap": inter,
        "depth_jaccard": inter / union if union > 0 else np.nan,
        "reference_fraction_overlapped": (
            inter / (a1 - a0) if a1 > a0 else np.nan
        ),
        "candidate_fraction_overlapped": (
            inter / (b1 - b0) if b1 > b0 else np.nan
        ),
    }


def specificity_summary(df, preferred_axis):
    required = {
        "u_valid", "v_valid", "u_minus_v_specificity"
    }
    missing = required - set(df.columns)
    if missing:
        raise RuntimeError(
            "sliding_window_axis_specificity.csv missing: "
            + ", ".join(sorted(missing))
        )

    valid = (
        df["u_valid"].astype(bool)
        & df["v_valid"].astype(bool)
        & np.isfinite(df["u_minus_v_specificity"])
    )
    x = df.loc[valid, "u_minus_v_specificity"].to_numpy(float)
    if preferred_axis == "V":
        x = -x

    if x.size == 0:
        return {
            "n_specificity_windows": 0,
            "mean_preferred_axis_specificity": np.nan,
            "fraction_windows_favouring_preferred_axis": np.nan,
        }

    return {
        "n_specificity_windows": int(x.size),
        "mean_preferred_axis_specificity": float(np.mean(x)),
        "fraction_windows_favouring_preferred_axis": float(np.mean(x > 0)),
    }


def centroid_stability(df, axis):
    required = {
        "profile_axis", "finger", "window_id", "centroid_position"
    }
    missing = required - set(df.columns)
    if missing:
        raise RuntimeError(
            "sliding_window_finger_metrics.csv missing: "
            + ", ".join(sorted(missing))
        )

    jumps = []
    for finger in ("thumb", "index", "middle", "ring", "little"):
        sub = (
            df[
                (df["profile_axis"] == axis)
                & (df["finger"] == finger)
            ]
            .sort_values("window_id")
        )
        vals = sub["centroid_position"].to_numpy(float)
        vals = vals[np.isfinite(vals)]
        if vals.size >= 2:
            jumps.extend(np.abs(np.diff(vals)).tolist())

    if not jumps:
        return np.nan
    return float(np.mean(jumps))


def extract_candidate(session_root, session, radius):
    tag = rtag(radius)
    session_compact = session.replace("-", "")

    huber = session_root / f"huber_style_maps_radius{tag}"
    robust = huber / "robust_continuous_laminar_somatotopy"
    flat = session_root / f"flat_uvd_radius{tag}"
    uv_qc = session_root / "true_uv" / "qc"

    step10 = read_json(huber / "qc" / "step10_summary.json")
    step11 = read_json(
        huber / "somatotopy_qc" / "step11_summary.json"
    )
    step13 = read_json(robust / "step13_summary.json")
    step09 = read_json(flat / "qc" / "flatten_summary.json")
    step08 = read_json(
        uv_qc
        / f"{session_compact}_multilaterate_radius{tag}_summary.json"
    )

    specificity = read_csv(
        robust / "sliding_window_axis_specificity.csv"
    )
    finger_metrics = read_csv(
        robust / "sliding_window_finger_metrics.csv"
    )
    intervals = read_csv(
        robust / "contiguous_interval_summary.csv"
    )

    preferred_axis = step11.get("recommended_somatotopic_axis")
    supported = step13.get("best_supported_contiguous_interval")

    row = {
        "radius_mm": float(radius),
        "step11_preferred_axis": preferred_axis,
        "supported_interval_present": supported is not None,
        "supported_interval_axis": (
            supported.get("axis") if supported else None
        ),
        "supported_interval_start": (
            float(supported["depth_start_normalized"])
            if supported else np.nan
        ),
        "supported_interval_stop": (
            float(supported["depth_stop_normalized"])
            if supported else np.nan
        ),
        "supported_interval_n_windows": (
            int(supported["n_windows"]) if supported else 0
        ),
        "supported_interval_mean_rho": (
            float(supported["mean_best_rho"])
            if supported else np.nan
        ),
        "supported_interval_minimum_rho": (
            float(supported["minimum_best_rho"])
            if supported else np.nan
        ),
        "supported_interval_mean_tau": (
            float(supported["mean_best_tau"])
            if supported else np.nan
        ),
        "supported_interval_minimum_specificity": (
            float(supported["minimum_axis_specificity"])
            if supported else np.nan
        ),
        "supported_interval_mean_specificity": (
            float(supported["mean_axis_specificity"])
            if supported else np.nan
        ),
        "step08_domain_voxels": int(step08["domain_voxels"]),
        "step08_u_span_mm": float(step08["u_span_mm"]),
        "step08_v_span_mm": float(step08["v_span_mm"]),
        "step09_valid_support_bins": int(
            step09.get(
                "raw_density_intersection_domain_bins",
                step09.get("raw_supported_bins", 0),
            )
        ),
        "step10_valid_support_bins": int(
            step10["valid_domain_intersection_density_bins_3d"]
        ),
        "step10_valid_wta_bins": int(
            step10["valid_depth_averaged_wta_bins"]
        ),
    }

    row.update(specificity_summary(specificity, preferred_axis))
    row["preferred_axis_mean_centroid_jump"] = (
        centroid_stability(
            finger_metrics,
            preferred_axis if preferred_axis in ("U", "V") else "U",
        )
    )

    intervals = intervals.copy()
    intervals.insert(0, "radius_mm", float(radius))
    return row, intervals


def make_figure(path, metrics, reference_radius):
    r = metrics["radius_mm"].to_numpy(float)

    fig, axes = plt.subplots(2, 2, figsize=(11, 8))
    fig.suptitle("Step 14 — multilateration-radius sensitivity")

    ax = axes[0, 0]
    ax.plot(r, metrics["supported_interval_mean_rho"], marker="o",
            label="Mean |rho|")
    ax.plot(r, metrics["supported_interval_minimum_rho"], marker="o",
            label="Minimum |rho|")
    ax.axvline(reference_radius, linestyle="--", linewidth=1)
    ax.set_xlabel("Radius (mm)")
    ax.set_ylabel("Supported interval ordering")
    ax.legend(frameon=False)
    ax.grid(alpha=0.2)

    ax = axes[0, 1]
    ax.plot(r, metrics["supported_interval_mean_specificity"], marker="o",
            label="Mean specificity")
    ax.plot(r, metrics["supported_interval_minimum_specificity"], marker="o",
            label="Minimum specificity")
    ax.axhline(0.0, linewidth=0.8)
    ax.axvline(reference_radius, linestyle="--", linewidth=1)
    ax.set_xlabel("Radius (mm)")
    ax.set_ylabel("Preferred-axis specificity")
    ax.legend(frameon=False)
    ax.grid(alpha=0.2)

    ax = axes[1, 0]
    ax.plot(r, metrics["step08_domain_voxels"], marker="o",
            label="Step-08 domain")
    ax.plot(r, metrics["step10_valid_support_bins"], marker="o",
            label="Step-10 quantitative support")
    ax.plot(r, metrics["step10_valid_wta_bins"], marker="o",
            label="Step-10 WTA support")
    ax.axvline(reference_radius, linestyle="--", linewidth=1)
    ax.set_xlabel("Radius (mm)")
    ax.set_ylabel("Count")
    ax.legend(frameon=False, fontsize=8)
    ax.grid(alpha=0.2)

    ax = axes[1, 1]
    for row in metrics.itertuples():
        if not bool(row.supported_interval_present):
            continue
        ax.plot(
            [row.supported_interval_start, row.supported_interval_stop],
            [row.radius_mm, row.radius_mm],
            linewidth=5,
        )
    ax.axhline(reference_radius, linestyle="--", linewidth=1)
    ax.set_xlabel("Normalized cortical depth")
    ax.set_ylabel("Radius (mm)")
    ax.set_title("Supported interval location")
    ax.grid(alpha=0.2)

    fig.tight_layout(rect=[0, 0, 1, 0.95])
    fig.savefig(path, dpi=220, bbox_inches="tight")
    plt.close(fig)


def main():
    args = parse_args()
    session_root, reference_radius, subject = resolve(
        args.config, args.session
    )

    if args.radii is not None and args.auto_detect:
        raise ValueError("Use either --radii or --auto-detect, not both.")

    if args.radii is not None:
        radii = sorted(set(float(x) for x in args.radii))
    elif args.auto_detect:
        radii = auto_detect(session_root)
    else:
        raise ValueError("Specify --radii ... or --auto-detect.")

    if len(radii) < 2:
        raise RuntimeError(
            "Step 14 requires at least two completed cleaned radius-specific "
            "pipelines."
        )

    if not any(np.isclose(x, reference_radius) for x in radii):
        raise RuntimeError(
            f"Frozen reference radius {reference_radius:g} mm is absent."
        )

    rows = []
    intervals = []
    for radius in radii:
        row, iv = extract_candidate(
            session_root, args.session, radius
        )
        rows.append(row)
        intervals.append(iv)

    metrics = pd.DataFrame(rows).sort_values("radius_mm").reset_index(drop=True)
    ref = metrics[np.isclose(metrics["radius_mm"], reference_radius)]
    if len(ref) != 1:
        raise RuntimeError("Frozen reference row is not unique.")
    ref = ref.iloc[0]

    if not bool(ref["supported_interval_present"]):
        raise RuntimeError(
            "Frozen reference radius has no supported Step-13 interval."
        )

    comparisons = []
    for row in metrics.itertuples(index=False):
        same_axis = row.step11_preferred_axis == ref["step11_preferred_axis"]
        supported = bool(row.supported_interval_present)
        same_supported_axis = (
            supported
            and row.supported_interval_axis
            == ref["supported_interval_axis"]
        )

        if supported:
            ov = interval_overlap(
                float(ref["supported_interval_start"]),
                float(ref["supported_interval_stop"]),
                float(row.supported_interval_start),
                float(row.supported_interval_stop),
            )
        else:
            ov = {
                "depth_overlap": 0.0,
                "depth_jaccard": 0.0,
                "reference_fraction_overlapped": 0.0,
                "candidate_fraction_overlapped": 0.0,
            }

        comparisons.append({
            "radius_mm": float(row.radius_mm),
            "is_frozen_reference": bool(
                np.isclose(row.radius_mm, reference_radius)
            ),
            "same_step11_axis_as_reference": same_axis,
            "supported_interval_present": supported,
            "same_supported_axis_as_reference": same_supported_axis,
            **ov,
            "conclusion_concordant": bool(
                same_axis
                and supported
                and same_supported_axis
                and ov["depth_overlap"] > 0
            ),
        })

    comparison = pd.DataFrame(comparisons)
    nonref = comparison[~comparison["is_frozen_reference"]]

    outdir = session_root / "radius_sensitivity"
    outdir.mkdir(parents=True, exist_ok=True)

    metrics.to_csv(outdir / "radius_sensitivity_metrics.csv", index=False)
    comparison.to_csv(
        outdir / "supported_interval_comparison.csv", index=False
    )
    pd.concat(intervals, ignore_index=True).to_csv(
        outdir / "all_supported_intervals.csv", index=False
    )

    fraction = float(nonref["conclusion_concordant"].mean())

    summary = {
        "status": "PASS",
        "subject": subject,
        "session": args.session,
        "frozen_reference_radius_mm": reference_radius,
        "candidate_radii_mm": radii,
        "reference_step11_axis": ref["step11_preferred_axis"],
        "reference_supported_interval": {
            "axis": ref["supported_interval_axis"],
            "depth_start_normalized": float(
                ref["supported_interval_start"]
            ),
            "depth_stop_normalized": float(
                ref["supported_interval_stop"]
            ),
            "mean_rho": float(ref["supported_interval_mean_rho"]),
            "minimum_rho": float(
                ref["supported_interval_minimum_rho"]
            ),
            "minimum_specificity": float(
                ref["supported_interval_minimum_specificity"]
            ),
        },
        "n_nonreference_candidates": int(len(nonref)),
        "fraction_nonreference_conclusion_concordant": fraction,
        "all_nonreference_conclusions_concordant": bool(
            nonref["conclusion_concordant"].all()
        ),
        "radius_selected_from_functional_results": False,
        "production_radius_changed": False,
        "interpretation": "sensitivity_analysis_only",
    }

    with (outdir / "radius_sensitivity_summary.json").open(
        "w", encoding="utf-8"
    ) as f:
        json.dump(summary, f, indent=2)

    with (outdir / "radius_sensitivity_summary.txt").open(
        "w", encoding="utf-8"
    ) as f:
        f.write("HuberPipeline Step 14 — radius sensitivity\n")
        f.write("==========================================\n\n")
        f.write(f"Frozen reference radius: {reference_radius:g} mm\n")
        f.write(
            "Candidate radii: "
            + ", ".join(f"{x:g}" for x in radii)
            + " mm\n"
        )
        f.write(
            f"Reference Step-11 axis: "
            f"{ref['step11_preferred_axis']}\n"
        )
        f.write(
            "Reference supported interval: "
            f"{ref['supported_interval_axis']} / "
            f"{ref['supported_interval_start']:.6f}–"
            f"{ref['supported_interval_stop']:.6f}\n\n"
        )
        for row in comparison.itertuples():
            f.write(
                f"{row.radius_mm:g} mm: "
                f"same Step-11 axis={row.same_step11_axis_as_reference}; "
                f"same supported axis={row.same_supported_axis_as_reference}; "
                f"depth Jaccard={row.depth_jaccard:.4f}; "
                f"concordant={row.conclusion_concordant}\n"
            )
        f.write("\nProduction radius selected from functional results: NO\n")
        f.write("Production radius changed: NO\n")
        f.write("Step 14 is sensitivity analysis only.\n")
        f.write("Step 14 validation: PASS\n")

    if not args.no_figures:
        make_figure(
            outdir / "radius_sensitivity_qc.png",
            metrics,
            reference_radius,
        )

    print("============================================================")
    print("HuberPipeline Step 14: Multilateration-radius sensitivity")
    print("============================================================")
    print(f"Frozen reference radius: {reference_radius:g} mm")
    print(
        "Candidate radii: "
        + ", ".join(f"{x:g}" for x in radii)
        + " mm"
    )
    print(
        f"Reference Step-11 axis: {ref['step11_preferred_axis']}"
    )
    print(
        "Reference supported interval: "
        f"{ref['supported_interval_axis']} / "
        f"{ref['supported_interval_start']:.3f}–"
        f"{ref['supported_interval_stop']:.3f}"
    )
    print()
    for row in comparison.itertuples():
        kind = "REFERENCE" if row.is_frozen_reference else "candidate"
        print(
            f"{row.radius_mm:g} mm [{kind}]: "
            f"same axis={row.same_step11_axis_as_reference}; "
            f"same supported axis={row.same_supported_axis_as_reference}; "
            f"depth Jaccard={row.depth_jaccard:.3f}; "
            f"concordant={row.conclusion_concordant}"
        )
    print()
    print(
        f"Non-reference concordance: {100.0 * fraction:.1f}%"
    )
    print("Production radius selected from functional results: NO")
    print("Production radius changed: NO")
    print(f"Output directory: {outdir}")
    print("Step 14 validation: PASS")


if __name__ == "__main__":
    try:
        main()
    except (
        FileNotFoundError,
        KeyError,
        RuntimeError,
        TypeError,
        ValueError,
    ) as exc:
        sys.exit(f"ERROR: {exc}")

