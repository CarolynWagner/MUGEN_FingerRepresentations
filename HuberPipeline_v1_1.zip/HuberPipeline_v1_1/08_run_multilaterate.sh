#!/usr/bin/env bash
set -euo pipefail

# =============================================================================
# HuberPipeline Step 08 — LN2_MULTILATERATE + intrinsic-coordinate QC
# =============================================================================
#
# Preferred use:
#   bash 08_run_multilaterate.sh 00_config.yaml ses-18
#   bash 08_run_multilaterate.sh 00_config.yaml ses-18 --qc-only
#
# Optional overrides:
#   RADIUS_MM=40 bash 08_run_multilaterate.sh 00_config.yaml ses-18
#   CONTROL_POINTS=/path/to/caseII.nii.gz bash 08_run_multilaterate.sh ...
#
# Step 08 consumes the complete CASE-II control image produced by Step 07:
#   0 = background
#   1 = ordinary middle-GM sheet
#   2 = origin
#   3 = min U
#   4 = max U
#   5 = min V
#   6 = max V
#
# The frozen primary radius is 30 mm. The output basename deliberately retains
# the historical suffix "_corrected" because Steps 09, 14, and 15 already use
# that filename contract. No landmark correction is performed in Step 08.
# =============================================================================

CONFIG="${1:-00_config.yaml}"
SESSION="${2:-ses-18}"
MODE="${3:-}"
QC_ONLY=0
if [[ "${MODE}" == "--qc-only" ]]; then
    QC_ONLY=1
elif [[ -n "${MODE}" ]]; then
    echo "ERROR: unknown third argument: ${MODE}" >&2
    echo "Usage: $0 [CONFIG] [SESSION] [--qc-only]" >&2
    exit 1
fi

[[ -f "${CONFIG}" ]] || {
    echo "ERROR: configuration file not found: ${CONFIG}" >&2
    exit 1
}

# -----------------------------------------------------------------------------
# Resolve environment and production paths from the frozen YAML.
# -----------------------------------------------------------------------------

PYTHON_DEFAULT="/home/carolyn.wagner/envs/layerfmri/bin/python"
PYTHON="${PYTHON:-${PYTHON_DEFAULT}}"

[[ -x "${PYTHON}" ]] || {
    echo "ERROR: Python executable not found: ${PYTHON}" >&2
    exit 1
}

RESOLVED="$(${PYTHON} - "${CONFIG}" "${SESSION}" <<'PY'
import os
import sys
from pathlib import Path
import yaml

cfg_path = Path(sys.argv[1])
session = sys.argv[2]
with cfg_path.open('r', encoding='utf-8') as f:
    cfg = yaml.safe_load(f)

subject = str(cfg.get('subject') or cfg.get('dataset', {}).get('subject'))
if not subject:
    raise SystemExit('ERROR: could not resolve subject from YAML.')

out_dir = cfg.get('out_dir')
if out_dir:
    subject_root = Path(str(out_dir).format(subject=subject))
else:
    pipeline_root = Path(str(cfg['paths']['pipeline_root']))
    subject_root = pipeline_root / 'outputs' / subject

base = subject_root / session
laynii_dir = Path(str(cfg.get('software', {}).get('laynii_dir', '/home/carolyn.wagner/software/laynii')))
radius = float(cfg.get('frozen', {}).get('multilateration_radius_mm', 30))
fig_bg = (cfg.get('sessions', {}).get(session, {}) or {}).get('figure_anatomical')
if not fig_bg:
    fig_bg = (cfg.get('paths', {}) or {}).get('figure_anatomical', '')

print(f'BASE={base}')
print(f'LAYNII_DIR={laynii_dir}')
print(f'RADIUS={radius:g}')
print(f'FIG_BG={fig_bg or ""}')
PY
)"

eval "${RESOLVED}"

LAYNII="${LAYNII:-${LAYNII_DIR}}"
RADIUS_MM="${RADIUS_MM:-${RADIUS}}"
LAYERS_DIR="${BASE}/layers"
UV_DIR="${BASE}/true_uv"
QC_DIR="${UV_DIR}/qc"

RIM="${RIM:-${LAYERS_DIR}/rim.nii.gz}"
MIDGM="${MIDGM:-${LAYERS_DIR}/depth3_midGM_equidist.nii}"
CONTROL_POINTS="${CONTROL_POINTS:-${UV_DIR}/uv_control_points_caseII.nii.gz}"
ANATOMICAL_BACKGROUND="${ANATOMICAL_BACKGROUND:-${FIG_BG}}"

SESSION_COMPACT="${SESSION//-/}"
RADIUS_TAG="radius${RADIUS_MM}"
OUTPUT_BASE="${OUTPUT_BASE:-${UV_DIR}/${SESSION_COMPACT}_multilaterate_${RADIUS_TAG}_corrected}"

UV_COORD="${OUTPUT_BASE}_UV_coordinates.nii"
DOMAIN="${OUTPUT_BASE}_perimeter_chunk.nii"
UV_AXES="${OUTPUT_BASE}_UV_axes.nii"
UV_NORM_L2="${OUTPUT_BASE}_UV_norm_L2.nii"

mkdir -p "${UV_DIR}" "${QC_DIR}"

LN2_MULTILATERATE="${LAYNII}/LN2_MULTILATERATE"
[[ -x "${LN2_MULTILATERATE}" ]] || {
    if command -v LN2_MULTILATERATE >/dev/null 2>&1; then
        LN2_MULTILATERATE="$(command -v LN2_MULTILATERATE)"
    else
        echo "ERROR: LN2_MULTILATERATE not found." >&2
        echo "Tried: ${LAYNII}/LN2_MULTILATERATE" >&2
        exit 1
    fi
}

for file in "${RIM}" "${MIDGM}" "${CONTROL_POINTS}"; do
    [[ -f "${file}" ]] || {
        echo "ERROR: required Step-08 input not found: ${file}" >&2
        exit 1
    }
done

# -----------------------------------------------------------------------------
# Preflight validation of Step-07 CASE-II input.
# -----------------------------------------------------------------------------

echo "============================================================"
echo "HuberPipeline Step 08: LN2_MULTILATERATE"
echo "============================================================"
echo "Session:        ${SESSION}"
echo "Rim:            ${RIM}"
echo "Middle-GM:      ${MIDGM}"
echo "Control points: ${CONTROL_POINTS}"
echo "Radius:         ${RADIUS_MM} mm"
echo "Output base:    ${OUTPUT_BASE}"
echo "LayNii:         ${LN2_MULTILATERATE}"
echo "Functional masks used: NO"
if [[ "${QC_ONLY}" -eq 1 ]]; then
    echo "Mode:           QC ONLY"
else
    echo "Mode:           RUN + QC"
fi
echo

PRECHECK_JSON="${QC_DIR}/${SESSION_COMPACT}_multilaterate_${RADIUS_TAG}_preflight.json"

env -u PYTHONPATH -u PYTHONHOME "${PYTHON}" - \
    "${RIM}" "${MIDGM}" "${CONTROL_POINTS}" "${RADIUS_MM}" "${PRECHECK_JSON}" <<'PY'
import json
import sys
from pathlib import Path
import nibabel as nib
import numpy as np

rim_path = Path(sys.argv[1])
midgm_path = Path(sys.argv[2])
cp_path = Path(sys.argv[3])
radius = float(sys.argv[4])
out_json = Path(sys.argv[5])

if not np.isfinite(radius) or radius <= 0:
    raise SystemExit('ERROR: radius must be finite and > 0.')

rim_img = nib.load(str(rim_path))
midgm_img = nib.load(str(midgm_path))
cp_img = nib.load(str(cp_path))

for name, img in [('middle-GM', midgm_img), ('control points', cp_img)]:
    if img.shape[:3] != rim_img.shape[:3]:
        raise SystemExit(
            f'ERROR: shape mismatch: rim={rim_img.shape[:3]}, '
            f'{name}={img.shape[:3]}'
        )
    if not np.allclose(rim_img.affine, img.affine, atol=1e-4, rtol=0.0):
        raise SystemExit(f'ERROR: affine mismatch between rim and {name}.')

rim = np.rint(rim_img.get_fdata(dtype=np.float32)).astype(np.int16)
midgm = midgm_img.get_fdata(dtype=np.float32) > 0
cp_raw = cp_img.get_fdata(dtype=np.float32)
if not np.all(np.isfinite(cp_raw)):
    raise SystemExit('ERROR: CASE-II image contains non-finite values.')
cp = np.rint(cp_raw).astype(np.int16)

allowed = {0, 1, 2, 3, 4, 5, 6}
unexpected = sorted(set(np.unique(cp).astype(int).tolist()) - allowed)
if unexpected:
    raise SystemExit(f'ERROR: unexpected CASE-II labels: {unexpected}')

midgm_n = int(midgm.sum())
caseii_n = int(np.count_nonzero(cp))
ordinary = int(np.count_nonzero(cp == 1))
missing = int(np.count_nonzero(midgm & (cp == 0)))
outside = int(np.count_nonzero((cp > 0) & ~midgm))

if caseii_n != midgm_n:
    raise SystemExit(
        f'ERROR: CASE-II nonzero voxels ({caseii_n}) != middle-GM '
        f'voxels ({midgm_n}).'
    )
if ordinary != midgm_n - 5:
    raise SystemExit(
        f'ERROR: expected {midgm_n - 5} ordinary value-1 voxels; '
        f'found {ordinary}.'
    )
if missing != 0 or outside != 0:
    raise SystemExit(
        f'ERROR: CASE-II sheet mismatch: missing={missing}, outside={outside}.'
    )

landmarks = {}
print('CASE-II landmark validation:')
for label, name in [(2,'origin'), (3,'min_u'), (4,'max_u'), (5,'min_v'), (6,'max_v')]:
    loc = np.argwhere(cp == label)
    if loc.shape[0] != 1:
        raise SystemExit(
            f'ERROR: label {label} ({name}) must occur exactly once; '
            f'found {loc.shape[0]}.'
        )
    voxel = tuple(int(v) for v in loc[0])
    rv = int(rim[voxel])
    if rv not in (1,2,3):
        raise SystemExit(
            f'ERROR: label {label} ({name}) lies outside cortical rim.'
        )
    world = nib.affines.apply_affine(cp_img.affine, np.asarray(voxel, float))
    landmarks[str(label)] = {
        'name': name,
        'voxel': list(voxel),
        'world_mm': [float(x) for x in world],
        'rim_value': rv,
    }
    print(
        f'  {label} {name:6s}: voxel={voxel}, '
        f'world=({world[0]:.3f}, {world[1]:.3f}, {world[2]:.3f}), '
        f'rim={rv}'
    )

summary = {
    'status': 'PASS',
    'radius_mm': radius,
    'middle_gm_voxels': midgm_n,
    'caseII_nonzero_voxels': caseii_n,
    'ordinary_value1_voxels': ordinary,
    'missing_middle_gm': missing,
    'outside_middle_gm': outside,
    'functional_masks_used': False,
    'landmarks': landmarks,
}
out_json.parent.mkdir(parents=True, exist_ok=True)
out_json.write_text(json.dumps(summary, indent=2), encoding='utf-8')
print('Step-08 input preflight: PASS')
PY

# -----------------------------------------------------------------------------
# Run LN2_MULTILATERATE, or validate the existing products only.
# -----------------------------------------------------------------------------

if [[ "${QC_ONLY}" -eq 0 ]]; then
    # Remove only products belonging to this exact output basename.
    rm -f "${OUTPUT_BASE}"*.nii "${OUTPUT_BASE}"*.nii.gz

    echo
    echo "Running LN2_MULTILATERATE..."

    "${LN2_MULTILATERATE}" \
        -rim "${RIM}" \
        -control_points "${CONTROL_POINTS}" \
        -radius "${RADIUS_MM}" \
        -incl_borders \
        -norms \
        -angles \
        -debug \
        -output "${OUTPUT_BASE}"
else
    echo
    echo "QC-only mode: preserving and validating existing LN2_MULTILATERATE outputs."
fi

# -----------------------------------------------------------------------------
# Required outputs.
# -----------------------------------------------------------------------------

for file in "${UV_COORD}" "${DOMAIN}" "${UV_AXES}" "${UV_NORM_L2}"; do
    [[ -f "${file}" ]] || {
        echo "ERROR: required LN2_MULTILATERATE output not found:" >&2
        echo "  ${file}" >&2
        exit 1
    }
done

mapfile -t GENERATED_FILES < <(
    find "${UV_DIR}" -maxdepth 1 -type f \
        \( -name "$(basename "${OUTPUT_BASE}")*.nii" \
           -o -name "$(basename "${OUTPUT_BASE}")*.nii.gz" \) \
        | sort
)

echo
echo "Generated outputs:"
printf '  %s\n' "${GENERATED_FILES[@]}"

# -----------------------------------------------------------------------------
# Post-run coordinate validation and QC figure.
# -----------------------------------------------------------------------------

QC_CSV="${QC_DIR}/${SESSION_COMPACT}_multilaterate_${RADIUS_TAG}_coordinate_qc.csv"
ENDPOINT_CSV="${QC_DIR}/${SESSION_COMPACT}_multilaterate_${RADIUS_TAG}_endpoint_qc.csv"
SUMMARY_JSON="${QC_DIR}/${SESSION_COMPACT}_multilaterate_${RADIUS_TAG}_summary.json"
SUMMARY_TXT="${QC_DIR}/${SESSION_COMPACT}_multilaterate_${RADIUS_TAG}_summary.txt"
QC_PNG="${QC_DIR}/${SESSION_COMPACT}_multilaterate_${RADIUS_TAG}_coordinate_qc.png"

env -u PYTHONPATH -u PYTHONHOME MPLBACKEND=Agg "${PYTHON}" - \
    "${RIM}" "${MIDGM}" "${CONTROL_POINTS}" "${UV_COORD}" "${DOMAIN}" \
    "${QC_CSV}" "${ENDPOINT_CSV}" "${SUMMARY_JSON}" "${SUMMARY_TXT}" \
    "${QC_PNG}" "${ANATOMICAL_BACKGROUND}" "${RADIUS_MM}" <<'PY'
import csv
import json
import sys
from pathlib import Path

import matplotlib
matplotlib.use('Agg', force=True)
import matplotlib.pyplot as plt
import nibabel as nib
import numpy as np
from scipy import ndimage

(
    rim_path, midgm_path, cp_path, uv_path, domain_path,
    qc_csv, endpoint_csv, summary_json, summary_txt,
    qc_png, background_path, radius_text,
) = sys.argv[1:]

radius = float(radius_text)
rim_img = nib.load(rim_path)
midgm_img = nib.load(midgm_path)
cp_img = nib.load(cp_path)
uv_img = nib.load(uv_path)
domain_img = nib.load(domain_path)

if len(uv_img.shape) != 4 or uv_img.shape[3] != 2:
    raise SystemExit(
        f'ERROR: UV coordinate image must be 4D with 2 volumes; '
        f'found {uv_img.shape}.'
    )

for name, img in [('midGM',midgm_img), ('control',cp_img), ('UV',uv_img), ('domain',domain_img)]:
    if img.shape[:3] != rim_img.shape[:3]:
        raise SystemExit(
            f'ERROR: {name} grid shape {img.shape[:3]} does not match '
            f'rim {rim_img.shape[:3]}.'
        )
    if not np.allclose(rim_img.affine, img.affine, atol=1e-4, rtol=0.0):
        raise SystemExit(f'ERROR: {name} affine does not match rim.')

rim = np.rint(rim_img.get_fdata(dtype=np.float32)).astype(np.int16)
midgm = midgm_img.get_fdata(dtype=np.float32) > 0
cp = np.rint(cp_img.get_fdata(dtype=np.float32)).astype(np.int16)
uv = uv_img.get_fdata(dtype=np.float32)
domain_raw = domain_img.get_fdata(dtype=np.float32)
domain = np.isfinite(domain_raw) & (domain_raw > 0)

if int(domain.sum()) < 20:
    raise SystemExit(f'ERROR: only {int(domain.sum())} domain voxels.')

finite_uv = np.isfinite(uv[...,0]) & np.isfinite(uv[...,1])
valid = domain & finite_uv
if not np.array_equal(valid, domain):
    raise SystemExit(
        f'ERROR: {int(np.count_nonzero(domain & ~finite_uv))} domain voxels '
        'have non-finite U/V coordinates.'
    )

# Domain must remain within cortical rim and away from image boundaries.
outside_rim = int(np.count_nonzero(domain & (rim == 0)))
if outside_rim:
    raise SystemExit(
        f'ERROR: {outside_rim} perimeter-domain voxels lie outside rim.'
    )

touches_boundary = bool(
    domain[0,:,:].any() or domain[-1,:,:].any()
    or domain[:,0,:].any() or domain[:,-1,:].any()
    or domain[:,:,0].any() or domain[:,:,-1].any()
)
if touches_boundary:
    raise SystemExit('ERROR: perimeter domain touches image boundary.')

structure = np.ones((3,3,3), dtype=np.uint8)
cc, n_components = ndimage.label(domain, structure=structure)
sizes = np.bincount(cc.ravel())[1:] if n_components else np.array([], dtype=int)
largest_component_fraction = (
    float(sizes.max() / sizes.sum()) if sizes.size else np.nan
)

u = uv[...,0]
v = uv[...,1]
u_vals = u[domain].astype(np.float64)
v_vals = v[domain].astype(np.float64)
u_min, u_max = float(u_vals.min()), float(u_vals.max())
v_min, v_max = float(v_vals.min()), float(v_vals.max())
u_span = u_max - u_min
v_span = v_max - v_min
if u_span <= 0 or v_span <= 0:
    raise SystemExit(
        f'ERROR: degenerate coordinate span: U={u_span}, V={v_span}.'
    )

# Endpoint checks are deliberately sign-invariant.
#
# LN2_MULTILATERATE may assign either sign to an intrinsic coordinate axis.
# Labels 3/4 define opposite U extrema and labels 5/6 opposite V extrema;
# their numerical ordering is therefore diagnostic, not a hard requirement.
# The hard requirement is non-collapse of each intended endpoint pair.
endpoint_rows = []
endpoint_values = {}
for label, name in [(2,'origin'), (3,'min_u'), (4,'max_u'), (5,'min_v'), (6,'max_v')]:
    loc = np.argwhere(cp == label)
    voxel = tuple(int(x) for x in loc[0])
    uu = float(u[voxel])
    vv = float(v[voxel])
    endpoint_values[label] = (uu, vv)
    world = nib.affines.apply_affine(cp_img.affine, np.asarray(voxel, float))
    endpoint_rows.append({
        'label': label,
        'name': name,
        'voxel_i': voxel[0], 'voxel_j': voxel[1], 'voxel_k': voxel[2],
        'world_x_mm': float(world[0]),
        'world_y_mm': float(world[1]),
        'world_z_mm': float(world[2]),
        'U': uu, 'V': vv,
    })

u_delta = float(endpoint_values[4][0] - endpoint_values[3][0])
u_cross_delta = float(endpoint_values[4][1] - endpoint_values[3][1])
v_delta = float(endpoint_values[6][1] - endpoint_values[5][1])
v_cross_delta = float(endpoint_values[6][0] - endpoint_values[5][0])

u_endpoint_separation = abs(u_delta)
v_endpoint_separation = abs(v_delta)
u_pair_total_separation = float(np.hypot(u_delta, u_cross_delta))
v_pair_total_separation = float(np.hypot(v_cross_delta, v_delta))

# Numerical non-collapse threshold only; this does not impose a biological
# minimum distance.
eps = 1e-6
u_endpoint_separated = bool(u_endpoint_separation > eps)
v_endpoint_separated = bool(v_endpoint_separation > eps)

if not u_endpoint_separated:
    raise SystemExit(
        'ERROR: labels 3 and 4 collapse to the same U coordinate.'
    )
if not v_endpoint_separated:
    raise SystemExit(
        'ERROR: labels 5 and 6 collapse to the same V coordinate.'
    )

u_direction = (
    '3_to_4_increasing' if u_delta > 0 else '4_to_3_increasing'
)
v_direction = (
    '5_to_6_increasing' if v_delta > 0 else '6_to_5_increasing'
)

# Axis specificity is a diagnostic rather than a hard failure because curved
# intrinsic sheets need not make the orthogonal coordinate difference vanish.
u_axis_specificity = (
    u_endpoint_separation / u_pair_total_separation
    if u_pair_total_separation > eps else np.nan
)
v_axis_specificity = (
    v_endpoint_separation / v_pair_total_separation
    if v_pair_total_separation > eps else np.nan
)
u_specificity_warning = bool(
    np.isfinite(u_axis_specificity) and u_axis_specificity < 0.5
)
v_specificity_warning = bool(
    np.isfinite(v_axis_specificity) and v_axis_specificity < 0.5
)

# Complementarity diagnostic.
if u_vals.size > 1:
    uv_corr = float(np.corrcoef(u_vals, v_vals)[0,1])
else:
    uv_corr = np.nan

# Neighbour-difference diagnostics over 6-connected domain edges.
def neighbour_diffs(values, mask):
    diffs = []
    for axis in range(3):
        sl1 = [slice(None)] * 3
        sl2 = [slice(None)] * 3
        sl1[axis] = slice(0, -1)
        sl2[axis] = slice(1, None)
        m = mask[tuple(sl1)] & mask[tuple(sl2)]
        if np.any(m):
            d = np.abs(values[tuple(sl2)] - values[tuple(sl1)])[m]
            d = d[np.isfinite(d)]
            if d.size:
                diffs.append(d.astype(np.float64))
    return np.concatenate(diffs) if diffs else np.array([], dtype=np.float64)

u_diff = neighbour_diffs(u, domain)
v_diff = neighbour_diffs(v, domain)

def diff_metrics(x):
    if x.size == 0:
        return dict(n=0, median=np.nan, p95=np.nan, p99=np.nan, maximum=np.nan)
    return dict(
        n=int(x.size),
        median=float(np.percentile(x,50)),
        p95=float(np.percentile(x,95)),
        p99=float(np.percentile(x,99)),
        maximum=float(np.max(x)),
    )

u_dm = diff_metrics(u_diff)
v_dm = diff_metrics(v_diff)

# Conservative diagnostics only; these are not scientific failure criteria.
def jump_warning(dm):
    if not np.isfinite(dm['p99']):
        return True
    baseline = max(dm['median'], 1e-6)
    return bool(dm['p99'] > max(10.0, 12.0 * baseline))

u_jump_warning = jump_warning(u_dm)
v_jump_warning = jump_warning(v_dm)
complementarity_warning = bool(np.isfinite(uv_corr) and abs(uv_corr) > 0.95)
component_warning = bool(
    np.isfinite(largest_component_fraction)
    and largest_component_fraction < 0.95
)

rows = [
    ('domain_voxels', int(domain.sum()), 'HARD', True),
    ('finite_uv_domain_voxels', int(valid.sum()), 'HARD', True),
    ('domain_outside_rim_voxels', outside_rim, 'HARD', outside_rim == 0),
    ('domain_touches_image_boundary', touches_boundary, 'HARD', not touches_boundary),
    ('domain_components_26conn', int(n_components), 'DIAGNOSTIC', not component_warning),
    ('largest_component_fraction', largest_component_fraction, 'DIAGNOSTIC', not component_warning),
    ('u_min_mm', u_min, 'DESCRIPTIVE', True),
    ('u_max_mm', u_max, 'DESCRIPTIVE', True),
    ('u_span_mm', u_span, 'HARD', u_span > 0),
    ('v_min_mm', v_min, 'DESCRIPTIVE', True),
    ('v_max_mm', v_max, 'DESCRIPTIVE', True),
    ('v_span_mm', v_span, 'HARD', v_span > 0),
    ('u_endpoint_separation_mm', u_endpoint_separation, 'HARD', u_endpoint_separated),
    ('v_endpoint_separation_mm', v_endpoint_separation, 'HARD', v_endpoint_separated),
    ('u_endpoint_direction', u_direction, 'DESCRIPTIVE', True),
    ('v_endpoint_direction', v_direction, 'DESCRIPTIVE', True),
    ('u_axis_specificity', u_axis_specificity, 'DIAGNOSTIC', not u_specificity_warning),
    ('v_axis_specificity', v_axis_specificity, 'DIAGNOSTIC', not v_specificity_warning),
    ('uv_pearson_correlation', uv_corr, 'DIAGNOSTIC', not complementarity_warning),
    ('u_neighbor_diff_median', u_dm['median'], 'DESCRIPTIVE', True),
    ('u_neighbor_diff_p95', u_dm['p95'], 'DESCRIPTIVE', True),
    ('u_neighbor_diff_p99', u_dm['p99'], 'DIAGNOSTIC', not u_jump_warning),
    ('u_neighbor_diff_max', u_dm['maximum'], 'DESCRIPTIVE', True),
    ('v_neighbor_diff_median', v_dm['median'], 'DESCRIPTIVE', True),
    ('v_neighbor_diff_p95', v_dm['p95'], 'DESCRIPTIVE', True),
    ('v_neighbor_diff_p99', v_dm['p99'], 'DIAGNOSTIC', not v_jump_warning),
    ('v_neighbor_diff_max', v_dm['maximum'], 'DESCRIPTIVE', True),
]

Path(qc_csv).parent.mkdir(parents=True, exist_ok=True)
with open(qc_csv, 'w', newline='', encoding='utf-8') as f:
    w = csv.writer(f)
    w.writerow(['metric','value','level','pass'])
    w.writerows(rows)

with open(endpoint_csv, 'w', newline='', encoding='utf-8') as f:
    w = csv.DictWriter(f, fieldnames=list(endpoint_rows[0].keys()))
    w.writeheader(); w.writerows(endpoint_rows)

warnings = []
if component_warning:
    warnings.append('perimeter_domain_fragmentation')
if complementarity_warning:
    warnings.append('u_v_high_linear_correlation')
if u_jump_warning:
    warnings.append('u_large_neighbor_jump')
if v_jump_warning:
    warnings.append('v_large_neighbor_jump')
if u_specificity_warning:
    warnings.append('u_endpoint_pair_not_u_dominant')
if v_specificity_warning:
    warnings.append('v_endpoint_pair_not_v_dominant')

summary = {
    'status': 'PASS',
    'radius_mm': radius,
    'uv_coordinates': uv_path,
    'perimeter_domain': domain_path,
    'domain_voxels': int(domain.sum()),
    'domain_components_26conn': int(n_components),
    'largest_component_fraction': largest_component_fraction,
    'domain_touches_image_boundary': touches_boundary,
    'u_range_mm': [u_min, u_max],
    'u_span_mm': u_span,
    'v_range_mm': [v_min, v_max],
    'v_span_mm': v_span,
    'u_endpoint_separation_mm': u_endpoint_separation,
    'v_endpoint_separation_mm': v_endpoint_separation,
    'u_endpoint_direction': u_direction,
    'v_endpoint_direction': v_direction,
    'u_axis_specificity': u_axis_specificity,
    'v_axis_specificity': v_axis_specificity,
    'uv_pearson_correlation': uv_corr,
    'u_neighbor_differences': u_dm,
    'v_neighbor_differences': v_dm,
    'diagnostic_warnings': warnings,
    'functional_masks_used': False,
    'landmark_geometry_changed': False,
}
Path(summary_json).write_text(json.dumps(summary, indent=2), encoding='utf-8')

with open(summary_txt, 'w', encoding='utf-8') as f:
    f.write('Step 08 LN2_MULTILATERATE coordinate validation\n')
    f.write('==============================================\n\n')
    f.write(f'Radius: {radius:g} mm\n')
    f.write(f'Domain voxels: {int(domain.sum())}\n')
    f.write(f'Domain components (26-connectivity): {int(n_components)}\n')
    f.write(f'Largest-component fraction: {largest_component_fraction:.6f}\n')
    f.write(f'Domain touches image boundary: {touches_boundary}\n')
    f.write(f'U range: {u_min:.6f} to {u_max:.6f} mm (span {u_span:.6f})\n')
    f.write(f'V range: {v_min:.6f} to {v_max:.6f} mm (span {v_span:.6f})\n')
    f.write(f'U endpoint separation: {u_endpoint_separation:.6f} mm\n')
    f.write(f'V endpoint separation: {v_endpoint_separation:.6f} mm\n')
    f.write(f'U numerical direction: {u_direction}\n')
    f.write(f'V numerical direction: {v_direction}\n')
    f.write(f'U axis specificity: {u_axis_specificity:.6f}\n')
    f.write(f'V axis specificity: {v_axis_specificity:.6f}\n')
    f.write(f'U/V Pearson correlation: {uv_corr:.6f}\n')
    f.write(f'U neighbour p99: {u_dm["p99"]:.6f}\n')
    f.write(f'V neighbour p99: {v_dm["p99"]:.6f}\n')
    f.write(f'Diagnostic warnings: {warnings}\n')
    f.write('Functional masks used: NO\n')
    f.write('Landmark geometry changed: NO\n')
    f.write('Hard validation: PASS\n')

# ------------------------------------------------------------------
# QC figure: cropped maximum/mean projections + U/V scatter.
# ------------------------------------------------------------------
background = None
if background_path and Path(background_path).is_file():
    try:
        bg_img = nib.load(background_path)
        if (
            bg_img.shape[:3] == rim_img.shape[:3]
            and np.allclose(bg_img.affine, rim_img.affine, atol=1e-4, rtol=0.0)
        ):
            background = bg_img.get_fdata(dtype=np.float32)
    except Exception:
        background = None

coords = np.column_stack(np.nonzero(domain))
mins = np.maximum(coords.min(axis=0) - 6, 0)
maxs = np.minimum(coords.max(axis=0) + 6, np.array(domain.shape)-1)

fig = plt.figure(figsize=(14.0, 8.0))
gs = fig.add_gridspec(2, 3, hspace=0.28, wspace=0.22)

# Use a representative axial slice through the domain centre for U and V.
k = int(np.median(coords[:,2]))
for col, (arr, title) in enumerate([(u,'U coordinate (mm)'), (v,'V coordinate (mm)')]):
    ax = fig.add_subplot(gs[0,col])
    if background is not None:
        bg = background[:,:,k]
        vals = bg[np.isfinite(bg)]
        if vals.size:
            lo, hi = np.percentile(vals, [2,98])
            ax.imshow(np.rot90(bg), cmap='gray', vmin=lo, vmax=hi)
    sl = np.where(domain[:,:,k], arr[:,:,k], np.nan)
    im = ax.imshow(np.rot90(sl), interpolation='nearest')
    ax.set_title(title)
    ax.set_xticks([]); ax.set_yticks([])
    fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04)

ax = fig.add_subplot(gs[0,2])
ax.scatter(u_vals, v_vals, s=4, alpha=0.35)
for row in endpoint_rows:
    ax.scatter(row['U'], row['V'], s=55, edgecolors='black', linewidths=0.6)
    ax.text(row['U'], row['V'], str(row['label']), fontsize=9, fontweight='bold')
ax.axhline(0, color='0.7', linewidth=0.7)
ax.axvline(0, color='0.7', linewidth=0.7)
ax.set_xlabel('U (mm)'); ax.set_ylabel('V (mm)')
ax.set_title(f'U–V coordinate plane | r={uv_corr:.3f}')

# Orthogonal domain projections.
for col, axis in enumerate((0,1,2)):
    ax = fig.add_subplot(gs[1,col])
    proj = np.rot90(np.any(domain, axis=axis))
    ax.imshow(proj, cmap='gray', interpolation='nearest')
    ax.set_title(['Sagittal domain','Coronal domain','Axial domain'][col])
    ax.set_xticks([]); ax.set_yticks([])

fig.suptitle(
    f'Step 08 LN2_MULTILATERATE QC | radius={radius:g} mm | '
    f'U span={u_span:.2f} mm | V span={v_span:.2f} mm',
    fontsize=13,
)
fig.savefig(qc_png, dpi=220, bbox_inches='tight')
plt.close(fig)

print('')
print('Post-run coordinate validation:')
print(f'  Domain voxels:              {int(domain.sum())}')
print(f'  Domain components:          {int(n_components)}')
print(f'  Largest component:          {largest_component_fraction:.2%}')
print(f'  Touches image boundary:     {touches_boundary}')
print(f'  U range/span:               {u_min:.3f} .. {u_max:.3f} / {u_span:.3f} mm')
print(f'  V range/span:               {v_min:.3f} .. {v_max:.3f} / {v_span:.3f} mm')
print(f'  U endpoint separation:      {u_endpoint_separation:.4f} mm')
print(f'  V endpoint separation:      {v_endpoint_separation:.4f} mm')
print(f'  U numerical direction:      {u_direction}')
print(f'  V numerical direction:      {v_direction}')
print(f'  U axis specificity:         {u_axis_specificity:.4f}')
print(f'  V axis specificity:         {v_axis_specificity:.4f}')
print(f'  U/V Pearson correlation:    {uv_corr:.4f}')
print(f'  U neighbour p99:            {u_dm["p99"]:.4f}')
print(f'  V neighbour p99:            {v_dm["p99"]:.4f}')
print(f'  Diagnostic warnings:        {warnings if warnings else "NONE"}')
print('  Hard validation:            PASS')
PY

# -----------------------------------------------------------------------------
# Human-readable output summary.
# -----------------------------------------------------------------------------

echo
echo "============================================================"
echo "Step 08 completed"
echo "============================================================"
echo "UV coordinates: ${UV_COORD}"
echo "Perimeter domain: ${DOMAIN}"
echo "QC table:        ${QC_CSV}"
echo "Endpoint QC:     ${ENDPOINT_CSV}"
echo "QC figure:       ${QC_PNG}"
echo "Summary:         ${SUMMARY_TXT}"
echo
echo "Before Step 09, inspect the QC figure and confirm:"
echo "  - U varies smoothly between labels 3 and 4 (sign may be reversed)."
echo "  - V varies smoothly between labels 5 and 6 (sign may be reversed)."
echo "  - no obvious coordinate discontinuity crosses the M1 patch."
echo "  - U and V encode complementary anatomical directions."
echo "  - the perimeter domain covers the intended M1 patch only."

