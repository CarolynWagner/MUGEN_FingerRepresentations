#!/usr/bin/env python3

import sys
from pathlib import Path

import nibabel as nib
import numpy as np
import yaml


AFFINE_ATOL = 1e-4


def load_yaml(path):
    with open(path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)


def find_existing_nifti(path_or_stem):
    path = Path(path_or_stem)

    if path.exists():
        return path

    text = str(path)

    if text.endswith(".nii"):
        candidate = Path(text + ".gz")
        if candidate.exists():
            return candidate

    elif not text.endswith(".nii.gz"):
        candidate_nii = Path(text + ".nii")
        candidate_nii_gz = Path(text + ".nii.gz")

        if candidate_nii.exists():
            return candidate_nii

        if candidate_nii_gz.exists():
            return candidate_nii_gz

    raise FileNotFoundError(f"NIfTI file not found: {path_or_stem}")


def check_same_grid(reference_img, moving_img, reference_name, moving_name):
    if reference_img.shape[:3] != moving_img.shape[:3]:
        raise RuntimeError(
            "Shape mismatch:\n"
            f"  {reference_name}: {reference_img.shape[:3]}\n"
            f"  {moving_name}: {moving_img.shape[:3]}"
        )

    if not np.allclose(
        reference_img.affine,
        moving_img.affine,
        atol=AFFINE_ATOL,
        rtol=0.0,
    ):
        raise RuntimeError(
            "Affine mismatch:\n"
            f"  {reference_name}\n"
            f"  {moving_name}\n"
            "The images are not in the same voxel grid."
        )


def save_nifti(data, reference_img, out_path, dtype):
    """Save values exactly while preserving the reference geometry."""
    data = np.asarray(data, dtype=dtype)

    header = nib.Nifti1Header()
    header.set_data_dtype(dtype)
    header.set_data_shape(data.shape)

    zooms = reference_img.header.get_zooms()
    if len(zooms) >= data.ndim:
        header.set_zooms(zooms[:data.ndim])

    spatial_unit, temporal_unit = reference_img.header.get_xyzt_units()
    header.set_xyzt_units(spatial_unit, temporal_unit)
    header.set_slope_inter(1.0, 0.0)

    output_img = nib.Nifti1Image(
        data,
        reference_img.affine.copy(),
        header,
    )

    qform, qform_code = reference_img.get_qform(coded=True)
    sform, sform_code = reference_img.get_sform(coded=True)

    if qform is not None:
        output_img.set_qform(qform, int(qform_code))
    if sform is not None:
        output_img.set_sform(sform, int(sform_code))

    output_img.header.set_slope_inter(1.0, 0.0)
    nib.save(output_img, str(out_path))

    reloaded = nib.load(str(out_path))
    check_same_grid(
        reference_img,
        reloaded,
        "reference PSC",
        f"saved output {out_path.name}",
    )

    reloaded_data = reloaded.get_fdata(dtype=np.float32)
    input_data = np.asarray(data, dtype=np.float32)
    finite = np.isfinite(input_data) & np.isfinite(reloaded_data)

    if np.any(finite):
        difference = float(
            np.max(
                np.abs(
                    input_data[finite].astype(np.float64)
                    - reloaded_data[finite].astype(np.float64)
                )
            )
        )
        if difference > 1e-6:
            raise RuntimeError(
                f"Saved values changed after reopening {out_path.name}: "
                f"maximum absolute difference={difference:.12g}"
            )

    if not np.array_equal(np.isnan(input_data), np.isnan(reloaded_data)):
        raise RuntimeError(
            f"NaN pattern changed after saving {out_path.name}."
        )


def print_distribution(label, values):
    """Print robust distributional QC for a one-dimensional finite array."""
    values = np.asarray(values, dtype=np.float64)
    values = values[np.isfinite(values)]

    print(f"\n  {label}")

    if values.size == 0:
        print("    No finite voxels.")
        return

    percentiles = np.percentile(
        values,
        [1, 5, 25, 50, 75, 90, 95, 99],
    )

    print(f"    n       = {values.size}")
    print(f"    min     = {values.min():.8f}")
    print(f"    P01     = {percentiles[0]:.8f}")
    print(f"    P05     = {percentiles[1]:.8f}")
    print(f"    P25     = {percentiles[2]:.8f}")
    print(f"    median  = {percentiles[3]:.8f}")
    print(f"    mean    = {values.mean():.8f}")
    print(f"    P75     = {percentiles[4]:.8f}")
    print(f"    P90     = {percentiles[5]:.8f}")
    print(f"    P95     = {percentiles[6]:.8f}")
    print(f"    P99     = {percentiles[7]:.8f}")
    print(f"    max     = {values.max():.8f}")


def print_threshold_counts(label, values, thresholds):
    """Print voxel counts and percentages above selected thresholds."""
    values = np.asarray(values, dtype=np.float64)
    values = values[np.isfinite(values)]

    print(f"\n  {label}")

    if values.size == 0:
        print("    No finite voxels.")
        return

    for threshold in thresholds:
        count = int(np.count_nonzero(values >= threshold))
        percentage = 100.0 * count / values.size
        print(
            f"    >= {threshold:>7.4f}% : "
            f"{count:>6d} / {values.size:<6d} "
            f"({percentage:6.2f}%)"
        )


def get_dominance_config(cfg):
    """
    Optional YAML section:

    dominance:
      denominator_eps: 1e-6

    denominator_eps:
        Small numerical safeguard for the original dominance ratio:

            positive finger response
            ------------------------
            sum of positive responses to the other four fingers

        No fixed PSC responsiveness threshold is applied. Voxels are
        analysed throughout the Step 3 anatomical mask, provided the
        relevant denominator is larger than this epsilon.
    """
    dominance_cfg = cfg.get("dominance", {})

    denominator_eps = float(
        dominance_cfg.get("denominator_eps", 1e-6)
    )

    if denominator_eps <= 0:
        raise ValueError(
            "dominance.denominator_eps must be > 0."
        )

    return denominator_eps


def main(cfg_path, session):
    cfg = load_yaml(cfg_path)

    subject = cfg["subject"]
    fingers = cfg["fingers"]

    if len(fingers) != 5:
        sys.exit(
            f"ERROR: Expected five fingers, but found {len(fingers)}: "
            f"{fingers}"
        )

    base_out = Path(cfg["out_dir"].format(subject=subject))
    session_out = base_out / session
    psc_dir = session_out / "psc"
    out_dir = session_out / "dominance"
    out_dir.mkdir(parents=True, exist_ok=True)

    try:
        denominator_eps = get_dominance_config(cfg)
    except ValueError as exc:
        sys.exit(f"ERROR: {exc}")

    analysis_mask_path = psc_dir / "psc_analysis_mask.nii.gz"
    if not analysis_mask_path.exists():
        sys.exit(
            "ERROR: Required Step 3 analysis mask not found:\n"
            f"  {analysis_mask_path}"
        )

    psc_paths = []
    psc_imgs = []

    print(f"[{session}] Loading Step 3 PSC maps")

    for finger in fingers:
        path = psc_dir / f"psc_{finger}.nii.gz"
        if not path.exists():
            sys.exit(
                "ERROR: Required Step 3 PSC map not found:\n"
                f"  {path}"
            )

        print(f"  {finger}: {path}")
        psc_paths.append(path)
        psc_imgs.append(nib.load(str(path)))

    reference_img = psc_imgs[0]

    for finger, img, path in zip(fingers, psc_imgs, psc_paths):
        try:
            check_same_grid(
                reference_img,
                img,
                f"PSC {fingers[0]}",
                f"PSC {finger}: {path}",
            )
        except RuntimeError as exc:
            sys.exit(f"ERROR: {exc}")

    mask_img = nib.load(analysis_mask_path)

    try:
        check_same_grid(
            reference_img,
            mask_img,
            f"PSC {fingers[0]}",
            f"Step 3 analysis mask: {analysis_mask_path}",
        )
    except RuntimeError as exc:
        sys.exit(f"ERROR: {exc}")

    analysis_mask = mask_img.get_fdata() > 0

    raw = np.stack(
        [img.get_fdata(dtype=np.float32) for img in psc_imgs],
        axis=0,
    )

    finite_all = np.all(np.isfinite(raw), axis=0)
    analysis_mask &= finite_all

    # Positive responses are used only for ratio-style dominance metrics.
    positive = np.clip(raw, 0.0, None)

    max_response = np.max(raw, axis=0)
    winner_index = np.argmax(raw, axis=0)

    # Difference between the strongest and second-strongest raw PSC.
    sorted_responses = np.sort(raw, axis=0)
    winner_margin = sorted_responses[-1] - sorted_responses[-2]

    # No fixed PSC threshold is imposed. The Step 3 anatomical mask is
    # the analysis domain; only ratio denominators receive a numerical
    # safeguard.
    responsive_mask = (
        analysis_mask
        & np.isfinite(max_response)
        & (max_response > 0.0)
    )

    total_positive = np.sum(positive, axis=0)

    # ------------------------------------------------------------------
    # PSC scale QC
    # ------------------------------------------------------------------
    print(f"\n[{session}] PSC distribution within the Step 3 analysis mask")

    for finger_index, finger in enumerate(fingers):
        print_distribution(
            f"{finger}: raw PSC",
            raw[finger_index][analysis_mask],
        )

    print_distribution(
        "Maximum PSC across the five fingers",
        max_response[analysis_mask],
    )

    print_distribution(
        "Winner margin: strongest minus second-strongest PSC",
        winner_margin[analysis_mask],
    )

    print_threshold_counts(
        "Maximum-finger PSC threshold counts (descriptive QC only)",
        max_response[analysis_mask],
        thresholds=[
            0.0,
            0.001,
            0.005,
            0.01,
            0.02,
            0.05,
            0.10,
            0.20,
            0.50,
            1.00,
        ],
    )

    # Save masks and basic response summaries first.
    save_nifti(
        analysis_mask,
        reference_img,
        out_dir / "dominance_input_mask.nii.gz",
        np.uint8,
    )

    save_nifti(
        analysis_mask,
        reference_img,
        out_dir / "dominance_analysis_mask.nii.gz",
        np.uint8,
    )

    save_nifti(
        responsive_mask,
        reference_img,
        out_dir / "dominance_responsive_mask.nii.gz",
        np.uint8,
    )

    max_response_out = np.zeros(max_response.shape, dtype=np.float32)
    max_response_out[analysis_mask] = max_response[analysis_mask]

    save_nifti(
        max_response_out,
        reference_img,
        out_dir / "maximum_finger_psc.nii.gz",
        np.float32,
    )

    winner_margin_out = np.zeros(winner_margin.shape, dtype=np.float32)
    winner_margin_out[analysis_mask] = winner_margin[analysis_mask]

    save_nifti(
        winner_margin_out,
        reference_img,
        out_dir / "winner_margin_psc.nii.gz",
        np.float32,
    )

    # Winner-take-all label map:
    # 0 = outside the Step 3 analysis mask
    # 1..5 = finger labels in cfg["fingers"] order
    argmax_map = np.zeros(max_response.shape, dtype=np.int16)
    argmax_map[responsive_mask] = (
        winner_index[responsive_mask] + 1
    ).astype(np.int16)

    save_nifti(
        argmax_map,
        reference_img,
        out_dir / "dominance_argmax.nii.gz",
        np.int16,
    )

    # Per-finger maps.
    for finger_index, finger in enumerate(fingers):
        finger_positive = positive[finger_index]
        other_positive_sum = total_positive - finger_positive

        # Original Huber-style ratio:
        # positive finger response / sum of positive responses to other fingers.
        # It is saved only where the voxel is responsive and the denominator
        # is sufficiently large.
        ratio_valid = (
            analysis_mask
            & (other_positive_sum > denominator_eps)
        )

        ratio = np.full(
            max_response.shape,
            np.nan,
            dtype=np.float32,
        )
        ratio[ratio_valid] = (
            finger_positive[ratio_valid]
            / other_positive_sum[ratio_valid]
        ).astype(np.float32)

        save_nifti(
            ratio,
            reference_img,
            out_dir / f"dominance_{finger}.nii.gz",
            np.float32,
        )

        save_nifti(
            ratio_valid,
            reference_img,
            out_dir / f"dominance_valid_{finger}.nii.gz",
            np.uint8,
        )

        # Bounded positive-response fraction:
        # positive finger response / total positive finger response.
        fraction_valid = (
            analysis_mask
            & (total_positive > denominator_eps)
        )

        fraction = np.full(
            max_response.shape,
            np.nan,
            dtype=np.float32,
        )
        fraction[fraction_valid] = (
            finger_positive[fraction_valid]
            / total_positive[fraction_valid]
        ).astype(np.float32)

        save_nifti(
            fraction,
            reference_img,
            out_dir / f"dominance_fraction_{finger}.nii.gz",
            np.float32,
        )

        # Signed selectivity:
        # finger PSC - mean PSC of the other four fingers.
        other_mean = (
            np.sum(raw, axis=0) - raw[finger_index]
        ) / (len(fingers) - 1)

        selectivity = np.zeros(max_response.shape, dtype=np.float32)
        selectivity[analysis_mask] = (
            raw[finger_index, analysis_mask]
            - other_mean[analysis_mask]
        ).astype(np.float32)

        save_nifti(
            selectivity,
            reference_img,
            out_dir / f"selectivity_{finger}.nii.gz",
            np.float32,
        )

    n_input = int(analysis_mask.sum())
    n_responsive = int(responsive_mask.sum())
    retained_percentage = (
        100.0 * n_responsive / n_input
        if n_input > 0
        else 0.0
    )

    labels, counts = np.unique(
        argmax_map[responsive_mask],
        return_counts=True,
    )
    winner_counts = {
        int(label): int(count)
        for label, count in zip(labels, counts)
    }

    print(f"[{session}] Step 4 completed successfully.")
    print(f"  PSC directory:       {psc_dir}")
    print(f"  Output directory:    {out_dir}")
    print(f"  Analysis-mask voxels:  {n_input:>7d}")
    print(f"  Responsive WTA voxels: {n_responsive:>7d}")
    print(f"  Retained for WTA:      {retained_percentage:>6.2f}%")
    print(f"  Denominator epsilon:   {denominator_eps:.8g}")
    print(
        "  Finger order:        "
        f"{list(enumerate(fingers, start=1))}"
    )
    print()
    print("  WTA winner counts:")
    for label, finger in enumerate(fingers, start=1):
        count = winner_counts.get(label, 0)
        percentage = (
            100.0 * count / n_responsive
            if n_responsive > 0
            else 0.0
        )
        print(
            f"    {label} ({finger:<6s}): "
            f"{count:>6d} ({percentage:6.2f}%)"
        )

    print()
    print("  Principal outputs:")
    print("    dominance_analysis_mask.nii.gz")
    print("    dominance_responsive_mask.nii.gz")
    print("    dominance_argmax.nii.gz")
    for finger in fingers:
        print(f"    dominance_{finger}.nii.gz")
    print()
    print("  Additional diagnostic outputs:")
    print("    maximum_finger_psc.nii.gz")
    print("    winner_margin_psc.nii.gz")
    for finger in fingers:
        print(f"    dominance_valid_{finger}.nii.gz")
        print(f"    dominance_fraction_{finger}.nii.gz")
        print(f"    selectivity_{finger}.nii.gz")


if __name__ == "__main__":
    if len(sys.argv) != 3:
        sys.exit(
            "Usage: python 04_finger_dominance_maps.py "
            "config.yaml <session>"
        )

    main(sys.argv[1], sys.argv[2])
