#!/usr/bin/env python3
"""
FINAL Step 06 — intrinsic-coordinate geometry QC v3 — Anatomy-only intrinsic UV control points for
LN2_MULTILATERATE.

This version removes the last PCA-dependent endpoint selection. Both U and V
are derived from the intrinsic graph geometry of:

    middle-GM sheet ∩ anatomical M1 ROI

No functional mask or finger-response information is used.

Overview
--------
1. Intersect the validated anatomical M1 ROI with the middle-GM sheet.
2. Build a 26-neighbour graph with physical edge lengths in millimetres.
3. Retain the largest connected anatomical component.
4. Define U from an intrinsic geodesic-diameter approximation.
5. Reconstruct the U geodesic path.
6. Remove a configurable geodesic corridor around the U path.
7. Identify the two largest remaining side components.
8. Select one intrinsic V endpoint from each side:
       the voxel farthest from the U corridor.
9. Orient V using an independent world-space anatomical direction.
10. Place the origin on the U path near its midpoint and geodesically
    balanced between the two V endpoints.

CASE-II labels
--------------
2 = origin
3 = Min U
4 = Max U
5 = Min V
6 = Max V

Default anatomical sign conventions for left M1
------------------------------------------------
U positive: +X
    approximately lateral -> medial

V positive: -Z
    approximately gyral crown -> sulcal depth

The sign conventions orient the endpoint pairs only. Endpoint locations and
distances are determined intrinsically from the cortical-sheet graph.

Required inputs
---------------
--midgm
    Middle-GM image from LN2_LAYERS.

--anatomical-roi
    Validated anatomical M1 ROI from Steps 1–2, in the same grid.

--anatomical-background
    Optional anatomical/EPI background in the same grid. If supplied, it is
    used only for the QC PNG and never for endpoint selection.

Outputs
-------
<output>.nii.gz
<output_prefix>_all_anatomical_components.nii.gz
<output_prefix>_anatomical_patch_mask.nii.gz
<output_prefix>_component_labels.nii.gz
<output_prefix>_u_geodesic_path.nii.gz
<output_prefix>_u_corridor_mask.nii.gz
<output_prefix>_side_components.nii.gz
<output_prefix>_distance_to_u_path_mm.nii.gz
<output_prefix>_intrinsic_geometry_qc_labels.nii.gz
<output_prefix>_intrinsic_geometry_qc.png
<output_prefix>_control_points_qc.csv
<output_prefix>_summary.txt

Important
---------
This is the final automatic proposal stage. Before LN2_MULTILATERATE, inspect the generated QC figure/map together with:
    - anatomical M1 ROI
    - middle-GM sheet
    - anatomical patch
    - U path and U corridor
    - the two intrinsic V side components
    - labels 2–6
"""

import argparse
import re
import csv
import sys
from pathlib import Path

import matplotlib
matplotlib.use("Agg", force=True)
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap, BoundaryNorm
from matplotlib.patches import Patch
import nibabel as nib
import numpy as np
from scipy import sparse
from scipy.sparse.csgraph import connected_components, dijkstra


AFFINE_ATOL = 1e-4


def find_nifti(path_or_stem):
    path = Path(path_or_stem)
    if path.exists():
        return path

    text = str(path)
    if text.endswith(".nii.gz"):
        candidates = [Path(text)]
    elif text.endswith(".nii"):
        candidates = [Path(text + ".gz"), Path(text)]
    else:
        candidates = [Path(text + ".nii.gz"), Path(text + ".nii")]

    for candidate in candidates:
        if candidate.exists():
            return candidate

    raise FileNotFoundError(
        "NIfTI file not found. Checked:\n  "
        + "\n  ".join(str(item) for item in candidates)
    )


def reject_functional_mask(path):
    forbidden = (
        "psc_analysis_mask",
        "responsive",
        "dominance",
        "argmax",
        "winner",
        "selectivity",
    )
    name = path.name.lower()
    if any(term in name for term in forbidden):
        raise ValueError(
            "The supplied --anatomical-roi appears to be functional:\n"
            f"  {path}\n"
            "Use the anatomical M1 ROI from Steps 1–2."
        )


def check_same_grid(reference, moving, reference_name, moving_name):
    if reference.shape[:3] != moving.shape[:3]:
        raise RuntimeError(
            "Shape mismatch:\n"
            f"  {reference_name}: {reference.shape[:3]}\n"
            f"  {moving_name}: {moving.shape[:3]}"
        )

    if not np.allclose(
        reference.affine,
        moving.affine,
        atol=AFFINE_ATOL,
        rtol=0.0,
    ):
        raise RuntimeError(
            "Affine mismatch between:\n"
            f"  {reference_name}\n"
            f"  {moving_name}"
        )


def save_nifti(data, reference, path, dtype):
    data = np.asarray(data, dtype=dtype)

    header = nib.Nifti1Header()
    header.set_data_dtype(dtype)
    header.set_data_shape(data.shape)

    zooms = reference.header.get_zooms()
    if len(zooms) >= data.ndim:
        header.set_zooms(zooms[: data.ndim])

    spatial_unit, temporal_unit = reference.header.get_xyzt_units()
    header.set_xyzt_units(spatial_unit, temporal_unit)
    header.set_slope_inter(1.0, 0.0)

    image = nib.Nifti1Image(
        data,
        reference.affine.copy(),
        header,
    )

    qform, qcode = reference.get_qform(coded=True)
    sform, scode = reference.get_sform(coded=True)

    if qform is not None:
        image.set_qform(qform, int(qcode))
    if sform is not None:
        image.set_sform(sform, int(scode))

    image.header.set_slope_inter(1.0, 0.0)
    nib.save(image, str(path))


def normalize_vector(vector, name):
    vector = np.asarray(vector, dtype=np.float64)
    norm = float(np.linalg.norm(vector))
    if norm == 0:
        raise ValueError(f"{name} must be nonzero.")
    return vector / norm


def derive_prefix(path):
    path = Path(path)
    name = path.name
    if name.endswith(".nii.gz"):
        stem = name[:-7]
    elif name.endswith(".nii"):
        stem = name[:-4]
    else:
        stem = name
    return path.parent / stem


def neighbour_offsets():
    return [
        (di, dj, dk)
        for di in (-1, 0, 1)
        for dj in (-1, 0, 1)
        for dk in (-1, 0, 1)
        if not (di == 0 and dj == 0 and dk == 0)
    ]


def build_graph(mask, affine):
    ijk = np.column_stack(np.nonzero(mask)).astype(np.int32)
    n_nodes = int(ijk.shape[0])
    if n_nodes == 0:
        raise RuntimeError("The anatomical patch is empty.")

    index_image = np.full(mask.shape, -1, dtype=np.int32)
    index_image[tuple(ijk.T)] = np.arange(n_nodes, dtype=np.int32)

    rows, cols, weights = [], [], []
    linear = affine[:3, :3]

    for offset in neighbour_offsets():
        offset_arr = np.asarray(offset, dtype=np.int32)
        shifted = ijk + offset_arr

        inside = np.all(
            (shifted >= 0)
            & (shifted < np.asarray(mask.shape, dtype=np.int32)),
            axis=1,
        )
        source = np.flatnonzero(inside)
        if source.size == 0:
            continue

        shifted_valid = shifted[inside]
        target = index_image[tuple(shifted_valid.T)]
        valid = target >= 0
        source = source[valid]
        target = target[valid]
        if source.size == 0:
            continue

        physical_offset = linear @ offset_arr.astype(np.float64)
        distance_mm = float(np.linalg.norm(physical_offset))

        rows.extend(source.tolist())
        cols.extend(target.tolist())
        weights.extend([distance_mm] * source.size)

    graph = sparse.coo_matrix(
        (weights, (rows, cols)),
        shape=(n_nodes, n_nodes),
        dtype=np.float64,
    ).tocsr()
    graph.sum_duplicates()

    return ijk, graph


def component_info(mask, ijk, graph):
    n_components, labels = connected_components(
        graph,
        directed=False,
        return_labels=True,
    )
    counts = np.bincount(labels)
    largest_label = int(np.argmax(counts))
    keep = np.flatnonzero(labels == largest_label)

    component_image = np.zeros(mask.shape, dtype=np.int16)
    component_image[tuple(ijk.T)] = labels.astype(np.int16) + 1

    return (
        int(n_components),
        labels,
        counts,
        largest_label,
        keep,
        component_image,
    )


def farthest_finite(distances):
    finite = np.isfinite(distances)
    if not np.any(finite):
        raise RuntimeError("No finite geodesic distances were found.")
    candidates = np.flatnonzero(finite)
    return int(candidates[np.argmax(distances[finite])])


def shortest_path(predecessors, source, target):
    path = [int(target)]
    current = int(target)

    while current != source:
        previous = int(predecessors[current])
        if previous < 0:
            raise RuntimeError("Could not reconstruct the geodesic path.")
        path.append(previous)
        current = previous

    path.reverse()
    return np.asarray(path, dtype=np.int64)


def orient_pair(a, b, coords_mm, positive_direction):
    vector = coords_mm[b] - coords_mm[a]
    if float(np.dot(vector, positive_direction)) >= 0:
        return int(a), int(b)
    return int(b), int(a)


def multi_source_distance(graph, sources):
    distances = dijkstra(
        graph,
        directed=False,
        indices=np.asarray(sources, dtype=np.int64),
        return_predecessors=False,
    )
    if distances.ndim == 1:
        return distances
    return np.min(distances, axis=0)


def intrinsic_side_components(
    graph,
    distance_to_u,
    corridor_width_mm,
    minimum_side_voxels,
):
    """
    Remove a geodesic corridor around U and find connected side components.

    Returns the two largest valid side components as graph-node index arrays.
    """
    outside_corridor = (
        np.isfinite(distance_to_u)
        & (distance_to_u > corridor_width_mm)
    )
    outside_nodes = np.flatnonzero(outside_corridor)

    if outside_nodes.size < 2 * minimum_side_voxels:
        raise RuntimeError(
            "Too few voxels remain outside the U corridor. "
            "Reduce --u-corridor-width-mm."
        )

    subgraph = graph[outside_nodes][:, outside_nodes].tocsr()
    n_components, labels = connected_components(
        subgraph,
        directed=False,
        return_labels=True,
    )
    counts = np.bincount(labels)

    valid_labels = [
        int(label)
        for label, count in enumerate(counts)
        if int(count) >= minimum_side_voxels
    ]

    if len(valid_labels) < 2:
        raise RuntimeError(
            "Removing the U corridor did not yield two sufficiently large "
            "intrinsic side components. Adjust the anatomical ROI or "
            "--u-corridor-width-mm."
        )

    valid_labels.sort(
        key=lambda label: int(counts[label]),
        reverse=True,
    )
    chosen = valid_labels[:2]

    side_1 = outside_nodes[np.flatnonzero(labels == chosen[0])]
    side_2 = outside_nodes[np.flatnonzero(labels == chosen[1])]

    return (
        side_1.astype(np.int64),
        side_2.astype(np.int64),
        outside_corridor,
        int(n_components),
        counts,
    )


def farthest_from_u_in_component(component_nodes, distance_to_u):
    component_nodes = np.asarray(component_nodes, dtype=np.int64)
    values = distance_to_u[component_nodes]
    finite = np.isfinite(values)

    if not np.any(finite):
        raise RuntimeError(
            "A side component contains no finite distance-to-U values."
        )

    candidates = component_nodes[finite]
    return int(candidates[np.argmax(values[finite])])


def orient_v_sides(
    endpoint_1,
    endpoint_2,
    coords_mm,
    positive_direction,
):
    vector = coords_mm[endpoint_2] - coords_mm[endpoint_1]
    if float(np.dot(vector, positive_direction)) >= 0:
        return int(endpoint_1), int(endpoint_2)
    return int(endpoint_2), int(endpoint_1)


def choose_origin(
    u_path,
    distance_from_v_min,
    distance_from_v_max,
    excluded,
):
    rank = np.arange(u_path.size, dtype=np.float64)
    midpoint = (u_path.size - 1) / 2.0

    midpoint_cost = np.abs(rank - midpoint)
    balance_cost = np.abs(
        distance_from_v_min[u_path]
        - distance_from_v_max[u_path]
    )

    if np.max(midpoint_cost) > 0:
        midpoint_cost /= np.max(midpoint_cost)

    finite_balance = np.isfinite(balance_cost)
    if np.any(finite_balance) and np.nanmax(balance_cost) > 0:
        balance_cost /= np.nanmax(balance_cost)

    cost = midpoint_cost + balance_cost

    for node in excluded:
        cost[u_path == node] = np.inf

    return int(u_path[int(np.nanargmin(cost))])



def robust_limits(data, mask=None):
    values = np.asarray(data, dtype=np.float64)
    valid = np.isfinite(values)
    if mask is not None:
        valid &= np.asarray(mask, dtype=bool)
    values = values[valid]
    if values.size == 0:
        return 0.0, 1.0
    lo, hi = np.percentile(values, [2.0, 98.0])
    if not np.isfinite(lo) or not np.isfinite(hi) or hi <= lo:
        lo = float(np.nanmin(values))
        hi = float(np.nanmax(values))
    if hi <= lo:
        hi = lo + 1.0
    return float(lo), float(hi)


def project_mask(mask, axis):
    return np.any(mask, axis=axis)


def _orient_projection(array):
    return np.rot90(np.asarray(array))


def _rot90_point_from_projection(voxel, axis, shape3d):
    """
    Map a 3-D voxel coordinate to the corresponding np.rot90-projected
    2-D plotting coordinate after projecting over `axis`.
    """
    remaining = [d for d in (0, 1, 2) if d != axis]
    a = int(voxel[remaining[0]])
    b = int(voxel[remaining[1]])
    size_b = int(shape3d[remaining[1]])
    # np.rot90: output row = size_b - 1 - b; output col = a.
    y = size_b - 1 - b
    x = a
    return x, y


def _bbox_from_mask(mask2d, margin=8):
    ys, xs = np.nonzero(mask2d)
    if len(xs) == 0:
        return 0, mask2d.shape[1] - 1, 0, mask2d.shape[0] - 1

    xmin = max(0, int(xs.min()) - margin)
    xmax = min(mask2d.shape[1] - 1, int(xs.max()) + margin)
    ymin = max(0, int(ys.min()) - margin)
    ymax = min(mask2d.shape[0] - 1, int(ys.max()) + margin)
    return xmin, xmax, ymin, ymax


def _anatomical_projection_names(img):
    """
    Infer human-readable projection names from the NIfTI affine.

    nibabel.aff2axcodes() returns the anatomical direction associated with
    increasing voxel i/j/k. Projecting across an axis corresponds to viewing
    along that anatomical axis:
        L/R -> sagittal
        A/P -> coronal
        S/I -> axial
    """
    try:
        axcodes = nib.aff2axcodes(img.affine)
    except Exception:
        axcodes = (None, None, None)

    out = {}
    for axis, code in enumerate(axcodes):
        if code in ("L", "R"):
            out[axis] = "Sagittal maximum projection"
        elif code in ("A", "P"):
            out[axis] = "Coronal maximum projection"
        elif code in ("S", "I"):
            out[axis] = "Axial maximum projection"
        else:
            out[axis] = f"Projection across voxel axis {axis}"
    return out


def build_qc_label_map(
    patch_mask,
    corridor_map,
    u_path_map,
    side_map,
    control_points,
):
    """
    Single categorical QC image.

    Codes:
      0 = background
      1 = anatomical patch
      2 = U corridor
      3 = U geodesic path
      4 = −V side
      5 = +V side
     12 = origin
     13 = min U
     14 = max U
     15 = min V
     16 = max V

    Priority is patch < corridor/sides < U path < control points.
    """
    qc = np.zeros(patch_mask.shape, dtype=np.int16)
    qc[patch_mask] = 1
    qc[corridor_map > 0] = 2
    qc[side_map == 1] = 4
    qc[side_map == 2] = 5
    qc[u_path_map > 0] = 3
    for label in (2, 3, 4, 5, 6):
        qc[control_points == label] = 10 + label
    return qc


def generate_intrinsic_geometry_qc(
    output_png,
    reference_img,
    patch_mask,
    corridor_map,
    u_path_map,
    side_map,
    control_points,
    background=None,
    background_name=None,
    u_length=None,
    v_distance=None,
    corridor_width=None,
    largest_fraction=None,
    crop_margin=10,
):
    """
    Generate a compact geometry QC figure showing the full intrinsic
    construction rather than isolated endpoint slices.

    The three orthogonal maximum projections are automatically cropped to the
    anatomical patch, labeled using the NIfTI affine when possible, and given
    dedicated space for the legend and metric summary.
    """
    patch_color = "#BDBDBD"
    corridor_color = "#FFD166"
    u_color = "#E63946"
    side1_color = "#4CC9F0"
    side2_color = "#4361EE"
    point_colors = {
        2: "#000000",  # origin
        3: "#7B2CBF",  # min U
        4: "#FF006E",  # max U
        5: "#2A9D8F",  # min V
        6: "#F77F00",  # max V
    }

    projection_names = _anatomical_projection_names(reference_img)

    fig = plt.figure(figsize=(15.5, 6.6))
    gs = fig.add_gridspec(
        3,
        3,
        height_ratios=[1.0, 0.13, 0.09],
        hspace=0.12,
        wspace=0.06,
    )
    axes = [fig.add_subplot(gs[0, i]) for i in range(3)]
    legend_ax = fig.add_subplot(gs[1, :])
    metrics_ax = fig.add_subplot(gs[2, :])
    legend_ax.axis("off")
    metrics_ax.axis("off")

    for panel_index, axis in enumerate((0, 1, 2)):
        ax = axes[panel_index]

        patch_proj = _orient_projection(project_mask(patch_mask, axis))
        corridor_proj = _orient_projection(project_mask(corridor_map > 0, axis))
        path_proj = _orient_projection(project_mask(u_path_map > 0, axis))
        side1_proj = _orient_projection(project_mask(side_map == 1, axis))
        side2_proj = _orient_projection(project_mask(side_map == 2, axis))

        if background is not None:
            bg = np.nanmean(
                np.where(np.isfinite(background), background, np.nan),
                axis=axis,
            )
            bg = _orient_projection(bg)
            # Use the patch neighborhood to define robust display limits.
            lo, hi = robust_limits(bg, mask=patch_proj)
            ax.imshow(
                bg,
                cmap="gray",
                vmin=lo,
                vmax=hi,
                interpolation="nearest",
            )

        # Patch is deliberately subtle.
        patch_rgba = np.zeros(patch_proj.shape + (4,), dtype=np.float32)
        patch_rgba[patch_proj, :3] = np.array([0.74, 0.74, 0.74])
        patch_rgba[patch_proj, 3] = 0.34 if background is not None else 0.72
        ax.imshow(patch_rgba, interpolation="nearest")

        def overlay(mask2d, color, alpha):
            rgba = np.zeros(mask2d.shape + (4,), dtype=np.float32)
            rgb = np.array(
                [int(color[i:i+2], 16) / 255.0 for i in (1, 3, 5)],
                dtype=np.float32,
            )
            rgba[mask2d, :3] = rgb
            rgba[mask2d, 3] = alpha
            ax.imshow(rgba, interpolation="nearest")

        overlay(corridor_proj, corridor_color, 0.34)
        overlay(side1_proj, side1_color, 0.60)
        overlay(side2_proj, side2_color, 0.60)
        overlay(path_proj, u_color, 0.98)

        cp_positions = np.column_stack(np.nonzero(control_points > 0))
        for voxel in cp_positions:
            label = int(control_points[tuple(voxel)])
            x_after, y_after = _rot90_point_from_projection(
                voxel,
                axis,
                patch_mask.shape,
            )
            ax.scatter(
                [x_after],
                [y_after],
                s=72,
                c=point_colors[label],
                edgecolors="white",
                linewidths=1.2,
                zorder=10,
            )
            ax.text(
                x_after + 1.5,
                y_after - 1.5,
                str(label),
                color=point_colors[label],
                fontsize=10,
                fontweight="bold",
                bbox=dict(
                    facecolor="white",
                    edgecolor="none",
                    alpha=0.80,
                    pad=0.8,
                ),
                zorder=11,
            )

        xmin, xmax, ymin, ymax = _bbox_from_mask(
            patch_proj | corridor_proj | path_proj | side1_proj | side2_proj,
            margin=crop_margin,
        )
        ax.set_xlim(xmin, xmax)
        ax.set_ylim(ymax, ymin)

        ax.set_title(projection_names[axis], fontsize=11, pad=8)
        ax.set_xticks([])
        ax.set_yticks([])
        for spine in ax.spines.values():
            spine.set_visible(False)

    bg_suffix = ""
    if background_name:
        bg_suffix = f"\nBackground: {background_name}"
    fig.suptitle(
        "Step 06 intrinsic-coordinate geometry QC" + bg_suffix,
        fontsize=14,
        y=0.985,
    )

    legend_handles = [
        Patch(facecolor=patch_color, alpha=0.72, label="Anatomical mid-GM patch"),
        Patch(facecolor=corridor_color, alpha=0.55, label="U corridor"),
        Patch(facecolor=u_color, alpha=0.95, label="U geodesic path"),
        Patch(facecolor=side1_color, alpha=0.65, label="−V side"),
        Patch(facecolor=side2_color, alpha=0.65, label="+V side"),
        Patch(facecolor=point_colors[2], label="2 origin"),
        Patch(facecolor=point_colors[3], label="3 min U"),
        Patch(facecolor=point_colors[4], label="4 max U"),
        Patch(facecolor=point_colors[5], label="5 min V"),
        Patch(facecolor=point_colors[6], label="6 max V"),
    ]
    legend_ax.legend(
        handles=legend_handles,
        loc="center",
        ncol=5,
        frameon=False,
        fontsize=8.5,
        columnspacing=1.2,
        handlelength=1.8,
    )

    metric_parts = []
    if u_length is not None:
        metric_parts.append(f"U geodesic = {u_length:.2f} mm")
    if v_distance is not None:
        metric_parts.append(f"V endpoint distance = {v_distance:.2f} mm")
    if corridor_width is not None:
        metric_parts.append(f"U corridor = {corridor_width:.2f} mm")
    if largest_fraction is not None:
        metric_parts.append(
            f"largest connected component = {100.0 * largest_fraction:.2f}%"
        )
    metrics_ax.text(
        0.5,
        0.52,
        "   |   ".join(metric_parts),
        ha="center",
        va="center",
        fontsize=9,
    )

    fig.savefig(output_png, dpi=240, bbox_inches="tight")
    plt.close(fig)


def auto_discover_background(midgm_img, anatomical_roi_path):
    """
    Try to locate the standard mean-EPI image associated with the anatomical
    ROI directory. The first same-grid candidate is returned.

    This is QC-only and never affects endpoint selection.
    """
    roi_dir = anatomical_roi_path.parent
    candidates = sorted(
        list(roi_dir.glob("mean_EPI_ses*.nii")) +
        list(roi_dir.glob("mean_EPI_ses*.nii.gz"))
    )
    for candidate in candidates:
        try:
            img = nib.load(str(candidate))
            check_same_grid(
                midgm_img,
                img,
                "middle-GM reference",
                str(candidate),
            )
            return candidate, img
        except Exception:
            continue
    return None, None


def compact_background_label(background_path):
    """
    Return a short human-readable QC background label rather than the full path.
    Examples:
      mean_EPI_ses18.nii.gz -> mean EPI (ses-18)
      mean_EPI_ses-18.nii.gz -> mean EPI (ses-18)
    """
    if background_path is None:
        return None

    name = Path(background_path).name
    m = re.search(r"mean[_-]?EPI[_-]?(ses-?\d+)", name, flags=re.IGNORECASE)
    if m:
        ses = m.group(1)
        if not ses.startswith("ses-"):
            ses = ses.replace("ses", "ses-", 1)
        return f"mean EPI ({ses})"

    # Fall back to a clean basename without NIfTI suffixes.
    if name.endswith(".nii.gz"):
        name = name[:-7]
    elif name.endswith(".nii"):
        name = name[:-4]
    return name.replace("_", " ")



def parse_args():
    parser = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
        description=(
            "Generate final anatomy-only intrinsic CASE-II UV control "
            "points for LN2_MULTILATERATE."
        ),
    )
    parser.add_argument(
        "--midgm",
        required=True,
        help="Middle-GM NIfTI from LN2_LAYERS.",
    )
    parser.add_argument(
        "--anatomical-roi",
        required=True,
        help="Validated anatomical M1 ROI from Steps 1–2.",
    )
    parser.add_argument(
        "--output",
        required=True,
        help="Output control-point NIfTI.",
    )
    parser.add_argument(
        "--anatomical-background",
        default=None,
        help=(
            "Optional anatomical/EPI NIfTI in the same grid, used only as "
            "the background of the Step-06 QC PNG. If omitted, Step 06 tries "
            "to auto-discover a mean_EPI_sesXX image from the standard "
            "RSA_240726 ROI directory."
        ),
    )
    parser.add_argument(
        "--u-positive",
        nargs=3,
        type=float,
        default=[1.0, 0.0, 0.0],
        metavar=("X", "Y", "Z"),
        help="World-space positive U direction.",
    )
    parser.add_argument(
        "--v-positive",
        nargs=3,
        type=float,
        default=[0.0, 0.0, -1.0],
        metavar=("X", "Y", "Z"),
        help="World-space positive V direction.",
    )
    parser.add_argument(
        "--roi-threshold",
        type=float,
        default=0.5,
        help="Numeric threshold applied to the anatomical ROI.",
    )
    parser.add_argument(
        "--midgm-threshold",
        type=float,
        default=0.0,
        help="Numeric threshold applied to the middle-GM image.",
    )
    parser.add_argument(
        "--minimum-largest-component-fraction",
        type=float,
        default=0.80,
        help=(
            "Minimum fraction of the anatomical intersection that must be "
            "contained in its largest connected component."
        ),
    )
    parser.add_argument(
        "--u-corridor-width-mm",
        type=float,
        default=1.5,
        help=(
            "Intrinsic distance removed around the U path before detecting "
            "the two V side components."
        ),
    )
    parser.add_argument(
        "--minimum-side-voxels",
        type=int,
        default=10,
        help="Minimum voxel count for each intrinsic V side component.",
    )
    return parser.parse_args()


def main():
    args = parse_args()

    if not 0 < args.minimum_largest_component_fraction <= 1:
        raise ValueError(
            "--minimum-largest-component-fraction must lie in (0,1]."
        )
    if args.u_corridor_width_mm < 0:
        raise ValueError("--u-corridor-width-mm must be >= 0.")
    if args.minimum_side_voxels < 1:
        raise ValueError("--minimum-side-voxels must be >= 1.")

    midgm_path = find_nifti(args.midgm)
    roi_path = find_nifti(args.anatomical_roi)
    reject_functional_mask(roi_path)

    output_path = Path(args.output)
    if not str(output_path).endswith((".nii", ".nii.gz")):
        output_path = Path(str(output_path) + ".nii.gz")
    output_path.parent.mkdir(parents=True, exist_ok=True)
    prefix = derive_prefix(output_path)

    midgm_img = nib.load(str(midgm_path))
    roi_img = nib.load(str(roi_path))

    background_img = None
    background = None
    background_path = None

    if args.anatomical_background:
        background_path = find_nifti(args.anatomical_background)
        background_img = nib.load(str(background_path))
        check_same_grid(
            midgm_img,
            background_img,
            str(midgm_path),
            str(background_path),
        )
    else:
        background_path, background_img = auto_discover_background(
            midgm_img,
            roi_path,
        )

    if background_img is not None:
        background = background_img.get_fdata(dtype=np.float32)

    check_same_grid(
        midgm_img,
        roi_img,
        str(midgm_path),
        str(roi_path),
    )

    midgm = midgm_img.get_fdata(dtype=np.float32)
    roi = roi_img.get_fdata(dtype=np.float32)

    full_mask = (
        np.isfinite(midgm)
        & np.isfinite(roi)
        & (midgm > args.midgm_threshold)
        & (roi > args.roi_threshold)
    )
    n_full = int(full_mask.sum())

    if n_full < 20:
        raise RuntimeError(
            f"middle-GM ∩ anatomical M1 contains only {n_full} voxels."
        )

    ijk_all, graph_all = build_graph(full_mask, midgm_img.affine)

    (
        n_components,
        labels,
        counts,
        largest_label,
        keep,
        component_image,
    ) = component_info(
        full_mask,
        ijk_all,
        graph_all,
    )

    n_largest = int(counts[largest_label])
    largest_fraction = float(n_largest / n_full)

    if largest_fraction < args.minimum_largest_component_fraction:
        raise RuntimeError(
            "The anatomy-only middle-GM patch is too fragmented:\n"
            f"  full voxels: {n_full}\n"
            f"  components: {n_components}\n"
            f"  largest voxels: {n_largest}\n"
            f"  largest fraction: {largest_fraction:.4f}"
        )

    ijk = ijk_all[keep]
    graph = graph_all[keep][:, keep].tocsr()

    patch_mask = np.zeros(full_mask.shape, dtype=bool)
    patch_mask[tuple(ijk.T)] = True

    coords_mm = nib.affines.apply_affine(
        midgm_img.affine,
        ijk,
    )

    u_positive = normalize_vector(
        args.u_positive,
        "--u-positive",
    )
    v_positive = normalize_vector(
        args.v_positive,
        "--v-positive",
    )

    # Intrinsic geodesic diameter approximation for U.
    center_mm = np.mean(coords_mm, axis=0)
    seed = int(
        np.argmin(
            (coords_mm - center_mm) @ u_positive
        )
    )

    distance_seed = dijkstra(
        graph,
        directed=False,
        indices=seed,
    )
    endpoint_a = farthest_finite(distance_seed)

    distance_a = dijkstra(
        graph,
        directed=False,
        indices=endpoint_a,
    )
    endpoint_b = farthest_finite(distance_a)

    u_min, u_max = orient_pair(
        endpoint_a,
        endpoint_b,
        coords_mm,
        u_positive,
    )

    distance_u_min, predecessors_u_min = dijkstra(
        graph,
        directed=False,
        indices=u_min,
        return_predecessors=True,
    )
    u_path = shortest_path(
        predecessors_u_min,
        u_min,
        u_max,
    )
    distance_to_u = multi_source_distance(
        graph,
        u_path,
    )

    (
        side_1,
        side_2,
        outside_corridor,
        n_side_components,
        side_component_counts,
    ) = intrinsic_side_components(
        graph,
        distance_to_u,
        args.u_corridor_width_mm,
        args.minimum_side_voxels,
    )

    endpoint_1 = farthest_from_u_in_component(
        side_1,
        distance_to_u,
    )
    endpoint_2 = farthest_from_u_in_component(
        side_2,
        distance_to_u,
    )

    v_min, v_max = orient_v_sides(
        endpoint_1,
        endpoint_2,
        coords_mm,
        v_positive,
    )

    distance_v_min = dijkstra(
        graph,
        directed=False,
        indices=v_min,
    )
    distance_v_max = dijkstra(
        graph,
        directed=False,
        indices=v_max,
    )

    origin = choose_origin(
        u_path,
        distance_v_min,
        distance_v_max,
        excluded={u_min, u_max, v_min, v_max},
    )

    selected = {
        2: origin,
        3: u_min,
        4: u_max,
        5: v_min,
        6: v_max,
    }

    control_points = np.zeros(
        patch_mask.shape,
        dtype=np.int16,
    )
    u_path_map = np.zeros(
        patch_mask.shape,
        dtype=np.uint8,
    )
    corridor_map = np.zeros(
        patch_mask.shape,
        dtype=np.uint8,
    )
    side_map = np.zeros(
        patch_mask.shape,
        dtype=np.int16,
    )
    distance_map = np.full(
        patch_mask.shape,
        np.nan,
        dtype=np.float32,
    )

    u_path_map[tuple(ijk[u_path].T)] = 1
    corridor_nodes = np.flatnonzero(
        np.isfinite(distance_to_u)
        & (distance_to_u <= args.u_corridor_width_mm)
    )
    corridor_map[tuple(ijk[corridor_nodes].T)] = 1
    side_map[tuple(ijk[side_1].T)] = 1
    side_map[tuple(ijk[side_2].T)] = 2
    distance_map[patch_mask] = distance_to_u.astype(np.float32)

    qc_label_map = build_qc_label_map(
        patch_mask,
        corridor_map,
        u_path_map,
        side_map,
        control_points,
    )

    labels_names = {
        2: "origin",
        3: "min_u",
        4: "max_u",
        5: "min_v",
        6: "max_v",
    }

    rows = []

    for label in (2, 3, 4, 5, 6):
        node = int(selected[label])
        voxel = tuple(int(v) for v in ijk[node])
        world = coords_mm[node]
        control_points[voxel] = label

        rows.append(
            {
                "label": label,
                "name": labels_names[label],
                "voxel_i_zero_based": voxel[0],
                "voxel_j_zero_based": voxel[1],
                "voxel_k_zero_based": voxel[2],
                "matlab_i_one_based": voxel[0] + 1,
                "matlab_j_one_based": voxel[1] + 1,
                "matlab_k_one_based": voxel[2] + 1,
                "world_x_mm": float(world[0]),
                "world_y_mm": float(world[1]),
                "world_z_mm": float(world[2]),
                "distance_to_u_path_mm": float(
                    distance_to_u[node]
                ),
            }
        )

    save_nifti(
        control_points,
        midgm_img,
        output_path,
        np.int16,
    )
    save_nifti(
        full_mask,
        midgm_img,
        Path(str(prefix) + "_all_anatomical_components.nii.gz"),
        np.uint8,
    )
    save_nifti(
        patch_mask,
        midgm_img,
        Path(str(prefix) + "_anatomical_patch_mask.nii.gz"),
        np.uint8,
    )
    save_nifti(
        component_image,
        midgm_img,
        Path(str(prefix) + "_component_labels.nii.gz"),
        np.int16,
    )
    save_nifti(
        u_path_map,
        midgm_img,
        Path(str(prefix) + "_u_geodesic_path.nii.gz"),
        np.uint8,
    )
    save_nifti(
        corridor_map,
        midgm_img,
        Path(str(prefix) + "_u_corridor_mask.nii.gz"),
        np.uint8,
    )
    save_nifti(
        side_map,
        midgm_img,
        Path(str(prefix) + "_side_components.nii.gz"),
        np.int16,
    )
    save_nifti(
        distance_map,
        midgm_img,
        Path(str(prefix) + "_distance_to_u_path_mm.nii.gz"),
        np.float32,
    )
    qc_labels_path = Path(
        str(prefix) + "_intrinsic_geometry_qc_labels.nii.gz"
    )
    save_nifti(
        qc_label_map,
        midgm_img,
        qc_labels_path,
        np.int16,
    )

    qc_path = Path(str(prefix) + "_control_points_qc.csv")
    with qc_path.open(
        "w",
        newline="",
        encoding="utf-8",
    ) as stream:
        writer = csv.DictWriter(
            stream,
            fieldnames=list(rows[0].keys()),
        )
        writer.writeheader()
        writer.writerows(rows)

    u_length = float(distance_u_min[u_max])
    v_distance = float(distance_v_min[v_max])

    qc_png_path = Path(str(prefix) + "_intrinsic_geometry_qc.png")
    generate_intrinsic_geometry_qc(
        qc_png_path,
        midgm_img,
        patch_mask,
        corridor_map,
        u_path_map,
        side_map,
        control_points,
        background=background,
        background_name=compact_background_label(background_path),
        u_length=u_length,
        v_distance=v_distance,
        corridor_width=args.u_corridor_width_mm,
        largest_fraction=largest_fraction,
        crop_margin=10,
    )

    summary_path = Path(str(prefix) + "_summary.txt")
    with summary_path.open("w", encoding="utf-8") as stream:
        stream.write(
            "Final anatomy-only intrinsic UV control points\n"
        )
        stream.write(
            "==============================================\n\n"
        )
        stream.write(f"Middle-GM:      {midgm_path}\n")
        stream.write(f"Anatomical ROI: {roi_path}\n")
        stream.write("Functional masks used: NO\n")
        stream.write("PCA used for endpoint selection: NO\n")
        stream.write(
            "QC anatomical background: "
            + (
                str(background_path)
                if background_path
                else "NONE (no same-grid mean EPI auto-discovered)"
            )
            + "\n\n"
        )
        stream.write(f"Full patch voxels: {n_full}\n")
        stream.write(f"Connected components: {n_components}\n")
        stream.write(f"Largest component voxels: {n_largest}\n")
        stream.write(
            f"Largest-component fraction: "
            f"{largest_fraction:.6f}\n\n"
        )
        stream.write(
            f"U geodesic length: {u_length:.6f} mm\n"
        )
        stream.write(
            f"U corridor width: "
            f"{args.u_corridor_width_mm:.6f} mm\n"
        )
        stream.write(
            f"Components outside U corridor: "
            f"{n_side_components}\n"
        )
        stream.write(
            f"Selected side 1 voxels: {side_1.size}\n"
        )
        stream.write(
            f"Selected side 2 voxels: {side_2.size}\n"
        )
        stream.write(
            f"V endpoint geodesic distance: "
            f"{v_distance:.6f} mm\n\n"
        )

        for row in rows:
            stream.write(
                f"Label {row['label']} ({row['name']}): "
                f"voxel=({row['voxel_i_zero_based']}, "
                f"{row['voxel_j_zero_based']}, "
                f"{row['voxel_k_zero_based']}), "
                f"world=({row['world_x_mm']:.4f}, "
                f"{row['world_y_mm']:.4f}, "
                f"{row['world_z_mm']:.4f}), "
                f"d(U)={row['distance_to_u_path_mm']:.4f} mm\n"
            )

    labels_out, counts_out = np.unique(
        control_points[control_points > 0],
        return_counts=True,
    )

    if not np.array_equal(
        labels_out,
        np.asarray([2, 3, 4, 5, 6]),
    ) or not np.all(counts_out == 1):
        raise RuntimeError(
            "Control-point output validation failed."
        )

    print(
        "FINAL anatomy-only intrinsic UV control points generated."
    )
    print(f"  Middle-GM:                {midgm_path}")
    print(f"  Anatomical M1 ROI:        {roi_path}")
    print("  Functional masks used:    NO")
    print("  PCA endpoint selection:   NO")
    print(f"  Full anatomical patch:    {n_full} voxels")
    print(f"  Connected components:     {n_components}")
    print(
        f"  Largest component:        {n_largest} "
        f"({100.0 * largest_fraction:.2f}%)"
    )
    print(f"  U geodesic length:        {u_length:.3f} mm")
    print(
        f"  U corridor width:         "
        f"{args.u_corridor_width_mm:.3f} mm"
    )
    print(
        f"  Side component sizes:     "
        f"{side_1.size}, {side_2.size} voxels"
    )
    print(
        f"  V endpoint distance:      "
        f"{v_distance:.3f} mm"
    )
    print()

    for row in rows:
        print(
            f"  Label {row['label']} ({row['name']}): "
            f"voxel=({row['voxel_i_zero_based']}, "
            f"{row['voxel_j_zero_based']}, "
            f"{row['voxel_k_zero_based']}), "
            f"world=({row['world_x_mm']:.3f}, "
            f"{row['world_y_mm']:.3f}, "
            f"{row['world_z_mm']:.3f})"
        )

    print()
    print(f"  Control points: {output_path}")
    print(
        "  QC background:  "
        + (
            f"{compact_background_label(background_path)} "
            f"[{background_path}]"
            if background_path
            else "NONE (no same-grid mean EPI auto-discovered)"
        )
    )
    print(f"  QC label map:   {qc_labels_path}")
    print(f"  QC figure:      {qc_png_path}")
    print(f"  QC table:       {qc_path}")
    print(f"  Summary:        {summary_path}")
    print()
    print(
        "This is the final automatic proposal. Inspect the generated "
        "intrinsic-geometry QC figure and label map. Confirm that the U "
        "geodesic follows the long anatomical direction of the patch, the "
        "two side components lie on opposite sides of the U corridor, and "
        "labels 2–6 are anatomically plausible before LN2_MULTILATERATE."
    )


if __name__ == "__main__":
    try:
        main()
    except (
        FileNotFoundError,
        RuntimeError,
        TypeError,
        ValueError,
    ) as exc:
        sys.exit(f"ERROR: {exc}")

