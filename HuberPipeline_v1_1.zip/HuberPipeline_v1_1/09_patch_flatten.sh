#!/usr/bin/env bash
set -euo pipefail

# =============================================================================
# HuberPipeline Step 09 — LN2_PATCH_FLATTEN + flattened-domain QC
# =============================================================================
#
# Preferred use:
#   bash 09_patch_flatten.sh 00_config.yaml ses-18
#   bash 09_patch_flatten.sh 00_config.yaml ses-18 --qc-only
#
# Frozen v1.0 methodology:
#   - multilateration radius: read from CONFIG (30 mm production reference)
#   - U/V computational bin width: 0.275 mm
#   - cortical-depth bins: 20
#   - raw non-Voronoi flattened maps: quantitative analysis
#   - Voronoi-filled flattened maps: display only
#
# Inputs from Step 08:
#   *_UV_coordinates.nii
#   *_perimeter_chunk.nii
#
# Depth input from Step 02:
#   depth3_metric_equidist.nii
#
# Step 09 flattens 22 continuous maps:
#   5 PSC
#   5 dominance fractions
#   5 signed selectivity maps
#   5 Huber-style dominance ratios
#   maximum_finger_psc
#   winner_margin_psc
#
# No finger-label/WTA image is flattened here. Step 10 reconstructs WTA from
# the five continuous dominance-fraction maps in flattened space.
# =============================================================================

CONFIG="${1:-00_config.yaml}"
SESSION="${2:-ses-18}"
MODE="${3:-}"

QC_ONLY=0
if [[ "${MODE}" == "--qc-only" ]]; then
    QC_ONLY=1
elif [[ -n "${MODE}" ]]; then
    echo "ERROR: unknown third argument: ${MODE}" >&2
    echo "Usage: $0 [CONFIG] [SESSION] [--qc-only]" >&2
    exit 1
fi

[[ -f "${CONFIG}" ]] || {
    echo "ERROR: configuration file not found: ${CONFIG}" >&2
    exit 1
}

# -----------------------------------------------------------------------------
# Resolve environment, paths, and frozen settings from 00_config.yaml.
# -----------------------------------------------------------------------------

PYTHON_DEFAULT="/home/carolyn.wagner/envs/layerfmri/bin/python"
PYTHON="${PYTHON:-${PYTHON_DEFAULT}}"

[[ -x "${PYTHON}" ]] || {
    echo "ERROR: Python executable not found: ${PYTHON}" >&2
    exit 1
}

RESOLVED="$(
env -u PYTHONPATH -u PYTHONHOME "${PYTHON}" - "${CONFIG}" "${SESSION}" <<'PY'
import os
import re
import sys
from pathlib import Path
import yaml

cfg_path = Path(sys.argv[1])
requested_session = sys.argv[2]

with cfg_path.open("r", encoding="utf-8") as stream:
    cfg = yaml.safe_load(stream)

def expand(value, mapping):
    value = str(value)
    for _ in range(12):
        new = value
        for key, replacement in mapping.items():
            new = new.replace("${" + key + "}", str(replacement))
        if new == value:
            return new
        value = new
    return value

dataset = cfg.get("dataset", {}) or {}
subject = str(cfg.get("subject") or dataset.get("subject") or "")
if not subject:
    raise SystemExit("ERROR: could not resolve subject from YAML.")

paths = cfg.get("paths", {}) or {}
project_root = str(paths.get("project_root", ""))
roi_root = str(paths.get("roi_root", ""))
pipeline_root = str(paths.get("pipeline_root", ""))

mapping = {
    "dataset.subject": subject,
    "dataset.session": requested_session,
    "paths.project_root": project_root,
    "paths.roi_root": roi_root,
    "paths.pipeline_root": pipeline_root,
}

project_root = expand(project_root, mapping)
mapping["paths.project_root"] = project_root
roi_root = expand(roi_root, mapping)
mapping["paths.roi_root"] = roi_root
pipeline_root = expand(pipeline_root, mapping)
mapping["paths.pipeline_root"] = pipeline_root

subject_root = paths.get("subject_root")
if subject_root:
    subject_root = expand(subject_root, mapping)
else:
    subject_root = str(Path(pipeline_root) / "outputs" / subject)
mapping["paths.subject_root"] = subject_root

session_root = paths.get("session_root")
if session_root:
    session_root = expand(session_root, mapping)
else:
    session_root = str(Path(subject_root) / requested_session)
mapping["paths.session_root"] = session_root

layers_dir = expand(
    paths.get("layers_dir", str(Path(session_root) / "layers")),
    mapping,
)
psc_dir = expand(
    paths.get("psc_dir", str(Path(session_root) / "psc")),
    mapping,
)
dom_dir = expand(
    paths.get("dominance_dir", str(Path(session_root) / "dominance")),
    mapping,
)
true_uv_dir = expand(
    paths.get("true_uv_dir", str(Path(session_root) / "true_uv")),
    mapping,
)

frozen = cfg.get("frozen", {}) or {}
radius = float(frozen.get("multilateration_radius_mm", 30))
flat_bin = float(frozen.get("flat_bin_width_mm", 0.275))
depth_bins = int(frozen.get("depth_bins", 20))

# Step-09 products are radius-specific by construction.
# Do not reuse a potentially stale paths.flat_uvd_dir (e.g. radius30)
# when running a sensitivity candidate at another radius.
radius_tag = f"{radius:g}"
flat_dir = str(Path(session_root) / f"flat_uvd_radius{radius_tag}")

software = cfg.get("software", {}) or {}
laynii = str(
    software.get(
        "laynii_dir",
        "/home/carolyn.wagner/software/laynii",
    )
)

print(f"SUBJECT={subject}")
print(f"BASE={session_root}")
print(f"LAYERS_DIR={layers_dir}")
print(f"PSC_DIR={psc_dir}")
print(f"DOM_DIR={dom_dir}")
print(f"UV_DIR={true_uv_dir}")
print(f"OUT_DIR={flat_dir}")
print(f"LAYNII_DIR={laynii}")
print(f"RADIUS_MM={radius:g}")
print(f"FLAT_BIN_MM_CFG={flat_bin:g}")
print(f"BINS_D_CFG={depth_bins}")
PY
)"

eval "${RESOLVED}"

LAYNII="${LAYNII:-${LAYNII_DIR}}"
RADIUS_MM="${RADIUS_MM_OVERRIDE:-${RADIUS_MM}}"
FLAT_BIN_MM="${FLAT_BIN_MM:-${FLAT_BIN_MM_CFG}}"
BINS_D="${BINS_D:-${BINS_D_CFG}}"
BINS_U="${BINS_U:-}"
BINS_V="${BINS_V:-}"

SESSION_COMPACT="${SESSION//-/}"
RADIUS_TAG="radius${RADIUS_MM}"

# Radius-specific Step-09 output root. This deliberately overrides any
# historical/stale flat_uvd_dir path from the YAML.
OUT_DIR="${BASE}/flat_uvd_${RADIUS_TAG}"

UV_COORD="${UV_COORD:-${UV_DIR}/${SESSION_COMPACT}_multilaterate_${RADIUS_TAG}_corrected_UV_coordinates.nii}"
DOMAIN="${DOMAIN:-${UV_DIR}/${SESSION_COMPACT}_multilaterate_${RADIUS_TAG}_corrected_perimeter_chunk.nii}"
DEPTH_COORD="${DEPTH_COORD:-${LAYERS_DIR}/depth3_metric_equidist.nii}"

# Fail fast if radius provenance is inconsistent.
EXPECTED_TOKEN="${RADIUS_TAG}"
if [[ "${UV_COORD}" != *"${EXPECTED_TOKEN}"* ]]; then
    echo "ERROR: Step-09 UV-coordinate radius mismatch." >&2
    echo "Configured radius: ${RADIUS_MM} mm" >&2
    echo "UV coordinates:    ${UV_COORD}" >&2
    exit 1
fi
if [[ "${DOMAIN}" != *"${EXPECTED_TOKEN}"* ]]; then
    echo "ERROR: Step-09 domain radius mismatch." >&2
    echo "Configured radius: ${RADIUS_MM} mm" >&2
    echo "Domain:            ${DOMAIN}" >&2
    exit 1
fi
if [[ "${OUT_DIR}" != *"${EXPECTED_TOKEN}" ]]; then
    echo "ERROR: Step-09 output-root radius mismatch." >&2
    echo "Configured radius: ${RADIUS_MM} mm" >&2
    echo "Output root:       ${OUT_DIR}" >&2
    exit 1
fi

RAW_DIR="${OUT_DIR}/raw"
DISPLAY_DIR="${OUT_DIR}/display_voronoi"
QC_DIR="${OUT_DIR}/qc"

mkdir -p "${RAW_DIR}" "${DISPLAY_DIR}" "${QC_DIR}"

LN2_PATCH_FLATTEN="${LAYNII}/LN2_PATCH_FLATTEN"
if [[ ! -x "${LN2_PATCH_FLATTEN}" ]]; then
    if command -v LN2_PATCH_FLATTEN >/dev/null 2>&1; then
        LN2_PATCH_FLATTEN="$(command -v LN2_PATCH_FLATTEN)"
    else
        echo "ERROR: LN2_PATCH_FLATTEN not found." >&2
        echo "Tried: ${LAYNII}/LN2_PATCH_FLATTEN" >&2
        exit 1
    fi
fi

for file in "${UV_COORD}" "${DOMAIN}" "${DEPTH_COORD}"; do
    [[ -f "${file}" ]] || {
        echo "ERROR: required Step-09 coordinate input not found:" >&2
        echo "  ${file}" >&2
        exit 1
    }
done

# -----------------------------------------------------------------------------
# Coordinate/depth preflight and physical U/V binning.
# -----------------------------------------------------------------------------

COORD_QC="${QC_DIR}/flatten_coordinate_qc.csv"
COORD_JSON="${QC_DIR}/flatten_coordinate_qc.json"

BIN_INFO="$(
env -u PYTHONPATH -u PYTHONHOME "${PYTHON}" - \
    "${UV_COORD}" \
    "${DOMAIN}" \
    "${DEPTH_COORD}" \
    "${FLAT_BIN_MM}" \
    "${BINS_U}" \
    "${BINS_V}" \
    "${BINS_D}" \
    "${COORD_QC}" \
    "${COORD_JSON}" <<'PY'
import csv
import json
import math
import sys
from pathlib import Path

import nibabel as nib
import numpy as np
from scipy import ndimage

(
    uv_path,
    domain_path,
    depth_path,
    bin_width_text,
    bins_u_override,
    bins_v_override,
    bins_d_text,
    qc_csv,
    qc_json,
) = sys.argv[1:]

bin_width = float(bin_width_text)
bins_d = int(bins_d_text)

if not np.isfinite(bin_width) or bin_width <= 0:
    raise SystemExit("ERROR: flat-bin width must be finite and > 0.")
if bins_d < 2:
    raise SystemExit("ERROR: cortical-depth bins must be >= 2.")

uv_img = nib.load(uv_path)
domain_img = nib.load(domain_path)
depth_img = nib.load(depth_path)

if len(uv_img.shape) != 4 or uv_img.shape[3] != 2:
    raise SystemExit(
        "ERROR: UV coordinate image must have shape X×Y×Z×2; "
        f"found {uv_img.shape}."
    )

for name, img in (("domain", domain_img), ("depth metric", depth_img)):
    if img.shape[:3] != uv_img.shape[:3]:
        raise SystemExit(
            f"ERROR: {name} shape {img.shape[:3]} does not match "
            f"UV grid {uv_img.shape[:3]}."
        )
    if not np.allclose(
        uv_img.affine,
        img.affine,
        atol=1e-4,
        rtol=0.0,
    ):
        raise SystemExit(f"ERROR: {name} affine does not match UV grid.")

uv = uv_img.get_fdata(dtype=np.float32)
domain = domain_img.get_fdata(dtype=np.float32) > 0
depth = depth_img.get_fdata(dtype=np.float32)

valid = (
    domain
    & np.isfinite(uv[..., 0])
    & np.isfinite(uv[..., 1])
    & np.isfinite(depth)
)

n_domain = int(domain.sum())
n_valid = int(valid.sum())
if n_domain < 20:
    raise SystemExit(f"ERROR: perimeter domain has only {n_domain} voxels.")
if n_valid != n_domain:
    raise SystemExit(
        f"ERROR: {n_domain - n_valid} domain voxels lack finite U/V/depth."
    )

u = uv[..., 0][valid].astype(np.float64)
v = uv[..., 1][valid].astype(np.float64)
d = depth[valid].astype(np.float64)

u_min, u_max = float(u.min()), float(u.max())
v_min, v_max = float(v.min()), float(v.max())
d_min, d_max = float(d.min()), float(d.max())
u_span = u_max - u_min
v_span = v_max - v_min

if u_span <= 0 or v_span <= 0:
    raise SystemExit(
        f"ERROR: degenerate coordinate span U={u_span}, V={v_span}."
    )

# The Step-02 depth metric is expected to be normalized to [0,1].
depth_tol = 1e-4
if d_min < -depth_tol or d_max > 1.0 + depth_tol:
    raise SystemExit(
        "ERROR: depth3_metric_equidist is outside expected normalized "
        f"range [0,1]: {d_min} .. {d_max}"
    )

if bins_u_override.strip():
    bins_u = int(bins_u_override)
else:
    bins_u = max(2, int(math.ceil(u_span / bin_width)) + 1)

if bins_v_override.strip():
    bins_v = int(bins_v_override)
else:
    bins_v = max(2, int(math.ceil(v_span / bin_width)) + 1)

if bins_u < 2 or bins_v < 2:
    raise SystemExit("ERROR: BINS_U and BINS_V must be >= 2.")

effective_u = u_span / max(1, bins_u - 1)
effective_v = v_span / max(1, bins_v - 1)

# Connected-domain diagnostic.
labels, n_components = ndimage.label(
    domain,
    structure=np.ones((3, 3, 3), dtype=np.uint8),
)
sizes = np.bincount(labels.ravel())[1:] if n_components else np.array([])
largest_fraction = (
    float(sizes.max() / sizes.sum()) if sizes.size else np.nan
)

rows = [
    ("domain_voxels", n_domain, "HARD", True),
    ("valid_uvd_voxels", n_valid, "HARD", n_valid == n_domain),
    ("domain_components_26conn", int(n_components), "DIAGNOSTIC", n_components == 1),
    ("largest_component_fraction", largest_fraction, "DIAGNOSTIC", largest_fraction >= 0.95),
    ("u_min_mm", u_min, "DESCRIPTIVE", True),
    ("u_max_mm", u_max, "DESCRIPTIVE", True),
    ("u_span_mm", u_span, "HARD", u_span > 0),
    ("v_min_mm", v_min, "DESCRIPTIVE", True),
    ("v_max_mm", v_max, "DESCRIPTIVE", True),
    ("v_span_mm", v_span, "HARD", v_span > 0),
    ("depth_min", d_min, "HARD", d_min >= -depth_tol),
    ("depth_max", d_max, "HARD", d_max <= 1.0 + depth_tol),
    ("requested_flat_bin_mm", bin_width, "FROZEN", True),
    ("bins_u", bins_u, "FROZEN", True),
    ("bins_v", bins_v, "FROZEN", True),
    ("bins_d", bins_d, "FROZEN", True),
    ("effective_u_bin_mm", effective_u, "DESCRIPTIVE", True),
    ("effective_v_bin_mm", effective_v, "DESCRIPTIVE", True),
]

Path(qc_csv).parent.mkdir(parents=True, exist_ok=True)
with open(qc_csv, "w", newline="", encoding="utf-8") as stream:
    writer = csv.writer(stream)
    writer.writerow(["metric", "value", "level", "pass"])
    writer.writerows(rows)

summary = {
    "status": "PASS",
    "domain_voxels": n_domain,
    "valid_uvd_voxels": n_valid,
    "domain_components_26conn": int(n_components),
    "largest_component_fraction": largest_fraction,
    "u_range_mm": [u_min, u_max],
    "u_span_mm": u_span,
    "v_range_mm": [v_min, v_max],
    "v_span_mm": v_span,
    "depth_range": [d_min, d_max],
    "requested_flat_bin_mm": bin_width,
    "bins": [bins_u, bins_v, bins_d],
    "effective_u_bin_mm": effective_u,
    "effective_v_bin_mm": effective_v,
}
Path(qc_json).write_text(json.dumps(summary, indent=2), encoding="utf-8")

# First line is machine-readable by Bash.
print(f"{bins_u} {bins_v}")
print(
    f"U range: {u_min:.6f} to {u_max:.6f} mm "
    f"(span {u_span:.6f} mm)"
)
print(
    f"V range: {v_min:.6f} to {v_max:.6f} mm "
    f"(span {v_span:.6f} mm)"
)
print(f"D range: {d_min:.6f} to {d_max:.6f}")
print(f"Flat bins: U={bins_u}, V={bins_v}, D={bins_d}")
print(
    "Effective bin widths: "
    f"U={effective_u:.6f} mm, V={effective_v:.6f} mm"
)
PY
)"

BIN_LINE="$(printf '%s\n' "${BIN_INFO}" | head -n 1)"
read -r RESOLVED_BINS_U RESOLVED_BINS_V <<< "${BIN_LINE}"

echo "============================================================"
echo "HuberPipeline Step 09: LN2_PATCH_FLATTEN"
echo "============================================================"
echo "Session:        ${SESSION}"
echo "UV coordinates: ${UV_COORD}"
echo "Depth metric:   ${DEPTH_COORD}"
echo "Domain:         ${DOMAIN}"
echo "Flat-bin target:${FLAT_BIN_MM} mm"
echo "Bins U/V/D:     ${RESOLVED_BINS_U}/${RESOLVED_BINS_V}/${BINS_D}"
echo "Output root:    ${OUT_DIR}"
echo "Radius branch:  ${RADIUS_TAG}"
echo "Quantitative:   raw non-Voronoi"
echo "Display only:   Voronoi-filled"
if [[ "${QC_ONLY}" -eq 1 ]]; then
    echo "Mode:           QC ONLY"
else
    echo "Mode:           RUN + QC"
fi
echo
printf '%s\n' "${BIN_INFO}" | tail -n +2
echo

# -----------------------------------------------------------------------------
# Frozen list of 22 continuous value maps.
# -----------------------------------------------------------------------------

FINGERS=(thumb index middle ring little)
VALUE_NAMES=()
VALUE_FILES=()

require_map() {
    local name="$1"
    local file="$2"
    [[ -f "${file}" ]] || {
        echo "ERROR: required Step-09 value map not found:" >&2
        echo "  ${file}" >&2
        exit 1
    }
    VALUE_NAMES+=("${name}")
    VALUE_FILES+=("${file}")
}

for finger in "${FINGERS[@]}"; do
    require_map "psc_${finger}" \
        "${PSC_DIR}/psc_${finger}.nii.gz"
    require_map "dominance_fraction_${finger}" \
        "${DOM_DIR}/dominance_fraction_${finger}.nii.gz"
    require_map "selectivity_${finger}" \
        "${DOM_DIR}/selectivity_${finger}.nii.gz"
    require_map "dominance_ratio_${finger}" \
        "${DOM_DIR}/dominance_${finger}.nii.gz"
done

require_map "maximum_finger_psc" \
    "${DOM_DIR}/maximum_finger_psc.nii.gz"
require_map "winner_margin_psc" \
    "${DOM_DIR}/winner_margin_psc.nii.gz"

if [[ "${#VALUE_FILES[@]}" -ne 22 ]]; then
    echo "ERROR: Step 09 must receive exactly 22 continuous maps; found ${#VALUE_FILES[@]}." >&2
    exit 1
fi

# Validate all 22 source maps against the Step-08 grid before flattening.
env -u PYTHONPATH -u PYTHONHOME "${PYTHON}" - \
    "${UV_COORD}" "${VALUE_FILES[@]}" <<'PY'
import sys
from pathlib import Path

import nibabel as nib
import numpy as np

reference_path = Path(sys.argv[1])
value_paths = [Path(item) for item in sys.argv[2:]]

reference = nib.load(str(reference_path))

for path in value_paths:
    image = nib.load(str(path))
    if image.shape[:3] != reference.shape[:3]:
        raise SystemExit(
            "ERROR: source-map shape mismatch:\n"
            f"  UV grid: {reference.shape[:3]}\n"
            f"  {path}: {image.shape[:3]}"
        )
    if not np.allclose(
        reference.affine,
        image.affine,
        atol=1e-4,
        rtol=0.0,
    ):
        raise SystemExit(
            f"ERROR: source-map affine mismatch:\n  {path}"
        )

print(f"Validated {len(value_paths)} value maps against the UV grid.")
PY

# -----------------------------------------------------------------------------
# Flatten every map.
# -----------------------------------------------------------------------------

if [[ "${QC_ONLY}" -eq 0 ]]; then
    for index in "${!VALUE_FILES[@]}"; do
        name="${VALUE_NAMES[$index]}"
        values="${VALUE_FILES[$index]}"

        raw_base="${RAW_DIR}/${name}_flat_raw"
        display_base="${DISPLAY_DIR}/${name}_flat_voronoi"

        echo
        echo "------------------------------------------------------------"
        echo "Flattening: ${name}"
        echo "Input:      ${values}"
        echo "------------------------------------------------------------"

        rm -f "${raw_base}"*.nii "${raw_base}"*.nii.gz
        rm -f "${display_base}"*.nii "${display_base}"*.nii.gz

        # PRIMARY QUANTITATIVE PRODUCT.
        # Empty U×V×D bins remain empty. No interpolation/filling is applied.
        "${LN2_PATCH_FLATTEN}" \
            -values "${values}" \
            -coord_uv "${UV_COORD}" \
            -coord_d "${DEPTH_COORD}" \
            -domain "${DOMAIN}" \
            -bins_u "${RESOLVED_BINS_U}" \
            -bins_v "${RESOLVED_BINS_V}" \
            -bins_d "${BINS_D}" \
            -density \
            -norm_mask \
            -debug \
            -output "${raw_base}"

        # DISPLAY-ONLY PRODUCT.
        # Voronoi nearest-neighbour propagation fills empty flat bins.
        "${LN2_PATCH_FLATTEN}" \
            -values "${values}" \
            -coord_uv "${UV_COORD}" \
            -coord_d "${DEPTH_COORD}" \
            -domain "${DOMAIN}" \
            -bins_u "${RESOLVED_BINS_U}" \
            -bins_v "${RESOLVED_BINS_V}" \
            -bins_d "${BINS_D}" \
            -voronoi \
            -density \
            -norm_mask \
            -output "${display_base}"
    done
else
    echo "QC-only mode: preserving and validating existing flattened outputs."
fi

# -----------------------------------------------------------------------------
# Post-flatten HARD validation, support diagnostics, and visual QC.
# -----------------------------------------------------------------------------

FLAT_QC_CSV="${QC_DIR}/flatten_outputs_qc.csv"
FLAT_SUMMARY_JSON="${QC_DIR}/flatten_summary.json"
FLAT_SUMMARY_TXT="${QC_DIR}/flatten_summary.txt"
FLAT_QC_PNG="${QC_DIR}/flatten_qc.png"

env -u PYTHONPATH -u PYTHONHOME MPLBACKEND=Agg "${PYTHON}" - \
    "${RAW_DIR}" \
    "${DISPLAY_DIR}" \
    "${RESOLVED_BINS_U}" \
    "${RESOLVED_BINS_V}" \
    "${BINS_D}" \
    "${FLAT_QC_CSV}" \
    "${FLAT_SUMMARY_JSON}" \
    "${FLAT_SUMMARY_TXT}" \
    "${FLAT_QC_PNG}" \
    "${VALUE_NAMES[@]}" <<'PY'
import csv
import json
import sys
from pathlib import Path

import matplotlib
matplotlib.use("Agg", force=True)
import matplotlib.pyplot as plt
import nibabel as nib
import numpy as np
from scipy import ndimage

raw_dir = Path(sys.argv[1])
display_dir = Path(sys.argv[2])
nu, nv, nd = map(int, sys.argv[3:6])
qc_csv = Path(sys.argv[6])
summary_json = Path(sys.argv[7])
summary_txt = Path(sys.argv[8])
qc_png = Path(sys.argv[9])
names = sys.argv[10:]

expected_shape = (nu, nv, nd)
if len(names) != 22:
    raise SystemExit(
        f"ERROR: expected 22 map names in post-flatten QC; found {len(names)}."
    )

def exactly_one(paths, label):
    paths = sorted(paths)
    if len(paths) != 1:
        raise SystemExit(
            f"ERROR: expected exactly one {label}; found {len(paths)}:\n"
            + "\n".join(str(p) for p in paths)
        )
    return paths[0]

rows = []
raw_main = {}
raw_density = {}
raw_domain = {}
display_main = {}

for name in names:
    raw = exactly_one(
        raw_dir.glob(
            f"{name}_flat_raw_flat_{nu}x{nv}x{nd}.nii*"
        ),
        f"raw flat map for {name}",
    )
    density = exactly_one(
        raw_dir.glob(
            f"{name}_flat_raw_flat_{nu}x{nv}x{nd}_density.nii*"
        ),
        f"raw density map for {name}",
    )
    domain = exactly_one(
        raw_dir.glob(
            f"{name}_flat_raw_flat_{nu}x{nv}x{nd}_domain.nii*"
        ),
        f"raw flat-domain map for {name}",
    )
    display = exactly_one(
        display_dir.glob(
            f"{name}_flat_voronoi_flat_{nu}x{nv}x{nd}_voronoi.nii*"
        ),
        f"Voronoi display map for {name}",
    )

    raw_img = nib.load(str(raw))
    density_img = nib.load(str(density))
    domain_img = nib.load(str(domain))
    display_img = nib.load(str(display))

    for label, img in (
        ("raw", raw_img),
        ("density", density_img),
        ("domain", domain_img),
        ("display", display_img),
    ):
        if img.shape[:3] != expected_shape:
            raise SystemExit(
                f"ERROR: {name} {label} shape {img.shape[:3]} "
                f"!= {expected_shape}."
            )

    r = raw_img.get_fdata(dtype=np.float32)
    den = density_img.get_fdata(dtype=np.float32)
    dom = domain_img.get_fdata(dtype=np.float32) > 0
    disp = display_img.get_fdata(dtype=np.float32)

    support = np.isfinite(den) & (den > 0)
    supported_domain = dom & support

    n_support = int(np.count_nonzero(support))
    n_domain = int(np.count_nonzero(dom))
    n_supported_domain = int(np.count_nonzero(supported_domain))
    raw_finite_supported = int(
        np.count_nonzero(np.isfinite(r) & supported_domain)
    )
    display_finite_domain = int(
        np.count_nonzero(np.isfinite(disp) & dom)
    )

    # LAYNII writes numeric zeros in empty bins; density/domain are therefore
    # the authoritative support masks. Do not interpret zeros as missing data.
    if n_support == 0:
        raise SystemExit(f"ERROR: {name} has zero flattened sampling support.")
    if n_domain == 0:
        raise SystemExit(f"ERROR: {name} has an empty flattened domain.")

    labels, n_components = ndimage.label(
        np.any(support, axis=2),
        structure=np.ones((3, 3), dtype=np.uint8),
    )
    sizes = (
        np.bincount(labels.ravel())[1:]
        if n_components
        else np.array([], dtype=int)
    )
    lcc_fraction = (
        float(sizes.max() / sizes.sum())
        if sizes.size
        else np.nan
    )

    rows.append(
        {
            "map": name,
            "raw_file": str(raw),
            "density_file": str(density),
            "domain_file": str(domain),
            "display_file": str(display),
            "shape_u": nu,
            "shape_v": nv,
            "shape_d": nd,
            "raw_supported_bins": n_support,
            "raw_domain_bins": n_domain,
            "raw_supported_domain_bins": n_supported_domain,
            "raw_finite_supported_bins": raw_finite_supported,
            "display_finite_domain_bins": display_finite_domain,
            "depth_averaged_support_components": int(n_components),
            "depth_averaged_lcc_fraction": lcc_fraction,
            "hard_pass": True,
        }
    )

    raw_main[name] = r
    raw_density[name] = den
    raw_domain[name] = dom
    display_main[name] = disp

qc_csv.parent.mkdir(parents=True, exist_ok=True)
with qc_csv.open("w", newline="", encoding="utf-8") as stream:
    writer = csv.DictWriter(stream, fieldnames=list(rows[0].keys()))
    writer.writeheader()
    writer.writerows(rows)

# Cross-map support consistency. All maps were flattened with the same
# coordinates/domain, so density/domain support should match exactly.
reference_name = names[0]
reference_support = raw_density[reference_name] > 0
reference_domain = raw_domain[reference_name]

support_mismatches = {}
domain_mismatches = {}
for name in names[1:]:
    support_mismatches[name] = int(
        np.count_nonzero(
            (raw_density[name] > 0) != reference_support
        )
    )
    domain_mismatches[name] = int(
        np.count_nonzero(
            raw_domain[name] != reference_domain
        )
    )

max_support_mismatch = max(support_mismatches.values(), default=0)
max_domain_mismatch = max(domain_mismatches.values(), default=0)

if max_support_mismatch != 0:
    raise SystemExit(
        "ERROR: raw density support differs across flattened maps; "
        f"maximum mismatch={max_support_mismatch} bins."
    )
if max_domain_mismatch != 0:
    raise SystemExit(
        "ERROR: flat domain differs across flattened maps; "
        f"maximum mismatch={max_domain_mismatch} bins."
    )

# Primary quantitative support statistics.
#
# LAYNII's density and domain outputs are not nested masks. Quantitative
# support is therefore their explicit intersection.
support = reference_support
domain = reference_domain
valid_support = support & domain

n_flat_total = int(np.prod(expected_shape))
n_density_support = int(np.count_nonzero(support))
n_domain = int(np.count_nonzero(domain))
n_valid_support = int(np.count_nonzero(valid_support))
n_domain_without_density = int(np.count_nonzero(domain & ~support))
n_density_outside_domain = int(np.count_nonzero(support & ~domain))

support_fraction_total = n_valid_support / n_flat_total
support_fraction_domain = (
    n_valid_support / n_domain if n_domain else np.nan
)

if n_valid_support == 0:
    raise SystemExit(
        "ERROR: no valid quantitative bins remain after domain ∩ density."
    )

diagnostic_warnings = []
if np.isfinite(support_fraction_domain) and support_fraction_domain < 0.05:
    diagnostic_warnings.append("very_sparse_raw_sampling_within_flat_domain")

# ------------------------------------------------------------------
# Visual QC: raw depth-averaged density + five dominance fractions.
# ------------------------------------------------------------------
fig, axes = plt.subplots(2, 3, figsize=(12.5, 8.0))
fig.suptitle(
    f"Step 09 flattened-domain QC | U×V×D = {nu}×{nv}×{nd}",
    fontsize=13,
)

density2d = np.sum(
    np.where(np.isfinite(raw_density[reference_name]),
             raw_density[reference_name], 0.0),
    axis=2,
)
im = axes[0, 0].imshow(
    density2d.T,
    origin="lower",
    interpolation="nearest",
    aspect="auto",
)
axes[0, 0].set_title("Raw sampling density (summed over depth)")
axes[0, 0].set_xlabel("U bin")
axes[0, 0].set_ylabel("V bin")
fig.colorbar(im, ax=axes[0, 0], fraction=0.046, pad=0.04)

finger_names = ["thumb", "index", "middle", "ring", "little"]
for ax, finger in zip(axes.flat[1:], finger_names):
    name = f"dominance_fraction_{finger}"
    values = raw_main[name]
    density = raw_density[name]
    valid = density > 0

    weighted_sum = np.sum(
        np.where(valid, values * density, 0.0),
        axis=2,
    )
    weight_sum = np.sum(
        np.where(valid, density, 0.0),
        axis=2,
    )
    mean = np.full(weight_sum.shape, np.nan, dtype=np.float32)
    ok = weight_sum > 0
    mean[ok] = weighted_sum[ok] / weight_sum[ok]

    image = ax.imshow(
        mean.T,
        origin="lower",
        interpolation="nearest",
        aspect="auto",
        vmin=0.0,
        vmax=1.0,
    )
    ax.set_title(f"{finger.title()} — raw dominance fraction")
    ax.set_xlabel("U bin")
    ax.set_ylabel("V bin")
    fig.colorbar(image, ax=ax, fraction=0.046, pad=0.04)

fig.tight_layout(rect=[0, 0, 1, 0.95])
fig.savefig(qc_png, dpi=220, bbox_inches="tight")
plt.close(fig)

summary = {
    "status": "PASS",
    "shape": [nu, nv, nd],
    "n_maps": len(names),
    "raw_quantitative_directory": str(raw_dir),
    "voronoi_display_directory": str(display_dir),
    "flat_total_bins": n_flat_total,
    "raw_density_supported_bins": n_density_support,
    "raw_domain_bins": n_domain,
    "raw_valid_domain_intersection_density_bins": n_valid_support,
    "raw_domain_bins_without_density": n_domain_without_density,
    "raw_density_bins_outside_domain": n_density_outside_domain,
    "raw_valid_support_fraction_total": support_fraction_total,
    "raw_valid_support_fraction_domain": support_fraction_domain,
    "max_cross_map_support_mismatch_bins": max_support_mismatch,
    "max_cross_map_domain_mismatch_bins": max_domain_mismatch,
    "diagnostic_warnings": diagnostic_warnings,
    "quantitative_input": "raw_non_voronoi",
    "voronoi_use": "display_only",
}
summary_json.write_text(json.dumps(summary, indent=2), encoding="utf-8")

with summary_txt.open("w", encoding="utf-8") as stream:
    stream.write("Step 09 LN2_PATCH_FLATTEN validation\n")
    stream.write("===================================\n\n")
    stream.write(f"Flat shape: U={nu}, V={nv}, D={nd}\n")
    stream.write(f"Flattened maps: {len(names)}\n")
    stream.write(f"Raw density-supported bins: {n_density_support}\n")
    stream.write(f"Raw domain bins: {n_domain}\n")
    stream.write(f"Raw domain ∩ density bins: {n_valid_support}\n")
    stream.write(
        f"Domain bins without raw density: "
        f"{n_domain_without_density}\n"
    )
    stream.write(
        f"Density-supported bins outside domain: "
        f"{n_density_outside_domain}\n"
    )
    stream.write(
        f"Raw supported fraction of domain: "
        f"{support_fraction_domain:.6f}\n"
    )
    stream.write(
        f"Cross-map support mismatch: {max_support_mismatch}\n"
    )
    stream.write(
        f"Cross-map domain mismatch: {max_domain_mismatch}\n"
    )
    stream.write(f"Diagnostic warnings: {diagnostic_warnings}\n")
    stream.write("Quantitative input: raw_non_voronoi\n")
    stream.write("Voronoi use: display_only\n")
    stream.write("Hard validation: PASS\n")

print("")
print("Post-flatten validation:")
print(f"  Flat shape:                  {nu} × {nv} × {nd}")
print(f"  Flattened continuous maps:  {len(names)}")
print(f"  Raw density-supported bins: {n_density_support}")
print(f"  Raw domain bins:            {n_domain}")
print(f"  Raw domain ∩ density bins:  {n_valid_support}")
print(f"  Domain without density:     {n_domain_without_density}")
print(f"  Density outside domain:     {n_density_outside_domain}")
print(
    f"  Raw supported/domain:       "
    f"{100.0 * support_fraction_domain:.2f}%"
)
print(f"  Cross-map support mismatch: {max_support_mismatch}")
print(f"  Cross-map domain mismatch:  {max_domain_mismatch}")
print(
    f"  Diagnostic warnings:        "
    f"{diagnostic_warnings if diagnostic_warnings else 'NONE'}"
)
print("  Hard validation:            PASS")
PY

echo
echo "============================================================"
echo "Step 09 completed"
echo "============================================================"
echo "Primary quantitative outputs:"
echo "  ${RAW_DIR}"
echo
echo "Display-only Voronoi outputs:"
echo "  ${DISPLAY_DIR}"
echo
echo "Coordinate QC:"
echo "  ${COORD_QC}"
echo
echo "Flattened-output QC:"
echo "  ${FLAT_QC_CSV}"
echo
echo "QC figure:"
echo "  ${FLAT_QC_PNG}"
echo
echo "Summary:"
echo "  ${FLAT_SUMMARY_TXT}"
echo
echo "Before Step 10, inspect the QC figure and confirm:"
echo "  - the raw density map samples one coherent U×V patch;"
echo "  - the five raw dominance-fraction maps retain plausible gradients;"
echo "  - no duplicated/mirrored branch appears after flattening;"
echo "  - sparse regions correspond to genuinely unsampled raw bins;"
echo "  - Voronoi products are used for display only."
