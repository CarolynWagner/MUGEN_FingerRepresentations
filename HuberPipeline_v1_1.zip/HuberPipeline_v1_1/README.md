# HuberPipeline v1.1

Clean production package for the frozen high-resolution M1 reference analysis. There is exactly one canonical production implementation per Step 01-15.

## Standard run
```bash
./run_pipeline.sh 00_config.yaml ses-18
./run_pipeline.sh 00_config.yaml ses-18 --from 10 --to 13
```

## Radius sensitivity
Do not maintain a second full YAML.
```bash
./run_radius_candidate.sh 00_config.yaml ses-18 --radius 30 --from-step 9
./run_radius_candidate.sh 00_config.yaml ses-18 --radius 40 --from-step 9
python 14_compare_multilaterate_radius.py 00_config.yaml ses-18 --radii 30 40
```
The wrapper creates a temporary radius override and leaves the frozen 30-mm base config unchanged.

## Scientific freeze
v1.1 is a software refactor, not a new method. Anatomy-only U/V construction, the frozen 30-mm reference radius, raw non-Voronoi quantitative inputs, display-only interpolation, U-vs-V testing, support-aware three-bin windows, strict supported intervals and explicit radius sensitivity remain unchanged.

## MUGEN_fMRI
See `MUGEN_FMRI_INTERFACE.md`. MUGEN_fMRI owns preprocessing/GLM/generic QA; HuberPipeline owns specialized cortical geometry, somatotopy and depth analysis.

## Historical material
Reference validation is under `validation/sub-01_ses-18/`. Development notes are under `archive/development_history/` and are not part of production execution.
