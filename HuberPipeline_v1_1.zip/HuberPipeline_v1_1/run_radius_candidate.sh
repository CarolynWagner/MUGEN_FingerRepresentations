#!/usr/bin/env bash
set -euo pipefail
D="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"; cd "$D"
CONFIG="${1:-}"; SESSION="${2:-}"; [[ -n "$CONFIG" && -n "$SESSION" ]] || { echo "Usage: $0 CONFIG SESSION --radius MM [candidate options]" >&2; exit 2; }; shift 2
RADIUS=""; REST=(); while [[ $# -gt 0 ]]; do case "$1" in --radius) RADIUS="${2:?missing radius}"; shift 2;; *) REST+=("$1"); shift;; esac; done
[[ -n "$RADIUS" ]] || { echo "ERROR: --radius MM is required" >&2; exit 2; }
TMP="$(mktemp "${TMPDIR:-/tmp}/huber_radius_${RADIUS}_XXXX.yaml")"; trap 'rm -f "$TMP"' EXIT
python - "$CONFIG" "$TMP" "$RADIUS" <<'PY2'
import sys,yaml
c=yaml.safe_load(open(sys.argv[1])); c.setdefault('frozen',{})['multilateration_radius_mm']=float(sys.argv[3])
with open(sys.argv[2],'w') as f: yaml.safe_dump(c,f,sort_keys=False)
PY2
echo "Radius candidate: ${RADIUS} mm (temporary override; base config unchanged)"
exec "$D/_run_radius_candidate_internal.sh" "$TMP" "$SESSION" "${REST[@]}"
