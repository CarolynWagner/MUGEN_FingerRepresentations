# Changelog

## 1.1.0
- One canonical production file for each Step 01-15.
- Final Step 06 promoted to canonical filename; robust laminar analysis canonicalized as Step 13.
- Final validated Step-15 v1.0.8 included as session-agnostic `15_generate_publication_figures.py`.
- One production wrapper; historical GCC wrappers archived/removed.
- Duplicate radius-40 YAML removed; radius candidates now use `--radius` temporary overrides.
- Stale radius-specific output aliases removed from the structured path block.
- ses-18 validation records separated from production code.
- Development notes archived.
- MUGEN_fMRI/Huber responsibility boundary documented.
- Scientific wording corrected: radius sensitivity does not select the production radius.

Compatibility: Steps 01, 03, 04 and 05 retain historical top-level YAML keys to preserve the frozen ses-18 computation. Remove them only after a regression-tested MUGEN_fMRI derivative adapter exists.
