
#!/usr/bin/env python3
"""
HuberPipeline Step 07
=====================

Prepare and validate the CASE-II control image required by LN2_MULTILATERATE.

Scientific role
---------------
Step 06 generates an anatomy-only image containing exactly five intrinsic
control-point labels:

    2 = origin
    3 = min U
    4 = max U
    5 = min V
    6 = max V

LN2_MULTILATERATE CASE II should not receive an otherwise empty five-voxel
image. The control-point labels must be embedded in the complete middle-GM
sheet. Step 07 therefore constructs a canonical CASE-II image:

    background              = 0
    ordinary middle-GM      = 1
    five special landmarks = 2, 3, 4, 5, 6

The geometry and endpoint selection are NOT changed in Step 07.

Preferred usage
---------------
Config/session mode:

    python 07_prepare_multilaterate_control_image.py \
        00_config.yaml ses-18

Explicit mode:

    python 07_prepare_multilaterate_control_image.py \
        --rim /path/to/rim.nii.gz \
        --midgm /path/to/depth3_midGM_equidist.nii \
        --control-points /path/to/uv_control_points_anatomical.nii.gz \
        --output /path/to/uv_control_points_caseII.nii.gz

Outputs
-------
<output>
<output_stem>_landmarks.csv
<output_stem>_value_counts.csv
<output_stem>_summary.txt
<output_stem>_summary.json
<output_stem>_qc.png

Step 08 should use <output> as the LN2_MULTILATERATE `-control_points` input.
"""

from __future__ import annotations

import argparse
import csv
import json
import sys
from pathlib import Path
from typing import Dict, Optional, Tuple

import matplotlib
matplotlib.use("Agg", force=True)
import matplotlib.pyplot as plt
import nibabel as nib
import numpy as np
import yaml


AFFINE_ATOL = 1e-4
LANDMARKS = {
    2: "origin",
    3: "min_u",
    4: "max_u",
    5: "min_v",
    6: "max_v",
}
POINT_COLORS = {
    2: "#000000",
    3: "#7B2CBF",
    4: "#FF006E",
    5: "#2A9D8F",
    6: "#F77F00",
}


def find_nifti(path_or_stem) -> Path:
    path = Path(path_or_stem)
    if path.exists():
        return path

    text = str(path)
    candidates = []
    if text.endswith(".nii.gz"):
        candidates = [Path(text)]
    elif text.endswith(".nii"):
        candidates = [Path(text), Path(text + ".gz")]
    else:
        candidates = [Path(text + ".nii.gz"), Path(text + ".nii")]

    for candidate in candidates:
        if candidate.exists():
            return candidate

    raise FileNotFoundError(f"NIfTI not found: {path_or_stem}")


def load_yaml(path: Path) -> dict:
    with path.open("r", encoding="utf-8") as stream:
        cfg = yaml.safe_load(stream)
    if not isinstance(cfg, dict):
        raise ValueError("YAML root must be a mapping.")
    return cfg


def check_same_grid(
    reference: nib.spatialimages.SpatialImage,
    moving: nib.spatialimages.SpatialImage,
    reference_name: str,
    moving_name: str,
) -> None:
    if reference.shape[:3] != moving.shape[:3]:
        raise RuntimeError(
            f"Shape mismatch: {reference_name} {reference.shape[:3]} vs "
            f"{moving_name} {moving.shape[:3]}"
        )

    if not np.allclose(
        reference.affine,
        moving.affine,
        atol=AFFINE_ATOL,
        rtol=0.0,
    ):
        raise RuntimeError(
            f"Affine mismatch between {reference_name} and {moving_name}."
        )


def integer_data(
    image: nib.spatialimages.SpatialImage,
    name: str,
) -> np.ndarray:
    data = image.get_fdata(dtype=np.float32)

    if not np.all(np.isfinite(data)):
        raise RuntimeError(f"{name} contains non-finite values.")

    rounded = np.rint(data)
    if not np.allclose(data, rounded, atol=1e-4, rtol=0.0):
        raise RuntimeError(f"{name} is not integer-labelled.")

    return rounded.astype(np.int16)


def save_nifti(
    data: np.ndarray,
    reference: nib.spatialimages.SpatialImage,
    output_path: Path,
) -> None:
    output_path.parent.mkdir(parents=True, exist_ok=True)

    header = reference.header.copy()
    header.set_data_dtype(np.int16)
    header.set_slope_inter(1.0, 0.0)

    image = nib.Nifti1Image(
        np.asarray(data, dtype=np.int16),
        reference.affine.copy(),
        header,
    )

    qform, qcode = reference.get_qform(coded=True)
    sform, scode = reference.get_sform(coded=True)

    if qform is not None:
        image.set_qform(qform, int(qcode))
    if sform is not None:
        image.set_sform(sform, int(scode))

    image.header.set_slope_inter(1.0, 0.0)
    nib.save(image, str(output_path))


def strip_nii_suffix(path: Path) -> Path:
    name = path.name
    if name.endswith(".nii.gz"):
        name = name[:-7]
    elif name.endswith(".nii"):
        name = name[:-4]
    return path.parent / name


def resolve_config_paths(
    config_path: Path,
    session: str,
) -> Tuple[Path, Path, Path, Path, Optional[Path]]:
    cfg = load_yaml(config_path)

    subject = str(cfg.get("subject") or cfg.get("dataset", {}).get("subject"))
    if not subject:
        raise ValueError("Could not determine subject from config.")

    out_dir_template = cfg.get("out_dir")
    if out_dir_template:
        subject_root = Path(str(out_dir_template).format(subject=subject))
    else:
        paths = cfg.get("paths", {})
        pipeline_root = Path(str(paths["pipeline_root"]))
        subject_root = pipeline_root / "outputs" / subject

    session_root = subject_root / session
    layers_dir = session_root / "layers"
    true_uv_dir = session_root / "true_uv"

    rim = layers_dir / "rim.nii.gz"
    midgm = layers_dir / "depth3_midGM_equidist.nii"
    control = true_uv_dir / "uv_control_points_anatomical.nii.gz"
    output = true_uv_dir / "uv_control_points_caseII.nii.gz"

    background = None
    session_cfg = (cfg.get("sessions", {}) or {}).get(session, {}) or {}
    candidate = session_cfg.get("figure_anatomical")
    if candidate:
        candidate_path = Path(str(candidate))
        if candidate_path.exists():
            background = candidate_path

    if background is None:
        candidate = (cfg.get("paths", {}) or {}).get("figure_anatomical")
        if candidate:
            candidate_path = Path(str(candidate))
            if candidate_path.exists():
                background = candidate_path

    return rim, midgm, control, output, background


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
        description=(
            "Prepare the canonical CASE-II middle-GM control image for "
            "LN2_MULTILATERATE."
        ),
    )

    parser.add_argument(
        "config",
        nargs="?",
        help="HuberPipeline YAML configuration.",
    )
    parser.add_argument(
        "session",
        nargs="?",
        help="Session key, e.g. ses-18.",
    )

    parser.add_argument("--rim", default=None)
    parser.add_argument("--midgm", default=None)
    parser.add_argument("--control-points", default=None)
    parser.add_argument("--output", default=None)
    parser.add_argument(
        "--anatomical-background",
        default=None,
        help="Optional same-grid image used only for the QC PNG.",
    )
    return parser.parse_args()


def resolve_args(args: argparse.Namespace):
    if args.config or args.session:
        if not (args.config and args.session):
            raise ValueError(
                "Config/session mode requires both positional arguments: "
                "CONFIG SESSION."
            )

        cfg_rim, cfg_midgm, cfg_cp, cfg_output, cfg_bg = resolve_config_paths(
            Path(args.config),
            args.session,
        )

        rim = Path(args.rim) if args.rim else cfg_rim
        midgm = Path(args.midgm) if args.midgm else cfg_midgm
        cp = Path(args.control_points) if args.control_points else cfg_cp
        output = Path(args.output) if args.output else cfg_output
        background = (
            Path(args.anatomical_background)
            if args.anatomical_background
            else cfg_bg
        )
    else:
        required = {
            "--rim": args.rim,
            "--midgm": args.midgm,
            "--control-points": args.control_points,
            "--output": args.output,
        }
        missing = [key for key, value in required.items() if not value]
        if missing:
            raise ValueError(
                "Explicit mode requires: " + ", ".join(missing)
            )

        rim = Path(args.rim)
        midgm = Path(args.midgm)
        cp = Path(args.control_points)
        output = Path(args.output)
        background = (
            Path(args.anatomical_background)
            if args.anatomical_background
            else None
        )

    return (
        find_nifti(rim),
        find_nifti(midgm),
        find_nifti(cp),
        output,
        find_nifti(background) if background else None,
    )


def value_counts(data: np.ndarray) -> Dict[int, int]:
    values, numbers = np.unique(data, return_counts=True)
    return {
        int(value): int(number)
        for value, number in zip(values, numbers)
    }


def crop_bbox(mask2d: np.ndarray, margin: int = 8):
    yy, xx = np.nonzero(mask2d)
    if xx.size == 0:
        return 0, mask2d.shape[1] - 1, 0, mask2d.shape[0] - 1

    xmin = max(0, int(xx.min()) - margin)
    xmax = min(mask2d.shape[1] - 1, int(xx.max()) + margin)
    ymin = max(0, int(yy.min()) - margin)
    ymax = min(mask2d.shape[0] - 1, int(yy.max()) + margin)
    return xmin, xmax, ymin, ymax


def projected_point(voxel, axis, shape3d):
    remaining = [d for d in (0, 1, 2) if d != axis]
    a = int(voxel[remaining[0]])
    b = int(voxel[remaining[1]])
    size_b = int(shape3d[remaining[1]])
    y = size_b - 1 - b
    x = a
    return x, y


def projection_names(reference_img):
    try:
        codes = nib.aff2axcodes(reference_img.affine)
    except Exception:
        codes = (None, None, None)

    names = {}
    for axis, code in enumerate(codes):
        if code in ("L", "R"):
            names[axis] = "Sagittal projection"
        elif code in ("A", "P"):
            names[axis] = "Coronal projection"
        elif code in ("S", "I"):
            names[axis] = "Axial projection"
        else:
            names[axis] = f"Projection across voxel axis {axis}"
    return names


def robust_limits(data: np.ndarray, mask: np.ndarray):
    values = np.asarray(data, dtype=np.float64)
    valid = mask & np.isfinite(values)
    if not np.any(valid):
        return None
    lo, hi = np.percentile(values[valid], [2.0, 98.0])
    if not np.isfinite(lo) or not np.isfinite(hi) or hi <= lo:
        lo = float(np.min(values[valid]))
        hi = float(np.max(values[valid]))
    if hi <= lo:
        hi = lo + 1.0
    return float(lo), float(hi)


def make_qc_figure(
    output_png: Path,
    reference_img,
    midgm_mask: np.ndarray,
    caseii: np.ndarray,
    background: Optional[np.ndarray] = None,
    background_name: Optional[str] = None,
) -> None:
    names = projection_names(reference_img)

    fig, axes = plt.subplots(1, 3, figsize=(13.5, 4.8))
    title = "Step 07 CASE-II control-image QC"
    if background_name:
        title += f"\nBackground: {background_name}"
    fig.suptitle(title, fontsize=13)

    for panel, axis in enumerate((0, 1, 2)):
        ax = axes[panel]

        sheet = np.rot90(np.any(midgm_mask, axis=axis))

        if background is not None:
            bg = np.nanmean(
                np.where(np.isfinite(background), background, np.nan),
                axis=axis,
            )
            bg = np.rot90(bg)
            lim = robust_limits(bg, sheet)
            if lim is not None:
                ax.imshow(
                    bg,
                    cmap="gray",
                    vmin=lim[0],
                    vmax=lim[1],
                    interpolation="nearest",
                )

        rgba = np.zeros(sheet.shape + (4,), dtype=np.float32)
        rgba[sheet, :3] = np.array([0.70, 0.70, 0.70])
        rgba[sheet, 3] = 0.35 if background is not None else 0.75
        ax.imshow(rgba, interpolation="nearest")

        for label in LANDMARKS:
            loc = np.argwhere(caseii == label)
            voxel = tuple(int(v) for v in loc[0])
            x, y = projected_point(voxel, axis, midgm_mask.shape)

            ax.scatter(
                x,
                y,
                s=72,
                c=POINT_COLORS[label],
                edgecolors="white",
                linewidths=1.1,
                zorder=5,
            )
            ax.text(
                x + 1.2,
                y - 1.2,
                str(label),
                color=POINT_COLORS[label],
                fontsize=10,
                fontweight="bold",
                bbox=dict(
                    facecolor="white",
                    edgecolor="none",
                    alpha=0.78,
                    pad=0.6,
                ),
                zorder=6,
            )

        xmin, xmax, ymin, ymax = crop_bbox(sheet, margin=8)
        ax.set_xlim(xmin, xmax)
        ax.set_ylim(ymax, ymin)
        ax.set_title(names[axis], fontsize=10)
        ax.set_xticks([])
        ax.set_yticks([])

        for spine in ax.spines.values():
            spine.set_visible(False)

    fig.text(
        0.5,
        0.015,
        "Gray = complete middle-GM sheet; labels 2–6 replace five ordinary "
        "sheet voxels. Step 07 does not alter landmark geometry.",
        ha="center",
        fontsize=8.5,
    )
    fig.tight_layout(rect=[0, 0.05, 1, 0.91])
    fig.savefig(output_png, dpi=220, bbox_inches="tight")
    plt.close(fig)


def main() -> None:
    args = parse_args()
    (
        rim_path,
        midgm_path,
        cp_path,
        output_path,
        background_path,
    ) = resolve_args(args)

    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    rim_img = nib.load(str(rim_path))
    midgm_img = nib.load(str(midgm_path))
    cp_img = nib.load(str(cp_path))

    check_same_grid(rim_img, midgm_img, "rim", "middle-GM")
    check_same_grid(rim_img, cp_img, "rim", "Step-06 control points")

    rim = integer_data(rim_img, "rim")
    midgm_raw = integer_data(midgm_img, "middle-GM")
    cp = integer_data(cp_img, "Step-06 control-point image")

    midgm_mask = midgm_raw > 0
    n_midgm = int(np.count_nonzero(midgm_mask))
    if n_midgm < 20:
        raise RuntimeError(
            f"Middle-GM sheet is unexpectedly small: {n_midgm} voxels."
        )

    # Step 06 must be a five-landmark image only.
    unexpected_cp = sorted(
        set(np.unique(cp).astype(int).tolist())
        - {0, 2, 3, 4, 5, 6}
    )
    if unexpected_cp:
        raise RuntimeError(
            f"Unexpected values in Step-06 control-point image: "
            f"{unexpected_cp}"
        )

    nonzero_cp = int(np.count_nonzero(cp))
    if nonzero_cp != 5:
        raise RuntimeError(
            f"Step-06 control-point image must contain exactly five nonzero "
            f"voxels; found {nonzero_cp}."
        )

    landmark_rows = []
    landmark_locations = {}

    for label, name in LANDMARKS.items():
        loc = np.argwhere(cp == label)
        if loc.shape[0] != 1:
            raise RuntimeError(
                f"Control label {label} ({name}) must occur exactly once; "
                f"found {loc.shape[0]}."
            )

        voxel = tuple(int(v) for v in loc[0])
        landmark_locations[label] = voxel

        if not midgm_mask[voxel]:
            raise RuntimeError(
                f"Control label {label} ({name}) lies outside the "
                "middle-GM sheet."
            )

        rim_value = int(rim[voxel])
        if rim_value not in (1, 2, 3):
            raise RuntimeError(
                f"Control label {label} ({name}) lies outside the cortical "
                f"rim; rim value={rim_value}."
            )

        world = nib.affines.apply_affine(
            cp_img.affine,
            np.asarray(voxel, dtype=np.float64),
        )

        landmark_rows.append(
            {
                "label": label,
                "name": name,
                "voxel_i": voxel[0],
                "voxel_j": voxel[1],
                "voxel_k": voxel[2],
                "world_x_mm": float(world[0]),
                "world_y_mm": float(world[1]),
                "world_z_mm": float(world[2]),
                "rim_value": rim_value,
                "inside_midgm": True,
            }
        )

    # ------------------------------------------------------------------
    # Canonical CASE-II construction.
    #
    # Ordinary middle-GM voxels are always encoded as value 1. This is
    # deliberate even if the source middle-GM image contains a different
    # positive integer representation.
    # ------------------------------------------------------------------
    caseii = np.zeros(midgm_mask.shape, dtype=np.int16)
    caseii[midgm_mask] = 1

    for label, voxel in landmark_locations.items():
        caseii[voxel] = label

    allowed = {0, 1, 2, 3, 4, 5, 6}
    unexpected = sorted(
        set(np.unique(caseii).astype(int).tolist()) - allowed
    )
    if unexpected:
        raise RuntimeError(
            f"Internal CASE-II construction produced unexpected labels: "
            f"{unexpected}"
        )

    # Exact algebraic invariants.
    n_caseii_nonzero = int(np.count_nonzero(caseii))
    ordinary_midgm = int(np.count_nonzero(caseii == 1))
    outside = int(np.count_nonzero((caseii > 0) & ~midgm_mask))
    missing = int(np.count_nonzero(midgm_mask & (caseii == 0)))

    if n_caseii_nonzero != n_midgm:
        raise RuntimeError(
            f"CASE-II nonzero voxel count {n_caseii_nonzero} does not match "
            f"middle-GM voxel count {n_midgm}."
        )
    if ordinary_midgm != n_midgm - 5:
        raise RuntimeError(
            f"Expected {n_midgm - 5} ordinary middle-GM voxels with value 1; "
            f"found {ordinary_midgm}."
        )
    if outside != 0 or missing != 0:
        raise RuntimeError(
            f"CASE-II sheet mismatch: outside={outside}, missing={missing}."
        )

    for label in LANDMARKS:
        if int(np.count_nonzero(caseii == label)) != 1:
            raise RuntimeError(
                f"CASE-II label {label} does not occur exactly once."
            )

    save_nifti(caseii, midgm_img, output_path)

    # Verify the file after writing.
    reloaded_img = nib.load(str(output_path))
    check_same_grid(midgm_img, reloaded_img, "middle-GM", "written CASE-II")
    reloaded = integer_data(reloaded_img, "written CASE-II image")
    if not np.array_equal(caseii, reloaded):
        raise RuntimeError(
            "Written CASE-II image does not exactly match the in-memory "
            "construction."
        )

    prefix = strip_nii_suffix(output_path)
    landmarks_csv = Path(str(prefix) + "_landmarks.csv")
    counts_csv = Path(str(prefix) + "_value_counts.csv")
    summary_txt = Path(str(prefix) + "_summary.txt")
    summary_json = Path(str(prefix) + "_summary.json")
    qc_png = Path(str(prefix) + "_qc.png")

    with landmarks_csv.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(
            stream,
            fieldnames=list(landmark_rows[0].keys()),
        )
        writer.writeheader()
        writer.writerows(landmark_rows)

    count_rows = []
    for image_name, data in (
        ("rim", rim),
        ("middle_gm_source", midgm_raw),
        ("step06_control_points", cp),
        ("caseII_output", caseii),
    ):
        for value, count in value_counts(data).items():
            count_rows.append(
                {
                    "image": image_name,
                    "value": value,
                    "voxel_count": count,
                }
            )

    with counts_csv.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(
            stream,
            fieldnames=["image", "value", "voxel_count"],
        )
        writer.writeheader()
        writer.writerows(count_rows)

    summary = {
        "status": "PASS",
        "rim": str(rim_path),
        "middle_gm": str(midgm_path),
        "step06_control_points": str(cp_path),
        "caseII_output": str(output_path),
        "middle_gm_voxels": n_midgm,
        "caseII_nonzero_voxels": n_caseii_nonzero,
        "ordinary_middle_gm_voxels_value_1": ordinary_midgm,
        "landmark_voxels": 5,
        "missing_middle_gm_voxels": missing,
        "caseII_voxels_outside_middle_gm": outside,
        "allowed_values": [0, 1, 2, 3, 4, 5, 6],
        "functional_masks_used": False,
        "landmark_geometry_changed": False,
        "recommended_step08_control_points": str(output_path),
    }

    with summary_json.open("w", encoding="utf-8") as stream:
        json.dump(summary, stream, indent=2)

    with summary_txt.open("w", encoding="utf-8") as stream:
        stream.write("Step 07 CASE-II control-image preparation\n")
        stream.write("=========================================\n\n")
        stream.write(f"Rim:                    {rim_path}\n")
        stream.write(f"Middle-GM:              {midgm_path}\n")
        stream.write(f"Step-06 control points: {cp_path}\n")
        stream.write(f"CASE-II output:         {output_path}\n\n")
        stream.write(f"Middle-GM voxels:       {n_midgm}\n")
        stream.write(f"CASE-II nonzero voxels: {n_caseii_nonzero}\n")
        stream.write(f"Ordinary value-1 voxels:{ordinary_midgm}\n")
        stream.write("Landmark voxels:        5\n")
        stream.write(f"Missing middle-GM:      {missing}\n")
        stream.write(f"Outside middle-GM:      {outside}\n")
        stream.write("Functional masks used:  NO\n")
        stream.write("Landmark geometry changed: NO\n")
        stream.write("Status: PASS\n\n")
        stream.write(
            "Use this file as LN2_MULTILATERATE -control_points:\n"
        )
        stream.write(f"  {output_path}\n")

    background = None
    background_name = None
    if background_path is not None:
        try:
            background_img = nib.load(str(background_path))
            check_same_grid(
                midgm_img,
                background_img,
                "middle-GM",
                "QC anatomical background",
            )
            background = background_img.get_fdata(dtype=np.float32)
            background_name = background_path.name
        except Exception as exc:
            print(
                f"WARNING: QC background ignored because it is not a "
                f"compatible grid: {exc}"
            )

    make_qc_figure(
        qc_png,
        midgm_img,
        midgm_mask,
        caseii,
        background=background,
        background_name=background_name,
    )

    print("============================================================")
    print("HuberPipeline Step 07: Prepare CASE-II control image")
    print("============================================================")
    print(f"Rim:                    {rim_path}")
    print(f"Middle-GM:              {midgm_path}")
    print(f"Step-06 control points: {cp_path}")
    print(f"Middle-GM voxels:       {n_midgm}")
    print(f"Ordinary value-1 voxels:{ordinary_midgm}")
    print("Landmark labels:        2, 3, 4, 5, 6")
    print(f"CASE-II nonzero voxels: {n_caseii_nonzero}")
    print(f"Missing middle-GM:      {missing}")
    print(f"Outside middle-GM:      {outside}")
    print("Functional masks used:  NO")
    print("Landmark geometry changed: NO")
    print()
    print(f"CASE-II output:         {output_path}")
    print(f"Landmarks CSV:          {landmarks_csv}")
    print(f"Value counts:           {counts_csv}")
    print(f"QC figure:              {qc_png}")
    print(f"Summary:                {summary_txt}")
    print()
    print("Step 07 validation: PASS")
    print("Use the CASE-II output as Step 08 -control_points input.")


if __name__ == "__main__":
    try:
        main()
    except (
        FileNotFoundError,
        KeyError,
        RuntimeError,
        TypeError,
        ValueError,
    ) as exc:
        sys.exit(f"ERROR: {exc}")


