#!/usr/bin/env python3
"""
Step 3 — SPM beta maps to run-wise percent-signal-change (PSC) maps.

This implementation is driven by SPM.mat rather than hard-coded beta numbers.

For each run and digit, it computes:

    PSC = 100 * beta_condition * peak(condition regressor) / beta_constant

This is the same GLM-based calculation used in the manual MATLAB check:

    100 * condition_beta * max(design regressor) / constant_beta

The condition beta and run constant beta are identified from
SPM.Vbeta.descrip; run rows and design columns are identified from SPM.mat.

Outputs
-------
psc/
    psc_analysis_mask.nii.gz

    # Canonical session-mean PSC maps in native ses-XX EPI space:
    psc_<finger>.nii.gz

    runwise/
        psc_<finger>_run-01.nii.gz
        ...

    native_space/
        psc_<finger>_native.nii.gz
        finger_wta_native.nii.gz
        finger_winner_strength_native.nii.gz
        finger_winner_margin_native.nii.gz
        finger_second_best_native.nii.gz
        native_space_manifest.csv

    qc/
        spm_design_audit.csv
        runwise_psc_qc.csv
        session_psc_qc.csv
        native_space_wta_qc.csv
        voxel_validation.csv          (always written)

The files in psc/native_space/ are explicit native-space figure inputs. They
are not reconstructed from flattened maps. The five continuous PSC maps are
copied from the validated session-mean PSC outputs, and the WTA, winner
strength, second-best value, and winner margin are computed directly from
those native-space continuous maps inside the PSC analysis mask.

Required YAML keys
------------------
subject: sub-01
out_dir: /path/to/output/{subject}
fingers: [thumb, index, middle, ring, little]

sessions:
  ses-18:
    spm_dir: /path/to/SPM/first_level

Optional YAML keys
------------------
condition_aliases:
  thumb:  ["thumb", "d1"]
  index:  ["index", "d2"]
  middle: ["middle", "d3"]
  ring:   ["ring", "d4"]
  little: ["little", "pinkie", "pinky", "d5"]

# Applied when matching SPM.Vbeta.descrip and SPM.xX.name.
exclude_condition_terms:
  - "parametric"
  - "modulator"
  - "derivative"

# If omitted, these defaults are used.
constant_terms:
  - "constant"

# Existing layer-pipeline locations. These defaults preserve the previous
# directory structure:
rim_name: rim
depth_name: depth3_layers_equidist

# Denominator threshold. A relative threshold is also applied per run.
denominator_eps: 1.0e-6
minimum_constant_fraction_of_median: 0.05

# Save NaN outside valid voxels instead of zero. Zero is convenient for
# visualization and remains the default.
write_nan_outside_valid: false

# Optional Python zero-based voxel coordinates for numerical auditing.
# The default [42,69,105] corresponds to MATLAB/SPM [43,70,106].
validation_voxels:
  - [42, 69, 105]
"""

from __future__ import annotations

import csv
import re
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable, Optional, Union

import nibabel as nib
import numpy as np
import yaml
from scipy.io import loadmat


AFFINE_ATOL = 1e-4
DEFAULT_DENOMINATOR_EPS = 1e-6
DEFAULT_MINIMUM_CONSTANT_FRACTION = 0.05

DEFAULT_CONSTANT_TERMS = ("constant",)
DEFAULT_EXCLUDE_TERMS = (
    "parametric",
    "modulator",
    "derivative",
)

DEFAULT_ALIASES = {
    "thumb": ("thumb", "d1", "digit1", "digit 1"),
    "index": ("index", "d2", "digit2", "digit 2"),
    "middle": ("middle", "d3", "digit3", "digit 3"),
    "ring": ("ring", "d4", "digit4", "digit 4"),
    "little": (
        "little",
        "pinkie",
        "pinky",
        "d5",
        "digit5",
        "digit 5",
    ),
}


@dataclass(frozen=True)
class BetaRecord:
    beta_number: int
    beta_path: Path
    description: str
    design_column: int
    design_name: str
    run_number: Optional[int]
    kind: str
    finger: Optional[str]


def load_yaml(path: Union[str, Path]) -> dict[str, Any]:
    with open(path, "r", encoding="utf-8") as stream:
        cfg = yaml.safe_load(stream)

    if not isinstance(cfg, dict):
        raise ValueError("The YAML root must be a mapping.")

    return cfg


def find_existing_nifti(path_or_stem: Union[str, Path]) -> Path:
    path = Path(path_or_stem)

    if path.exists():
        return path

    text = str(path)

    if text.endswith(".nii"):
        candidate = Path(text + ".gz")
        if candidate.exists():
            return candidate
    elif not text.endswith(".nii.gz"):
        for suffix in (".nii", ".nii.gz"):
            candidate = Path(text + suffix)
            if candidate.exists():
                return candidate

    raise FileNotFoundError(f"NIfTI file not found: {path_or_stem}")


def normalize_text(text: Any) -> str:
    value = str(text).lower()
    value = value.replace("_", " ")
    value = re.sub(r"\s+", " ", value)
    return value.strip()


def as_list(value: Any) -> list[Any]:
    if value is None:
        return []
    if isinstance(value, list):
        return value
    if isinstance(value, tuple):
        return list(value)
    if isinstance(value, np.ndarray):
        if value.ndim == 0:
            return [value.item()]
        return list(value.ravel())
    return [value]


def get_field(obj: Any, name: str, default: Any = None) -> Any:
    if isinstance(obj, dict):
        return obj.get(name, default)
    return getattr(obj, name, default)


def check_same_grid(
    reference_img: nib.spatialimages.SpatialImage,
    moving_img: nib.spatialimages.SpatialImage,
    reference_name: str,
    moving_name: str,
) -> None:
    if reference_img.shape[:3] != moving_img.shape[:3]:
        raise RuntimeError(
            "Shape mismatch:\n"
            f"  {reference_name}: {reference_img.shape[:3]}\n"
            f"  {moving_name}: {moving_img.shape[:3]}"
        )

    if not np.allclose(
        reference_img.affine,
        moving_img.affine,
        atol=AFFINE_ATOL,
        rtol=0.0,
    ):
        raise RuntimeError(
            "Affine mismatch:\n"
            f"  {reference_name}\n"
            f"  {moving_name}\n"
            "The images are not in the same voxel grid."
        )

def save_nifti(data, reference_img, output_path, dtype):
    """
    Save supplied values exactly, with no inherited NIfTI intensity scaling.

    Spatial geometry is copied from the reference image, but the output
    header is newly constructed so scl_slope/scl_inter and other source
    intensity-scaling metadata cannot propagate into the PSC image.
    """
    data = np.asarray(data, dtype=dtype)

    header = nib.Nifti1Header()
    header.set_data_dtype(dtype)
    header.set_data_shape(data.shape)
    header.set_zooms(reference_img.header.get_zooms()[: data.ndim])
    header.set_xyzt_units(
        *reference_img.header.get_xyzt_units()
    )
    header.set_slope_inter(1.0, 0.0)

    output_img = nib.Nifti1Image(
        data,
        reference_img.affine.copy(),
        header,
    )

    qform, qform_code = reference_img.get_qform(coded=True)
    sform, sform_code = reference_img.get_sform(coded=True)

    if qform is not None:
        output_img.set_qform(qform, int(qform_code))

    if sform is not None:
        output_img.set_sform(sform, int(sform_code))

    output_img.header.set_slope_inter(1.0, 0.0)

    nib.save(output_img, str(output_path))

    # Validate the physical values after reopening the actual saved file.
    reloaded = nib.load(str(output_path))
    reloaded_data = reloaded.get_fdata(dtype=np.float32)

    finite = np.isfinite(data) & np.isfinite(reloaded_data)

    if np.any(finite):
        difference = float(
            np.max(
                np.abs(
                    reloaded_data[finite].astype(np.float64)
                    - data[finite].astype(np.float64)
                )
            )
        )

        if difference > 1e-6:
            raise RuntimeError(
                f"Saved NIfTI values changed after reopening: "
                f"maximum absolute difference = {difference:.12g}"
            )

#def save_nifti(
#    data: np.ndarray,
#    reference_img: nib.spatialimages.SpatialImage,
#    output_path: Path,
#    dtype: np.dtype,
#) -> None:
#    header = reference_img.header.copy()
#    header.set_data_dtype(dtype)

#    nib.save(
#        nib.Nifti1Image(
#            np.asarray(data, dtype=dtype),
#            reference_img.affine,
#            header,
#        ),
#        output_path,
#    )


def write_csv(
    output_path: Path,
    fieldnames: list[str],
    rows: Iterable[dict[str, Any]],
) -> None:
    with open(output_path, "w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def _matlab_to_python(value: Any) -> Any:
    """Recursively convert scipy MATLAB structs and cells."""
    if isinstance(value, np.ndarray):
        if value.dtype == object:
            converted = [_matlab_to_python(item) for item in value.ravel()]
            if value.size == 1:
                return converted[0]
            return converted
        if value.ndim == 0:
            return value.item()
        return value

    field_names = getattr(value, "_fieldnames", None)
    if field_names:
        return {
            field_name: _matlab_to_python(getattr(value, field_name))
            for field_name in field_names
        }

    return value


def load_spm(spm_mat_path: Path) -> Any:
    try:
        loaded = loadmat(
            spm_mat_path,
            squeeze_me=True,
            struct_as_record=False,
        )
    except NotImplementedError as exc:
        raise RuntimeError(
            "SPM.mat uses MATLAB v7.3/HDF5 format. Re-save it in MATLAB "
            "with '-v7', or use an HDF5-compatible reader."
        ) from exc

    if "SPM" not in loaded:
        raise RuntimeError(f"No SPM structure found in {spm_mat_path}")

    return _matlab_to_python(loaded["SPM"])


def extract_spm_structure(
    spm: Any,
) -> tuple[np.ndarray, list[str], list[np.ndarray], list[Any]]:
    x_x = get_field(spm, "xX")
    sessions = as_list(get_field(spm, "Sess"))
    vbeta = as_list(get_field(spm, "Vbeta"))

    if x_x is None or not sessions or not vbeta:
        raise RuntimeError(
            "SPM.mat must contain SPM.xX, SPM.Sess, and SPM.Vbeta."
        )

    design = np.asarray(get_field(x_x, "X"), dtype=np.float64)
    design_names = [
        str(item) for item in as_list(get_field(x_x, "name"))
    ]

    if design.ndim != 2:
        raise RuntimeError(
            f"SPM.xX.X must be two-dimensional; got {design.shape}."
        )

    if len(design_names) != design.shape[1]:
        raise RuntimeError(
            "SPM.xX.name and SPM.xX.X disagree:\n"
            f"  names: {len(design_names)}\n"
            f"  columns: {design.shape[1]}"
        )

    session_rows: list[np.ndarray] = []

    for run_number, session in enumerate(sessions, start=1):
        rows = np.asarray(
            get_field(session, "row"),
            dtype=np.int64,
        ).reshape(-1)

        if rows.size == 0:
            raise RuntimeError(
                f"SPM.Sess({run_number}).row is empty."
            )

        # MATLAB indices are one-based.
        rows = rows - 1

        if np.any(rows < 0) or np.any(rows >= design.shape[0]):
            raise RuntimeError(
                f"SPM.Sess({run_number}).row contains invalid rows."
            )

        session_rows.append(rows)

    if len(vbeta) != design.shape[1]:
        raise RuntimeError(
            "The number of beta descriptors differs from the number of "
            "design columns:\n"
            f"  SPM.Vbeta: {len(vbeta)}\n"
            f"  design columns: {design.shape[1]}"
        )

    return design, design_names, session_rows, vbeta


def parse_run_number(text: str) -> Optional[int]:
    normalized = normalize_text(text)

    patterns = (
        r"\bsn\((\d+)\)",
        r"\bsession\s*(\d+)\b",
        r"\brun[-_\s]*(\d+)\b",
    )

    for pattern in patterns:
        match = re.search(pattern, normalized, flags=re.IGNORECASE)
        if match:
            return int(match.group(1))

    return None


def contains_term(text: str, term: str) -> bool:
    normalized_text = normalize_text(text)
    normalized_term = normalize_text(term)

    if not normalized_term:
        return False

    # Short alphanumeric aliases such as d1 should match as tokens.
    if re.fullmatch(r"[a-z]\d+", normalized_term):
        return (
            re.search(
                rf"(?<![a-z0-9]){re.escape(normalized_term)}"
                rf"(?![a-z0-9])",
                normalized_text,
            )
            is not None
        )

    return normalized_term in normalized_text


def identify_finger(
    text: str,
    aliases: dict[str, tuple[str, ...]],
    exclude_terms: tuple[str, ...],
) -> Optional[str]:
    if any(contains_term(text, term) for term in exclude_terms):
        return None

    matched = [
        finger
        for finger, finger_aliases in aliases.items()
        if any(contains_term(text, alias) for alias in finger_aliases)
    ]

    if len(matched) > 1:
        raise RuntimeError(
            f"Ambiguous finger description '{text}'; matches {matched}."
        )

    return matched[0] if matched else None


def resolve_beta_path(
    spm_dir: Path,
    beta_number: int,
    vbeta_entry: Any,
) -> Path:
    fname = get_field(vbeta_entry, "fname")

    if fname:
        candidate = Path(str(fname))
        if not candidate.is_absolute():
            candidate = spm_dir / candidate

        try:
            return find_existing_nifti(candidate)
        except FileNotFoundError:
            pass

    return find_existing_nifti(
        spm_dir / f"beta_{beta_number:04d}"
    )


def build_beta_records(
    spm_dir: Path,
    design_names: list[str],
    vbeta: list[Any],
    aliases: dict[str, tuple[str, ...]],
    constant_terms: tuple[str, ...],
    exclude_terms: tuple[str, ...],
) -> list[BetaRecord]:
    records: list[BetaRecord] = []

    for column_index, entry in enumerate(vbeta):
        beta_number = column_index + 1
        description = str(
            get_field(entry, "descrip", design_names[column_index])
        )
        design_name = design_names[column_index]
        combined_text = f"{description} {design_name}"

        run_from_description = parse_run_number(description)
        run_from_design = parse_run_number(design_name)

        if (
            run_from_description is not None
            and run_from_design is not None
            and run_from_description != run_from_design
        ):
            raise RuntimeError(
                f"Conflicting run assignments for beta_{beta_number:04d}:\n"
                f"  Vbeta: {description}\n"
                f"  xX.name: {design_name}"
            )

        run_number = (
            run_from_description
            if run_from_description is not None
            else run_from_design
        )

        is_constant = any(
            contains_term(combined_text, term)
            for term in constant_terms
        )

        finger = identify_finger(
            combined_text,
            aliases,
            exclude_terms,
        )

        if is_constant and finger is not None:
            raise RuntimeError(
                f"beta_{beta_number:04d} matches both a constant and "
                f"finger '{finger}': {combined_text}"
            )

        if is_constant:
            kind = "constant"
        elif finger is not None:
            kind = "condition"
        else:
            kind = "other"

        records.append(
            BetaRecord(
                beta_number=beta_number,
                beta_path=resolve_beta_path(
                    spm_dir,
                    beta_number,
                    entry,
                ),
                description=description,
                design_column=column_index,
                design_name=design_name,
                run_number=run_number,
                kind=kind,
                finger=finger,
            )
        )

    return records


def validate_design_mapping(
    records: list[BetaRecord],
    fingers: list[str],
    n_runs: int,
) -> tuple[
    dict[tuple[int, str], BetaRecord],
    dict[int, BetaRecord],
]:
    conditions: dict[tuple[int, str], BetaRecord] = {}
    constants: dict[int, BetaRecord] = {}

    for record in records:
        if record.kind == "other":
            continue

        if record.run_number is None:
            raise RuntimeError(
                "Could not identify the run for:\n"
                f"  beta_{record.beta_number:04d}\n"
                f"  {record.description}\n"
                f"  {record.design_name}"
            )

        if not 1 <= record.run_number <= n_runs:
            raise RuntimeError(
                f"Invalid run {record.run_number} for "
                f"beta_{record.beta_number:04d}."
            )

        if record.kind == "constant":
            if record.run_number in constants:
                previous = constants[record.run_number]
                raise RuntimeError(
                    f"More than one constant beta was found for run "
                    f"{record.run_number}:\n"
                    f"  beta_{previous.beta_number:04d}: "
                    f"{previous.description}\n"
                    f"  beta_{record.beta_number:04d}: "
                    f"{record.description}"
                )
            constants[record.run_number] = record

        elif record.kind == "condition":
            key = (record.run_number, str(record.finger))
            if key in conditions:
                previous = conditions[key]
                raise RuntimeError(
                    f"More than one beta was found for {key}:\n"
                    f"  beta_{previous.beta_number:04d}: "
                    f"{previous.description}\n"
                    f"  beta_{record.beta_number:04d}: "
                    f"{record.description}"
                )
            conditions[key] = record

    missing_constants = [
        run for run in range(1, n_runs + 1)
        if run not in constants
    ]
    if missing_constants:
        raise RuntimeError(
            "No unique constant beta was found for runs: "
            f"{missing_constants}"
        )

    missing_conditions = [
        (run, finger)
        for run in range(1, n_runs + 1)
        for finger in fingers
        if (run, finger) not in conditions
    ]
    if missing_conditions:
        formatted = ", ".join(
            f"run {run}/{finger}"
            for run, finger in missing_conditions
        )
        raise RuntimeError(
            "Missing condition beta(s): " + formatted
        )

    return conditions, constants


def load_binary_mask(
    path: Path,
    reference_img: nib.spatialimages.SpatialImage,
    name: str,
) -> np.ndarray:
    image = nib.load(path)
    check_same_grid(reference_img, image, "reference beta", name)
    return np.asarray(image.dataobj) > 0


def build_analysis_mask(
    spm_mask_path: Path,
    rim_path: Path,
    depth_path: Path,
    reference_img: nib.spatialimages.SpatialImage,
) -> np.ndarray:
    spm_mask = load_binary_mask(
        spm_mask_path,
        reference_img,
        "SPM analysis mask",
    )
    rim_mask = load_binary_mask(
        rim_path,
        reference_img,
        "Step 1 cortical rim",
    )
    depth_mask = load_binary_mask(
        depth_path,
        reference_img,
        "Step 2 cortical-depth labels",
    )

    analysis_mask = spm_mask & rim_mask & depth_mask

    print("  Mask voxel counts:")
    print(f"    SPM mask:             {int(spm_mask.sum())}")
    print(f"    cortical rim:         {int(rim_mask.sum())}")
    print(f"    depth-labelled:       {int(depth_mask.sum())}")
    print(f"    final intersection:   {int(analysis_mask.sum())}")

    if not np.any(analysis_mask):
        raise RuntimeError(
            "The PSC analysis-mask intersection is empty."
        )

    return analysis_mask


def get_regressor_peak(
    design: np.ndarray,
    session_rows: list[np.ndarray],
    record: BetaRecord,
) -> float:
    assert record.run_number is not None

    rows = session_rows[record.run_number - 1]
    regressor = design[rows, record.design_column]
    finite = regressor[np.isfinite(regressor)]

    if finite.size == 0:
        raise RuntimeError(
            f"No finite regressor values for "
            f"beta_{record.beta_number:04d}."
        )

    peak = float(np.max(finite))

    if peak <= 0:
        raise RuntimeError(
            f"The regressor peak is nonpositive for "
            f"beta_{record.beta_number:04d}: {peak}"
        )

    return peak


def summarize(values: np.ndarray) -> dict[str, Union[float, int]]:
    values = np.asarray(values, dtype=np.float64)
    values = values[np.isfinite(values)]

    if values.size == 0:
        return {
            "n": 0,
            "mean": np.nan,
            "median": np.nan,
            "p05": np.nan,
            "p95": np.nan,
            "p99": np.nan,
            "minimum": np.nan,
            "maximum": np.nan,
            "positive_fraction_percent": np.nan,
            "negative_fraction_percent": np.nan,
        }

    p05, p95, p99 = np.percentile(values, [5, 95, 99])

    return {
        "n": int(values.size),
        "mean": float(np.mean(values)),
        "median": float(np.median(values)),
        "p05": float(p05),
        "p95": float(p95),
        "p99": float(p99),
        "minimum": float(np.min(values)),
        "maximum": float(np.max(values)),
        "positive_fraction_percent": float(
            100.0 * np.mean(values > 0)
        ),
        "negative_fraction_percent": float(
            100.0 * np.mean(values < 0)
        ),
    }


def configure_aliases(
    cfg: dict[str, Any],
    fingers: list[str],
) -> dict[str, tuple[str, ...]]:
    supplied = cfg.get("condition_aliases", {})
    aliases: dict[str, tuple[str, ...]] = {}

    for finger in fingers:
        if finger in supplied:
            values = tuple(str(item) for item in supplied[finger])
        elif finger in DEFAULT_ALIASES:
            values = DEFAULT_ALIASES[finger]
        else:
            values = (finger,)

        # Always include the exact configured name.
        aliases[finger] = tuple(dict.fromkeys((finger, *values)))

    unknown = set(supplied) - set(fingers)
    if unknown:
        raise ValueError(
            "condition_aliases contains fingers not listed in "
            f"cfg['fingers']: {sorted(unknown)}"
        )

    return aliases



def compute_native_space_wta(
    finger_maps: dict[str, np.ndarray],
    fingers: list[str],
    analysis_mask: np.ndarray,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """
    Compute native-space WTA products from continuous session-mean PSC maps.

    Returns
    -------
    wta_labels
        Integer labels 1..N in the order supplied by ``fingers``; 0 outside
        valid voxels.
    winner_strength
        Largest PSC value across fingers.
    second_best
        Second-largest PSC value across fingers.
    winner_margin
        Largest minus second-largest PSC.
    valid_all_fingers
        Voxels inside the analysis mask with finite values for every finger.
    """
    if not fingers:
        raise ValueError("At least one finger is required for native WTA.")

    missing = [finger for finger in fingers if finger not in finger_maps]
    if missing:
        raise RuntimeError(
            "Missing session-mean PSC maps for native WTA: "
            + ", ".join(missing)
        )

    stack = np.stack(
        [np.asarray(finger_maps[finger], dtype=np.float32) for finger in fingers],
        axis=0,
    )

    if stack.ndim != 4:
        raise RuntimeError(
            f"Expected finger stack with shape F×X×Y×Z; got {stack.shape}."
        )

    finite_all = np.all(np.isfinite(stack), axis=0)
    valid = analysis_mask & finite_all

    safe = np.where(np.isfinite(stack), stack, -np.inf)
    sorted_values = np.sort(safe, axis=0)

    wta = np.zeros(stack.shape[1:], dtype=np.int16)
    winner_strength = np.full(stack.shape[1:], np.nan, dtype=np.float32)
    second_best = np.full(stack.shape[1:], np.nan, dtype=np.float32)
    winner_margin = np.full(stack.shape[1:], np.nan, dtype=np.float32)

    if np.any(valid):
        wta[valid] = (
            np.argmax(safe[:, valid], axis=0) + 1
        ).astype(np.int16)

        winner_strength[valid] = sorted_values[-1, valid].astype(np.float32)

        if len(fingers) >= 2:
            second_best[valid] = sorted_values[-2, valid].astype(np.float32)
            winner_margin[valid] = (
                sorted_values[-1, valid] - sorted_values[-2, valid]
            ).astype(np.float32)
        else:
            second_best[valid] = np.nan
            winner_margin[valid] = np.nan

    return (
        wta,
        winner_strength,
        second_best,
        winner_margin,
        valid,
    )


def main(cfg_path: str, session: str) -> None:
    cfg = load_yaml(cfg_path)

    subject = str(cfg["subject"])
    fingers = [str(item) for item in cfg["fingers"]]

    if len(fingers) != len(set(fingers)):
        raise ValueError("cfg['fingers'] contains duplicates.")

    sessions_cfg = cfg["sessions"]
    if session not in sessions_cfg:
        raise ValueError(f"Session not found in YAML: {session}")

    session_cfg = sessions_cfg[session]
    spm_dir = Path(session_cfg["spm_dir"])
    spm_mat_path = spm_dir / "SPM.mat"

    if not spm_mat_path.exists():
        raise FileNotFoundError(f"SPM.mat not found: {spm_mat_path}")

    output_root = Path(
        str(cfg["out_dir"]).format(subject=subject)
    )
    session_output = output_root / session
    psc_dir = session_output / "psc"
    runwise_dir = psc_dir / "runwise"
    native_space_dir = psc_dir / "native_space"
    qc_dir = psc_dir / "qc"
    layers_dir = session_output / "layers"

    for directory in (
        psc_dir,
        runwise_dir,
        native_space_dir,
        qc_dir,
    ):
        directory.mkdir(parents=True, exist_ok=True)

    rim_name = str(cfg.get("rim_name", "rim"))
    depth_name = str(
        cfg.get("depth_name", "depth3_layers_equidist")
    )

    spm_mask_path = find_existing_nifti(spm_dir / "mask")
    rim_path = find_existing_nifti(layers_dir / rim_name)
    depth_path = find_existing_nifti(layers_dir / depth_name)

    aliases = configure_aliases(cfg, fingers)
    constant_terms = tuple(
        str(item)
        for item in cfg.get(
            "constant_terms",
            DEFAULT_CONSTANT_TERMS,
        )
    )
    exclude_terms = tuple(
        str(item)
        for item in cfg.get(
            "exclude_condition_terms",
            DEFAULT_EXCLUDE_TERMS,
        )
    )

    denominator_eps = float(
        cfg.get("denominator_eps", DEFAULT_DENOMINATOR_EPS)
    )
    minimum_constant_fraction = float(
        cfg.get(
            "minimum_constant_fraction_of_median",
            DEFAULT_MINIMUM_CONSTANT_FRACTION,
        )
    )
    write_nan_outside_valid = bool(
        cfg.get("write_nan_outside_valid", False)
    )

    if denominator_eps < 0:
        raise ValueError("denominator_eps cannot be negative.")

    if not 0 <= minimum_constant_fraction < 1:
        raise ValueError(
            "minimum_constant_fraction_of_median must be in [0, 1)."
        )

    print(f"[{session}] SPM-driven beta-to-PSC conversion")
    print(f"  SPM.mat: {spm_mat_path}")
    print(f"  Rim:     {rim_path}")
    print(f"  Depth:   {depth_path}")
    print()

    spm = load_spm(spm_mat_path)
    design, design_names, session_rows, vbeta = (
        extract_spm_structure(spm)
    )

    records = build_beta_records(
        spm_dir=spm_dir,
        design_names=design_names,
        vbeta=vbeta,
        aliases=aliases,
        constant_terms=constant_terms,
        exclude_terms=exclude_terms,
    )

    n_runs = len(session_rows)
    conditions, constants = validate_design_mapping(
        records,
        fingers,
        n_runs,
    )

    first_record = conditions[(1, fingers[0])]
    reference_img = nib.load(first_record.beta_path)

    analysis_mask = build_analysis_mask(
        spm_mask_path,
        rim_path,
        depth_path,
        reference_img,
    )

    analysis_mask_path = psc_dir / "psc_analysis_mask.nii.gz"
    save_nifti(
        analysis_mask.astype(np.uint8),
        reference_img,
        analysis_mask_path,
        np.uint8,
    )

    audit_rows: list[dict[str, Any]] = []

    for record in records:
        audit_rows.append(
            {
                "beta_number": record.beta_number,
                "beta_file": str(record.beta_path),
                "description": record.description,
                "design_column_one_based": record.design_column + 1,
                "design_name": record.design_name,
                "run": record.run_number,
                "kind": record.kind,
                "finger": record.finger,
            }
        )

    write_csv(
        qc_dir / "spm_design_audit.csv",
        [
            "beta_number",
            "beta_file",
            "description",
            "design_column_one_based",
            "design_name",
            "run",
            "kind",
            "finger",
        ],
        audit_rows,
    )

    constant_data: dict[int, np.ndarray] = {}
    constant_thresholds: dict[int, float] = {}

    print()
    print("  Run constants:")

    for run_number in range(1, n_runs + 1):
        record = constants[run_number]
        image = nib.load(record.beta_path)
        check_same_grid(
            reference_img,
            image,
            "reference beta",
            f"run {run_number} constant beta",
        )

        data = image.get_fdata(dtype=np.float32)
        finite_positive = data[
            analysis_mask
            & np.isfinite(data)
            & (data > denominator_eps)
        ]

        if finite_positive.size == 0:
            raise RuntimeError(
                f"Run {run_number} has no positive constant-beta "
                "values inside the analysis mask."
            )

        median_constant = float(np.median(finite_positive))
        relative_threshold = (
            minimum_constant_fraction * median_constant
        )
        threshold = max(denominator_eps, relative_threshold)

        constant_data[run_number] = data
        constant_thresholds[run_number] = threshold

        print(
            f"    Run {run_number}: "
            f"beta_{record.beta_number:04d}; "
            f"median={median_constant:.6f}; "
            f"valid threshold={threshold:.6f}"
        )
        print(f"      {record.description}")

    runwise_qc_rows: list[dict[str, Any]] = []
    session_qc_rows: list[dict[str, Any]] = []
    voxel_validation_rows: list[dict[str, Any]] = []

    # Retain validated session-mean PSC arrays so native-space WTA products
    # can be computed directly, without reconstructing anything from flat maps.
    session_mean_maps: dict[str, np.ndarray] = {}
    session_mean_paths: dict[str, Path] = {}

    validation_voxels = [
        tuple(int(value) for value in voxel)
        for voxel in cfg.get(
            "validation_voxels",
            [[42, 69, 105]],
        )
    ]

    for voxel in validation_voxels:
        if len(voxel) != 3:
            raise ValueError(
                "Every validation_voxels entry must contain exactly "
                "three zero-based voxel indices."
            )

    print()
    print("  Validation voxels:")
    for voxel in validation_voxels:
        matlab_voxel = tuple(index + 1 for index in voxel)
        world = nib.affines.apply_affine(
            reference_img.affine,
            voxel,
        )
        print(
            f"    Python zero-based {voxel} "
            f"<-> MATLAB/SPM one-based {matlab_voxel}; "
            f"world=({world[0]:.6f}, {world[1]:.6f}, "
            f"{world[2]:.6f}) mm"
        )

    print()
    print("  Condition PSC maps:")

    for finger in fingers:
        run_maps: list[np.ndarray] = []

        print(f"    {finger}")

        for run_number in range(1, n_runs + 1):
            record = conditions[(run_number, finger)]
            condition_img = nib.load(record.beta_path)

            check_same_grid(
                reference_img,
                condition_img,
                "reference beta",
                f"{finger}, run {run_number}",
            )

            condition_beta = condition_img.get_fdata(
                dtype=np.float32
            )
            constant_beta = constant_data[run_number]
            threshold = constant_thresholds[run_number]
            regressor_peak = get_regressor_peak(
                design,
                session_rows,
                record,
            )

            valid = (
                analysis_mask
                & np.isfinite(condition_beta)
                & np.isfinite(constant_beta)
                & (constant_beta > threshold)
            )

            if not np.any(valid):
                raise RuntimeError(
                    f"No valid PSC voxels for {finger}, "
                    f"run {run_number}."
                )

            psc_run = np.full(
                condition_beta.shape,
                np.nan,
                dtype=np.float32,
            )
            psc_run[valid] = (
                100.0
                * condition_beta[valid]
                * regressor_peak
                / constant_beta[valid]
            ).astype(np.float32)

            run_maps.append(psc_run)

            if write_nan_outside_valid:
                output_data = psc_run
            else:
                output_data = np.zeros(
                    psc_run.shape,
                    dtype=np.float32,
                )
                output_data[valid] = psc_run[valid]

            runwise_path = (
                runwise_dir
                / f"psc_{finger}_run-{run_number:02d}.nii.gz"
            )
            save_nifti(
                output_data,
                reference_img,
                runwise_path,
                np.float32,
            )

            saved_img = nib.load(runwise_path)
            check_same_grid(
                reference_img,
                saved_img,
                "reference beta",
                f"saved PSC map {runwise_path.name}",
            )
            saved_data = saved_img.get_fdata(dtype=np.float32)
            maximum_saved_map_difference = float(
                np.max(
                    np.abs(
                        saved_data[valid].astype(np.float64)
                        - psc_run[valid].astype(np.float64)
                    )
                )
            )

            if maximum_saved_map_difference > 1e-6:
                raise RuntimeError(
                    "Saved PSC map failed numerical validation for "
                    f"{finger}, run {run_number}: maximum absolute "
                    f"difference={maximum_saved_map_difference:.12g}"
                )

            stats = summarize(psc_run[valid])

            runwise_qc_rows.append(
                {
                    "finger": finger,
                    "run": run_number,
                    "condition_beta": record.beta_number,
                    "condition_beta_file": str(record.beta_path),
                    "condition_description": record.description,
                    "design_column_one_based": (
                        record.design_column + 1
                    ),
                    "design_name": record.design_name,
                    "regressor_peak": regressor_peak,
                    "constant_beta": (
                        constants[run_number].beta_number
                    ),
                    "constant_beta_file": str(
                        constants[run_number].beta_path
                    ),
                    "constant_threshold": threshold,
                    "maximum_saved_map_difference": (
                        maximum_saved_map_difference
                    ),
                    **stats,
                }
            )

            print(
                f"      Run {run_number}: "
                f"beta_{record.beta_number:04d}; "
                f"peak={regressor_peak:.8f}; "
                f"median={stats['median']:.4f}%; "
                f"P05={stats['p05']:.4f}%; "
                f"P95={stats['p95']:.4f}%; "
                f"range=[{stats['minimum']:.4f}, "
                f"{stats['maximum']:.4f}]%"
            )
            print(f"        {record.description}")

            for voxel in validation_voxels:
                in_bounds = all(
                    0 <= voxel[axis] < condition_beta.shape[axis]
                    for axis in range(3)
                )

                matlab_voxel = tuple(index + 1 for index in voxel)

                if not in_bounds:
                    condition_value = np.nan
                    constant_value = np.nan
                    direct_psc = np.nan
                    stored_psc = np.nan
                    voxel_valid = False
                    inside_analysis_mask = False
                    world = (np.nan, np.nan, np.nan)
                else:
                    condition_value = float(condition_beta[voxel])
                    constant_value = float(constant_beta[voxel])
                    inside_analysis_mask = bool(analysis_mask[voxel])
                    voxel_valid = bool(valid[voxel])

                    if (
                        np.isfinite(condition_value)
                        and np.isfinite(constant_value)
                        and constant_value != 0
                    ):
                        direct_psc = float(
                            100.0
                            * condition_value
                            * regressor_peak
                            / constant_value
                        )
                    else:
                        direct_psc = np.nan

                    stored_psc = (
                        float(psc_run[voxel])
                        if voxel_valid
                        else np.nan
                    )

                    world_array = nib.affines.apply_affine(
                        reference_img.affine,
                        voxel,
                    )
                    world = (
                        float(world_array[0]),
                        float(world_array[1]),
                        float(world_array[2]),
                    )

                voxel_validation_rows.append(
                    {
                        "finger": finger,
                        "run": run_number,
                        "python_i": voxel[0],
                        "python_j": voxel[1],
                        "python_k": voxel[2],
                        "matlab_i": matlab_voxel[0],
                        "matlab_j": matlab_voxel[1],
                        "matlab_k": matlab_voxel[2],
                        "world_x_mm": world[0],
                        "world_y_mm": world[1],
                        "world_z_mm": world[2],
                        "in_bounds": in_bounds,
                        "inside_analysis_mask": inside_analysis_mask,
                        "valid_for_stored_psc": voxel_valid,
                        "condition_beta_value": condition_value,
                        "regressor_peak": regressor_peak,
                        "constant_beta_value": constant_value,
                        "direct_psc": direct_psc,
                        "stored_psc": stored_psc,
                    }
                )

                if finger == fingers[0] and run_number == 1:
                    print(
                        f"      Validation {finger}, run {run_number}"
                    )
                    print(
                        f"        Python zero-based: {voxel}"
                    )
                    print(
                        f"        MATLAB/SPM one-based: "
                        f"{matlab_voxel}"
                    )
                    print(
                        f"        World (mm): "
                        f"({world[0]:.6f}, {world[1]:.6f}, "
                        f"{world[2]:.6f})"
                    )
                    print(
                        f"        Condition beta: "
                        f"{condition_value:.10f}"
                    )
                    print(
                        f"        Constant beta: "
                        f"{constant_value:.10f}"
                    )
                    print(
                        f"        Regressor peak: "
                        f"{regressor_peak:.10f}"
                    )
                    print(
                        f"        Direct PSC: "
                        f"{direct_psc:.10f}%"
                    )
                    print(
                        f"        Inside analysis mask: "
                        f"{'YES' if inside_analysis_mask else 'NO'}"
                    )
                    if np.isfinite(stored_psc):
                        print(
                            f"        Stored PSC: "
                            f"{stored_psc:.10f}%"
                        )
                    else:
                        print(
                            "        Stored PSC: NaN "
                            "(outside valid mask)"
                        )

        stack = np.stack(run_maps, axis=0)
        finite = np.isfinite(stack)
        count = finite.sum(axis=0)
        total = np.where(finite, stack, 0.0).sum(
            axis=0,
            dtype=np.float64,
        )

        session_mean = np.full(
            stack.shape[1:],
            np.nan,
            dtype=np.float32,
        )
        mean_valid = analysis_mask & (count > 0)
        session_mean[mean_valid] = (
            total[mean_valid] / count[mean_valid]
        ).astype(np.float32)

        if write_nan_outside_valid:
            output_data = session_mean
        else:
            output_data = np.zeros(
                session_mean.shape,
                dtype=np.float32,
            )
            output_data[mean_valid] = session_mean[mean_valid]

        session_path = psc_dir / f"psc_{finger}.nii.gz"
        save_nifti(
            output_data,
            reference_img,
            session_path,
            np.float32,
        )

        # Canonical in-memory map keeps NaN outside valid voxels regardless of
        # the visualization-oriented zero-filling policy used for psc/<file>.
        session_mean_maps[finger] = session_mean.copy()
        session_mean_paths[finger] = session_path

        native_finger_path = (
            native_space_dir / f"psc_{finger}_native.nii.gz"
        )
        native_output_data = (
            session_mean
            if write_nan_outside_valid
            else np.where(
                mean_valid,
                session_mean,
                0.0,
            ).astype(np.float32)
        )
        save_nifti(
            native_output_data,
            reference_img,
            native_finger_path,
            np.float32,
        )

        stats = summarize(session_mean[mean_valid])
        session_qc_rows.append(
            {
                "finger": finger,
                "runs": n_runs,
                **stats,
            }
        )

        print(
            f"      Session mean: "
            f"mean={stats['mean']:.4f}%; "
            f"median={stats['median']:.4f}%; "
            f"P05={stats['p05']:.4f}%; "
            f"P95={stats['p95']:.4f}%; "
            f"P99={stats['p99']:.4f}%; "
            f"range=[{stats['minimum']:.4f}, "
            f"{stats['maximum']:.4f}]%"
        )
        print(f"      Saved: {session_path}")
        print(f"      Native figure input: {native_finger_path}")

    # ------------------------------------------------------------------
    # Native-space WTA and confidence products
    # ------------------------------------------------------------------
    (
        native_wta,
        native_winner_strength,
        native_second_best,
        native_winner_margin,
        native_wta_valid,
    ) = compute_native_space_wta(
        session_mean_maps,
        fingers,
        analysis_mask,
    )

    native_wta_path = native_space_dir / "finger_wta_native.nii.gz"
    native_strength_path = (
        native_space_dir / "finger_winner_strength_native.nii.gz"
    )
    native_second_path = (
        native_space_dir / "finger_second_best_native.nii.gz"
    )
    native_margin_path = (
        native_space_dir / "finger_winner_margin_native.nii.gz"
    )

    save_nifti(
        native_wta,
        reference_img,
        native_wta_path,
        np.int16,
    )

    def native_continuous_output(values: np.ndarray) -> np.ndarray:
        if write_nan_outside_valid:
            return values
        output = np.zeros(values.shape, dtype=np.float32)
        output[native_wta_valid] = values[native_wta_valid]
        return output

    save_nifti(
        native_continuous_output(native_winner_strength),
        reference_img,
        native_strength_path,
        np.float32,
    )
    save_nifti(
        native_continuous_output(native_second_best),
        reference_img,
        native_second_path,
        np.float32,
    )
    save_nifti(
        native_continuous_output(native_winner_margin),
        reference_img,
        native_margin_path,
        np.float32,
    )

    native_manifest_rows: list[dict[str, Any]] = []

    for label_value, finger in enumerate(fingers, start=1):
        native_manifest_rows.append(
            {
                "kind": "continuous_finger_psc",
                "finger": finger,
                "wta_label": label_value,
                "path": str(
                    native_space_dir / f"psc_{finger}_native.nii.gz"
                ),
                "metric": "session_mean_percent_signal_change",
                "space": "native_session_epi",
                "quantitative_source": "direct_session_mean_psc",
            }
        )

    for kind, path_value, metric in (
        (
            "wta",
            native_wta_path,
            "winning_finger_label",
        ),
        (
            "winner_strength",
            native_strength_path,
            "maximum_session_mean_percent_signal_change",
        ),
        (
            "second_best",
            native_second_path,
            "second_largest_session_mean_percent_signal_change",
        ),
        (
            "winner_margin",
            native_margin_path,
            "largest_minus_second_largest_percent_signal_change",
        ),
    ):
        native_manifest_rows.append(
            {
                "kind": kind,
                "finger": "",
                "wta_label": "",
                "path": str(path_value),
                "metric": metric,
                "space": "native_session_epi",
                "quantitative_source": "direct_session_mean_psc",
            }
        )

    write_csv(
        native_space_dir / "native_space_manifest.csv",
        [
            "kind",
            "finger",
            "wta_label",
            "path",
            "metric",
            "space",
            "quantitative_source",
        ],
        native_manifest_rows,
    )

    native_wta_qc_rows: list[dict[str, Any]] = []
    for label_value, finger in enumerate(fingers, start=1):
        selected = native_wta_valid & (native_wta == label_value)
        native_wta_qc_rows.append(
            {
                "finger": finger,
                "wta_label": label_value,
                "winning_voxels": int(np.count_nonzero(selected)),
                "winning_fraction_percent": (
                    float(
                        100.0
                        * np.count_nonzero(selected)
                        / np.count_nonzero(native_wta_valid)
                    )
                    if np.any(native_wta_valid)
                    else np.nan
                ),
                "mean_winner_strength": (
                    float(np.mean(native_winner_strength[selected]))
                    if np.any(selected)
                    else np.nan
                ),
                "mean_winner_margin": (
                    float(np.mean(native_winner_margin[selected]))
                    if np.any(selected)
                    else np.nan
                ),
            }
        )

    write_csv(
        qc_dir / "native_space_wta_qc.csv",
        [
            "finger",
            "wta_label",
            "winning_voxels",
            "winning_fraction_percent",
            "mean_winner_strength",
            "mean_winner_margin",
        ],
        native_wta_qc_rows,
    )

    print()
    print("  Native-space figure products:")
    for finger in fingers:
        print(
            "    "
            + str(native_space_dir / f"psc_{finger}_native.nii.gz")
        )
    print(f"    {native_wta_path}")
    print(f"    {native_strength_path}")
    print(f"    {native_second_path}")
    print(f"    {native_margin_path}")

    write_csv(
        qc_dir / "runwise_psc_qc.csv",
        [
            "finger",
            "run",
            "condition_beta",
            "condition_beta_file",
            "condition_description",
            "design_column_one_based",
            "design_name",
            "regressor_peak",
            "constant_beta",
            "constant_beta_file",
            "constant_threshold",
            "maximum_saved_map_difference",
            "n",
            "mean",
            "median",
            "p05",
            "p95",
            "p99",
            "minimum",
            "maximum",
            "positive_fraction_percent",
            "negative_fraction_percent",
        ],
        runwise_qc_rows,
    )

    write_csv(
        qc_dir / "session_psc_qc.csv",
        [
            "finger",
            "runs",
            "n",
            "mean",
            "median",
            "p05",
            "p95",
            "p99",
            "minimum",
            "maximum",
            "positive_fraction_percent",
            "negative_fraction_percent",
        ],
        session_qc_rows,
    )

    write_csv(
        qc_dir / "voxel_validation.csv",
        [
            "finger",
            "run",
            "python_i",
            "python_j",
            "python_k",
            "matlab_i",
            "matlab_j",
            "matlab_k",
            "world_x_mm",
            "world_y_mm",
            "world_z_mm",
            "in_bounds",
            "inside_analysis_mask",
            "valid_for_stored_psc",
            "condition_beta_value",
            "regressor_peak",
            "constant_beta_value",
            "direct_psc",
            "stored_psc",
        ],
        voxel_validation_rows,
    )

    print()
    print(f"[{session}] Step 3 completed successfully.")
    print(f"  PSC maps:             {psc_dir}")
    print(f"  Run-wise maps:        {runwise_dir}")
    print(f"  Native-space inputs:  {native_space_dir}")
    print(f"  Analysis mask:        {analysis_mask_path}")
    print(f"  QC files:             {qc_dir}")
    print(
        "  Validation CSV: "
        f"{qc_dir / 'voxel_validation.csv'}"
    )


if __name__ == "__main__":
    if len(sys.argv) != 3:
        sys.exit(
            "Usage: python 03_beta_to_psc.py config.yaml <session>"
        )

    try:
        main(sys.argv[1], sys.argv[2])
    except (
        FileNotFoundError,
        KeyError,
        RuntimeError,
        TypeError,
        ValueError,
    ) as exc:
        sys.exit(f"ERROR: {exc}")
