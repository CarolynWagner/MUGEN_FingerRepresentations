#!/usr/bin/env bash

set -euo pipefail

# ============================================================
# Step 2: Generate broad cortical-depth compartments with LAYNII
#
# This script processes ONE session only.
# The session loop remains in run_pipeline.sh.
#
# The first argument may be either:
#   - a full layers-directory path, for example:
#       /.../sub-01/ses-18/layers
#   - a session name, for example:
#       ses-18
#
# If no argument is supplied, the script attempts to infer the
# session from the current working directory.
#
# Outputs:
#   depth3_metric_equidist.nii
#   depth3_layers_equidist.nii
#   depth3_midGM_equidist.nii
#
# The three bins are broad cortical-depth compartments, not
# histological cortical layers.
# ============================================================


# ------------------------------------------------------------
# Configuration
# ------------------------------------------------------------

BASE="${BASE:-/mnt/beegfs/workspace/2025-0422-Musicians7T/SPM_Prepro_FirstLevel/ROIs/HuberPipeline_v1_0/outputs/sub-01}"

NR_LAYERS=3
OUTPUT_BASENAME="depth3"


# ------------------------------------------------------------
# Resolve current session and layers directory
# ------------------------------------------------------------

INPUT="${1:-${SES:-}}"

if [[ -n "${INPUT}" && -d "${INPUT}" ]]; then

    # run_pipeline.sh passes the full layers-directory path
    DIR="$(cd "${INPUT}" && pwd -P)"

    if [[ "$(basename "${DIR}")" != "layers" ]]; then
        echo "ERROR: The supplied directory is not a layers directory:" >&2
        echo "  ${DIR}" >&2
        exit 1
    fi

    SESSION="$(basename "$(dirname "${DIR}")")"

elif [[ -n "${INPUT}" && "${INPUT}" =~ ^ses-[0-9]+$ ]]; then

    # A session name such as ses-18 was supplied
    SESSION="${INPUT}"
    DIR="${BASE}/${SESSION}/layers"

else

    # Try to infer the session from the current working directory
    CURRENT_DIR="$(pwd -P)"

    if [[ "$(basename "${CURRENT_DIR}")" == "layers" ]] &&
       [[ "$(basename "$(dirname "${CURRENT_DIR}")")" =~ ^ses-[0-9]+$ ]]; then

        DIR="${CURRENT_DIR}"
        SESSION="$(basename "$(dirname "${DIR}")")"

    else
        echo "ERROR: Could not determine the session or layers directory." >&2
        echo "Received argument: ${INPUT:-<none>}" >&2
        echo "Current directory: ${CURRENT_DIR}" >&2
        exit 1
    fi

fi

if [[ ! "${SESSION}" =~ ^ses-[0-9]+$ ]]; then
    echo "ERROR: Invalid session name derived from path:" >&2
    echo "  ${SESSION}" >&2
    exit 1
fi

RIM="${DIR}/rim.nii.gz"


# ------------------------------------------------------------
# Check dependencies and input paths
# ------------------------------------------------------------

echo "--- Step 2: LAYNII cortical-depth estimation ---"
echo "Session:   ${SESSION}"
echo "Directory: ${DIR}"
echo "Rim:       ${RIM}"

if ! command -v LN2_LAYERS >/dev/null 2>&1; then
    echo "ERROR: LN2_LAYERS was not found in PATH." >&2
    exit 1
fi

if ! command -v fslstats >/dev/null 2>&1; then
    echo "ERROR: fslstats was not found in PATH." >&2
    exit 1
fi

if [[ ! -d "${DIR}" ]]; then
    echo "ERROR: Directory does not exist:" >&2
    echo "  ${DIR}" >&2
    exit 1
fi

if [[ ! -f "${RIM}" ]]; then
    echo "ERROR: Rim file does not exist:" >&2
    echo "  ${RIM}" >&2
    exit 1
fi

echo ">>> Using LN2_LAYERS:"
command -v LN2_LAYERS

echo ">>> Using fslstats:"
command -v fslstats

cd "${DIR}"


# ------------------------------------------------------------
# Remove previous outputs
# ------------------------------------------------------------

echo
echo ">>> Removing previous depth3 outputs..."

rm -f \
    "${OUTPUT_BASENAME}_metric_equidist.nii" \
    "${OUTPUT_BASENAME}_metric_equidist.nii.gz" \
    "${OUTPUT_BASENAME}_layers_equidist.nii" \
    "${OUTPUT_BASENAME}_layers_equidist.nii.gz" \
    "${OUTPUT_BASENAME}_midGM_equidist.nii" \
    "${OUTPUT_BASENAME}_midGM_equidist.nii.gz"


# ------------------------------------------------------------
# Generate broad equidistant depth compartments
# ------------------------------------------------------------

echo ">>> Generating ${NR_LAYERS} broad equidistant depth compartments..."
echo ">>> Including inner and outer GM-border voxels..."

LN2_LAYERS \
    -rim "rim.nii.gz" \
    -nr_layers "${NR_LAYERS}" \
    -incl_borders \
    -output "${OUTPUT_BASENAME}"


# ------------------------------------------------------------
# Identify generated outputs
# ------------------------------------------------------------

find_output() {

    local stem="$1"

    if [[ -f "${stem}.nii" ]]; then
        printf '%s\n' "${stem}.nii"
    elif [[ -f "${stem}.nii.gz" ]]; then
        printf '%s\n' "${stem}.nii.gz"
    else
        return 1
    fi
}

METRIC_FILE="$(
    find_output "${OUTPUT_BASENAME}_metric_equidist"
)" || {
    echo "ERROR: Continuous-depth metric output was not created." >&2
    exit 1
}

LAYERS_FILE="$(
    find_output "${OUTPUT_BASENAME}_layers_equidist"
)" || {
    echo "ERROR: Layer-label output was not created." >&2
    exit 1
}

MIDGM_FILE="$(
    find_output "${OUTPUT_BASENAME}_midGM_equidist"
)" || {
    echo "ERROR: Middle-GM output was not created." >&2
    exit 1
}


# ------------------------------------------------------------
# Check expected outputs
# ------------------------------------------------------------

echo
echo ">>> Checking expected outputs..."

for FILE in \
    "${METRIC_FILE}" \
    "${LAYERS_FILE}" \
    "${MIDGM_FILE}"
do
    ls -lh "${FILE}"
done


# ------------------------------------------------------------
# Numerical QC
# ------------------------------------------------------------

echo
echo ">>> Numerical summary"

echo "Depth-compartment range:"
fslstats "${LAYERS_FILE}" -R

RIM_COUNT="$(
    fslstats "rim.nii.gz" -l 0.5 -V |
    awk '{print $1}'
)"

LAYER_COUNT="$(
    fslstats "${LAYERS_FILE}" -l 0.5 -V |
    awk '{print $1}'
)"

echo "Rim voxels:             ${RIM_COUNT}"
echo "Layer-labelled voxels:  ${LAYER_COUNT}"

TOTAL_LABELLED=0

for LABEL in 1 2 3; do

    LOWER="$(
        awk -v x="${LABEL}" \
            'BEGIN {printf "%.1f", x - 0.5}'
    )"

    UPPER="$(
        awk -v x="${LABEL}" \
            'BEGIN {printf "%.1f", x + 0.5}'
    )"

    COUNT="$(
        fslstats "${LAYERS_FILE}" \
            -l "${LOWER}" \
            -u "${UPPER}" \
            -V |
        awk '{print $1}'
    )"

    echo "Label ${LABEL}:             ${COUNT} voxels"

    TOTAL_LABELLED=$((TOTAL_LABELLED + COUNT))

done

echo "Sum of labels 1-3:      ${TOTAL_LABELLED}"


# ------------------------------------------------------------
# Validate coverage
# ------------------------------------------------------------

if [[ "${LAYER_COUNT}" -ne "${RIM_COUNT}" ]]; then
    echo "ERROR: Not every rim voxel received a depth label." >&2
    echo "Rim voxels:            ${RIM_COUNT}" >&2
    echo "Layer-labelled voxels: ${LAYER_COUNT}" >&2
    exit 1
fi

if [[ "${TOTAL_LABELLED}" -ne "${RIM_COUNT}" ]]; then
    echo "ERROR: Labels 1-3 do not sum to the rim voxel count." >&2
    echo "Rim voxels:        ${RIM_COUNT}" >&2
    echo "Sum of labels 1-3: ${TOTAL_LABELLED}" >&2
    exit 1
fi


# ------------------------------------------------------------
# Completion message
# ------------------------------------------------------------

echo
echo ">>> Step 2 completed successfully for ${SESSION}."

echo
echo "Continuous-depth output:"
echo "  ${DIR}/${METRIC_FILE}"

echo
echo "Three-compartment output:"
echo "  ${DIR}/${LAYERS_FILE}"

echo
echo "Middle-GM output:"
echo "  ${DIR}/${MIDGM_FILE}"

echo
echo "No cortical-column maps were generated."
