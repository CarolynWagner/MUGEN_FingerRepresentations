# MUGEN_fMRI -> HuberPipeline interface

HuberPipeline is a downstream specialized analysis, not a second preprocessing/GLM pipeline.

## MUGEN_fMRI owns
- acquisition/BIDS curation;
- preprocessing and spatial provenance;
- first-level GLM construction;
- beta/residual validity and finite-voxel QA;
- run/condition schema;
- generic first-level QA and reference-grid provenance.

## HuberPipeline owns
- cortical ribbon/depth geometry required here;
- anatomy-only intrinsic U/V construction;
- CASE-II control image and LN2_MULTILATERATE;
- U x V x depth flattening;
- finger dominance/topographic maps specific to this analysis;
- U-vs-V somatotopic tests;
- depth-resolved supported-window analysis;
- multilateration-radius sensitivity;
- Huber-specific publication/QC figures.

## v1.1 transition
The frozen ses-18 Steps 01-05 predate the final MUGEN_fMRI derivative contract. They therefore retain legacy path/schema compatibility. The next architectural change should be a regression-tested adapter from canonical MUGEN_fMRI derivatives to a Huber input manifest, not a rewrite of the validated ses-18 science.
