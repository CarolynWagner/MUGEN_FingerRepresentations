#!/usr/bin/env python3
"""
HuberPipeline Step 12 — Broad depth-band somatotopy in intrinsic U/V space.

This script tests whether thumb-to-little ordering becomes clearer when the
20 flattened cortical-depth bins are analysed separately rather than pooled.

Input
-----
The long-format dominance-fraction profile table produced by Step 10:

    dominance_fraction_profiles_long.csv

Default depth bands
-------------------
For 20 depth bins:
    low_depth     = bins 0–6
    middle_depth  = bins 7–12
    high_depth    = bins 13–19

The labels low/middle/high are deliberately neutral. Whether low depth
corresponds to white-matter-side or pial-side depends on the orientation of
the LN2_LAYERS metric and must be confirmed separately.

For each axis and depth band, the script computes:
    - density-weighted position profile for every finger;
    - weighted centroid;
    - peak position;
    - profile spread;
    - thumb→little Spearman correlation;
    - best-direction Spearman correlation;
    - adjacent inversions;
    - all-pair inversions;
    - finger-position range.

It then nominates the best axis × depth-band combination descriptively.

Outputs
-------
depth_band_finger_metrics.csv
depth_band_ordering_summary.csv
depth_band_profiles_long.csv
recommended_axis_depth_band.txt
depth_band_matrices.npz

Optional figures
----------------
U_depth_band_profiles.png
V_depth_band_profiles.png
U_depth_band_centroids.png
V_depth_band_centroids.png
axis_depth_band_ordering.png

Usage
-----
python 12_depth_band_somatotopy.py 00_config.yaml ses-18

Custom depth bands can be supplied as:
  --bands low:0:7 middle:7:13 high:13:20

Band syntax is name:start:stop, with stop exclusive.
"""

import argparse
import json
import sys
from pathlib import Path
from typing import Dict, List, Tuple

import numpy as np
import pandas as pd
import yaml
from scipy.stats import spearmanr


FINGERS = ("thumb", "index", "middle", "ring", "little")
FINGER_ORDER = {finger: index for index, finger in enumerate(FINGERS)}
AXES = ("U", "V")


def parse_args():
    parser = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
        description=(
            "Summarize thumb-to-little somatotopic ordering across broad "
            "cortical-depth bands in intrinsic U/V space."
        ),
    )
    parser.add_argument(
        "config",
        nargs="?",
        help="HuberPipeline YAML configuration.",
    )
    parser.add_argument(
        "session",
        nargs="?",
        help="Session key, e.g. ses-18.",
    )
    parser.add_argument(
        "--input-csv",
        default=None,
        help=(
            "Explicit Step-10 dominance_fraction_profiles_long.csv. "
            "Normally resolved automatically from CONFIG SESSION."
        ),
    )
    parser.add_argument(
        "--output-dir",
        default=None,
        help="Explicit output directory.",
    )
    parser.add_argument(
        "--bands",
        nargs="+",
        default=["low:0:7", "middle:7:13", "high:13:20"],
        help=(
            "Depth bands as name:start:stop, where stop is exclusive. "
            "For the frozen 20-bin analysis: low=0:7, middle=7:13, high=13:20."
        ),
    )
    parser.add_argument(
        "--minimum-position-support",
        type=float,
        default=1.0,
        help="Minimum summed density support for a valid position bin.",
    )
    parser.add_argument(
        "--no-figures",
        action="store_true",
        help="Skip Step-12 QC figures.",
    )
    return parser.parse_args()


def _expand_config_string(value, mapping):
    value = str(value)
    for _ in range(12):
        new = value
        for key, replacement in mapping.items():
            new = new.replace("${" + key + "}", str(replacement))
        if new == value:
            return new
        value = new
    return value


def resolve_production_paths(args):
    if args.config or args.session:
        if not (args.config and args.session):
            raise ValueError(
                "Config/session mode requires both positional arguments: "
                "CONFIG SESSION."
            )

        cfg_path = Path(args.config)
        if not cfg_path.is_file():
            raise FileNotFoundError(cfg_path)

        with cfg_path.open("r", encoding="utf-8") as stream:
            cfg = yaml.safe_load(stream)
        if not isinstance(cfg, dict):
            raise ValueError("YAML root must be a mapping.")

        dataset = cfg.get("dataset", {}) or {}
        subject = str(cfg.get("subject") or dataset.get("subject") or "")
        if not subject:
            raise ValueError("Could not resolve subject from configuration.")

        paths = cfg.get("paths", {}) or {}
        project_root = str(paths.get("project_root", ""))
        roi_root = str(paths.get("roi_root", ""))
        pipeline_root = str(paths.get("pipeline_root", ""))

        mapping = {
            "dataset.subject": subject,
            "dataset.session": args.session,
            "paths.project_root": project_root,
            "paths.roi_root": roi_root,
            "paths.pipeline_root": pipeline_root,
        }

        project_root = _expand_config_string(project_root, mapping)
        mapping["paths.project_root"] = project_root
        roi_root = _expand_config_string(roi_root, mapping)
        mapping["paths.roi_root"] = roi_root
        pipeline_root = _expand_config_string(pipeline_root, mapping)
        mapping["paths.pipeline_root"] = pipeline_root

        subject_root = paths.get("subject_root")
        if subject_root:
            subject_root = _expand_config_string(subject_root, mapping)
        else:
            subject_root = str(Path(pipeline_root) / "outputs" / subject)
        mapping["paths.subject_root"] = subject_root

        session_root = paths.get("session_root")
        if session_root:
            session_root = _expand_config_string(session_root, mapping)
        else:
            session_root = str(Path(subject_root) / args.session)

        frozen = cfg.get("frozen", {}) or {}
        radius = float(frozen.get("multilateration_radius_mm", 30))
        radius_tag = f"{radius:g}"

        step10_root = (
            Path(session_root) / f"huber_style_maps_radius{radius_tag}"
        )
        input_csv = (
            Path(args.input_csv)
            if args.input_csv
            else step10_root / "tables" / "dominance_fraction_profiles_long.csv"
        )
        output_dir = (
            Path(args.output_dir)
            if args.output_dir
            else step10_root / "depth_resolved_somatotopy"
        )

        return input_csv, output_dir, radius, cfg_path

    if not args.input_csv or not args.output_dir:
        raise ValueError(
            "Explicit mode requires --input-csv and --output-dir."
        )

    return (
        Path(args.input_csv),
        Path(args.output_dir),
        np.nan,
        None,
    )


def parse_bands(
    band_specs: List[str],
    n_depth: int,
) -> List[Tuple[str, int, int]]:
    bands = []
    used_names = set()

    for spec in band_specs:
        parts = spec.split(":")
        if len(parts) != 3:
            raise ValueError(
                f"Invalid band '{spec}'. Use name:start:stop."
            )

        name = parts[0].strip()
        start = int(parts[1])
        stop = int(parts[2])

        if not name:
            raise ValueError(f"Empty band name in '{spec}'.")
        if name in used_names:
            raise ValueError(f"Duplicate band name: {name}")
        if start < 0 or stop <= start or stop > n_depth:
            raise ValueError(
                f"Invalid band {name}:{start}:{stop} for "
                f"{n_depth} depth bins."
            )

        used_names.add(name)
        bands.append((name, start, stop))

    return bands


def validate_input(data: pd.DataFrame):
    required = {
        "finger",
        "profile_axis",
        "position_bin",
        "depth_bin",
        "dominance_fraction",
        "density_weight",
    }
    missing = sorted(required - set(data.columns))

    if missing:
        raise RuntimeError(
            "Missing required columns: " + ", ".join(missing)
        )

    unknown_fingers = sorted(
        set(data["finger"].dropna().unique()) - set(FINGERS)
    )
    if unknown_fingers:
        raise RuntimeError(
            f"Unexpected finger labels: {unknown_fingers}"
        )

    unknown_axes = sorted(
        set(data["profile_axis"].dropna().unique()) - set(AXES)
    )
    if unknown_axes:
        raise RuntimeError(
            f"Unexpected profile axes: {unknown_axes}"
        )


def reconstruct_matrix(
    data: pd.DataFrame,
    axis_name: str,
    finger: str,
) -> Tuple[np.ndarray, np.ndarray]:
    subset = data[
        (data["profile_axis"] == axis_name)
        & (data["finger"] == finger)
    ].copy()

    if subset.empty:
        raise RuntimeError(
            f"No rows for axis={axis_name}, finger={finger}."
        )

    n_position = int(subset["position_bin"].max()) + 1
    n_depth = int(subset["depth_bin"].max()) + 1

    values = np.full(
        (n_position, n_depth),
        np.nan,
        dtype=np.float64,
    )
    support = np.zeros(
        (n_position, n_depth),
        dtype=np.float64,
    )

    position = subset["position_bin"].astype(int).to_numpy()
    depth = subset["depth_bin"].astype(int).to_numpy()

    values[position, depth] = subset[
        "dominance_fraction"
    ].to_numpy(dtype=float)
    support[position, depth] = subset[
        "density_weight"
    ].to_numpy(dtype=float)

    values[support <= 0] = np.nan

    return values, support


def pooled_band_profile(
    matrix: np.ndarray,
    support: np.ndarray,
    start: int,
    stop: int,
) -> Tuple[np.ndarray, np.ndarray]:
    band_values = matrix[:, start:stop]
    band_support = support[:, start:stop]

    valid = (
        np.isfinite(band_values)
        & np.isfinite(band_support)
        & (band_support > 0)
    )

    numerator = np.sum(
        np.where(valid, band_values * band_support, 0.0),
        axis=1,
    )
    denominator = np.sum(
        np.where(valid, band_support, 0.0),
        axis=1,
    )

    profile = np.full(
        matrix.shape[0],
        np.nan,
        dtype=np.float64,
    )
    np.divide(
        numerator,
        denominator,
        out=profile,
        where=denominator > 0,
    )

    return profile, denominator


def position_metrics(
    profile: np.ndarray,
    support: np.ndarray,
    minimum_support: float,
) -> Dict[str, float]:
    position = np.arange(profile.size, dtype=np.float64)

    valid = (
        np.isfinite(profile)
        & np.isfinite(support)
        & (support >= minimum_support)
        & (profile > 0)
    )

    if not np.any(valid):
        return {
            "centroid_position": np.nan,
            "peak_position": np.nan,
            "profile_spread": np.nan,
            "profile_mass": 0.0,
            "n_valid_positions": 0,
        }

    weight = profile[valid] * support[valid]
    valid_position = position[valid]
    total = float(np.sum(weight))

    if total <= 0:
        return {
            "centroid_position": np.nan,
            "peak_position": np.nan,
            "profile_spread": np.nan,
            "profile_mass": 0.0,
            "n_valid_positions": int(np.count_nonzero(valid)),
        }

    centroid = float(
        np.sum(valid_position * weight) / total
    )
    variance = float(
        np.sum(
            ((valid_position - centroid) ** 2) * weight
        )
        / total
    )

    valid_indices = np.flatnonzero(valid)
    peak = int(
        valid_indices[
            np.argmax(profile[valid] * support[valid])
        ]
    )

    return {
        "centroid_position": centroid,
        "peak_position": float(peak),
        "profile_spread": float(np.sqrt(max(variance, 0.0))),
        "profile_mass": total,
        "n_valid_positions": int(np.count_nonzero(valid)),
    }


def inversion_counts(values: np.ndarray) -> Tuple[int, int]:
    adjacent = 0
    all_pairs = 0

    for index in range(values.size - 1):
        if values[index + 1] < values[index]:
            adjacent += 1

    for first in range(values.size):
        for second in range(first + 1, values.size):
            if values[second] < values[first]:
                all_pairs += 1

    return adjacent, all_pairs


def ordering_metrics(
    finger_metrics: pd.DataFrame,
    axis_name: str,
    band_name: str,
    metric_name: str,
) -> Dict[str, object]:
    subset = (
        finger_metrics[
            (finger_metrics["profile_axis"] == axis_name)
            & (finger_metrics["depth_band"] == band_name)
        ]
        .set_index("finger")
        .loc[list(FINGERS)]
    )

    positions = subset[metric_name].to_numpy(dtype=float)

    if not np.all(np.isfinite(positions)):
        return {
            "profile_axis": axis_name,
            "depth_band": band_name,
            "position_metric": metric_name,
            "spearman_rho_raw": np.nan,
            "spearman_p_raw": np.nan,
            "spearman_rho_best_direction": np.nan,
            "best_direction": "undetermined",
            "adjacent_inversions": np.nan,
            "all_pair_inversions": np.nan,
            "position_range": np.nan,
        }

    order = np.arange(len(FINGERS), dtype=float)
    rho, p_value = spearmanr(order, positions)

    if rho >= 0:
        oriented = positions
        direction = "increasing"
        best_rho = float(rho)
    else:
        oriented = -positions
        direction = "decreasing"
        best_rho = float(-rho)

    adjacent, all_pairs = inversion_counts(oriented)

    return {
        "profile_axis": axis_name,
        "depth_band": band_name,
        "position_metric": metric_name,
        "spearman_rho_raw": float(rho),
        "spearman_p_raw": float(p_value),
        "spearman_rho_best_direction": best_rho,
        "best_direction": direction,
        "adjacent_inversions": adjacent,
        "all_pair_inversions": all_pairs,
        "position_range": float(
            np.max(positions) - np.min(positions)
        ),
    }


def choose_best(ordering: pd.DataFrame) -> pd.Series:
    candidates = ordering[
        ordering["position_metric"] == "centroid_position"
    ].copy()

    candidates["score"] = (
        candidates["spearman_rho_best_direction"].fillna(-1.0)
        - 0.10 * candidates["adjacent_inversions"].fillna(99)
        - 0.02 * candidates["all_pair_inversions"].fillna(99)
    )

    candidates = candidates.sort_values(
        ["score", "position_range"],
        ascending=[False, False],
    )

    return candidates.iloc[0]


def create_figures(
    output_dir: Path,
    profiles: Dict[str, Dict[str, Dict[str, np.ndarray]]],
    metrics: pd.DataFrame,
    ordering: pd.DataFrame,
    bands: List[Tuple[str, int, int]],
):
    try:
        import matplotlib
        matplotlib.use("Agg", force=True)
        import matplotlib.pyplot as plt
    except Exception as exc:
        print(
            "WARNING: matplotlib unavailable; figures skipped.\n"
            f"  {exc}"
        )
        return

    band_names = [band[0] for band in bands]

    for axis_name in AXES:
        figure, axes = plt.subplots(
            nrows=len(band_names),
            ncols=1,
            figsize=(11, 4 * len(band_names)),
            sharex=True,
        )

        if len(band_names) == 1:
            axes = [axes]

        for plot_axis, band_name in zip(axes, band_names):
            for finger in FINGERS:
                profile = profiles[axis_name][band_name][finger]
                plot_axis.plot(
                    np.arange(profile.size),
                    profile,
                    label=finger,
                )

            plot_axis.set_ylabel("Dominance fraction")
            plot_axis.set_title(
                f"{axis_name} profiles — {band_name}"
            )
            plot_axis.legend()

        axes[-1].set_xlabel(f"{axis_name} position bin")
        figure.tight_layout()
        figure.savefig(
            output_dir
            / f"{axis_name}_depth_band_profiles.png",
            dpi=220,
        )
        plt.close(figure)

        centroid = metrics[
            metrics["profile_axis"] == axis_name
        ].pivot(
            index="finger",
            columns="depth_band",
            values="centroid_position",
        ).loc[list(FINGERS), band_names]

        figure = plt.figure(figsize=(10, 6))
        plot_axis = figure.add_subplot(111)

        x = np.arange(len(FINGERS))
        width = 0.8 / len(band_names)

        for band_index, band_name in enumerate(band_names):
            offset = (
                band_index - (len(band_names) - 1) / 2
            ) * width
            plot_axis.bar(
                x + offset,
                centroid[band_name].to_numpy(),
                width,
                label=band_name,
            )

        plot_axis.set_xticks(x)
        plot_axis.set_xticklabels(FINGERS)
        plot_axis.set_ylabel("Weighted centroid position bin")
        plot_axis.set_title(
            f"Finger centroids along {axis_name} by depth band"
        )
        plot_axis.legend()
        figure.tight_layout()
        figure.savefig(
            output_dir
            / f"{axis_name}_depth_band_centroids.png",
            dpi=220,
        )
        plt.close(figure)

    centroid_ordering = ordering[
        ordering["position_metric"] == "centroid_position"
    ].copy()

    labels = [
        f"{row.profile_axis}-{row.depth_band}"
        for row in centroid_ordering.itertuples()
    ]
    values = centroid_ordering[
        "spearman_rho_best_direction"
    ].to_numpy(dtype=float)

    figure = plt.figure(figsize=(11, 6))
    plot_axis = figure.add_subplot(111)
    plot_axis.bar(np.arange(len(labels)), values)
    plot_axis.set_xticks(np.arange(len(labels)))
    plot_axis.set_xticklabels(labels, rotation=45, ha="right")
    plot_axis.set_ylim(0, 1)
    plot_axis.set_ylabel("Best-direction Spearman rho")
    plot_axis.set_title(
        "Thumb-to-little ordering across axis x depth band"
    )
    figure.tight_layout()
    figure.savefig(
        output_dir / "axis_depth_band_ordering.png",
        dpi=220,
    )
    plt.close(figure)


def main():
    args = parse_args()

    input_path, output_dir, radius_mm, config_path = (
        resolve_production_paths(args)
    )
    output_dir.mkdir(parents=True, exist_ok=True)

    if not input_path.is_file():
        raise FileNotFoundError(input_path)

    data = pd.read_csv(input_path)
    validate_input(data)

    n_depth = int(data["depth_bin"].max()) + 1
    if n_depth != 20:
        raise RuntimeError(
            f"Frozen HuberPipeline v1.0 expects 20 depth bins; found {n_depth}."
        )
    bands = parse_bands(args.bands, n_depth)

    matrices = {axis_name: {} for axis_name in AXES}
    supports = {axis_name: {} for axis_name in AXES}
    profiles = {
        axis_name: {
            band_name: {}
            for band_name, _, _ in bands
        }
        for axis_name in AXES
    }

    metric_rows = []
    profile_rows = []
    npz_output = {}

    for axis_name in AXES:
        for finger in FINGERS:
            matrix, support = reconstruct_matrix(
                data,
                axis_name,
                finger,
            )
            matrices[axis_name][finger] = matrix
            supports[axis_name][finger] = support

            for band_name, start, stop in bands:
                profile, position_support = pooled_band_profile(
                    matrix,
                    support,
                    start,
                    stop,
                )
                profiles[axis_name][band_name][finger] = profile

                metrics = position_metrics(
                    profile,
                    position_support,
                    args.minimum_position_support,
                )

                metric_rows.append(
                    {
                        "profile_axis": axis_name,
                        "depth_band": band_name,
                        "depth_start": start,
                        "depth_stop_exclusive": stop,
                        "finger": finger,
                        "finger_order": FINGER_ORDER[finger],
                        **metrics,
                    }
                )

                for position_bin in range(profile.size):
                    profile_rows.append(
                        {
                            "profile_axis": axis_name,
                            "depth_band": band_name,
                            "depth_start": start,
                            "depth_stop_exclusive": stop,
                            "finger": finger,
                            "finger_order": FINGER_ORDER[finger],
                            "position_bin": position_bin,
                            "dominance_fraction": (
                                float(profile[position_bin])
                                if np.isfinite(profile[position_bin])
                                else np.nan
                            ),
                            "density_support": float(
                                position_support[position_bin]
                            ),
                        }
                    )

                key_prefix = (
                    f"{axis_name}_{band_name}_{finger}"
                )
                npz_output[f"{key_prefix}_profile"] = profile
                npz_output[
                    f"{key_prefix}_support"
                ] = position_support

    finger_metrics = pd.DataFrame(metric_rows)
    finger_metrics.to_csv(
        output_dir / "depth_band_finger_metrics.csv",
        index=False,
    )

    pd.DataFrame(profile_rows).to_csv(
        output_dir / "depth_band_profiles_long.csv",
        index=False,
    )

    ordering_rows = []

    for axis_name in AXES:
        for band_name, _, _ in bands:
            for metric_name in (
                "centroid_position",
                "peak_position",
            ):
                ordering_rows.append(
                    ordering_metrics(
                        finger_metrics,
                        axis_name,
                        band_name,
                        metric_name,
                    )
                )

    ordering = pd.DataFrame(ordering_rows)
    ordering.to_csv(
        output_dir / "depth_band_ordering_summary.csv",
        index=False,
    )

    np.savez_compressed(
        output_dir / "depth_band_matrices.npz",
        **npz_output,
    )

    best = choose_best(ordering)

    recommendation_path = (
        output_dir / "recommended_axis_depth_band.txt"
    )
    with recommendation_path.open(
        "w",
        encoding="utf-8",
    ) as stream:
        stream.write(
            "Depth-resolved intrinsic somatotopy assessment\n"
        )
        stream.write(
            "============================================\n\n"
        )
        stream.write(
            f"Best axis: {best['profile_axis']}\n"
        )
        stream.write(
            f"Best depth band: {best['depth_band']}\n"
        )
        stream.write(
            f"Best direction: {best['best_direction']}\n"
        )
        stream.write(
            "Best-direction Spearman rho: "
            f"{best['spearman_rho_best_direction']:.6f}\n"
        )
        stream.write(
            "Adjacent inversions: "
            f"{best['adjacent_inversions']}\n"
        )
        stream.write(
            "All-pair inversions: "
            f"{best['all_pair_inversions']}\n"
        )
        stream.write(
            "Position range: "
            f"{best['position_range']:.6f} bins\n\n"
        )
        stream.write(
            "Depth-band labels are neutral. Confirm whether low and high "
            "depth correspond to white-matter-side or pial-side using the "
            "orientation of depth3_metric_equidist.nii.\n"
        )

    # Production provenance. Step 12 is descriptive/QC only and does not
    # alter the intrinsic coordinate system or the Step-11 recommendation.
    centroid_ordering = ordering[
        ordering["position_metric"] == "centroid_position"
    ].copy()

    step11_summary_path = (
        output_dir.parent / "somatotopy_qc" / "step11_summary.json"
    )
    step11_recommended_axis = None
    step11_direction = None
    if step11_summary_path.is_file():
        try:
            with step11_summary_path.open("r", encoding="utf-8") as stream:
                step11_summary = json.load(stream)
            step11_recommended_axis = step11_summary.get(
                "recommended_somatotopic_axis"
            )
            if step11_recommended_axis in ("U", "V"):
                step11_direction = (
                    step11_summary.get("axes", {})
                    .get(step11_recommended_axis, {})
                    .get("direction")
                )
        except Exception:
            step11_recommended_axis = None
            step11_direction = None

    summary = {
        "status": "PASS",
        "config": str(config_path) if config_path else None,
        "session": args.session,
        "radius_mm": (
            float(radius_mm) if np.isfinite(radius_mm) else None
        ),
        "input_csv": str(input_path),
        "n_depth_bins": n_depth,
        "depth_bands": [
            {"name": name, "start": start, "stop_exclusive": stop}
            for name, start, stop in bands
        ],
        "depth_labels_are_neutral": True,
        "primary_metric": "dominance_fraction",
        "step11_recommended_axis": step11_recommended_axis,
        "step11_numerical_direction": step11_direction,
        "best_descriptive_axis_depth_band": {
            "axis": str(best["profile_axis"]),
            "depth_band": str(best["depth_band"]),
            "direction": str(best["best_direction"]),
            "best_direction_rho": float(
                best["spearman_rho_best_direction"]
            ),
            "adjacent_inversions": int(best["adjacent_inversions"]),
            "all_pair_inversions": int(best["all_pair_inversions"]),
        },
        "coordinate_geometry_modified": False,
        "axis_flipped_on_disk": False,
        "functional_feedback_to_uv_construction": False,
    }

    with (
        output_dir / "step12_summary.json"
    ).open("w", encoding="utf-8") as stream:
        json.dump(summary, stream, indent=2)

    with (
        output_dir / "step12_summary.txt"
    ).open("w", encoding="utf-8") as stream:
        stream.write("HuberPipeline Step 12 — broad depth-band somatotopy\n")
        stream.write("==================================================\n\n")
        stream.write(f"Input: {input_path}\n")
        stream.write(f"Depth bins: {n_depth}\n")
        stream.write(
            "Bands: low=0–6; middle=7–12; high=13–19\n"
        )
        stream.write("Depth labels are neutral: YES\n")
        stream.write("Primary metric: dominance fraction\n")
        if step11_recommended_axis:
            stream.write(
                f"Step-11 recommended axis: {step11_recommended_axis}\n"
            )
        if step11_direction:
            stream.write(
                f"Step-11 numerical direction: {step11_direction}\n"
            )
        stream.write("\n")
        for row in centroid_ordering.itertuples():
            stream.write(
                f"{row.profile_axis} / {row.depth_band}: "
                f"rho={row.spearman_rho_raw:.6f}; "
                f"|rho|={row.spearman_rho_best_direction:.6f}; "
                f"direction={row.best_direction}; "
                f"adjacent inversions={int(row.adjacent_inversions)}; "
                f"all-pair inversions={int(row.all_pair_inversions)}\n"
            )
        stream.write("\n")
        stream.write(
            "Best descriptive axis x depth band: "
            f"{best['profile_axis']} / {best['depth_band']} "
            f"({best['best_direction']})\n"
        )
        stream.write("Coordinate geometry modified: NO\n")
        stream.write("Axis flipped on disk: NO\n")
        stream.write("Functional feedback to UV construction: NO\n")
        stream.write("Hard validation: PASS\n")

    if not args.no_figures:
        create_figures(
            output_dir,
            profiles,
            finger_metrics,
            ordering,
            bands,
        )

    print("HuberPipeline Step 12 completed successfully.")
    print()

    centroid_rows = ordering[
        ordering["position_metric"] == "centroid_position"
    ]

    for row in centroid_rows.itertuples():
        print(
            f"{row.profile_axis} / {row.depth_band}: "
            f"rho={row.spearman_rho_raw:.4f}; "
            f"best={row.spearman_rho_best_direction:.4f}; "
            f"direction={row.best_direction}; "
            f"adjacent inversions={int(row.adjacent_inversions)}; "
            f"all-pair inversions={int(row.all_pair_inversions)}"
        )

    print()
    print(
        "Best descriptive axis x depth band: "
        f"{best['profile_axis']} / {best['depth_band']} "
        f"({best['best_direction']})"
    )
    if step11_recommended_axis:
        print(
            f"Step-11 recommended somatotopic axis: "
            f"{step11_recommended_axis}"
        )
    print(f"Output directory: {output_dir}")
    print("Depth labels low/middle/high are neutral.")
    print("Coordinate geometry modified: NO")
    print("Axis flipped on disk: NO")
    print("Functional feedback to UV construction: NO")
    print("Step 12 validation: PASS")


if __name__ == "__main__":
    try:
        main()
    except (
        FileNotFoundError,
        RuntimeError,
        TypeError,
        ValueError,
    ) as exc:
        sys.exit(f"ERROR: {exc}")

