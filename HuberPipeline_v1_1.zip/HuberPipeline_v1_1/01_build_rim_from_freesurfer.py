#!/usr/bin/env python
"""
Rim-Convention (LAYNII-Standard):
    1 = GM/CSF-boarder (outside)
    2 = GM/WM-boarder  (inside)
    3 = only GM
"""
import subprocess
import sys
from glob import glob
from pathlib import Path

import nibabel as nib
import numpy as np
import yaml
from scipy import ndimage


def run(cmd):
    print("+", " ".join(str(c) for c in cmd))
    subprocess.run(cmd, check=True)


def find_reference_beta(spm_dir):
    """First beta_*.nii(.gz) in SPM-folder - definies final grid
    identical to the one, that was also reference for the ROI."""
    candidates = sorted(glob(str(Path(spm_dir) / "beta_*.nii"))) + \
        sorted(glob(str(Path(spm_dir) / "beta_*.nii.gz")))
    if not candidates:
        sys.exit(f"ERROR: No beta_*.nii(.gz) found in {spm_dir}")
    return candidates[0]


def resample_to_session_space(moving_nii, reference, xfm, out_path, interp="NearestNeighbor"):
    run([
        "antsApplyTransforms", "-d", "3",
        "-i", str(moving_nii),
        "-r", str(reference),
        "-o", str(out_path),
        "-n", interp,
        "-t", str(xfm),
    ])


def build_rim(ribbon_native, wm_native, roi_native, out_path):
    ribbon = nib.load(ribbon_native)
    wm_img = nib.load(wm_native)
    roi_img = nib.load(roi_native)

    ribbon_data = ribbon.get_fdata()
    wm_data = wm_img.get_fdata()
    roi_data = roi_img.get_fdata() > 0.5

    # FreeSurfer ribbon.mgz: 3 = left GM, 42 = right GM (Cortex-Label)
    gm_mask = np.isin(np.round(ribbon_data), [3])
    wm_mask = np.isin(np.round(ribbon_data), [2])

    if roi_data.shape != gm_mask.shape:
        sys.exit(f"ERROR: Shape-Mismatch ROI {roi_data.shape} vs. ribbon {gm_mask.shape} "
                  "- check if same reference (Beta-picture) was used.")

    roi_dil = ndimage.binary_dilation(roi_data, iterations=6)
    gm_mask = gm_mask & roi_dil
    wm_mask = wm_mask & roi_dil

    if gm_mask.sum() == 0:
        sys.exit("ERROR: No GM-Voxel in ROI - check transformation/ROI-orientation!")

    gm_wm_border = ndimage.binary_dilation(wm_mask, iterations=1) & gm_mask
    gm_csf_border = gm_mask & ~ndimage.binary_erosion(gm_mask, iterations=1)
    gm_csf_border = gm_csf_border & ~gm_wm_border

    rim = np.zeros(gm_mask.shape, dtype=np.int16)
    rim[gm_mask] = 3
    rim[gm_wm_border] = 2
    rim[gm_csf_border] = 1

    out_img = nib.Nifti1Image(rim, ribbon.affine, ribbon.header)
    out_img.set_data_dtype(np.int16)
    nib.save(out_img, out_path)
    print(f"rim.nii saved: {out_path}  (only GM-Voxel: {int((rim == 3).sum())})")


def main(cfg_path, session):
    cfg = yaml.safe_load(open(cfg_path))
    sub = cfg["subject"]
    sess_cfg = cfg["sessions"][session]

    fs_dir = Path(cfg["freesurfer_subjects_dir"]) / cfg["freesurfer_subject_id"]
    out_dir = Path(cfg["out_dir"].format(subject=sub)) / session / "layers"
    out_dir.mkdir(parents=True, exist_ok=True)

    ribbon_fsnative = fs_dir / "mri" / "ribbon.mgz"
    wm_fsnative = fs_dir / "mri" / "wm.mgz"
    for p in (ribbon_fsnative, wm_fsnative):
        if not p.exists():
            sys.exit(f"ERROR: {p} not found - check freesurfer_subjects_dir/-subject_id!")

    xfm = Path(sess_cfg["xfm_fsnative_to_T1w"])
    roi_native = Path(sess_cfg["m1_roi"])
    reference = find_reference_beta(sess_cfg["spm_dir"])
    print(f"[{session}] Referencegrid: {reference}")

    # mgz -> nii.gz intermediate data (for ANTs)
    ribbon_nii = out_dir / "ribbon_fsnative.nii.gz"
    wm_nii = out_dir / "wm_fsnative.nii.gz"
    nib.save(nib.load(ribbon_fsnative), ribbon_nii)
    nib.save(nib.load(wm_fsnative), wm_nii)

    ribbon_native_out = out_dir / "ribbon_native.nii.gz"
    wm_native_out = out_dir / "wm_native.nii.gz"
    resample_to_session_space(ribbon_nii, reference, xfm, ribbon_native_out)
    resample_to_session_space(wm_nii, reference, xfm, wm_native_out)

    build_rim(ribbon_native_out, wm_native_out, roi_native, out_dir / "rim.nii.gz")


if __name__ == "__main__":
    if len(sys.argv) != 3:
        sys.exit("Usage: python 01_build_rim_from_freesurfer.py config.yaml <session>")
    main(sys.argv[1], sys.argv[2])
