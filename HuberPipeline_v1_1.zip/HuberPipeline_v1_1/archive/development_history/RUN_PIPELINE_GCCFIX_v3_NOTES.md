# HuberPipeline wrapper GCC fix v3

This revision keeps the validated ANTs/GCC runtime fix and corrects the actual
production filename for Step 02:

`02_generate_laynii_depths.sh`

The previous wrapper incorrectly called:

`02_laynii_layers_columns.sh`

Install `run_pipeline_GCCFIX_v3.sh` as `run_pipeline.sh`, convert to Unix line
endings if necessary, and resume from Step 02.
