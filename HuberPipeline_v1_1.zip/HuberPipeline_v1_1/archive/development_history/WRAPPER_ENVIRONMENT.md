# HuberPipeline wrapper environment

The wrapper bootstraps the tested runtime environment before Step 01:

- ANTs: `$HOME/ants-2.5.3/bin`
- LayNii: `$HOME/LayNii_v2.10.0_Linux64`
- FSL: `/cluster/apps/FSL/fsl-6.0.7.18`
- Python environment: `$HOME/envs/layerfmri`
- Matplotlib backend: `Agg`

It performs preflight checks for Python, ANTs, LayNii and FSL and rejects the obsolete Step-15 depth filename `layers_metric_equidist.nii`.

Run:

```bash
chmod +x run_pipeline_ENV_FINAL.sh
./run_pipeline_ENV_FINAL.sh 00_config.yaml ses-18
```

Resume from a step:

```bash
./run_pipeline_ENV_FINAL.sh 00_config.yaml ses-18 --from 03 --to 15
```
