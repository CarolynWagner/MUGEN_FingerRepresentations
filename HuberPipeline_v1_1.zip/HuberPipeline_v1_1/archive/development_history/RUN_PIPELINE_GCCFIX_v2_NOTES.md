# HuberPipeline wrapper GCC fix v2

This revision fixes a false-positive Step-15 preflight error.

The previous wrapper searched for the string `layers_metric_equidist.nii`
anywhere in the Step-15 script. The corrected Step-15 script intentionally
mentions that obsolete filename in comments and error messages, so the wrapper
incorrectly stopped even when the actual default path was correct.

The new wrapper inspects only the resolver expression:

`else layers / "depth3_metric_equidist.nii"`

and passes only when the actual production default is exactly
`depth3_metric_equidist.nii`.

The ANTs/GCC runtime fix is unchanged.
