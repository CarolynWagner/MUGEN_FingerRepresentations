# Step 15 production release 1.0.5

Exact filename: `15_generate_complete_ses18_figures.py`.

Changes:
- reads the reference multilateration radius dynamically from the YAML;
- no longer hard-codes radius30 for Huber maps, UV coordinates, perimeter, or
  metadata;
- labels Figure S18-4 as the reference-radius laminar analysis;
- adds Figure S18-S3 for Step-14 radius sensitivity;
- records explicitly that Step 14 does not select or change the production
  radius;
- preserves the original seven figures and adds S18-S3 as an eighth figure
  because the sensitivity result is scientifically substantive.
