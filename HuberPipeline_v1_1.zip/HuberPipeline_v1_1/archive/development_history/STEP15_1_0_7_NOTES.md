# Step 15 release 1.0.7 — final figure-QC revision

Changes are confined to Step-15 visualization/reporting.

## Global layout

- Panel letters are anchored close to each panel corner instead of high above
  the axes.
- Figure title and intrinsic-coordinate convention are combined into one
  layout-managed two-line `suptitle`, so constrained layout reserves a real
  header band.
- The coordinate wording is now:
  `reference-analysis somatotopic axis`
  rather than `preferred somatotopic axis`.

## Figure S18-4

- Explicitly labelled as the reference-radius laminar analysis.
- Caption states that radius sensitivity is reported separately in S18-S3.

## Figure S18-S3

- Panel C explicitly plots every strict supported interval.
- U and V have fixed distinct colors and line styles.
- The 30-mm U and 40-mm V intervals are annotated with their depth ranges.
- The legend is moved outside the data region so it cannot obscure the 40-mm
  interval.
- Panel D is renamed `Sensitivity summary`.
- `Conclusion concordance` is replaced by the more precise
  `criterion concordance`.
- The interpretation distinguishes the stable whole-depth U preference from
  the radius-sensitive strict depth-localized result.

No upstream computations, thresholds, radii, Step-13 interval definitions, or
Step-14 sensitivity calculations were changed.
