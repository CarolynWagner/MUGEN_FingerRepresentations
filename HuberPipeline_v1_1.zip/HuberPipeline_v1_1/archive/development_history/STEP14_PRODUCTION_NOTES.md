# Step 14 production notes

Exact filename: `14_compare_multilaterate_radius.py`.

Step 14 is a sensitivity analysis only. The production radius remains the
radius frozen in `00_config.yaml`; functional results are not used to optimize
or replace it.

At least two *cleaned* radius-specific Steps 08–13 must be complete. This
prevents comparison against obsolete legacy-radius products generated with
different control images, support definitions, or Step-13 interval criteria.

Run explicitly:

```bash
env -u PYTHONPATH -u PYTHONHOME \
  /home/carolyn.wagner/envs/layerfmri/bin/python \
  14_compare_multilaterate_radius.py \
  00_config.yaml ses-18 \
  --radii 25 30 35 40
```

Or auto-detect completed `huber_style_maps_radius*` candidates:

```bash
env -u PYTHONPATH -u PYTHONHOME \
  /home/carolyn.wagner/envs/layerfmri/bin/python \
  14_compare_multilaterate_radius.py \
  00_config.yaml ses-18 \
  --auto-detect
```

If only radius30 exists, the script intentionally stops because a sensitivity
analysis cannot be performed with one candidate.
