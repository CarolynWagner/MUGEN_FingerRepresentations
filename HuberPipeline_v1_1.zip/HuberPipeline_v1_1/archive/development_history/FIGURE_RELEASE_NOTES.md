# HuberPipeline figure release 1.0.2

This update is based on direct review of the complete seven-figure ses-18
output set.

## Canonical finger palette

The exact same five colors are now used everywhere a categorical finger
identity is displayed:

| Finger | Hex |
|---|---|
| Thumb | `#E64B35` |
| Index | `#F3C300` |
| Middle | `#00A087` |
| Ring | `#3C5488` |
| Little | `#B2479A` |

The native WTA (Figure S18-2A F), flattened WTA (S18-2B F), finger-profile
plots, centroid trajectories, and all finger legends therefore share one
palette.

Adjacent-finger pair plots use deterministic blends of the corresponding two
canonical finger colors.

## Layout corrections

- Added a dedicated header band for figure title.
- Intrinsic-coordinate annotation is placed below the main title.
- Crowded figures are slightly taller.
- Panel letters in S18-4 are slightly smaller.
- The methods statement in S18-S1 has its own header line.
- These changes specifically prevent the title/coordinate-note collisions
  visible in the previous S18-2B, S18-3, S18-4, S18-S1, and S18-S2 outputs.

## Label corrections

- S18-2A F: `Native-space winner-take-all`.
- S18-S2 A: `Winning dominance (maximum)`.
- S18-S2 B: `Winner margin (largest − second-largest)`.
- S18-S2 B colorbar: `Largest − second-largest dominance`.

## WTA visibility

Categorical WTA overlays are more opaque so the five finger identities are
more visually distinct while anatomical and ROI/rim contours remain visible.

## Provenance

`figure_manifest.json` and `figure_provenance.json` now record the exact
finger-color dictionary used for the release.
