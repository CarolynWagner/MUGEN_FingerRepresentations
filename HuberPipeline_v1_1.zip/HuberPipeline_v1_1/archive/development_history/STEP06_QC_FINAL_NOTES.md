# Step 06 QC enhancement

This corrected Step 06 keeps the anatomy-only endpoint-selection algorithm
unchanged and adds explicit QC products for the geometry that must be inspected
before `LN2_MULTILATERATE`.

New outputs:

- `*_intrinsic_geometry_qc_labels.nii.gz`
- `*_intrinsic_geometry_qc.png`

The categorical QC label map encodes:

- 1 anatomical patch
- 2 U corridor
- 3 U geodesic path
- 4 intrinsic side 1
- 5 intrinsic side 2
- 12 origin
- 13 min U
- 14 max U
- 15 min V
- 16 max V

A new optional argument, `--anatomical-background`, may point to an anatomical
or EPI image in the same grid. It is used only for the QC PNG and never affects
control-point selection.

The scientific construction remains fully anatomy-only: no functional mask,
finger-response map, or PCA endpoint selection is introduced.
