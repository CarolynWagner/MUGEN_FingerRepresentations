# HuberPipeline publication-figure captions

Figure release: **v1.0**  
Generator release: **1.0.1**

## Figure S18-1 — Anatomical localization and intrinsic-coordinate pipeline

Figure S18-1 | Anatomical localization and intrinsic-coordinate pipeline. (A) Mean EPI image in native space with the anatomical M1 region of interest (ROI). (B) Cortical rim generated from the FreeSurfer tissue boundaries after transformation to the native EPI grid; labels denote white matter (WM), cerebrospinal-fluid/pial side (CSF), and grey matter (GM). (C) Equidistant cortical-depth metric with the middle-grey-matter sheet outlined. (D) Corrected CASE-II multilateration control image containing the origin and four extrema that define the intrinsic coordinate system. (E) Intrinsic U coordinate; the arrow indicates increasing U. (F) Flattened anatomical patch. Black points mark directly sampled flat bins used for quantitative analysis.

## Figure S18-2A — Native-space finger responses

Figure S18-2A | Native-space finger responses. Panels A–E show session-mean percent signal change (PSC) for thumb, index, middle, ring, and little-finger movements on the mean EPI in native acquisition space. The cyan contour denotes the anatomical M1 ROI and the white contour denotes the cortical rim. Panel F shows the native-space winner-take-all (WTA) map, assigning each valid M1 voxel to the finger with the largest PSC. Colours identify the winning finger according to the legend.

## Figure S18-2B — Flattened continuous finger representations

Figure S18-2B | Flattened continuous finger representations on the unfolded cortical patch. Panels A–E show continuous finger-dominance maps in intrinsic U–V coordinates, overlaid on the display-only flattened anatomical background. Panel F shows the flattened WTA summary. Display interpolation and smoothing are used only for visualisation; all quantitative analyses use raw sampled bins.

## Figure S18-3 — Quantitative somatotopy and overlap

Figure S18-3 | Quantitative characterization of intrinsic somatotopy. (A) Raw column-wise finger-dominance profiles along U. (B) Best-direction Spearman association between canonical finger order and intrinsic position across cortical depth for U and V. (C) Adjacent-order violations; lower values indicate better preservation of canonical order. (D) Weighted overlap between adjacent finger representations across cortical depth.

## Figure S18-4 — Laminar organization and robustness

Figure S18-4 | Laminar variation in somatotopic organization and robustness. (A) Best-direction Spearman ordering across depth. (B) Kendall consistency for the same ordering. (C) U-minus-V axis specificity. (D) Finger-centroid trajectories along U. (E) Adjacent-finger overlap across depth. (F) Minimum positional support for U and V; the blue shaded region marks the selected robust contiguous interval.

## Figure S18-S1 — Raw versus display-processed flattened maps

Figure S18-S1 | Raw versus display-processed flattened maps. The upper row shows raw sampled finger-dominance maps without interpolation or smoothing. The lower row shows the corresponding display-only Gaussian-processed maps. Quantitative analyses use only the raw sampled maps.

## Figure S18-S2 — Display confidence and provenance

Figure S18-S2 | Confidence and provenance of flattened display maps. (A) Maximum finger dominance. (B) Winner margin, defined as the largest minus second-largest finger dominance. (C) Directly sampled flat locations. (D) Display-interpolation provenance, distinguishing raw sampled from display-filled bins. Interpolated values are never used for quantitative inference.
