# `run_radius_candidate.sh`

This wrapper runs the cleaned radius-specific Steps **09–13** for one already
generated Step-08 sensitivity branch.

## Why it exists

A prior 40-mm run correctly used radius-40 UV coordinates but Step 09 wrote
into `flat_uvd_radius30`. The corrected Step 09 fixes that bug. This wrapper
adds a second layer of protection by verifying radius provenance and expected
summary files after every step.

## Usage

Production/reference 30-mm branch:

```bash
./run_radius_candidate.sh 00_config.yaml ses-18
```

40-mm sensitivity branch:

```bash
./run_radius_candidate.sh 00_config_radius40.yaml ses-18
```

Then compare completed candidates:

```bash
env -u PYTHONPATH -u PYTHONHOME   /home/carolyn.wagner/envs/layerfmri/bin/python   14_compare_multilaterate_radius.py   00_config.yaml ses-18   --radii 30 40
```

## What the wrapper checks

Before running:
- Step-08 corrected UV-coordinate and perimeter files exist;
- their filenames match the radius configured in the YAML;
- expected flat and Huber output roots carry the same radius.

After Step 09:
- radius-specific `flatten_summary.json` exists and reports PASS.

After Step 10:
- `step10_summary.json` reports PASS;
- quantitative source is `raw_non_voronoi`;
- Voronoi is not used quantitatively.

After Steps 11–13:
- each summary reports PASS;
- coordinate geometry remains unchanged;
- no axis is flipped on disk;
- Step 13 still excludes Voronoi quantitatively.

Finally it writes a radius-candidate manifest under:

`outputs/<subject>/<session>/radius_candidates/`

and a complete terminal log under:

`outputs/<subject>/<session>/radius_candidate_logs/`.

## Optional controls

```bash
--from-step N
--to-step N
--qc-only-step09
--no-figures
```

For example, if Step 09 is already correct and you only want to rebuild
Steps 10–13:

```bash
./run_radius_candidate.sh   00_config_radius40.yaml ses-18   --from-step 10
```

The wrapper never changes the production radius and never ranks/optimizes
radii from functional performance.
