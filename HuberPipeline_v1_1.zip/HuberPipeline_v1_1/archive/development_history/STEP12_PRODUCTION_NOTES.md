# HuberPipeline Step 12 — production notes

Exact pipeline filename: `12_depth_band_somatotopy.py`.

Step 12 summarizes broad depth bands using the Step-10
`dominance_fraction_profiles_long.csv` raw quantitative product.

Frozen 20-bin bands:

- low: bins 0–6;
- middle: bins 7–12;
- high: bins 13–19.

These labels are deliberately neutral until the orientation of
`depth3_metric_equidist.nii` is explicitly interpreted anatomically.

For each U/V × depth-band combination the script reports density-weighted
finger centroids and peaks, profile spread, Spearman ordering, best numerical
direction, adjacent inversions, all-pair inversions, and position range.

The historical descriptive ranking is preserved. Step 12 does not modify the
Step-11 axis recommendation, flip U/V on disk, or feed functional information
back into Steps 06–09.
