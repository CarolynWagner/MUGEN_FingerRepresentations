# HuberPipeline wrapper — GCC runtime fix

This wrapper fixes the ANTs loader error:

`GLIBCXX_3.4.30 not found`

by prepending:

`/cluster/EasyBuild/apps/GCCcore/13.3.0/lib64`

to `LD_LIBRARY_PATH` before and after activating the Python environment.

The preflight additionally checks:

- ANTs can execute;
- ANTs no longer resolves `/lib64/libstdc++.so.6`;
- required LayNii/FSL/Python commands are available;
- Step 15 references `depth3_metric_equidist.nii` and not the obsolete filename.

Install as `run_pipeline.sh`.
