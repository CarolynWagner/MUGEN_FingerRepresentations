# HuberPipeline Step 09 — radius-specific output fix

Observed bug
------------

During a run with `00_config_radius40.yaml`, Step 09 correctly used the
radius-40 Step-08 UV coordinates and perimeter but wrote the flattened products
into `flat_uvd_radius30`.

Correction
----------

The production script now derives its output root directly from the current
session and configured multilateration radius:

- 30 mm -> `flat_uvd_radius30`
- 40 mm -> `flat_uvd_radius40`
- R mm  -> `flat_uvd_radiusR`

A stale `paths.flat_uvd_dir` value in the YAML is deliberately ignored for
Step 09, because allowing it to override radius-specific provenance can mix
sensitivity branches.

The script also recomputes the output root after `RADIUS_MM_OVERRIDE` and
fails before flattening if the UV-coordinate path, perimeter/domain path, and
output-root radius do not agree.

Unchanged
---------

No scientific flattening logic was changed:

- `depth3_metric_equidist.nii` remains the depth metric;
- target U/V bin width remains 0.275 mm;
- depth remains 20 bins;
- raw non-Voronoi products remain quantitative;
- Voronoi-filled products remain display-only;
- the Step-09 density/domain QC logic is unchanged.
