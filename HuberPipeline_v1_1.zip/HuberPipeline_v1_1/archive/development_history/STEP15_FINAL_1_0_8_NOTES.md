# Step 15 FINAL release 1.0.8

Exact production filename:

`15_generate_complete_ses18_figures.py`

This release is intended to freeze the ses-18 publication-figure generator.

## Final layout correction

The remaining overlap came from Matplotlib constrained layout allocating panel
axes too close to a two-line figure-level header. Release 1.0.8 fixes this at
the layout-engine level:

- every figure receives an explicit constrained-layout rectangle;
- the top 7.5% of one-line figures and top 11.5% of two-line
  intrinsic-coordinate figures are reserved exclusively for the figure header;
- panel letters are anchored closer to their own axes;
- the figure title and coordinate convention therefore cannot share vertical
  space with first-row panel titles.

The layout strategy was independently smoke-tested on representative 2x2,
2x3, and 2x5 figure grids and passed a rendered bounding-box overlap check.

## Figure S18-S3

- both strict supported intervals remain explicitly plotted;
- 30-mm U and 40-mm V interval labels are offset to opposite sides of their
  radius rows to avoid annotation collisions;
- terminology remains `Sensitivity summary` and `criterion concordance`.

## Scientific analysis

No upstream data, radius, Step-10 map construction, Step-11 axis statistics,
Step-12 depth-band results, Step-13 supported-interval rule, or Step-14
sensitivity analysis has changed.

Only Step 15 needs to be rerun.
