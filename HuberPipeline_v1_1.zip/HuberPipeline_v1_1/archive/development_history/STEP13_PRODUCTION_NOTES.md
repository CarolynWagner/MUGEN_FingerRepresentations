# HuberPipeline Step 13 — production notes

Exact production filename: `13_robust_laminar_somatotopy.py`.

Step 13 is the primary laminar somatotopy analysis in frozen HuberPipeline
v1.0. It uses Step-10 raw, non-Voronoi dominance-fraction profiles.

Frozen settings:

- 20 cortical-depth bins;
- three-bin sliding windows;
- minimum position support = 1;
- minimum valid positions per finger = 5;
- minimum profile mass = 1;
- minimum centroid/peak position range = 1;
- minimum contiguous interval length = 3 windows.

The script computes:

- single-bin diagnostics;
- three-bin sliding-window estimates;
- finger centroids and peaks;
- Spearman and Kendall ordering;
- adjacent/all-pair inversions;
- adjacent-finger overlap;
- U-versus-V axis specificity;
- robust contiguous valid intervals.

The contiguous sliding-window result is the primary Step-13 summary.
Step 11 and Step 12 are read only for provenance; their results never alter
the intrinsic U/V geometry.

Outputs are written to:

`huber_style_maps_radius30/robust_continuous_laminar_somatotopy/`

including `step13_summary.json` and the historical
`robust_laminar_summary.txt`.
