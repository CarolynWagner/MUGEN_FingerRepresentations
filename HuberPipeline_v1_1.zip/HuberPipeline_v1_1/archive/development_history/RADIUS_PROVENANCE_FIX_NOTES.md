# Radius-provenance correction for Step 10 and candidate wrapper

## Observed issue

The 40-mm Step-09 rerun correctly produced a 260×160×20 branch under
`flat_uvd_radius40`, but a subsequent Step-10 run reported a 228×149×20 input
while writing to `huber_style_maps_radius40`.

That pattern is consistent with a stale `paths.flat_uvd_dir` value pointing to
the 30-mm branch.

## Step 10 correction

`10_build_huber_style_maps.py` now derives its input root strictly from:

`session_root / flat_uvd_radius<configured multilateration radius>`

and its output root from:

`session_root / huber_style_maps_radius<configured multilateration radius>`

A stale YAML `paths.flat_uvd_dir` can no longer override this.

The script fails immediately if the configured radius token does not occur in
both its input and output branch paths.

Its `step10_summary.json` now explicitly records:

- `flat_root`
- `output_dir`
- `radius_token`

## Wrapper correction

`run_radius_candidate.sh` now checks all three Step-10 provenance fields after
Step 10 completes. Thus a 40-mm branch cannot silently consume
`flat_uvd_radius30` while writing `huber_style_maps_radius40`.

## What to rerun now

Radius 30 is already clean once rebuilt with the corrected Step 09/10.

For radius 40, Step 09 is already clean. Therefore you only need:

```bash
./run_radius_candidate.sh   00_config_radius40.yaml ses-18   --from-step 10
```

This will rebuild Steps 10–13 from `flat_uvd_radius40` and stop immediately if
Step 10 does not consume that exact branch.
