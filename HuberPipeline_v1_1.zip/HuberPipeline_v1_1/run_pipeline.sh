#!/usr/bin/env bash
set -euo pipefail
D="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"; cd "$D"
CONFIG="${1:-}"; SESSION="${2:-}"; [[ -n "$CONFIG" && -n "$SESSION" ]] || { echo "Usage: $0 CONFIG SESSION [--from STEP] [--to STEP]" >&2; exit 2; }; shift 2
FROM=1; TO=15; while [[ $# -gt 0 ]]; do case "$1" in --from|--from-step) FROM="$2"; shift 2;; --to|--to-step) TO="$2"; shift 2;; *) echo "ERROR: unknown argument $1" >&2; exit 2;; esac; done
inrange(){ local n=$((10#$1)); (( n >= 10#$FROM && n <= 10#$TO )); }
run(){ local n="$1" title="$2"; shift 2; if inrange "$n"; then echo; echo "=== Step $n: $title ==="; "$@"; else echo "Skipping Step $n: $title"; fi; }
die(){ echo "ERROR: $*" >&2; exit 1; }
FILES=(01_build_rim_from_freesurfer.py 02_generate_laynii_depths.sh 03_beta_to_psc.py 04_compute_finger_dominance.py 05_validate_reference_session.py 06_generate_intrinsic_uv_control_points.py 07_prepare_multilaterate_control_image.py 08_run_multilaterate.sh 09_patch_flatten.sh 10_build_huber_style_maps.py 11_identify_somatotopic_axis.py 12_depth_band_somatotopy.py 13_robust_laminar_somatotopy.py 14_compare_multilaterate_radius.py 15_generate_publication_figures.py pipeline_utils.py figure_utils.py "$CONFIG")
for f in "${FILES[@]}"; do [[ -f "$f" ]] || die "missing $f"; done
GCC=/cluster/EasyBuild/apps/GCCcore/13.3.0/lib64; [[ -d "$GCC" ]] && export LD_LIBRARY_PATH="$GCC:${LD_LIBRARY_PATH:-}"
export FSLDIR="${FSLDIR:-/cluster/apps/FSL/fsl-6.0.7.18}"; [[ -f "$FSLDIR/etc/fslconf/fsl.sh" ]] && source "$FSLDIR/etc/fslconf/fsl.sh"
export PATH="$HOME/ants-2.5.3/bin:$HOME/software/laynii:$FSLDIR/bin:$PATH"; export MPLBACKEND=Agg
PY="$(python - "$CONFIG" <<'PY2'
import sys,yaml
c=yaml.safe_load(open(sys.argv[1])); print((c.get('software') or {}).get('python') or 'python')
PY2
)"; [[ -x "$PY" ]] || PY="$(command -v python)"
echo "HuberPipeline v1.1 | $SESSION | Steps $FROM-$TO | Python $PY"
run 01 "Build cortical rim" "$PY" 01_build_rim_from_freesurfer.py "$CONFIG" "$SESSION"
run 02 "Generate LayNii cortical depths" bash 02_generate_laynii_depths.sh "$SESSION"
run 03 "Beta to PSC/native products" "$PY" 03_beta_to_psc.py "$CONFIG" "$SESSION"
run 04 "Finger dominance" "$PY" 04_compute_finger_dominance.py "$CONFIG" "$SESSION"
run 05 "Huber reference validation" "$PY" 05_validate_reference_session.py "$CONFIG" "$SESSION"
if inrange 06; then eval "$("$PY" - "$CONFIG" "$SESSION" <<'PY2'
import sys,shlex,yaml
from pathlib import Path
c=yaml.safe_load(open(sys.argv[1])); ses=sys.argv[2]; sub=str(c.get('subject') or c['dataset']['subject']); base=Path(str(c['out_dir']).format(subject=sub))/ses; sc=c['sessions'][ses]
for k,v in {'MIDGM':base/'layers'/'depth3_midGM_equidist.nii','ROI':sc['m1_roi'],'BG':sc.get('figure_anatomical',''),'OUT':base/'true_uv'/'uv_control_points_anatomical.nii.gz'}.items(): print(f'{k}={shlex.quote(str(v))}')
PY2
)"; A=(--midgm "$MIDGM" --anatomical-roi "$ROI" --output "$OUT"); [[ -n "${BG:-}" ]] && A+=(--anatomical-background "$BG"); run 06 "Anatomy-only intrinsic UV control points" "$PY" 06_generate_intrinsic_uv_control_points.py "${A[@]}"; fi
run 07 "Prepare CASE-II control image" "$PY" 07_prepare_multilaterate_control_image.py "$CONFIG" "$SESSION"
run 08 "Run multilateration" bash 08_run_multilaterate.sh "$CONFIG" "$SESSION"
run 09 "Patch flattening" bash 09_patch_flatten.sh "$CONFIG" "$SESSION"
run 10 "Build Huber-style maps" "$PY" 10_build_huber_style_maps.py "$CONFIG" "$SESSION"
run 11 "Identify candidate somatotopic axis" "$PY" 11_identify_somatotopic_axis.py "$CONFIG" "$SESSION"
run 12 "Depth-band somatotopy" "$PY" 12_depth_band_somatotopy.py "$CONFIG" "$SESSION"
run 13 "Robust continuous laminar somatotopy" "$PY" 13_robust_laminar_somatotopy.py "$CONFIG" "$SESSION"
run 14 "Radius sensitivity" "$PY" 14_compare_multilaterate_radius.py "$CONFIG" "$SESSION"
run 15 "Publication/QC figures" "$PY" 15_generate_publication_figures.py "$CONFIG" "$SESSION"
