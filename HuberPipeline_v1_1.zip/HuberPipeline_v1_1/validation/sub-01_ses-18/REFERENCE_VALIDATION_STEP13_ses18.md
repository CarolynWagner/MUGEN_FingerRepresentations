# HuberPipeline reference validation — Step 13

Reference dataset: `sub-01 / ses-18`
Status: **PASS**
Frozen production radius: **30 mm**

Primary supported Step-13 interval:
- axis: U
- windows: 10–13
- normalized depth: 0.526316–0.684211
- n windows: 4
- mean |rho|: 0.7000
- minimum |rho|: 0.6000
- mean |tau|: 0.5000
- minimum U-vs-V specificity: 0.3000
- mean U-vs-V specificity: 0.4750

Step-11 preferred axis remains U.

Interpretation: supported U-axis somatotopy is present over a restricted
intermediate normalized-depth interval, not uniformly across the full ribbon.
