# Release validation

The final archive was checked on 2026-08-06 as follows:

- `00_config.yaml` parsed successfully with PyYAML.
- Every Python file passed syntax compilation with Python 3.11 using
  `python -m py_compile`.
- Every shell script passed `bash -n` syntax validation.
- The archive contains all documented Steps 01–15, including Steps 12 and 13.
- `figure_utils.py`, required by Step 15, is included.
- Step 03 and Step 15 are the final native-space/publication versions.

Full numerical execution was not possible in the packaging environment because
it does not contain the project NIfTI inputs, LAYNII executables, FSL, ANTs, or
the dedicated `layerfmri` Python environment. Run the reference session through
the wrapper and inspect the documented QC outputs before group deployment.
