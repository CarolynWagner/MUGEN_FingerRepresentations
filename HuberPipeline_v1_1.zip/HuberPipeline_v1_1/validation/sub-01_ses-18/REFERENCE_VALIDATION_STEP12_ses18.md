# HuberPipeline reference validation — Step 12

Reference dataset: `sub-01 / ses-18`

Status: **PASS**

Broad depth-band somatotopy:

- U / low: rho = -1.0000; best-direction rho = 1.0000;
  decreasing; adjacent inversions = 0; all-pair inversions = 0.
- U / middle: rho = 0.8000; best-direction rho = 0.8000;
  increasing; adjacent inversions = 2; all-pair inversions = 2.
- U / high: rho = -0.1000; best-direction rho = 0.1000;
  decreasing; adjacent inversions = 2; all-pair inversions = 5.
- V / low: rho = -0.1000; best-direction rho = 0.1000;
  decreasing; adjacent inversions = 2; all-pair inversions = 5.
- V / middle: rho = -0.2000; best-direction rho = 0.2000;
  decreasing; adjacent inversions = 1; all-pair inversions = 4.
- V / high: rho = -0.6000; best-direction rho = 0.6000;
  decreasing; adjacent inversions = 2; all-pair inversions = 3.

Best descriptive axis × depth band: **U / low (decreasing)**.

Step-11 recommended somatotopic axis remains **U**.

The labels low/middle/high remain numerically neutral until the orientation of
`depth3_metric_equidist.nii` is explicitly assigned to WM/pial anatomy.
No coordinate geometry is modified and no axis is flipped on disk.
