# HuberPipeline reference validation — Step 11

Reference dataset: `sub-01 / ses-18`

Status: **PASS**

Primary metric: dominance fraction.

Observed intrinsic-axis ordering:

- U: centroid rho = -1.0000; best-direction rho = 1.0000;
  numerical direction = decreasing; adjacent inversions = 0;
  all-pair inversions = 0; minimum adjacent centroid separation = 0.700 bins.
- V: centroid rho = -0.1000; best-direction rho = 0.1000;
  numerical direction = decreasing; adjacent inversions = 2;
  all-pair inversions = 5; minimum adjacent centroid separation = -11.950 bins.

Frozen reference interpretation:

**Recommended somatotopic axis: U, decreasing numerical direction.**

The sign of U is descriptive only. The coordinate image is not flipped on
disk, and functional information is not fed back into the anatomy-only
intrinsic-coordinate construction.
