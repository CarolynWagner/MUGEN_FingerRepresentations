#!/usr/bin/env python3
"""
HuberPipeline Step 10 - Build Huber-style flattened finger maps and laminar/column profiles.

Inputs
------
Raw, non-Voronoi LN2_PATCH_FLATTEN outputs in:

    <session>/flat_uvd/raw

The script uses the five flattened dominance-fraction maps as the primary
finger-topography measure and optionally processes PSC and selectivity maps.

Primary quantitative outputs
----------------------------
1. Depth-averaged U x V maps for every finger.
2. Winner-take-all finger map in U x V space.
3. Winner margin and maximum dominance-fraction maps.
4. U x depth matrices, averaging over V with density weights.
5. V x depth matrices, averaging over U with density weights.
6. Long-format CSV tables for subsequent statistical analysis.
7. QC tables describing support, density, and finger-map coverage.

Important methodological choices
--------------------------------
- Only raw, non-Voronoi flattened maps are used quantitatively.
- Empty flat bins remain NaN.
- No smoothing is applied.
- Density-weighted averaging is used when collapsing one flat coordinate.
- WTA is computed from bounded dominance fractions, not from integer labels.
- Both U x depth and V x depth profiles are produced. The anatomically
  relevant finger-order axis can then be selected after visual validation.

Optional figures
----------------
If matplotlib is installed, PNG maps and profile figures are written.
If it is unavailable, all NIfTI/NPY/CSV outputs are still produced.

Usage
-----
Preferred production mode:

python 10_build_huber_style_maps.py 00_config.yaml ses-18

Explicit mode remains available:

python 10_build_huber_style_maps.py \
    --flat-root /path/to/ses-18/flat_uvd_radius30 \
    --output-dir /path/to/ses-18/huber_style_maps_radius30

Dependencies
------------
Required:
    numpy
    nibabel
    pandas

Optional:
    matplotlib
"""

import argparse
import csv
import re
import sys
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import nibabel as nib
import numpy as np
import pandas as pd
import yaml


FINGERS = ("thumb", "index", "middle", "ring", "little")
FINGER_TO_LABEL = {
    "thumb": 1,
    "index": 2,
    "middle": 3,
    "ring": 4,
    "little": 5,
}


def parse_args():
    parser = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
        description=(
            "Construct Huber-style UxV finger maps and U/Vxdepth profiles "
            "from raw LN2_PATCH_FLATTEN outputs."
        ),
    )

    # Preferred production interface.
    parser.add_argument(
        "config",
        nargs="?",
        help="HuberPipeline YAML configuration.",
    )
    parser.add_argument(
        "session",
        nargs="?",
        help="Session key, e.g. ses-18.",
    )

    # Explicit/debug interface.
    parser.add_argument(
        "--flat-root",
        default=None,
        help="Directory containing raw/ and display_voronoi/.",
    )
    parser.add_argument(
        "--output-dir",
        default=None,
        help="Output directory.",
    )
    parser.add_argument(
        "--minimum-density",
        type=float,
        default=None,
        help=(
            "Minimum raw density required for a valid flat bin. "
            "Default is read from flat_validity.minimum_density or 1.0."
        ),
    )
    parser.add_argument(
        "--minimum-finger-coverage",
        type=int,
        default=5,
        help=(
            "Number of finite finger maps required for a valid WTA bin. "
            "Use 5 for complete five-finger coverage."
        ),
    )
    parser.add_argument(
        "--depth-start",
        type=int,
        default=0,
        help="First zero-based depth bin included in depth averages.",
    )
    parser.add_argument(
        "--depth-stop",
        type=int,
        default=None,
        help=(
            "Exclusive zero-based depth-bin endpoint. "
            "Default: include all bins."
        ),
    )
    parser.add_argument(
        "--no-figures",
        action="store_true",
        help="Skip Step-10 QC/summary figures.",
    )
    return parser.parse_args()


def _expand_config_string(value, mapping):
    value = str(value)
    for _ in range(12):
        new = value
        for key, replacement in mapping.items():
            new = new.replace("${" + key + "}", str(replacement))
        if new == value:
            return new
        value = new
    return value


def resolve_production_args(args):
    """
    Resolve Step-10 input/output paths from 00_config.yaml while preserving the
    explicit --flat-root/--output-dir interface for debugging.
    """
    if args.config or args.session:
        if not (args.config and args.session):
            raise ValueError(
                "Config/session mode requires both positional arguments: "
                "CONFIG SESSION."
            )

        cfg_path = Path(args.config)
        if not cfg_path.is_file():
            raise FileNotFoundError(cfg_path)

        with cfg_path.open("r", encoding="utf-8") as stream:
            cfg = yaml.safe_load(stream)
        if not isinstance(cfg, dict):
            raise ValueError("YAML root must be a mapping.")

        dataset = cfg.get("dataset", {}) or {}
        subject = str(cfg.get("subject") or dataset.get("subject") or "")
        if not subject:
            raise ValueError("Could not resolve subject from configuration.")

        paths = cfg.get("paths", {}) or {}
        project_root = str(paths.get("project_root", ""))
        roi_root = str(paths.get("roi_root", ""))
        pipeline_root = str(paths.get("pipeline_root", ""))

        mapping = {
            "dataset.subject": subject,
            "dataset.session": args.session,
            "paths.project_root": project_root,
            "paths.roi_root": roi_root,
            "paths.pipeline_root": pipeline_root,
        }

        project_root = _expand_config_string(project_root, mapping)
        mapping["paths.project_root"] = project_root
        roi_root = _expand_config_string(roi_root, mapping)
        mapping["paths.roi_root"] = roi_root
        pipeline_root = _expand_config_string(pipeline_root, mapping)
        mapping["paths.pipeline_root"] = pipeline_root

        subject_root = paths.get("subject_root")
        if subject_root:
            subject_root = _expand_config_string(subject_root, mapping)
        else:
            subject_root = str(Path(pipeline_root) / "outputs" / subject)
        mapping["paths.subject_root"] = subject_root

        session_root = paths.get("session_root")
        if session_root:
            session_root = _expand_config_string(session_root, mapping)
        else:
            session_root = str(Path(subject_root) / args.session)
        mapping["paths.session_root"] = session_root

        frozen = cfg.get("frozen", {}) or {}
        radius = float(frozen.get("multilateration_radius_mm", 30))
        radius_tag = f"{radius:g}"

        # Radius-specific Step-10 provenance.
        # Do not honor a stale paths.flat_uvd_dir from YAML because that can
        # silently read radius30 while writing radius40 outputs.
        flat_root = str(
            Path(session_root) / f"flat_uvd_radius{radius_tag}"
        )
        output_dir = (
            Path(session_root) / f"huber_style_maps_radius{radius_tag}"
        )

        flat_validity = cfg.get("flat_validity", {}) or {}
        minimum_density = (
            float(args.minimum_density)
            if args.minimum_density is not None
            else float(flat_validity.get("minimum_density", 1.0))
        )

        return (
            Path(args.flat_root) if args.flat_root else Path(flat_root),
            Path(args.output_dir) if args.output_dir else output_dir,
            minimum_density,
            radius,
            cfg_path,
        )

    if not args.flat_root or not args.output_dir:
        raise ValueError(
            "Explicit mode requires --flat-root and --output-dir."
        )

    minimum_density = (
        float(args.minimum_density)
        if args.minimum_density is not None
        else 1.0
    )
    return (
        Path(args.flat_root),
        Path(args.output_dir),
        minimum_density,
        np.nan,
        None,
    )


def find_single(pattern: str, directory: Path) -> Path:
    matches = sorted(directory.glob(pattern))

    if len(matches) != 1:
        raise RuntimeError(
            f"Expected exactly one file matching:\n"
            f"  {directory / pattern}\n"
            f"Found {len(matches)}:\n  "
            + "\n  ".join(str(path) for path in matches)
        )

    return matches[0]


def find_flat_map(raw_dir: Path, metric: str, finger: str) -> Path:
    pattern = f"{metric}_{finger}_flat_raw_flat_*x*x*.nii*"
    candidates = [
        path
        for path in sorted(raw_dir.glob(pattern))
        if "_density" not in path.name
        and "_domain" not in path.name
        and "_foldedcoords" not in path.name
    ]

    if len(candidates) != 1:
        raise RuntimeError(
            f"Expected one raw flat map for {metric}/{finger}; "
            f"found {len(candidates)}:\n  "
            + "\n  ".join(str(path) for path in candidates)
        )

    return candidates[0]


def find_density_map(raw_dir: Path) -> Path:
    candidates = sorted(
        raw_dir.glob(
            "dominance_fraction_thumb_flat_raw_flat_*x*x*_density.nii*"
        )
    )

    if len(candidates) != 1:
        candidates = sorted(
            raw_dir.glob("*_flat_raw_flat_*x*x*_density.nii*")
        )

    if len(candidates) < 1:
        raise RuntimeError("No raw density map found.")

    return candidates[0]


def find_domain_map(raw_dir: Path) -> Path:
    candidates = sorted(
        raw_dir.glob(
            "dominance_fraction_thumb_flat_raw_flat_*x*x*_domain.nii*"
        )
    )

    if len(candidates) != 1:
        candidates = sorted(
            raw_dir.glob("*_flat_raw_flat_*x*x*_domain.nii*")
        )

    if len(candidates) < 1:
        raise RuntimeError("No raw domain map found.")

    return candidates[0]


def load_image(path: Path) -> Tuple[nib.Nifti1Image, np.ndarray]:
    image = nib.load(str(path))
    data = image.get_fdata(dtype=np.float32)

    if data.ndim != 3:
        raise RuntimeError(
            f"Expected a 3D flattened map, found {data.shape}: {path}"
        )

    return image, data


def validate_same_grid(
    reference: nib.Nifti1Image,
    moving: nib.Nifti1Image,
    moving_path: Path,
):
    if reference.shape != moving.shape:
        raise RuntimeError(
            f"Shape mismatch: reference={reference.shape}, "
            f"{moving_path}={moving.shape}"
        )

    if not np.allclose(
        reference.affine,
        moving.affine,
        atol=1e-5,
        rtol=0.0,
    ):
        raise RuntimeError(f"Affine mismatch: {moving_path}")


def save_nifti(
    data: np.ndarray,
    reference: nib.Nifti1Image,
    path: Path,
    dtype,
):
    array = np.asarray(data, dtype=dtype)
    header = reference.header.copy()
    header.set_data_dtype(dtype)
    header.set_slope_inter(1.0, 0.0)

    image = nib.Nifti1Image(
        array,
        reference.affine.copy(),
        header,
    )

    qform, qcode = reference.get_qform(coded=True)
    sform, scode = reference.get_sform(coded=True)

    if qform is not None:
        image.set_qform(qform, int(qcode))
    if sform is not None:
        image.set_sform(sform, int(scode))

    image.header.set_slope_inter(1.0, 0.0)
    nib.save(image, str(path))


def depth_slice(
    n_depth: int,
    start: int,
    stop: Optional[int],
) -> slice:
    if start < 0 or start >= n_depth:
        raise ValueError(
            f"--depth-start must lie in [0,{n_depth - 1}]."
        )

    resolved_stop = n_depth if stop is None else stop

    if resolved_stop <= start or resolved_stop > n_depth:
        raise ValueError(
            f"--depth-stop must lie in [{start + 1},{n_depth}]."
        )

    return slice(start, resolved_stop)


def weighted_mean(
    values: np.ndarray,
    weights: np.ndarray,
    axis,
) -> np.ndarray:
    valid = np.isfinite(values) & np.isfinite(weights) & (weights > 0)

    numerator = np.sum(
        np.where(valid, values * weights, 0.0),
        axis=axis,
    )
    denominator = np.sum(
        np.where(valid, weights, 0.0),
        axis=axis,
    )

    output = np.full(
        numerator.shape,
        np.nan,
        dtype=np.float32,
    )
    np.divide(
        numerator,
        denominator,
        out=output,
        where=denominator > 0,
    )

    return output


def weighted_support(weights: np.ndarray, axis) -> np.ndarray:
    valid = np.isfinite(weights) & (weights > 0)
    return np.sum(
        np.where(valid, weights, 0.0),
        axis=axis,
    ).astype(np.float32)


def write_matrix_csv(
    matrix: np.ndarray,
    support: np.ndarray,
    finger: str,
    profile_axis: str,
    path: Path,
):
    rows = []

    n_position, n_depth = matrix.shape

    for position_index in range(n_position):
        for depth_index in range(n_depth):
            value = matrix[position_index, depth_index]
            density = support[position_index, depth_index]

            rows.append(
                {
                    "finger": finger,
                    "profile_axis": profile_axis,
                    "position_bin": position_index,
                    "depth_bin": depth_index,
                    "value": (
                        float(value)
                        if np.isfinite(value)
                        else np.nan
                    ),
                    "density_weight": float(density),
                }
            )

    pd.DataFrame(rows).to_csv(path, index=False)


def collapse_depth(
    values: np.ndarray,
    density: np.ndarray,
    depth_selection: slice,
) -> Tuple[np.ndarray, np.ndarray]:
    selected_values = values[:, :, depth_selection]
    selected_density = density[:, :, depth_selection]

    mean_map = weighted_mean(
        selected_values,
        selected_density,
        axis=2,
    )
    support_map = weighted_support(
        selected_density,
        axis=2,
    )

    return mean_map, support_map


def create_figures(
    out_dir: Path,
    finger_maps: Dict[str, np.ndarray],
    wta: np.ndarray,
    winner_margin: np.ndarray,
    u_depth: Dict[str, np.ndarray],
    v_depth: Dict[str, np.ndarray],
):
    try:
        import matplotlib
        matplotlib.use("Agg", force=True)
        import matplotlib.pyplot as plt
    except Exception as exc:
        print(
            "WARNING: matplotlib unavailable; PNG figures skipped.\n"
            f"  {exc}"
        )
        return

    figure_dir = out_dir / "figures"
    figure_dir.mkdir(parents=True, exist_ok=True)

    for finger, data in finger_maps.items():
        figure = plt.figure(figsize=(8, 5))
        axis = figure.add_subplot(111)
        image = axis.imshow(
            np.swapaxes(data, 0, 1),
            origin="lower",
            interpolation="nearest",
            aspect="auto",
        )
        axis.set_title(
            f"{finger}: depth-averaged dominance fraction"
        )
        axis.set_xlabel("U bin")
        axis.set_ylabel("V bin")
        figure.colorbar(image, ax=axis, label="Dominance fraction")
        figure.tight_layout()
        figure.savefig(
            figure_dir / f"depth_averaged_{finger}.png",
            dpi=200,
        )
        plt.close(figure)

    figure = plt.figure(figsize=(8, 5))
    axis = figure.add_subplot(111)
    image = axis.imshow(
        np.swapaxes(wta, 0, 1),
        origin="lower",
        interpolation="nearest",
        aspect="auto",
        vmin=0,
        vmax=5,
    )
    axis.set_title("Finger WTA in flattened UxV space")
    axis.set_xlabel("U bin")
    axis.set_ylabel("V bin")
    colorbar = figure.colorbar(image, ax=axis)
    colorbar.set_ticks([0, 1, 2, 3, 4, 5])
    colorbar.set_ticklabels(
        ["invalid", "thumb", "index", "middle", "ring", "little"]
    )
    figure.tight_layout()
    figure.savefig(
        figure_dir / "finger_wta_uv.png",
        dpi=200,
    )
    plt.close(figure)

    figure = plt.figure(figsize=(8, 5))
    axis = figure.add_subplot(111)
    image = axis.imshow(
        np.swapaxes(winner_margin, 0, 1),
        origin="lower",
        interpolation="nearest",
        aspect="auto",
    )
    axis.set_title("WTA winner margin")
    axis.set_xlabel("U bin")
    axis.set_ylabel("V bin")
    figure.colorbar(image, ax=axis, label="Fraction difference")
    figure.tight_layout()
    figure.savefig(
        figure_dir / "finger_wta_margin_uv.png",
        dpi=200,
    )
    plt.close(figure)

    for axis_name, matrices in (
        ("u", u_depth),
        ("v", v_depth),
    ):
        for finger, matrix in matrices.items():
            figure = plt.figure(figsize=(8, 5))
            axis = figure.add_subplot(111)
            image = axis.imshow(
                np.swapaxes(matrix, 0, 1),
                origin="lower",
                interpolation="nearest",
                aspect="auto",
            )
            axis.set_title(
                f"{finger}: {axis_name.upper()} x depth"
            )
            axis.set_xlabel(f"{axis_name.upper()} bin")
            axis.set_ylabel("Depth bin")
            figure.colorbar(
                image,
                ax=axis,
                label="Dominance fraction",
            )
            figure.tight_layout()
            figure.savefig(
                figure_dir
                / f"{finger}_{axis_name}_by_depth.png",
                dpi=200,
            )
            plt.close(figure)


def main():
    args = parse_args()

    (
        flat_root,
        out_dir,
        minimum_density,
        radius_mm,
        config_path,
    ) = resolve_production_args(args)

    radius_token = (
        f"radius{float(radius_mm):g}"
        if np.isfinite(radius_mm)
        else None
    )

    if radius_token is not None:
        if radius_token not in str(flat_root):
            raise RuntimeError(
                "Step-10 radius/input-root mismatch: "
                f"configured {radius_token}, flat_root={flat_root}"
            )
        if radius_token not in str(out_dir):
            raise RuntimeError(
                "Step-10 radius/output-root mismatch: "
                f"configured {radius_token}, output_dir={out_dir}"
            )

    raw_dir = flat_root / "raw"

    if not raw_dir.is_dir():
        raise RuntimeError(f"Raw flat directory not found: {raw_dir}")

    for subdir in (
        out_dir,
        out_dir / "depth_averaged_uv",
        out_dir / "wta",
        out_dir / "profiles_u_depth",
        out_dir / "profiles_v_depth",
        out_dir / "tables",
        out_dir / "qc",
    ):
        subdir.mkdir(parents=True, exist_ok=True)

    density_path = find_density_map(raw_dir)
    domain_path = find_domain_map(raw_dir)

    reference_img, density = load_image(density_path)
    domain_img, domain = load_image(domain_path)
    validate_same_grid(reference_img, domain_img, domain_path)

    domain_mask = domain > 0
    density_valid = (
        np.isfinite(density)
        & (density >= minimum_density)
    )
    valid_support = domain_mask & density_valid

    # The LAYNII density and flat-domain images are not nested masks.  The
    # quantitative support is explicitly their intersection.
    n_domain_3d = int(np.count_nonzero(domain_mask))
    n_density_3d = int(np.count_nonzero(density_valid))
    n_valid_support_3d = int(np.count_nonzero(valid_support))
    n_domain_without_density = int(
        np.count_nonzero(domain_mask & ~density_valid)
    )
    n_density_outside_domain = int(
        np.count_nonzero(density_valid & ~domain_mask)
    )

    if n_valid_support_3d == 0:
        raise RuntimeError(
            "No quantitative raw support remains after applying "
            "domain x density."
        )

    n_u, n_v, n_depth = reference_img.shape
    selection = depth_slice(
        n_depth,
        args.depth_start,
        args.depth_stop,
    )

    metric_maps = {}
    map_paths = {}

    for metric in (
        "dominance_fraction",
        "psc",
        "selectivity",
        "dominance_ratio",
    ):
        metric_maps[metric] = {}
        map_paths[metric] = {}

        for finger in FINGERS:
            path = find_flat_map(raw_dir, metric, finger)
            image, data = load_image(path)
            validate_same_grid(reference_img, image, path)

            # LAYNII writes numeric zeros into unsupported flattened bins.
            # Restore NaN using the frozen quantitative support rule:
            #     (flat domain > 0) AND (raw density >= minimum_density)
            # This preserves genuine zero-valued functional measurements.
            cleaned = data.astype(np.float32)
            cleaned[~valid_support] = np.nan

            metric_maps[metric][finger] = cleaned
            map_paths[metric][finger] = path

    primary = metric_maps["dominance_fraction"]

    depth_averaged = {}
    depth_support = {}

    for finger in FINGERS:
        mean_map, support_map = collapse_depth(
            primary[finger],
            density,
            selection,
        )
        depth_averaged[finger] = mean_map
        depth_support[finger] = support_map

        save_nifti(
            mean_map,
            reference_img,
            out_dir
            / "depth_averaged_uv"
            / f"dominance_fraction_{finger}_uv_mean.nii.gz",
            np.float32,
        )
        save_nifti(
            support_map,
            reference_img,
            out_dir
            / "depth_averaged_uv"
            / f"dominance_fraction_{finger}_uv_density.nii.gz",
            np.float32,
        )

    stack = np.stack(
        [depth_averaged[finger] for finger in FINGERS],
        axis=0,
    )

    finite_count = np.sum(np.isfinite(stack), axis=0)
    complete = (
        finite_count >= args.minimum_finger_coverage
    )

    safe_stack = np.where(
        np.isfinite(stack),
        stack,
        -np.inf,
    )
    winner_index = np.argmax(safe_stack, axis=0)
    sorted_values = np.sort(safe_stack, axis=0)

    maximum = np.full(
        (n_u, n_v),
        np.nan,
        dtype=np.float32,
    )
    margin = np.full(
        (n_u, n_v),
        np.nan,
        dtype=np.float32,
    )
    wta = np.zeros(
        (n_u, n_v),
        dtype=np.int16,
    )

    maximum[complete] = sorted_values[-1][complete]
    margin[complete] = (
        sorted_values[-1][complete]
        - sorted_values[-2][complete]
    ).astype(np.float32)
    wta[complete] = winner_index[complete].astype(np.int16) + 1

    save_nifti(
        wta,
        reference_img,
        out_dir / "wta" / "finger_wta_uv.nii.gz",
        np.int16,
    )
    save_nifti(
        maximum,
        reference_img,
        out_dir / "wta" / "finger_wta_maximum_fraction_uv.nii.gz",
        np.float32,
    )
    save_nifti(
        margin,
        reference_img,
        out_dir / "wta" / "finger_wta_margin_uv.nii.gz",
        np.float32,
    )

    u_depth = {}
    v_depth = {}
    u_support = {}
    v_support = {}

    for finger in FINGERS:
        values = primary[finger]

        # Collapse V -> U x depth.
        u_depth[finger] = weighted_mean(
            values,
            density,
            axis=1,
        )
        u_support[finger] = weighted_support(
            density,
            axis=1,
        )

        # Collapse U -> V x depth.
        v_depth[finger] = weighted_mean(
            values,
            density,
            axis=0,
        )
        v_support[finger] = weighted_support(
            density,
            axis=0,
        )

        np.save(
            out_dir
            / "profiles_u_depth"
            / f"dominance_fraction_{finger}_u_by_depth.npy",
            u_depth[finger],
        )
        np.save(
            out_dir
            / "profiles_v_depth"
            / f"dominance_fraction_{finger}_v_by_depth.npy",
            v_depth[finger],
        )

        write_matrix_csv(
            u_depth[finger],
            u_support[finger],
            finger,
            "U",
            out_dir
            / "tables"
            / f"dominance_fraction_{finger}_u_by_depth.csv",
        )
        write_matrix_csv(
            v_depth[finger],
            v_support[finger],
            finger,
            "V",
            out_dir
            / "tables"
            / f"dominance_fraction_{finger}_v_by_depth.csv",
        )

    # Combined long-format profile table.
    combined_rows = []

    for axis_name, matrices, supports in (
        ("U", u_depth, u_support),
        ("V", v_depth, v_support),
    ):
        for finger in FINGERS:
            matrix = matrices[finger]
            support = supports[finger]

            for position_index in range(matrix.shape[0]):
                for depth_index in range(matrix.shape[1]):
                    value = matrix[position_index, depth_index]

                    combined_rows.append(
                        {
                            "finger": finger,
                            "finger_label": FINGER_TO_LABEL[finger],
                            "profile_axis": axis_name,
                            "position_bin": position_index,
                            "depth_bin": depth_index,
                            "dominance_fraction": (
                                float(value)
                                if np.isfinite(value)
                                else np.nan
                            ),
                            "density_weight": float(
                                support[position_index, depth_index]
                            ),
                        }
                    )

    pd.DataFrame(combined_rows).to_csv(
        out_dir
        / "tables"
        / "dominance_fraction_profiles_long.csv",
        index=False,
    )

    # Depth-averaged long-form table.
    uv_rows = []

    for u_index in range(n_u):
        for v_index in range(n_v):
            if not complete[u_index, v_index]:
                continue

            row = {
                "u_bin": u_index,
                "v_bin": v_index,
                "wta_label": int(wta[u_index, v_index]),
                "wta_finger": FINGERS[
                    int(wta[u_index, v_index]) - 1
                ],
                "maximum_fraction": float(
                    maximum[u_index, v_index]
                ),
                "winner_margin": float(
                    margin[u_index, v_index]
                ),
            }

            for finger in FINGERS:
                row[f"dominance_fraction_{finger}"] = float(
                    depth_averaged[finger][u_index, v_index]
                )

            uv_rows.append(row)

    pd.DataFrame(uv_rows).to_csv(
        out_dir / "tables" / "depth_averaged_uv_long.csv",
        index=False,
    )

    qc_rows = [
        {
            "metric": "flat_shape_u",
            "value": n_u,
        },
        {
            "metric": "flat_shape_v",
            "value": n_v,
        },
        {
            "metric": "flat_shape_depth",
            "value": n_depth,
        },
        {
            "metric": "selected_depth_start",
            "value": selection.start,
        },
        {
            "metric": "selected_depth_stop_exclusive",
            "value": selection.stop,
        },
        {
            "metric": "domain_bins_3d",
            "value": n_domain_3d,
        },
        {
            "metric": "density_supported_bins_3d",
            "value": n_density_3d,
        },
        {
            "metric": "valid_domain_intersection_density_bins_3d",
            "value": n_valid_support_3d,
        },
        {
            "metric": "domain_bins_without_density_3d",
            "value": n_domain_without_density,
        },
        {
            "metric": "density_bins_outside_domain_3d",
            "value": n_density_outside_domain,
        },
        {
            "metric": "valid_support_fraction_of_domain",
            "value": (
                n_valid_support_3d / n_domain_3d
                if n_domain_3d > 0
                else np.nan
            ),
        },
        {
            "metric": "minimum_density",
            "value": minimum_density,
        },
        {
            "metric": "wta_valid_uv_bins",
            "value": int(np.count_nonzero(complete)),
        },
        {
            "metric": "wta_thumb_bins",
            "value": int(np.count_nonzero(wta == 1)),
        },
        {
            "metric": "wta_index_bins",
            "value": int(np.count_nonzero(wta == 2)),
        },
        {
            "metric": "wta_middle_bins",
            "value": int(np.count_nonzero(wta == 3)),
        },
        {
            "metric": "wta_ring_bins",
            "value": int(np.count_nonzero(wta == 4)),
        },
        {
            "metric": "wta_little_bins",
            "value": int(np.count_nonzero(wta == 5)),
        },
    ]

    pd.DataFrame(qc_rows).to_csv(
        out_dir / "qc" / "step10_qc.csv",
        index=False,
    )

    source_rows = []

    for metric, finger_paths in map_paths.items():
        for finger, path in finger_paths.items():
            source_rows.append(
                {
                    "metric": metric,
                    "finger": finger,
                    "source_file": str(path),
                }
            )

    pd.DataFrame(source_rows).to_csv(
        out_dir / "qc" / "source_files.csv",
        index=False,
    )

    support_summary = {
        "status": "PASS",
        "flat_root": str(flat_root),
        "output_dir": str(out_dir),
        "radius_token": (
            radius_token if radius_token is not None else None
        ),
        "radius_mm": (
            float(radius_mm) if np.isfinite(radius_mm) else None
        ),
        "config": str(config_path) if config_path else None,
        "flat_shape": [int(n_u), int(n_v), int(n_depth)],
        "selected_depth_bins": [
            int(selection.start),
            int(selection.stop),
        ],
        "minimum_density": float(minimum_density),
        "domain_bins_3d": n_domain_3d,
        "density_supported_bins_3d": n_density_3d,
        "valid_domain_intersection_density_bins_3d": n_valid_support_3d,
        "domain_bins_without_density_3d": n_domain_without_density,
        "density_bins_outside_domain_3d": n_density_outside_domain,
        "valid_support_fraction_of_domain": (
            n_valid_support_3d / n_domain_3d
            if n_domain_3d > 0 else None
        ),
        "valid_depth_averaged_wta_bins": int(
            np.count_nonzero(complete)
        ),
        "quantitative_support_rule": "domain > 0 AND density >= minimum_density",
        "quantitative_source": "raw_non_voronoi",
        "voronoi_used_quantitatively": False,
        "smoothing_applied": False,
        "wta_source": "depth_averaged_dominance_fraction",
    }

    import json
    with (
        out_dir / "qc" / "step10_summary.json"
    ).open("w", encoding="utf-8") as stream:
        json.dump(support_summary, stream, indent=2)

    with (
        out_dir / "qc" / "step10_summary.txt"
    ).open("w", encoding="utf-8") as stream:
        stream.write("HuberPipeline Step 10 validation\n")
        stream.write("================================\n\n")
        stream.write(f"Flat root: {flat_root}\n")
        stream.write(f"Output directory: {out_dir}\n")
        stream.write(
            f"Flat shape: U={n_u}, V={n_v}, D={n_depth}\n"
        )
        stream.write(
            f"Selected depth bins: "
            f"{selection.start}..{selection.stop - 1}\n"
        )
        stream.write(
            f"Minimum density: {minimum_density:.6f}\n"
        )
        stream.write(
            f"Domain bins: {n_domain_3d}\n"
        )
        stream.write(
            f"Density-supported bins: {n_density_3d}\n"
        )
        stream.write(
            f"Domain ∩ density bins: {n_valid_support_3d}\n"
        )
        stream.write(
            f"Domain without density: "
            f"{n_domain_without_density}\n"
        )
        stream.write(
            f"Density outside domain: "
            f"{n_density_outside_domain}\n"
        )
        stream.write(
            f"Valid support fraction of domain: "
            f"{n_valid_support_3d / n_domain_3d:.6f}\n"
        )
        stream.write(
            f"Depth-averaged WTA bins: "
            f"{int(np.count_nonzero(complete))}\n"
        )
        stream.write(
            "Quantitative support: domain x density\n"
        )
        stream.write("Quantitative source: raw_non_voronoi\n")
        stream.write("Voronoi used quantitatively: NO\n")
        stream.write("Smoothing applied: NO\n")
        stream.write("Hard validation: PASS\n")

    if not args.no_figures:
        create_figures(
            out_dir,
            depth_averaged,
            wta,
            margin,
            u_depth,
            v_depth,
        )

    print("HuberPipeline Step 10 completed successfully.")
    print(f"Flat input shape: U={n_u}, V={n_v}, D={n_depth}")
    print(
        "Depth bins averaged: "
        f"{selection.start}..{selection.stop - 1}"
    )
    print(f"Raw domain bins: {n_domain_3d}")
    print(f"Raw density-supported bins: {n_density_3d}")
    print(f"Valid domain x density bins: {n_valid_support_3d}")
    print(
        f"Valid support/domain: "
        f"{100.0 * n_valid_support_3d / n_domain_3d:.2f}%"
    )
    print(
        f"Domain without raw density: {n_domain_without_density}"
    )
    print(
        f"Density outside flat domain: {n_density_outside_domain}"
    )
    print(
        f"Valid depth-averaged WTA bins: "
        f"{int(np.count_nonzero(complete))}"
    )
    print("WTA bin counts:")
    for finger in FINGERS:
        label = FINGER_TO_LABEL[finger]
        print(
            f"  {finger}: {int(np.count_nonzero(wta == label))}"
        )
    print(f"Flat input root: {flat_root}")
    if radius_token is not None:
        print(f"Radius branch: {radius_token}")
    print(f"Output directory: {out_dir}")
    print(f"QC table: {out_dir / 'qc' / 'step10_qc.csv'}")
    print(f"QC summary: {out_dir / 'qc' / 'step10_summary.txt'}")
    print()
    print(
        "Use raw outputs for quantitative analysis. "
        "No Voronoi-filled values or smoothing are used here."
    )


if __name__ == "__main__":
    try:
        main()
    except (
        FileNotFoundError,
        RuntimeError,
        TypeError,
        ValueError,
    ) as exc:
        sys.exit(f"ERROR: {exc}")
