
#!/usr/bin/env python3
"""
Step 05 — Validate the high-resolution reference session after Steps 01–04.

Scope
-----
This validator intentionally stops at the outputs that genuinely exist after
Steps 01–04. It does NOT depend on intrinsic U/V coordinates, multilateration,
flattening, somatotopic-axis maps, or the obsolete exploratory
`sheet_axis_mm.nii.gz`.

Validated products
------------------
Step 01/02:
  layers/rim.nii.gz
  layers/depth3_layers_equidist.nii

Step 03:
  psc/psc_analysis_mask.nii.gz
  psc/psc_<finger>.nii.gz

Step 04:
  dominance/dominance_responsive_mask.nii.gz
  dominance/dominance_argmax.nii.gz
  dominance/maximum_finger_psc.nii.gz
  dominance/winner_margin_psc.nii.gz
  dominance/dominance_<finger>.nii.gz
  dominance/dominance_valid_<finger>.nii.gz
  dominance/dominance_fraction_<finger>.nii.gz
  dominance/selectivity_<finger>.nii.gz

The script separates:
  HARD checks
      algebraic, grid, mask, and WTA identities that should be exact;
  DIAGNOSTIC checks
      anatomical/topological plausibility that should be reviewed but should
      not invalidate the pipeline automatically.

Usage
-----
python 05_validate_reference_session.py 00_config.yaml ses-18
"""

from __future__ import annotations

import csv
import json
import sys
from pathlib import Path
from typing import Dict, Iterable, List, Tuple

import matplotlib
matplotlib.use("Agg", force=True)
import matplotlib.pyplot as plt
import nibabel as nib
import numpy as np
import pandas as pd
import yaml
from scipy import ndimage


AFFINE_ATOL = 1e-4
ABS_ATOL = 2e-5
FRACTION_ATOL = 2e-5


def load_yaml(path: str) -> dict:
    with open(path, "r", encoding="utf-8") as stream:
        cfg = yaml.safe_load(stream)
    if not isinstance(cfg, dict):
        raise ValueError("YAML root must be a mapping.")
    return cfg


def require(path: Path, label: str) -> Path:
    if path.is_file():
        return path
    raise FileNotFoundError(f"Required {label} not found:\n  {path}")


def same_grid(ref: nib.spatialimages.SpatialImage,
              img: nib.spatialimages.SpatialImage,
              ref_name: str,
              img_name: str) -> None:
    if ref.shape[:3] != img.shape[:3]:
        raise RuntimeError(
            f"Shape mismatch: {ref_name} {ref.shape[:3]} vs "
            f"{img_name} {img.shape[:3]}"
        )
    if not np.allclose(ref.affine, img.affine, atol=AFFINE_ATOL, rtol=0.0):
        raise RuntimeError(
            f"Affine mismatch between {ref_name} and {img_name}."
        )


def load_checked(path: Path,
                 ref: nib.spatialimages.SpatialImage,
                 label: str) -> np.ndarray:
    img = nib.load(str(path))
    same_grid(ref, img, "analysis mask", label)
    return img.get_fdata(dtype=np.float32)


def write_csv(path: Path, rows: List[dict]) -> None:
    pd.DataFrame(rows).to_csv(path, index=False)


def component_stats(mask: np.ndarray) -> Tuple[int, int, float]:
    labels, n = ndimage.label(
        np.asarray(mask, dtype=bool),
        structure=np.ones((3, 3, 3), dtype=np.uint8),
    )
    if n == 0:
        return 0, 0, np.nan
    sizes = np.bincount(labels.ravel())[1:]
    largest = int(sizes.max())
    total = int(sizes.sum())
    return int(n), largest, float(largest / total)


def add_check(rows: List[dict],
              name: str,
              value,
              passed: bool,
              level: str = "HARD",
              note: str = "") -> None:
    rows.append(
        {
            "check": name,
            "value": value,
            "pass": bool(passed),
            "level": level,
            "note": note,
        }
    )


def max_abs_error(observed: np.ndarray,
                  expected: np.ndarray,
                  mask: np.ndarray) -> float:
    valid = (
        np.asarray(mask, dtype=bool)
        & np.isfinite(observed)
        & np.isfinite(expected)
    )
    if not np.any(valid):
        return np.nan
    return float(
        np.max(
            np.abs(
                observed[valid].astype(np.float64)
                - expected[valid].astype(np.float64)
            )
        )
    )


def finite_quantiles(values: np.ndarray) -> dict:
    x = np.asarray(values, dtype=np.float64)
    x = x[np.isfinite(x)]
    if x.size == 0:
        return {
            "n": 0, "mean": np.nan, "median": np.nan,
            "p05": np.nan, "p95": np.nan, "min": np.nan, "max": np.nan
        }
    q05, med, q95 = np.percentile(x, [5, 50, 95])
    return {
        "n": int(x.size),
        "mean": float(np.mean(x)),
        "median": float(med),
        "p05": float(q05),
        "p95": float(q95),
        "min": float(np.min(x)),
        "max": float(np.max(x)),
    }


def make_qc_figure(
    out_path: Path,
    fingers: List[str],
    psc_stack: np.ndarray,
    analysis: np.ndarray,
    argmax: np.ndarray,
    responsive: np.ndarray,
    fraction_stack: np.ndarray,
    topology_rows: List[dict],
) -> None:
    fig, axes = plt.subplots(2, 2, figsize=(11.5, 8.0))
    fig.suptitle("Step 05 reference-session validation | Steps 01–04", fontsize=13)

    # PSC distributions.
    ax = axes[0, 0]
    data = [
        psc_stack[i][analysis & np.isfinite(psc_stack[i])]
        for i in range(len(fingers))
    ]
    try:
        ax.boxplot(
            data,
            tick_labels=[f.title() for f in fingers],
            showfliers=False,
        )
    except TypeError:
        # Matplotlib < 3.9 uses `labels` rather than `tick_labels`.
        ax.boxplot(
            data,
            labels=[f.title() for f in fingers],
            showfliers=False,
        )
    ax.axhline(0, color="0.5", linewidth=0.8)
    ax.set_ylabel("Session-mean PSC (%)")
    ax.set_title("PSC distributions")

    # WTA counts.
    ax = axes[0, 1]
    counts = [
        int(np.count_nonzero(responsive & (argmax == i + 1)))
        for i in range(len(fingers))
    ]
    ax.bar(np.arange(len(fingers)), counts)
    ax.set_xticks(np.arange(len(fingers)), [f.title() for f in fingers])
    ax.set_ylabel("Responsive voxels")
    ax.set_title("Native-space WTA counts")

    # Fraction-sum identity.
    #
    # For a correctly computed dominance-fraction stack, sums are often
    # numerically identical (or nearly identical) to 1.0. Asking NumPy for
    # a fixed 40-bin histogram over an effectively zero-width range can fail
    # on recent NumPy/Matplotlib versions with:
    #   ValueError: Too many bins for data range
    #
    # Therefore use an adaptive display: histogram for a non-degenerate
    # range, otherwise show the single concentrated value explicitly.
    ax = axes[1, 0]
    finite = np.all(np.isfinite(fraction_stack), axis=0) & analysis
    sums = np.sum(fraction_stack[:, finite], axis=0).astype(np.float64)
    sums = sums[np.isfinite(sums)]

    if sums.size:
        smin = float(np.min(sums))
        smax = float(np.max(sums))
        spread = smax - smin

        if spread > 1e-10:
            # Cap bin count relative to the number of observations and let
            # NumPy span the actual finite range safely.
            n_bins = int(min(40, max(5, round(np.sqrt(sums.size)))))
            ax.hist(sums, bins=n_bins, range=(smin, smax))
        else:
            # Exact/nearly exact identity: a histogram is not informative.
            center = float(np.mean(sums))
            ax.scatter([center], [sums.size], s=45, zorder=3)
            ax.vlines(center, 0, sums.size, linewidth=1.5)
            pad = max(1e-6, abs(center) * 1e-6)
            ax.set_xlim(center - pad, center + pad)
            ax.text(
                0.5,
                0.92,
                f"All {sums.size} voxels ≈ {center:.9f}",
                transform=ax.transAxes,
                ha="center",
                va="top",
                fontsize=8,
            )

    ax.axvline(1.0, color="black", linestyle="--", linewidth=1)
    ax.set_xlabel("Σ dominance fractions")
    ax.set_ylabel("Voxels")
    ax.set_title("Dominance-fraction identity")

    # Threshold topology.
    ax = axes[1, 1]
    x = np.arange(len(fingers))
    lcc = [
        float(r["largest_component_fraction"])
        if np.isfinite(r["largest_component_fraction"])
        else 0.0
        for r in topology_rows
    ]
    ax.bar(x, lcc)
    ax.set_xticks(x, [f.title() for f in fingers])
    ax.set_ylim(0, 1)
    ax.set_ylabel("Largest-component fraction")
    ax.set_title("Thresholded dominance topology")

    fig.tight_layout(rect=[0, 0, 1, 0.96])
    fig.savefig(out_path, dpi=200, bbox_inches="tight")
    plt.close(fig)


def main(cfg_path: str, session: str) -> None:
    cfg = load_yaml(cfg_path)
    subject = str(cfg["subject"])
    fingers = [str(x) for x in cfg["fingers"]]

    if len(fingers) != 5:
        raise ValueError(f"Expected five fingers; found {fingers}")

    expected_session = str(cfg.get("reference_validation_session", "ses-18"))
    if session != expected_session:
        print(
            f"WARNING: configured reference session is {expected_session}, "
            f"but validating {session}."
        )

    base = Path(str(cfg["out_dir"]).format(subject=subject)) / session
    layers_dir = base / "layers"
    psc_dir = base / "psc"
    dom_dir = base / "dominance"
    out_dir = base / "validation_reference"
    out_dir.mkdir(parents=True, exist_ok=True)

    validation_cfg = cfg.get("reference_validation", {}) or {}
    dominance_threshold = float(
        validation_cfg.get(
            "dominance_fraction_threshold",
            cfg.get("qc", {}).get("dominance_threshold", 0.40),
        )
    )
    min_lcc_fraction = float(
        validation_cfg.get("minimum_largest_component_fraction", 0.25)
    )
    denominator_eps = float(
        (cfg.get("dominance", {}) or {}).get("denominator_eps", 1e-6)
    )
    generate_figures = bool(validation_cfg.get("generate_figures", True))

    # ------------------------------------------------------------------
    # Reference grid and Step-01/02 geometry
    # ------------------------------------------------------------------
    analysis_path = require(
        psc_dir / "psc_analysis_mask.nii.gz",
        "Step-03 analysis mask",
    )
    ref = nib.load(str(analysis_path))
    analysis = ref.get_fdata(dtype=np.float32) > 0

    rim = np.rint(
        load_checked(
            require(layers_dir / "rim.nii.gz", "Step-01 rim"),
            ref,
            "rim",
        )
    ).astype(np.int16)

    depth = np.rint(
        load_checked(
            require(
                layers_dir / "depth3_layers_equidist.nii",
                "Step-02 depth compartments",
            ),
            ref,
            "depth compartments",
        )
    ).astype(np.int16)

    # ------------------------------------------------------------------
    # Step-03/04 maps
    # ------------------------------------------------------------------
    psc: Dict[str, np.ndarray] = {}
    fraction: Dict[str, np.ndarray] = {}
    selectivity: Dict[str, np.ndarray] = {}
    ratio: Dict[str, np.ndarray] = {}
    ratio_valid: Dict[str, np.ndarray] = {}

    for finger in fingers:
        psc[finger] = load_checked(
            require(psc_dir / f"psc_{finger}.nii.gz", f"PSC {finger}"),
            ref,
            f"PSC {finger}",
        )
        fraction[finger] = load_checked(
            require(
                dom_dir / f"dominance_fraction_{finger}.nii.gz",
                f"dominance fraction {finger}",
            ),
            ref,
            f"dominance fraction {finger}",
        )
        selectivity[finger] = load_checked(
            require(
                dom_dir / f"selectivity_{finger}.nii.gz",
                f"selectivity {finger}",
            ),
            ref,
            f"selectivity {finger}",
        )
        ratio[finger] = load_checked(
            require(
                dom_dir / f"dominance_{finger}.nii.gz",
                f"dominance ratio {finger}",
            ),
            ref,
            f"dominance ratio {finger}",
        )
        ratio_valid[finger] = (
            load_checked(
                require(
                    dom_dir / f"dominance_valid_{finger}.nii.gz",
                    f"dominance valid mask {finger}",
                ),
                ref,
                f"dominance valid mask {finger}",
            ) > 0
        )

    responsive = (
        load_checked(
            require(
                dom_dir / "dominance_responsive_mask.nii.gz",
                "responsive mask",
            ),
            ref,
            "responsive mask",
        ) > 0
    )
    argmax = np.rint(
        load_checked(
            require(dom_dir / "dominance_argmax.nii.gz", "WTA map"),
            ref,
            "WTA map",
        )
    ).astype(np.int16)
    max_psc = load_checked(
        require(dom_dir / "maximum_finger_psc.nii.gz", "maximum PSC"),
        ref,
        "maximum PSC",
    )
    margin = load_checked(
        require(dom_dir / "winner_margin_psc.nii.gz", "winner margin"),
        ref,
        "winner margin",
    )

    psc_stack = np.stack([psc[f] for f in fingers], axis=0)
    fraction_stack = np.stack([fraction[f] for f in fingers], axis=0)

    checks: List[dict] = []

    # ------------------------------------------------------------------
    # HARD geometry/mask checks
    # ------------------------------------------------------------------
    add_check(
        checks,
        "analysis_inside_cortical_rim",
        int(np.count_nonzero(analysis & (rim == 0))),
        not np.any(analysis & (rim == 0)),
        note="Value is number of violating voxels.",
    )
    add_check(
        checks,
        "analysis_depth_labelled",
        int(np.count_nonzero(analysis & ~np.isin(depth, [1, 2, 3]))),
        not np.any(analysis & ~np.isin(depth, [1, 2, 3])),
        note="Value is number of violating voxels.",
    )
    add_check(
        checks,
        "responsive_inside_analysis",
        int(np.count_nonzero(responsive & ~analysis)),
        not np.any(responsive & ~analysis),
        note="Value is number of violating voxels.",
    )
    add_check(
        checks,
        "wta_zero_outside_responsive",
        int(np.count_nonzero(argmax[~responsive] != 0)),
        not np.any(argmax[~responsive] != 0),
        note="Value is number of violating voxels.",
    )
    add_check(
        checks,
        "wta_labels_1_to_5",
        sorted(np.unique(argmax[responsive]).astype(int).tolist()),
        bool(np.all(np.isin(argmax[responsive], np.arange(1, 6)))),
    )

    expected_wta = np.argmax(psc_stack, axis=0) + 1
    wta_agreement = (
        float(np.mean(argmax[responsive] == expected_wta[responsive]))
        if np.any(responsive)
        else np.nan
    )
    add_check(
        checks,
        "wta_matches_signed_psc_argmax",
        wta_agreement,
        bool(np.isfinite(wta_agreement) and np.isclose(wta_agreement, 1.0)),
    )

    expected_max = np.max(psc_stack, axis=0)
    max_error = max_abs_error(max_psc, expected_max, analysis)
    add_check(
        checks,
        "maximum_psc_identity",
        max_error,
        bool(np.isfinite(max_error) and max_error <= ABS_ATOL),
    )

    sorted_psc = np.sort(psc_stack, axis=0)
    expected_margin = sorted_psc[-1] - sorted_psc[-2]
    margin_error = max_abs_error(margin, expected_margin, analysis)
    add_check(
        checks,
        "winner_margin_identity",
        margin_error,
        bool(np.isfinite(margin_error) and margin_error <= ABS_ATOL),
    )

    # ------------------------------------------------------------------
    # HARD dominance-fraction/selectivity/ratio identities
    # ------------------------------------------------------------------
    positive = np.clip(psc_stack, 0.0, None)
    total_positive = np.sum(positive, axis=0)
    fraction_valid = analysis & (total_positive > denominator_eps)

    fraction_sum = np.nansum(fraction_stack, axis=0)
    fraction_sum_error = (
        float(np.max(np.abs(fraction_sum[fraction_valid] - 1.0)))
        if np.any(fraction_valid)
        else np.nan
    )
    add_check(
        checks,
        "dominance_fraction_sum_to_one",
        fraction_sum_error,
        bool(
            np.isfinite(fraction_sum_error)
            and fraction_sum_error <= FRACTION_ATOL
        ),
    )

    finite_fraction = fraction_stack[:, fraction_valid]
    fraction_bounds_ok = bool(
        np.all(finite_fraction >= -FRACTION_ATOL)
        and np.all(finite_fraction <= 1.0 + FRACTION_ATOL)
    )
    add_check(
        checks,
        "dominance_fraction_bounds",
        fraction_bounds_ok,
        fraction_bounds_ok,
    )

    for i, finger in enumerate(fingers):
        expected_fraction = np.full(analysis.shape, np.nan, dtype=np.float32)
        expected_fraction[fraction_valid] = (
            positive[i][fraction_valid] / total_positive[fraction_valid]
        )
        err = max_abs_error(
            fraction[finger],
            expected_fraction,
            fraction_valid,
        )
        add_check(
            checks,
            f"dominance_fraction_identity_{finger}",
            err,
            bool(np.isfinite(err) and err <= ABS_ATOL),
        )

        other_mean = (
            np.sum(psc_stack, axis=0) - psc_stack[i]
        ) / (len(fingers) - 1)
        expected_sel = psc_stack[i] - other_mean
        sel_err = max_abs_error(
            selectivity[finger],
            expected_sel,
            analysis,
        )
        add_check(
            checks,
            f"selectivity_identity_{finger}",
            sel_err,
            bool(np.isfinite(sel_err) and sel_err <= ABS_ATOL),
        )

        other_positive = total_positive - positive[i]
        expected_ratio_valid = analysis & (other_positive > denominator_eps)
        valid_match = bool(
            np.array_equal(
                ratio_valid[finger],
                expected_ratio_valid,
            )
        )
        add_check(
            checks,
            f"dominance_valid_mask_identity_{finger}",
            valid_match,
            valid_match,
        )

        expected_ratio = np.full(analysis.shape, np.nan, dtype=np.float32)
        expected_ratio[expected_ratio_valid] = (
            positive[i][expected_ratio_valid]
            / other_positive[expected_ratio_valid]
        )
        ratio_err = max_abs_error(
            ratio[finger],
            expected_ratio,
            expected_ratio_valid,
        )
        add_check(
            checks,
            f"dominance_ratio_identity_{finger}",
            ratio_err,
            bool(np.isfinite(ratio_err) and ratio_err <= ABS_ATOL),
        )

    # ------------------------------------------------------------------
    # DIAGNOSTIC topology of continuous dominance fractions
    # ------------------------------------------------------------------
    topology_rows: List[dict] = []
    for i, finger in enumerate(fingers):
        territory = (
            analysis
            & np.isfinite(fraction_stack[i])
            & (fraction_stack[i] >= dominance_threshold)
        )
        n_components, largest, lcc_fraction = component_stats(territory)
        diagnostic_pass = bool(
            np.isfinite(lcc_fraction)
            and lcc_fraction >= min_lcc_fraction
        )
        topology_rows.append(
            {
                "finger": finger,
                "threshold": dominance_threshold,
                "territory_voxels": int(np.count_nonzero(territory)),
                "n_components": n_components,
                "largest_component_voxels": largest,
                "largest_component_fraction": lcc_fraction,
                "diagnostic_pass": diagnostic_pass,
            }
        )
        add_check(
            checks,
            f"continuous_topology_{finger}",
            lcc_fraction,
            diagnostic_pass,
            level="DIAGNOSTIC",
            note=(
                f"Threshold={dominance_threshold}; "
                f"minimum LCC fraction={min_lcc_fraction}. "
                "Diagnostic only; does not fail Step 05."
            ),
        )

    # ------------------------------------------------------------------
    # Descriptive tables
    # ------------------------------------------------------------------
    psc_rows = []
    for finger in fingers:
        row = {"finger": finger}
        row.update(finite_quantiles(psc[finger][analysis]))
        psc_rows.append(row)

    depth_rows = []
    for label, depth_name in ((1, "deep"), (2, "middle"), (3, "superficial")):
        mask = analysis & (depth == label)
        row = {
            "depth_label": label,
            "depth_name": depth_name,
            "analysis_voxels": int(np.count_nonzero(mask)),
            "responsive_voxels": int(np.count_nonzero(mask & responsive)),
        }
        depth_rows.append(row)

    wta_rows = []
    for label, finger in enumerate(fingers, start=1):
        wta_rows.append(
            {
                "finger": finger,
                "label": label,
                "responsive_voxels": int(
                    np.count_nonzero(responsive & (argmax == label))
                ),
            }
        )

    write_csv(out_dir / "checks.csv", checks)
    write_csv(out_dir / "continuous_topology.csv", topology_rows)
    write_csv(out_dir / "psc_summary.csv", psc_rows)
    write_csv(out_dir / "depth_summary.csv", depth_rows)
    write_csv(out_dir / "wta_counts.csv", wta_rows)

    hard_failures = [
        row for row in checks
        if row["level"] == "HARD" and not row["pass"]
    ]
    diagnostic_failures = [
        row for row in checks
        if row["level"] == "DIAGNOSTIC" and not row["pass"]
    ]

    summary = {
        "subject": subject,
        "session": session,
        "scope": "Steps 01-04 only",
        "analysis_voxels": int(np.count_nonzero(analysis)),
        "responsive_voxels": int(np.count_nonzero(responsive)),
        "hard_checks_total": int(
            sum(row["level"] == "HARD" for row in checks)
        ),
        "hard_failures": [row["check"] for row in hard_failures],
        "diagnostic_warnings": [
            row["check"] for row in diagnostic_failures
        ],
        "sheet_axis_dependency": False,
        "intrinsic_uv_dependency": False,
        "status": "PASS" if not hard_failures else "FAIL",
    }
    with (out_dir / "validation_summary.json").open(
        "w", encoding="utf-8"
    ) as stream:
        json.dump(summary, stream, indent=2)

    if generate_figures:
        make_qc_figure(
            out_dir / "reference_validation_qc.png",
            fingers,
            psc_stack,
            analysis,
            argmax,
            responsive,
            fraction_stack,
            topology_rows,
        )

    print("============================================================")
    print("Step 05: Reference-session validation of Steps 01–04")
    print("============================================================")
    print(f"Subject:              {subject}")
    print(f"Session:              {session}")
    print(f"Analysis voxels:      {int(np.count_nonzero(analysis))}")
    print(f"Responsive voxels:    {int(np.count_nonzero(responsive))}")
    print(f"Hard checks:          {summary['hard_checks_total']}")
    print(f"Hard failures:        {len(hard_failures)}")
    print(f"Diagnostic warnings:  {len(diagnostic_failures)}")
    print("sheet_axis_mm needed: NO")
    print("Intrinsic U/V needed: NO")
    print(f"Output:               {out_dir}")

    if diagnostic_failures:
        print()
        print("Diagnostic warnings (review, but do not invalidate Step 05):")
        for row in diagnostic_failures:
            print(f"  - {row['check']}: {row['value']}")

    if hard_failures:
        print()
        print("HARD VALIDATION FAILURES:")
        for row in hard_failures:
            print(f"  - {row['check']}: {row['value']}")
        raise SystemExit(1)

    print()
    print("Step 05 HARD validation: PASS")
    print(
        "This validator intentionally makes no claim about intrinsic "
        "somatotopic ordering; that belongs to Steps 11–13."
    )


if __name__ == "__main__":
    if len(sys.argv) != 3:
        raise SystemExit(
            "Usage: python 05_validate_reference_session.py "
            "00_config.yaml ses-18"
        )
    main(sys.argv[1], sys.argv[2])




