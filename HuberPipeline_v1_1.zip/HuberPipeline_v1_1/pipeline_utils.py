#!/usr/bin/env python3
"""
Shared utilities for HuberPipeline v1.0.

The module deliberately keeps configuration handling small and explicit.
It supports:
- YAML loading;
- recursive ${section.key} interpolation;
- environment-variable and user-home expansion;
- subject/session path access;
- input and grid validation;
- standard CSV/TXT provenance outputs.

This module does not expose frozen methodological parameters as arbitrary
runtime options. Changing those parameters requires a new pipeline version.
"""

from __future__ import annotations

import csv
import os
import re
from pathlib import Path
from typing import Any, Dict, Iterable, Mapping, Optional, Sequence, Tuple, Union

import nibabel as nib
import numpy as np
import yaml


AFFINE_ATOL = 1e-4
_TOKEN = re.compile(r"\$\{([^}]+)\}")


class ConfigError(RuntimeError):
    """Raised when the pipeline configuration is invalid."""


def _get_nested(mapping: Mapping[str, Any], dotted_key: str) -> Any:
    current: Any = mapping
    for part in dotted_key.split("."):
        if not isinstance(current, Mapping) or part not in current:
            raise ConfigError(f"Unknown configuration reference: ${{{dotted_key}}}")
        current = current[part]
    return current


def _resolve_string(value: str, config: Mapping[str, Any]) -> str:
    """Resolve ${section.key}, environment variables, and '~'."""
    previous = None
    resolved = value

    for _ in range(20):
        if resolved == previous:
            break
        previous = resolved

        def replace(match: re.Match[str]) -> str:
            replacement = _get_nested(config, match.group(1))
            if isinstance(replacement, (dict, list, tuple)):
                raise ConfigError(
                    f"Configuration reference ${{{match.group(1)}}} is not scalar."
                )
            return str(replacement)

        resolved = _TOKEN.sub(replace, resolved)

    if _TOKEN.search(resolved):
        raise ConfigError(f"Unresolved configuration reference in: {value}")

    return os.path.expandvars(os.path.expanduser(resolved))


def _resolve_tree(value: Any, root_config: Mapping[str, Any]) -> Any:
    if isinstance(value, str):
        return _resolve_string(value, root_config)
    if isinstance(value, list):
        return [_resolve_tree(item, root_config) for item in value]
    if isinstance(value, tuple):
        return tuple(_resolve_tree(item, root_config) for item in value)
    if isinstance(value, dict):
        return {
            key: _resolve_tree(item, root_config)
            for key, item in value.items()
        }
    return value


def load_config(path: Union[str, Path]) -> Dict[str, Any]:
    """
    Load and fully resolve a HuberPipeline YAML configuration.

    References such as ${paths.project_root} are resolved recursively.
    """
    path = Path(path)
    if not path.is_file():
        raise FileNotFoundError(path)

    with path.open("r", encoding="utf-8") as stream:
        raw = yaml.safe_load(stream)

    if not isinstance(raw, dict):
        raise ConfigError("The YAML root must be a mapping.")

    # Multiple passes allow references to other referenced values.
    resolved: Dict[str, Any] = raw
    for _ in range(20):
        candidate = _resolve_tree(resolved, resolved)
        if candidate == resolved:
            break
        resolved = candidate

    validate_config(resolved)
    resolved["_config_file"] = str(path.resolve())
    return resolved


def validate_config(config: Mapping[str, Any]) -> None:
    required = (
        "pipeline",
        "dataset",
        "paths",
        "software",
        "fingers",
        "frozen",
    )
    missing = [key for key in required if key not in config]
    if missing:
        raise ConfigError("Missing top-level keys: " + ", ".join(missing))

    fingers = tuple(config["fingers"])
    expected = ("thumb", "index", "middle", "ring", "little")
    if fingers != expected:
        raise ConfigError(
            "Finger order must be exactly: " + ", ".join(expected)
        )

    radius = float(config["frozen"]["multilateration_radius_mm"])
    if radius != 30.0:
        raise ConfigError(
            "HuberPipeline v1.0 requires multilateration_radius_mm = 30."
        )

    depth_bins = int(config["frozen"]["depth_bins"])
    if depth_bins != 20:
        raise ConfigError("HuberPipeline v1.0 requires depth_bins = 20.")

    expected_axis = str(config["frozen"]["expected_somatotopic_axis"])
    if expected_axis != "U":
        raise ConfigError(
            "HuberPipeline v1.0 documents U as the expected axis."
        )


def config_path(config: Mapping[str, Any], dotted_key: str) -> Path:
    """Return a resolved configuration value as a Path."""
    return Path(str(_get_nested(config, dotted_key)))


def ensure_directories(
    config: Mapping[str, Any],
    keys: Sequence[str],
) -> Dict[str, Path]:
    """Create configured directories and return them by dotted key."""
    output: Dict[str, Path] = {}
    for key in keys:
        path = config_path(config, key)
        path.mkdir(parents=True, exist_ok=True)
        output[key] = path
    return output


def require_files(
    paths: Iterable[Union[str, Path]],
    label: str = "required input",
) -> Tuple[Path, ...]:
    resolved = tuple(Path(path) for path in paths)
    missing = [path for path in resolved if not path.is_file()]
    if missing:
        raise FileNotFoundError(
            f"Missing {label}(s):\n  " + "\n  ".join(map(str, missing))
        )
    return resolved


def load_nifti(path: Union[str, Path]) -> nib.Nifti1Image:
    path = Path(path)
    if not path.is_file():
        raise FileNotFoundError(path)
    return nib.load(str(path))


def check_same_grid(
    reference: nib.Nifti1Image,
    moving: nib.Nifti1Image,
    reference_name: str = "reference",
    moving_name: str = "moving",
    affine_atol: float = AFFINE_ATOL,
) -> None:
    """Require equal 3D shape and affine within a fixed tolerance."""
    if reference.shape[:3] != moving.shape[:3]:
        raise RuntimeError(
            "Shape mismatch:\n"
            f"  {reference_name}: {reference.shape[:3]}\n"
            f"  {moving_name}: {moving.shape[:3]}"
        )

    if not np.allclose(
        reference.affine,
        moving.affine,
        atol=affine_atol,
        rtol=0.0,
    ):
        raise RuntimeError(
            "Affine mismatch between:\n"
            f"  {reference_name}\n"
            f"  {moving_name}"
        )


def save_nifti_like(
    data: np.ndarray,
    reference: nib.Nifti1Image,
    output_path: Union[str, Path],
    dtype: Union[str, np.dtype],
) -> Path:
    """Save an array while preserving the reference geometry."""
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    array = np.asarray(data, dtype=dtype)
    header = reference.header.copy()
    header.set_data_dtype(dtype)
    header.set_slope_inter(1.0, 0.0)

    image = nib.Nifti1Image(
        array,
        reference.affine.copy(),
        header,
    )

    qform, qcode = reference.get_qform(coded=True)
    sform, scode = reference.get_sform(coded=True)

    if qform is not None:
        image.set_qform(qform, int(qcode))
    if sform is not None:
        image.set_sform(sform, int(scode))

    image.header.set_slope_inter(1.0, 0.0)
    nib.save(image, str(output_path))
    return output_path


def write_qc_csv(
    rows: Iterable[Mapping[str, Any]],
    output_path: Union[str, Path],
) -> Path:
    rows = list(rows)
    if not rows:
        raise ValueError("QC table cannot be empty.")

    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    fieldnames = list(rows[0].keys())
    with output_path.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)

    return output_path


def write_summary(
    output_path: Union[str, Path],
    title: str,
    values: Mapping[str, Any],
) -> Path:
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    with output_path.open("w", encoding="utf-8") as stream:
        stream.write(title + "\n")
        stream.write("=" * len(title) + "\n\n")
        for key, value in values.items():
            stream.write(f"{key}: {value}\n")

    return output_path


def provenance(config: Mapping[str, Any]) -> Dict[str, Any]:
    """Return the minimum provenance fields for all pipeline summaries."""
    return {
        "pipeline_name": config["pipeline"]["name"],
        "pipeline_version": config["pipeline"]["version"],
        "subject": config["dataset"]["subject"],
        "session": config["dataset"]["session"],
        "resolution_mm": config["dataset"]["resolution_mm"],
        "multilateration_radius_mm": config["frozen"][
            "multilateration_radius_mm"
        ],
        "primary_functional_metric": config["frozen"][
            "primary_functional_metric"
        ],
        "config_file": config.get("_config_file", ""),
    }
