#!/usr/bin/env python3
"""
Step 15 — Complete ses-18 publication-figure generator.

Figure set
----------
Figure S18-1
    Anatomical localization and intrinsic-coordinate pipeline.

Figure S18-2A
    Native-space finger maps on the mean EPI:
    thumb, index, middle, ring, little, and native-space WTA.

Figure S18-2B
    Flattened finger maps on the unfolded anatomical patch:
    thumb, index, middle, ring, little, and flattened composite WTA.

Figure S18-3
    Quantitative columnar organization along intrinsic U.

Figure S18-4
    Laminar variation in ordering, overlap, and support.

Supplementary Figure S18-S1
    Raw versus display-processed flattened maps.

Supplementary Figure S18-S2
    Display confidence and provenance.

Supplementary Figure S18-S3
    Multilateration-radius sensitivity of the somatotopic conclusions.

Scientific safeguards
---------------------
- Native-space maps are never inferred from flattened maps.
- Flattened display interpolation is visualization-only.
- WTA labels are recomputed from continuous finger maps.
- Raw non-Voronoi outputs remain the quantitative source.
- The orthogonal unfolded axis is called "transverse within-sheet position",
  not "sulcal depth", unless independently validated.
- The production/reference multilateration radius is read from the YAML and is
  never selected from functional performance.
- Radius sensitivity is reported explicitly as sensitivity analysis.

Required local module
---------------------
figure_utils.py must be in the same directory or on PYTHONPATH.

Native-map inputs
-----------------
Provide one native-space continuous finger map per digit. These should be on the
same ses-18 EPI grid as --anatomical and --m1-roi. They may be PSC, beta,
t-value, or another continuous dominance/selectivity metric, but all five must
use the same metric.

Preferred use
-------------
After Step 3 has generated psc/native_space/, run:

env -u PYTHONPATH -u PYTHONHOME \
  /home/carolyn.wagner/envs/layerfmri/bin/python \
  15_generate_complete_ses18_figures_RELEASE.py \
  00_config.yaml ses-18 \
  --anatomical "/path/to/mean_EPI_ses18.nii.gz" \
  --m1-roi "/path/to/cROI_M1_EPIspace1p1mm18.nii.gz"

The --anatomical and --m1-roi options may be omitted when the YAML contains
either global or session-specific keys named:

    figure_anatomical: /path/to/mean_EPI_ses18.nii.gz
    m1_roi: /path/to/cROI_M1_EPIspace1p1mm18.nii.gz

Step 15 automatically discovers the five native PSC maps from:

    <out_dir>/<session>/psc/native_space/psc_<finger>_native.nii.gz

The default output directory is:

    <out_dir>/<session>/publication_figures
"""

from __future__ import annotations

import argparse
import hashlib
import json
import subprocess
import sys
from datetime import datetime, timezone
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Mapping, Optional, Sequence, Tuple

import matplotlib
matplotlib.use("Agg", force=True)
import matplotlib.pyplot as plt
from matplotlib.colors import BoundaryNorm, ListedColormap
from matplotlib.lines import Line2D
from matplotlib.patches import Patch
from matplotlib.path import Path as MplPath
import nibabel as nib
import numpy as np
import pandas as pd
import yaml
from scipy.interpolate import griddata
from scipy.ndimage import (
    binary_closing,
    binary_fill_holes,
    binary_opening,
    distance_transform_edt,
    gaussian_filter,
    label,
)
from scipy.spatial import ConvexHull, QhullError

from figure_utils import (
    FINGERS,
    FINGER_COLORS,
    WTA_CMAP,
    WTA_NORM,
    add_colorbar,
    add_panel_label,
    append_manifest_entries,
    configure_publication_style,
    export_figure,
    extract_slice,
    finite_percentile_limits,
    load_depth_averaged_finger_maps,
    load_depth_pooled_u_profiles,
    load_nifti,
    load_robust_laminar_tables,
    robust_slice_index,
    validate_many_grids,
    write_array_long,
    write_dataframe,
    write_manifest,
    write_provenance_json,
)


FINGER_LABELS = {
    "thumb": 1,
    "index": 2,
    "middle": 3,
    "ring": 4,
    "little": 5,
}

FIGURE_VERSION = "v1.0"
PIPELINE_FIGURE_RELEASE = "1.0.8"

FIGURE_CAPTIONS = {
    "S18-1": (
        "**Figure S18-1 | Anatomical localization and intrinsic-coordinate "
        "pipeline.** (A) Mean EPI image in native space with the anatomical "
        "M1 region of interest (ROI). (B) Cortical rim generated from the "
        "FreeSurfer tissue boundaries after transformation to the native EPI "
        "grid; labels denote white matter (WM), cerebrospinal-fluid/pial side "
        "(CSF), and grey matter (GM). (C) Equidistant cortical-depth metric "
        "with the middle-grey-matter sheet outlined. (D) Corrected CASE-II "
        "multilateration control image containing the origin and four extrema "
        "that define the intrinsic coordinate system. (E) Intrinsic U "
        "coordinate; the arrow indicates increasing U. (F) Flattened "
        "anatomical patch. Black points mark directly sampled flat bins used "
        "for quantitative analysis."
    ),
    "S18-2A": (
        "**Figure S18-2A | Native-space finger responses.** Panels A-E show "
        "session-mean percent signal change (PSC) for thumb, index, middle, "
        "ring, and little-finger movements on the mean EPI in native "
        "acquisition space. The cyan contour denotes the anatomical M1 ROI "
        "and the white contour denotes the cortical rim. Panel F shows the "
        "native-space winner-take-all (WTA) map, assigning each valid M1 voxel "
        "to the finger with the largest PSC. Colours identify the winning "
        "finger according to the legend."
    ),
    "S18-2B": (
        "**Figure S18-2B | Flattened continuous finger representations on the "
        "unfolded cortical patch.** Panels A-E show continuous finger-dominance "
        "maps in intrinsic U-V coordinates, overlaid on the display-only "
        "flattened anatomical background. Panel F shows the flattened WTA "
        "summary. Display interpolation and smoothing are used only for "
        "visualisation; all quantitative analyses use raw sampled bins."
    ),
    "S18-3": (
        "**Figure S18-3 | Quantitative characterization of intrinsic "
        "somatotopy.** (A) Raw column-wise finger-dominance profiles along U. "
        "(B) Best-direction Spearman association between canonical finger "
        "order and intrinsic position across cortical depth for U and V. "
        "(C) Adjacent-order violations; lower values indicate better "
        "preservation of canonical order. (D) Weighted overlap between "
        "adjacent finger representations across cortical depth."
    ),
    "S18-4": (
        "**Figure S18-4 | Reference-radius laminar organization and "
        "robustness.** Results use the frozen 30-mm reference radius. "
        "(A) Best-direction Spearman ordering across depth. (B) Kendall "
        "consistency for the same ordering. (C) U-minus-V axis specificity. "
        "(D) Finger-centroid trajectories along U. (E) Adjacent-finger "
        "overlap across depth. (F) Minimum positional support for U and V; "
        "the shaded interval marks the strict supported Step-13 interval. "
        "Radius sensitivity of this depth-localized result is reported "
        "separately in Figure S18-S3."
    ),
    "S18-S1": (
        "**Figure S18-S1 | Raw versus display-processed flattened maps.** "
        "The upper row shows raw sampled finger-dominance maps without "
        "interpolation or smoothing. The lower row shows the corresponding "
        "display-only Gaussian-processed maps. Quantitative analyses use only "
        "the raw sampled maps."
    ),
    "S18-S2": (
        "**Figure S18-S2 | Confidence and provenance of flattened display "
        "maps.** (A) Maximum finger dominance. (B) Winner margin, defined as "
        "the largest minus second-largest finger dominance. (C) Directly "
        "sampled flat locations. (D) Display-interpolation provenance, "
        "distinguishing raw sampled from display-filled bins. Interpolated "
        "values are never used for quantitative inference."
    ),
    "S18-S3": (
        "**Figure S18-S3 | Multilateration-radius sensitivity.** (A) Mean "
        "and minimum ordering strength within the strict supported Step-13 "
        "interval for each tested radius. (B) Mean and minimum supported-axis "
        "specificity. (C) Location and intrinsic axis of each strict "
        "supported normalized-depth interval, showing the U interval at the "
        "30-mm reference radius and the V interval at 40 mm. (D) Sensitivity "
        "summary relative to the frozen reference radius. Step 14 is "
        "sensitivity analysis only: the production/reference radius is not "
        "selected or changed on the basis of functional performance."
    ),
}


@dataclass
class FlatDisplayProducts:
    finger_maps: Dict[str, np.ndarray]
    wta: np.ndarray
    winner_strength: np.ndarray
    winner_margin: np.ndarray
    raw_support: np.ndarray
    display_domain: np.ndarray
    filled_mask: np.ndarray
    flat_anatomical: np.ndarray
    flat_anatomical_source: str


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
        description=(
            "Generate the complete ses-18 publication figure set from a "
            "HuberPipeline YAML configuration and frozen pipeline outputs."
        ),
    )

    parser.add_argument("config", help="HuberPipeline YAML configuration.")
    parser.add_argument("session", help="Session key, e.g. ses-18.")

    parser.add_argument(
        "--anatomical",
        default=None,
        help=(
            "Mean EPI or anatomical background on the native session EPI "
            "grid. When omitted, read figure_anatomical/anatomical/mean_epi "
            "from the session or global YAML mapping."
        ),
    )
    parser.add_argument(
        "--m1-roi",
        default=None,
        help=(
            "M1 ROI on the native session EPI grid. When omitted, read "
            "m1_roi from the session or global YAML mapping."
        ),
    )
    parser.add_argument(
        "--output-dir",
        default=None,
        help=(
            "Figure output directory. Defaults to "
            "<out_dir>/<session>/publication_figures."
        ),
    )

    parser.add_argument("--rim", default=None)
    parser.add_argument("--depth-metric", default=None)
    parser.add_argument("--middle-gm", default=None)
    parser.add_argument("--control-points", default=None)
    parser.add_argument("--uv-coordinates", default=None)
    parser.add_argument("--perimeter", default=None)
    parser.add_argument("--huber-maps-dir", default=None)
    parser.add_argument("--robust-dir", default=None)
    parser.add_argument("--flat-anatomical", default=None)

    parser.add_argument(
        "--native-space-dir",
        default=None,
        help=(
            "Override the Step-3 native-space directory. Defaults to "
            "<base>/psc/native_space."
        ),
    )
    parser.add_argument("--native-thumb", default=None)
    parser.add_argument("--native-index", default=None)
    parser.add_argument("--native-middle", default=None)
    parser.add_argument("--native-ring", default=None)
    parser.add_argument("--native-little", default=None)

    parser.add_argument(
        "--display-mode",
        choices=("raw", "voronoi", "linear", "gaussian"),
        default="gaussian",
    )
    parser.add_argument(
        "--display-domain",
        choices=("convex-hull", "morphological", "raw"),
        default="convex-hull",
    )
    parser.add_argument("--gaussian-sigma-bins", type=float, default=1.0)
    parser.add_argument("--support-closing-iterations", type=int, default=6)
    parser.add_argument("--support-opening-iterations", type=int, default=0)
    parser.add_argument(
        "--fill-internal-holes",
        action=argparse.BooleanOptionalAction,
        default=True,
    )
    parser.add_argument(
        "--linear-complete-with-nearest",
        action=argparse.BooleanOptionalAction,
        default=True,
    )
    parser.add_argument("--minimum-valid-fingers", type=int, default=3)

    parser.add_argument(
        "--native-display-threshold",
        type=float,
        default=None,
        help=(
            "Optional absolute threshold applied identically to all native "
            "finger maps for visualization."
        ),
    )
    parser.add_argument(
        "--native-slice-axis",
        choices=(0, 1, 2),
        type=int,
        default=2,
    )
    parser.add_argument(
        "--native-slice-index",
        type=int,
        default=None,
    )
    parser.add_argument("--native-overlay-alpha", type=float, default=0.75)
    parser.add_argument("--native-map-cmap", default="viridis")

    parser.add_argument("--horizontal-axis", choices=("U", "V"), default="U")
    parser.add_argument("--png-dpi", type=int, default=600)
    parser.add_argument("--font-family", default="DejaVu Sans")
    parser.add_argument(
        "--pipeline-slice-axis",
        choices=(0, 1, 2),
        type=int,
        default=2,
    )

    return parser.parse_args()


def load_config(path: Path) -> dict:
    if not path.is_file():
        raise FileNotFoundError(path)
    with path.open("r", encoding="utf-8") as stream:
        config = yaml.safe_load(stream)
    if not isinstance(config, dict):
        raise ValueError("The YAML root must be a mapping.")
    return config


def first_config_path(
    command_line_value: Optional[str],
    session_cfg: Mapping,
    global_cfg: Mapping,
    keys: Sequence[str],
    description: str,
) -> Path:
    if command_line_value:
        return Path(command_line_value)

    for mapping in (session_cfg, global_cfg):
        for key in keys:
            value = mapping.get(key)
            if value:
                return Path(str(value))

    key_text = ", ".join(keys)
    raise ValueError(
        f"No {description} was supplied. Use the command-line option or add "
        f"one of these YAML keys: {key_text}"
    )



def resolve_paths(args: argparse.Namespace) -> Dict[str, Path]:
    config_path = Path(args.config)
    cfg = load_config(config_path)

    subject = str(cfg["subject"])
    sessions_cfg = cfg.get("sessions")
    if not isinstance(sessions_cfg, dict) or args.session not in sessions_cfg:
        raise ValueError(f"Session not found in YAML: {args.session}")

    session_cfg = sessions_cfg[args.session]
    if not isinstance(session_cfg, dict):
        raise ValueError(
            f"YAML session entry must be a mapping: {args.session}"
        )

    frozen_cfg = cfg.get("frozen", {}) or {}
    radius_mm = float(frozen_cfg.get("multilateration_radius_mm", 30))
    radius_tag = f"{radius_mm:g}"
    radius_token = f"radius{radius_tag}"

    output_root = Path(
        str(cfg["out_dir"]).format(subject=subject)
    )
    base = output_root / args.session
    layers = base / "layers"
    true_uv = base / "true_uv"

    anatomical = first_config_path(
        args.anatomical,
        session_cfg,
        cfg,
        ("figure_anatomical", "anatomical", "mean_epi"),
        "figure anatomical/mean-EPI image",
    )
    m1_roi = first_config_path(
        args.m1_roi,
        session_cfg,
        cfg,
        ("m1_roi",),
        "M1 ROI",
    )

    huber = (
        Path(args.huber_maps_dir)
        if args.huber_maps_dir
        else base / f"huber_style_maps_radius{radius_tag}"
    )
    robust = (
        Path(args.robust_dir)
        if args.robust_dir
        else huber / "robust_continuous_laminar_somatotopy"
    )

    native_space_dir = (
        Path(args.native_space_dir)
        if args.native_space_dir
        else base / "psc" / "native_space"
    )

    native_overrides = {
        "thumb": args.native_thumb,
        "index": args.native_index,
        "middle": args.native_middle,
        "ring": args.native_ring,
        "little": args.native_little,
    }

    native_paths = {
        finger: (
            Path(native_overrides[finger])
            if native_overrides[finger]
            else native_space_dir / f"psc_{finger}_native.nii.gz"
        )
        for finger in FINGERS
    }

    output_dir = (
        Path(args.output_dir)
        if args.output_dir
        else base / "publication_figures"
    )

    paths = {
        "config": config_path,
        "base": base,
        "anatomical": anatomical,
        "m1_roi": m1_roi,
        "rim": Path(args.rim) if args.rim else layers / "rim.nii.gz",
        # Frozen Step-02 continuous equidistant cortical-depth metric.
        # Production Step 02 writes exactly:
        #   layers/depth3_metric_equidist.nii
        # Do not silently fall back to the obsolete layers_metric_equidist.nii.
        "depth_metric": (
            Path(args.depth_metric)
            if args.depth_metric
            else layers / "depth3_metric_equidist.nii"
        ),
        "middle_gm": (
            Path(args.middle_gm)
            if args.middle_gm
            else layers / "depth3_midGM_equidist.nii"
        ),
        "control_points": (
            Path(args.control_points)
            if args.control_points
            else true_uv / "uv_control_points_caseII.nii.gz"
        ),
        "uv_coordinates": (
            Path(args.uv_coordinates)
            if args.uv_coordinates
            else true_uv
            / f"{args.session.replace('-', '')}_multilaterate_radius{radius_tag}_corrected_UV_coordinates.nii"
        ),
        "perimeter": (
            Path(args.perimeter)
            if args.perimeter
            else true_uv
            / f"{args.session.replace('-', '')}_multilaterate_radius{radius_tag}_corrected_perimeter_chunk.nii"
        ),
        "huber": huber,
        "robust": robust,
        "radius_mm": radius_mm,
        "radius_tag": radius_tag,
        "radius_token": radius_token,
        "radius_sensitivity": base / "radius_sensitivity",
        "radius_sensitivity_metrics": (
            base / "radius_sensitivity" / "radius_sensitivity_metrics.csv"
        ),
        "radius_sensitivity_comparison": (
            base / "radius_sensitivity" / "supported_interval_comparison.csv"
        ),
        "radius_sensitivity_summary": (
            base / "radius_sensitivity" / "radius_sensitivity_summary.json"
        ),
        "flat_anatomical": (
            Path(args.flat_anatomical)
            if args.flat_anatomical
            else None
        ),
        "native_space_dir": native_space_dir,
        "output": output_dir,
        **{
            f"native_{finger}": native_paths[finger]
            for finger in FINGERS
        },
    }

    required_files = (
        "anatomical",
        "m1_roi",
        "rim",
        "depth_metric",
        "middle_gm",
        "control_points",
        "uv_coordinates",
        "perimeter",
        *tuple(f"native_{finger}" for finger in FINGERS),
    )

    # Fail explicitly if the frozen Step-02 depth metric is missing.
    # This protects the pipeline from accidentally reverting to the obsolete
    # layers_metric_equidist.nii filename.
    if not paths["depth_metric"].is_file():
        raise FileNotFoundError(
            "Required Step-15 cortical-depth metric not found:\n"
            f"  {paths['depth_metric']}\n"
            "Expected production Step-02 output:\n"
            f"  {layers / 'depth3_metric_equidist.nii'}"
        )

    missing_files = [
        paths[key] for key in required_files
        if not paths[key].is_file()
    ]
    if missing_files:
        formatted = "\n".join(f"  {path}" for path in missing_files)
        raise FileNotFoundError(
            "Required Step-15 input file(s) not found:\n" + formatted
        )

    for key in ("huber", "robust"):
        if not paths[key].is_dir():
            raise FileNotFoundError(paths[key])

    return paths



def orient(array: np.ndarray, horizontal_axis: str) -> np.ndarray:
    return np.swapaxes(array, 0, 1) if horizontal_axis == "U" else array


def largest_component(mask: np.ndarray) -> np.ndarray:
    labels, number = label(mask)
    if number <= 1:
        return mask.astype(bool)
    counts = np.bincount(labels.ravel())
    counts[0] = 0
    return labels == int(np.argmax(counts))


def convex_hull_mask(mask: np.ndarray) -> np.ndarray:
    coordinates = np.argwhere(mask)
    if coordinates.shape[0] < 3:
        return mask.astype(bool)

    try:
        hull = ConvexHull(coordinates)
    except QhullError:
        return mask.astype(bool)

    vertices = coordinates[hull.vertices]
    grid = np.indices(mask.shape).reshape(2, -1).T
    polygon = MplPath(vertices[:, ::-1])
    inside = polygon.contains_points(grid[:, ::-1], radius=1e-9)
    return inside.reshape(mask.shape)


def build_display_domain(
    raw_support: np.ndarray,
    strategy: str,
    closing_iterations: int,
    opening_iterations: int,
    fill_holes: bool,
) -> np.ndarray:
    if strategy == "raw":
        domain = raw_support.astype(bool)

    elif strategy == "convex-hull":
        domain = convex_hull_mask(raw_support)

    elif strategy == "morphological":
        domain = raw_support.astype(bool)
        for _ in range(max(closing_iterations, 0)):
            domain = binary_closing(domain)
        if fill_holes:
            domain = binary_fill_holes(domain)
        for _ in range(max(opening_iterations, 0)):
            domain = binary_opening(domain)
        domain = largest_component(domain)
        return domain.astype(bool)

    else:
        raise ValueError(strategy)

    if strategy == "convex-hull":
        for _ in range(max(closing_iterations, 0)):
            domain = binary_closing(domain)

    if fill_holes:
        domain = binary_fill_holes(domain)

    for _ in range(max(opening_iterations, 0)):
        domain = binary_opening(domain)

    return domain.astype(bool)


def nearest_fill(
    array: np.ndarray,
    valid: np.ndarray,
    domain: np.ndarray,
) -> np.ndarray:
    output = np.full(array.shape, np.nan, dtype=float)
    source = valid & np.isfinite(array)
    if not np.any(source):
        return output

    _, indices = distance_transform_edt(~source, return_indices=True)
    nearest = array[tuple(indices)]
    output[domain] = nearest[domain]
    output[source] = array[source]
    return output


def linear_fill(
    array: np.ndarray,
    valid: np.ndarray,
    domain: np.ndarray,
    complete_with_nearest: bool,
) -> np.ndarray:
    output = np.full(array.shape, np.nan, dtype=float)
    source = valid & np.isfinite(array)
    coordinates = np.argwhere(source)
    if coordinates.shape[0] < 3:
        return nearest_fill(array, valid, domain)

    target = np.argwhere(domain)
    values = array[source]
    interpolated = griddata(
        coordinates,
        values,
        target,
        method="linear",
    )
    output[tuple(target.T)] = interpolated
    output[source] = array[source]

    if complete_with_nearest:
        missing = domain & ~np.isfinite(output)
        if np.any(missing):
            nearest = nearest_fill(array, valid, domain)
            output[missing] = nearest[missing]

    return output


def normalized_gaussian(
    array: np.ndarray,
    domain: np.ndarray,
    sigma: float,
) -> np.ndarray:
    finite = domain & np.isfinite(array)
    values = np.where(finite, array, 0.0)
    weights = finite.astype(float)

    smooth_values = gaussian_filter(values, sigma=sigma, mode="constant")
    smooth_weights = gaussian_filter(weights, sigma=sigma, mode="constant")

    output = np.full(array.shape, np.nan, dtype=float)
    usable = domain & (smooth_weights > 1e-8)
    output[usable] = smooth_values[usable] / smooth_weights[usable]
    return output


def derive_flat_anatomical(
    anatomical: np.ndarray,
    rim: np.ndarray,
    uv: np.ndarray,
    shape: Tuple[int, int],
) -> Tuple[np.ndarray, np.ndarray]:
    valid = (
        (rim > 0)
        & np.isfinite(anatomical)
        & np.isfinite(uv[..., 0])
        & np.isfinite(uv[..., 1])
    )
    if np.count_nonzero(valid) < 20:
        raise RuntimeError("Too few ribbon voxels for flat anatomy.")

    u = uv[..., 0][valid].astype(float)
    v = uv[..., 1][valid].astype(float)
    intensity = anatomical[valid].astype(float)

    u_min, u_max = float(np.min(u)), float(np.max(u))
    v_min, v_max = float(np.min(v)), float(np.max(v))

    n_u, n_v = shape
    u_bin = np.rint((u - u_min) / (u_max - u_min) * (n_u - 1)).astype(int)
    v_bin = np.rint((v - v_min) / (v_max - v_min) * (n_v - 1)).astype(int)
    u_bin = np.clip(u_bin, 0, n_u - 1)
    v_bin = np.clip(v_bin, 0, n_v - 1)

    sums = np.zeros(shape, dtype=float)
    counts = np.zeros(shape, dtype=np.int32)
    np.add.at(sums, (u_bin, v_bin), intensity)
    np.add.at(counts, (u_bin, v_bin), 1)

    flat = np.full(shape, np.nan, dtype=float)
    sampled = counts > 0
    flat[sampled] = sums[sampled] / counts[sampled]
    return flat, sampled


def normalize_anatomy(
    array: np.ndarray,
    domain: np.ndarray,
) -> np.ndarray:
    output = np.full(array.shape, np.nan, dtype=float)
    valid = domain & np.isfinite(array)
    if not np.any(valid):
        return output

    low, high = np.percentile(array[valid], [2, 98])
    if high <= low:
        high = low + 1.0
    output[valid] = np.clip((array[valid] - low) / (high - low), 0, 1)
    return output


def load_optional_flat_anatomical(
    path: Optional[Path],
    expected_shape: Tuple[int, int],
) -> Optional[np.ndarray]:
    if path is None:
        return None

    if path.suffix == ".npy":
        data = np.load(path)
    else:
        image = nib.load(str(path))
        data = image.get_fdata(dtype=np.float32)
        if data.ndim == 3 and data.shape[2] == 1:
            data = data[:, :, 0]

    if data.shape != expected_shape:
        raise RuntimeError(
            f"Flat anatomical shape {data.shape} != {expected_shape}"
        )
    return np.asarray(data, dtype=float)


def prepare_flat_products(
    paths: Mapping[str, Path],
    args: argparse.Namespace,
) -> FlatDisplayProducts:
    raw_maps = load_depth_averaged_finger_maps(paths["huber"])
    stack = np.stack([raw_maps[finger] for finger in FINGERS], axis=0)

    raw_support = (
        np.sum(np.isfinite(stack), axis=0)
        >= args.minimum_valid_fingers
    )
    display_domain = build_display_domain(
        raw_support,
        strategy=args.display_domain,
        closing_iterations=args.support_closing_iterations,
        opening_iterations=args.support_opening_iterations,
        fill_holes=args.fill_internal_holes,
    )

    processed: Dict[str, np.ndarray] = {}

    for finger in FINGERS:
        raw = raw_maps[finger]
        valid = raw_support & np.isfinite(raw)

        if args.display_mode == "raw":
            current = np.where(valid, raw, np.nan)
        elif args.display_mode == "voronoi":
            current = nearest_fill(raw, valid, display_domain)
        elif args.display_mode == "linear":
            current = linear_fill(
                raw,
                valid,
                display_domain,
                args.linear_complete_with_nearest,
            )
        elif args.display_mode == "gaussian":
            filled = nearest_fill(raw, valid, display_domain)
            current = normalized_gaussian(
                filled,
                display_domain,
                args.gaussian_sigma_bins,
            )
        else:
            raise ValueError(args.display_mode)

        processed[finger] = current

    processed_stack = np.stack(
        [processed[finger] for finger in FINGERS],
        axis=0,
    )
    valid_display = (
        display_domain
        & (np.sum(np.isfinite(processed_stack), axis=0) == len(FINGERS))
    )

    safe = np.where(np.isfinite(processed_stack), processed_stack, -np.inf)
    sorted_values = np.sort(safe, axis=0)

    wta = np.zeros(display_domain.shape, dtype=np.int16)
    winner_strength = np.full(display_domain.shape, np.nan)
    winner_margin = np.full(display_domain.shape, np.nan)

    wta[valid_display] = (
        np.argmax(safe[:, valid_display], axis=0) + 1
    ).astype(np.int16)
    winner_strength[valid_display] = sorted_values[-1, valid_display]
    winner_margin[valid_display] = (
        sorted_values[-1, valid_display]
        - sorted_values[-2, valid_display]
    )

    flat_anatomical = load_optional_flat_anatomical(
        paths["flat_anatomical"],
        raw_support.shape,
    )
    anatomical_source = "user_supplied_flat_anatomical"

    if flat_anatomical is None:
        anatomical_img, anatomical = load_nifti(paths["anatomical"])
        rim_img, rim = load_nifti(paths["rim"])
        uv_img, uv = load_nifti(paths["uv_coordinates"])

        validate_many_grids(
            anatomical_img,
            (
                ("rim", rim_img),
                ("UV coordinates", uv_img),
            ),
            reference_name="mean EPI",
        )

        raw_flat, sampled = derive_flat_anatomical(
            anatomical,
            rim,
            uv,
            raw_support.shape,
        )
        flat_anatomical = nearest_fill(
            raw_flat,
            sampled,
            display_domain,
        )
        flat_anatomical = normalized_gaussian(
            flat_anatomical,
            display_domain,
            sigma=0.8,
        )
        anatomical_source = "derived_cortical_ribbon_projection"

    flat_anatomical = normalize_anatomy(
        flat_anatomical,
        display_domain,
    )

    return FlatDisplayProducts(
        finger_maps=processed,
        wta=wta,
        winner_strength=winner_strength,
        winner_margin=winner_margin,
        raw_support=raw_support,
        display_domain=display_domain,
        filled_mask=display_domain & ~raw_support,
        flat_anatomical=flat_anatomical,
        flat_anatomical_source=anatomical_source,
    )



def _hex_to_rgb01(hex_color: str) -> np.ndarray:
    value = hex_color.lstrip("#")
    return np.array(
        [int(value[i:i + 2], 16) / 255.0 for i in (0, 2, 4)],
        dtype=float,
    )


def _rgb01_to_hex(rgb: np.ndarray) -> str:
    rgb = np.clip(rgb, 0.0, 1.0)
    return "#" + "".join(f"{int(round(v * 255)):02X}" for v in rgb)


def pair_color(pair: str) -> str:
    """
    Deterministic color for an adjacent-finger pair, derived by averaging the
    exact two single-finger colors. This keeps pair plots visually linked to
    the five canonical finger colors.
    """
    parts = pair.lower().split("-")
    if len(parts) != 2 or any(part not in FINGER_COLORS for part in parts):
        return "#666666"
    rgb = (
        _hex_to_rgb01(FINGER_COLORS[parts[0]])
        + _hex_to_rgb01(FINGER_COLORS[parts[1]])
    ) / 2.0
    # Slightly darken blended yellowish colors for visibility on white.
    rgb *= 0.88
    return _rgb01_to_hex(rgb)


def finger_legend_handles() -> List[Patch]:
    return [
        Patch(
            facecolor=FINGER_COLORS[finger],
            edgecolor="none",
            label=f"{FINGER_LABELS[finger]}: {finger.capitalize()}",
        )
        for finger in FINGERS
    ]


def composite_rgba(
    wta: np.ndarray,
    strength: np.ndarray,
) -> np.ndarray:
    rgba = np.zeros(wta.shape + (4,), dtype=float)

    finite = strength[np.isfinite(strength)]
    if finite.size:
        low, high = np.percentile(finite, [2, 98])
    else:
        low, high = 0.0, 1.0

    normalized = (
        np.clip((strength - low) / (high - low), 0, 1)
        if high > low
        else np.ones_like(strength)
    )

    def rgb(hex_value: str) -> Tuple[float, float, float]:
        value = hex_value.lstrip("#")
        return tuple(
            int(value[index:index + 2], 16) / 255.0
            for index in (0, 2, 4)
        )

    for finger in FINGERS:
        selected = wta == FINGER_LABELS[finger]
        colour = rgb(FINGER_COLORS[finger])
        rgba[selected, :3] = colour
        rgba[selected, 3] = 0.55 + 0.45 * normalized[selected]

    return rgba


def load_native_maps(
    paths: Mapping[str, Path],
) -> Tuple[nib.Nifti1Image, Dict[str, np.ndarray]]:
    anatomical_img, _ = load_nifti(paths["anatomical"])
    maps: Dict[str, np.ndarray] = {}

    for finger in FINGERS:
        image, data = load_nifti(paths[f"native_{finger}"])
        validate_many_grids(
            anatomical_img,
            ((f"native {finger}", image),),
            reference_name="mean EPI",
        )
        maps[finger] = data

    return anatomical_img, maps


def select_native_slice(
    maps: Mapping[str, np.ndarray],
    roi: np.ndarray,
    axis: int,
    fixed_index: Optional[int],
) -> int:
    if fixed_index is not None:
        if fixed_index < 0 or fixed_index >= roi.shape[axis]:
            raise ValueError("native-slice-index is outside the image.")
        return fixed_index

    combined = np.zeros_like(roi, dtype=float)
    for finger in FINGERS:
        values = maps[finger]
        finite = np.isfinite(values)
        combined += np.where(finite, np.abs(values), 0.0)

    combined *= roi.astype(bool)

    summed_axes = tuple(
        dimension for dimension in range(3) if dimension != axis
    )
    score = np.sum(combined, axis=summed_axes)

    if np.any(score > 0):
        return int(np.argmax(score))

    return robust_slice_index(roi > 0, axis=axis)


def native_wta(
    maps: Mapping[str, np.ndarray],
    roi: np.ndarray,
    threshold: Optional[float],
) -> Tuple[np.ndarray, np.ndarray]:
    stack = np.stack([maps[finger] for finger in FINGERS], axis=0)
    finite_all = np.all(np.isfinite(stack), axis=0)
    safe = np.where(np.isfinite(stack), stack, -np.inf)

    wta = np.zeros(roi.shape, dtype=np.int16)
    maximum = np.full(roi.shape, np.nan)

    valid = roi.astype(bool) & finite_all
    if threshold is not None:
        valid &= np.max(safe, axis=0) >= threshold

    wta[valid] = (np.argmax(safe[:, valid], axis=0) + 1).astype(np.int16)
    maximum[valid] = np.max(safe[:, valid], axis=0)
    return wta, maximum




def add_panel_label(
    axis: plt.Axes,
    label: str,
    *,
    fontsize: int = 11,
) -> None:
    """
    Place panel labels close to the axes corner so they cannot intrude into
    the figure-level title/subtitle band.
    """
    axis.text(
        -0.055,
        1.008,
        label,
        transform=axis.transAxes,
        ha="right",
        va="bottom",
        fontsize=fontsize,
        fontweight="bold",
        clip_on=False,
    )


def figure_stem(figure_id: str) -> str:
    return f"Figure_{figure_id.replace('-', '_')}_{FIGURE_VERSION}"



def apply_figure_header(
    figure: plt.Figure,
    title: str,
    *,
    horizontal_axis: Optional[str] = None,
    include_coordinate_note: bool = False,
) -> None:
    """
    Reserve a dedicated figure-level header band.

    All Step-15 figures use constrained layout. A suptitle alone is not
    sufficient to guarantee separation from first-row panel titles across
    Matplotlib versions, especially for a two-line title. Therefore the
    constrained-layout engine is explicitly restricted to a lower rectangle,
    leaving a fixed top band exclusively for the figure title / coordinate
    convention.

    This affects layout only; it does not change any plotted data.
    """
    header = title
    if include_coordinate_note:
        transverse = "V" if horizontal_axis == "U" else "U"
        header += (
            "\n"
            f"Intrinsic coordinates: horizontal = {horizontal_axis} "
            f"(reference-analysis somatotopic axis); vertical = {transverse}"
        )

    # Reserve more space for the two-line coordinate header.
    header_bottom = 0.885 if include_coordinate_note else 0.925

    layout_engine = figure.get_layout_engine()
    if layout_engine is not None and hasattr(layout_engine, "set"):
        try:
            # rect=(left, bottom, width, height)
            layout_engine.set(
                rect=(0.015, 0.015, 0.970, header_bottom - 0.015),
                h_pad=0.035,
                w_pad=0.035,
                hspace=0.045,
                wspace=0.045,
            )
        except (TypeError, ValueError):
            # Older Matplotlib fallback. Keep this local and deterministic.
            figure.subplots_adjust(
                left=0.06,
                right=0.97,
                bottom=0.07,
                top=header_bottom,
                hspace=0.28,
                wspace=0.24,
            )
    else:
        figure.subplots_adjust(
            left=0.06,
            right=0.97,
            bottom=0.07,
            top=header_bottom,
            hspace=0.28,
            wspace=0.24,
        )

    figure.suptitle(
        header,
        x=0.5,
        y=0.992,
        ha="center",
        va="top",
        fontsize=10.0 if include_coordinate_note else 10.8,
        fontweight="normal",
        linespacing=1.35,
    )



def add_intrinsic_coordinate_note(
    figure: plt.Figure,
    horizontal_axis: str,
) -> None:
    """Backward-compatible coordinate note with non-overlapping placement."""
    transverse = "V" if horizontal_axis == "U" else "U"
    figure.text(
        0.5,
        0.962,
        (
            f"Intrinsic coordinates: horizontal = {horizontal_axis} "
            f"(reference-analysis somatotopic axis); vertical = {transverse}"
        ),
        ha="center",
        va="top",
        fontsize=8,
        fontweight="bold",
    )

def robust_background_limits(array: np.ndarray) -> Tuple[float, float]:
    finite = array[np.isfinite(array)]
    if finite.size == 0:
        return 0.0, 1.0
    low, high = np.percentile(finite, [1, 99])
    if high <= low:
        high = low + 1.0
    return float(low), float(high)


def write_captions_file(output_dir: Path) -> Path:
    path = output_dir / "captions.md"
    lines = [
        "# HuberPipeline publication-figure captions",
        "",
        f"Figure release: **{FIGURE_VERSION}**  ",
        f"Generator release: **{PIPELINE_FIGURE_RELEASE}**",
        "",
    ]
    for key in (
        "S18-1", "S18-2A", "S18-2B", "S18-3", "S18-4",
        "S18-S1", "S18-S2", "S18-S3",
    ):
        lines.extend([FIGURE_CAPTIONS[key], ""])
    path.write_text("\n".join(lines), encoding="utf-8")
    return path


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def current_git_commit(directory: Path) -> Optional[str]:
    try:
        result = subprocess.run(
            ["git", "-C", str(directory), "rev-parse", "HEAD"],
            check=True,
            capture_output=True,
            text=True,
        )
        return result.stdout.strip() or None
    except (OSError, subprocess.CalledProcessError):
        return None



def figure_s18_1(
    paths: Mapping[str, Path],
    args: argparse.Namespace,
    flat: FlatDisplayProducts,
    manifest: List[dict],
) -> None:
    anatomical_img, anatomical = load_nifti(paths["anatomical"])
    roi_img, roi = load_nifti(paths["m1_roi"])
    rim_img, rim = load_nifti(paths["rim"])
    depth_img, depth = load_nifti(paths["depth_metric"])
    middle_img, middle = load_nifti(paths["middle_gm"])
    control_img, control = load_nifti(paths["control_points"])
    uv_img, uv = load_nifti(paths["uv_coordinates"])

    validate_many_grids(
        anatomical_img,
        (
            ("M1 ROI", roi_img),
            ("rim", rim_img),
            ("depth", depth_img),
            ("middle GM", middle_img),
            ("control points", control_img),
            ("UV coordinates", uv_img),
        ),
        reference_name="mean EPI",
    )

    slice_index = robust_slice_index(roi > 0, axis=args.pipeline_slice_axis)
    arrays = {
        "anatomical": extract_slice(anatomical, args.pipeline_slice_axis, slice_index),
        "roi": extract_slice(roi > 0, args.pipeline_slice_axis, slice_index),
        "rim": extract_slice(rim, args.pipeline_slice_axis, slice_index),
        "depth": extract_slice(depth, args.pipeline_slice_axis, slice_index),
        "middle": extract_slice(middle > 0, args.pipeline_slice_axis, slice_index),
        "control": extract_slice(control, args.pipeline_slice_axis, slice_index),
        "u": extract_slice(uv[..., 0], args.pipeline_slice_axis, slice_index),
    }

    figure = plt.figure(figsize=(12, 8), constrained_layout=True)
    grid = figure.add_gridspec(2, 3)
    axes = [figure.add_subplot(grid[r, c]) for r in range(2) for c in range(3)]
    bg_min, bg_max = robust_background_limits(arrays["anatomical"])

    axes[0].imshow(arrays["anatomical"], cmap="gray", vmin=bg_min, vmax=bg_max)
    axes[0].contour(arrays["roi"], levels=[0.5], colors=["cyan"], linewidths=1.0)
    axes[0].set_title("Mean EPI and anatomical M1 ROI")
    add_panel_label(axes[0], "A")

    axes[1].imshow(arrays["anatomical"], cmap="gray", vmin=bg_min, vmax=bg_max)
    rim_cmap = ListedColormap(["#4C78A8", "#E0E0E0", "#F58518"])
    image = axes[1].imshow(
        np.ma.masked_where(arrays["rim"] <= 0, arrays["rim"]),
        cmap=rim_cmap,
        vmin=1,
        vmax=3,
        alpha=0.82,
        interpolation="nearest",
    )
    axes[1].set_title("Cortical rim")
    cbar = figure.colorbar(image, ax=axes[1], fraction=0.046, pad=0.04, ticks=[1, 2, 3])
    cbar.ax.set_yticklabels(["WM", "CSF", "GM"])
    cbar.set_label("Rim compartment")
    add_panel_label(axes[1], "B")

    axes[2].imshow(arrays["anatomical"], cmap="gray", vmin=bg_min, vmax=bg_max)
    image = axes[2].imshow(
        np.ma.masked_where(arrays["rim"] <= 0, arrays["depth"]),
        cmap="magma",
        alpha=0.80,
        interpolation="nearest",
    )
    axes[2].contour(arrays["middle"], levels=[0.5], colors=["cyan"], linewidths=0.9)
    axes[2].set_title("Depth metric and middle GM")
    add_colorbar(figure, image, axes[2], label="Normalized cortical depth")
    add_panel_label(axes[2], "C")

    axes[3].imshow(arrays["anatomical"], cmap="gray", vmin=bg_min, vmax=bg_max)
    axes[3].imshow(
        np.ma.masked_where(arrays["control"] <= 0, arrays["control"]),
        cmap="tab10",
        vmin=0,
        vmax=9,
        interpolation="nearest",
    )
    axes[3].set_title("CASE-II control image")
    add_panel_label(axes[3], "D")

    image = axes[4].imshow(np.ma.masked_invalid(arrays["u"]), cmap="coolwarm")
    axes[4].set_title("Intrinsic U coordinate")
    add_colorbar(figure, image, axes[4], label="U")
    valid_u = np.argwhere(np.isfinite(arrays["u"]))
    if valid_u.size:
        row, col = np.mean(valid_u, axis=0)
        axes[4].annotate(
            "+U",
            xy=(col + 18, row - 10),
            xytext=(col, row),
            color="black",
            fontweight="bold",
            arrowprops={"arrowstyle": "->", "linewidth": 1.2, "color": "black"},
        )
    add_panel_label(axes[4], "E")

    flat_anat = orient(flat.flat_anatomical, args.horizontal_axis)
    raw_support = orient(flat.raw_support, args.horizontal_axis)
    axes[5].imshow(flat_anat, origin="lower", cmap="gray", vmin=0, vmax=1, aspect="auto")
    rows, cols = np.nonzero(raw_support)
    axes[5].scatter(cols, rows, s=1.4, c="black", alpha=0.72, linewidths=0)
    axes[5].set_title("Flattened anatomical patch")
    axes[5].set_xlabel(f"Intrinsic {args.horizontal_axis}")
    transverse = "V" if args.horizontal_axis == "U" else "U"
    axes[5].set_ylabel(f"Transverse within-sheet {transverse}")
    add_panel_label(axes[5], "F")

    for axis in axes[:5]:
        axis.set_xticks([])
        axis.set_yticks([])

    apply_figure_header(
        figure,
        "Figure S18-1 | Anatomical localization and intrinsic coordinates",
    )
    stem = figure_stem("S18-1")
    files = export_figure(
        figure, paths["output"] / "Figure_S18_1", stem, png_dpi=args.png_dpi
    )
    append_manifest_entries(
        manifest, figure_id="S18-1", files=files,
        description="Anatomical localization and intrinsic coordinates",
    )


def figure_s18_2a_native(
    paths: Mapping[str, Path],
    args: argparse.Namespace,
    manifest: List[dict],
) -> None:
    anatomical_img, anatomical = load_nifti(paths["anatomical"])
    roi_img, roi = load_nifti(paths["m1_roi"])
    rim_img, rim = load_nifti(paths["rim"])
    validate_many_grids(
        anatomical_img,
        (("M1 ROI", roi_img), ("rim", rim_img)),
        reference_name="mean EPI",
    )

    _, native_maps = load_native_maps(paths)
    wta, maximum = native_wta(native_maps, roi, args.native_display_threshold)
    slice_index = select_native_slice(
        native_maps, roi, args.native_slice_axis, args.native_slice_index
    )

    anatomy_slice = extract_slice(anatomical, args.native_slice_axis, slice_index)
    roi_slice = extract_slice(roi > 0, args.native_slice_axis, slice_index)
    rim_slice = extract_slice(rim > 0, args.native_slice_axis, slice_index)
    map_slices = {
        finger: extract_slice(native_maps[finger], args.native_slice_axis, slice_index)
        for finger in FINGERS
    }
    wta_slice = extract_slice(wta, args.native_slice_axis, slice_index)

    vmin, vmax = finite_percentile_limits(
        [
            values[np.isfinite(values) & roi_slice.astype(bool)]
            for values in map_slices.values()
        ],
        lower=2,
        upper=98,
        fallback=(0, 1),
    )
    bg_min, bg_max = robust_background_limits(anatomy_slice)

    figure = plt.figure(figsize=(13, 8.5), constrained_layout=True)
    grid = figure.add_gridspec(2, 3)
    axes = [figure.add_subplot(grid[r, c]) for r in range(2) for c in range(3)]
    overlay_images = []

    for index, finger in enumerate(FINGERS):
        axis = axes[index]
        axis.imshow(anatomy_slice, cmap="gray", vmin=bg_min, vmax=bg_max)
        values = map_slices[finger]
        valid = roi_slice.astype(bool) & np.isfinite(values)
        if args.native_display_threshold is not None:
            valid &= values >= args.native_display_threshold

        image = axis.imshow(
            np.ma.masked_where(~valid, values),
            cmap=args.native_map_cmap,
            vmin=vmin,
            vmax=vmax,
            alpha=args.native_overlay_alpha,
            interpolation="nearest",
        )
        overlay_images.append(image)
        # Draw both boundaries after the functional overlay so neither is hidden.
        axis.contour(rim_slice, levels=[0.5], colors=["white"], linewidths=0.75, zorder=7)
        axis.contour(roi_slice, levels=[0.5], colors=["cyan"], linewidths=1.05, zorder=8)
        axis.set_title(f"{FINGER_LABELS[finger]}: {finger.capitalize()}")
        axis.set_xticks([])
        axis.set_yticks([])
        add_panel_label(axis, chr(ord("A") + index))

    axes[5].imshow(anatomy_slice, cmap="gray", vmin=bg_min, vmax=bg_max)
    axes[5].imshow(
        np.ma.masked_where(wta_slice <= 0, wta_slice),
        cmap=WTA_CMAP,
        norm=WTA_NORM,
        alpha=0.92,
        interpolation="nearest",
    )
    axes[5].contour(rim_slice, levels=[0.5], colors=["white"], linewidths=0.75, zorder=7)
    axes[5].contour(roi_slice, levels=[0.5], colors=["cyan"], linewidths=1.05, zorder=8)
    axes[5].set_title("Native-space winner-take-all")
    axes[5].set_xticks([])
    axes[5].set_yticks([])
    axes[5].legend(
        handles=finger_legend_handles(),
        title="Winning finger",
        loc="upper center",
        bbox_to_anchor=(0.5, -0.08),
        ncol=3,
        frameon=False,
    )
    add_panel_label(axes[5], "F")

    boundary_handles = [
        Line2D([0], [0], color="cyan", linewidth=1.5, label="Anatomical M1 ROI"),
        Line2D([0], [0], color="white", linewidth=1.5, label="Cortical rim"),
    ]
    axes[0].legend(
        handles=boundary_handles,
        loc="lower left",
        frameon=True,
        framealpha=0.65,
        facecolor="black",
        labelcolor="white",
        fontsize=6.5,
    )

    colorbar = figure.colorbar(
        overlay_images[0],
        ax=axes[:5],
        orientation="horizontal",
        shrink=0.78,
        pad=0.06,
        aspect=38,
    )
    colorbar.set_label("Session-mean percent signal change (%)")
    apply_figure_header(
        figure,
        "Figure S18-2A | Native-space finger responses (PSC)",
    )

    stem = figure_stem("S18-2A")
    files = export_figure(
        figure, paths["output"] / "Figure_S18_2A_native", stem,
        png_dpi=args.png_dpi,
    )
    write_dataframe(
        pd.DataFrame([{
            "native_slice_axis": args.native_slice_axis,
            "native_slice_index": slice_index,
            "native_display_threshold": args.native_display_threshold,
            "native_vmin": vmin,
            "native_vmax": vmax,
            "map_metric": "session_mean_percent_signal_change",
            "cyan_contour": "anatomical_M1_ROI",
            "white_contour": "cortical_rim",
        }]),
        paths["output"] / "figure_data" /
        "Figure_S18_2A_native_display_parameters.csv",
    )
    append_manifest_entries(
        manifest, figure_id="S18-2A", files=files,
        description="Native-space session-mean PSC and WTA maps",
    )


def figure_s18_2b_flat(
    paths: Mapping[str, Path],
    args: argparse.Namespace,
    flat: FlatDisplayProducts,
    manifest: List[dict],
) -> None:
    vmin, vmax = finite_percentile_limits(
        flat.finger_maps.values(), lower=2, upper=98, fallback=(0, 1)
    )
    figure = plt.figure(figsize=(13, 8.5), constrained_layout=True)
    grid = figure.add_gridspec(2, 3)
    axes = [figure.add_subplot(grid[r, c]) for r in range(2) for c in range(3)]
    images = []
    transverse = "V" if args.horizontal_axis == "U" else "U"

    for index, finger in enumerate(FINGERS):
        axis = axes[index]
        axis.imshow(
            orient(flat.flat_anatomical, args.horizontal_axis),
            origin="lower", cmap="gray", vmin=0, vmax=1, aspect="auto",
        )
        image = axis.imshow(
            orient(np.ma.masked_invalid(flat.finger_maps[finger]), args.horizontal_axis),
            origin="lower", cmap="viridis", vmin=vmin, vmax=vmax,
            alpha=0.66, aspect="auto", interpolation="nearest",
        )
        images.append(image)
        axis.set_title(f"{FINGER_LABELS[finger]}: {finger.capitalize()}")
        axis.set_xlabel(f"Intrinsic {args.horizontal_axis}", fontsize=9)
        axis.set_ylabel(f"Transverse within-sheet {transverse}", fontsize=9)
        add_panel_label(axis, chr(ord("A") + index))

    axes[5].imshow(
        orient(flat.flat_anatomical, args.horizontal_axis),
        origin="lower", cmap="gray", vmin=0, vmax=1, aspect="auto",
    )
    axes[5].imshow(
        orient(composite_rgba(flat.wta, flat.winner_strength), args.horizontal_axis),
        origin="lower", aspect="auto", interpolation="nearest",
    )
    axes[5].set_title("Flattened winner-take-all")
    axes[5].set_xlabel(f"Intrinsic {args.horizontal_axis}", fontsize=9)
    axes[5].set_ylabel(f"Transverse within-sheet {transverse}", fontsize=9)
    axes[5].legend(
        handles=finger_legend_handles(), title="Winning finger",
        loc="upper center", bbox_to_anchor=(0.5, -0.10),
        ncol=3, frameon=False,
    )
    add_panel_label(axes[5], "F")

    colorbar = figure.colorbar(
        images[0], ax=axes[:5], orientation="horizontal",
        shrink=0.78, pad=0.06, aspect=38,
    )
    colorbar.set_label("Displayed finger-dominance fraction")
    apply_figure_header(
        figure,
        "Figure S18-2B | Finger maps on the unfolded anatomical patch",
        horizontal_axis=args.horizontal_axis,
        include_coordinate_note=True,
    )

    stem = figure_stem("S18-2B")
    files = export_figure(
        figure, paths["output"] / "Figure_S18_2B_flat", stem,
        png_dpi=args.png_dpi,
    )
    append_manifest_entries(
        manifest, figure_id="S18-2B", files=files,
        description="Finger dominance on unfolded anatomical patch",
    )


def figure_s18_3(
    paths: Mapping[str, Path],
    args: argparse.Namespace,
    manifest: List[dict],
) -> None:
    pooled = load_depth_pooled_u_profiles(paths["huber"])
    robust = load_robust_laminar_tables(paths["robust"])
    ordering = robust["ordering"]
    overlap = robust["overlap"]

    figure, axes = plt.subplots(2, 2, figsize=(11, 8.6), constrained_layout=True)
    axes = axes.ravel()

    for finger in FINGERS:
        subset = pooled[pooled["finger"] == finger].sort_values("position_bin")
        axes[0].plot(
            subset["position_bin"], subset["dominance_fraction"],
            color=FINGER_COLORS[finger], linewidth=1.35,
            label=finger.capitalize(),
        )
    axes[0].set_xlabel("Intrinsic U position")
    axes[0].set_ylabel("Raw density-weighted dominance")
    axes[0].set_title("Columnar finger profiles")
    axes[0].legend(
        frameon=False, ncol=1, loc="upper left",
        bbox_to_anchor=(1.01, 1.0), borderaxespad=0,
    )
    add_panel_label(axes[0], "A")

    centroid = ordering[ordering["position_metric"] == "centroid_position"]
    for axis_name, linestyle in (("U", "-"), ("V", "--")):
        subset = centroid[centroid["profile_axis"] == axis_name].sort_values(
            "depth_center_normalized"
        )
        axes[1].plot(
            subset["depth_center_normalized"],
            subset["spearman_rho_best_direction"],
            linestyle=linestyle, marker="o", markersize=4.5,
            linewidth=1.7, label=axis_name,
        )
    axes[1].set_ylim(0, 1)
    axes[1].set_xlabel("Normalized cortical depth")
    axes[1].set_ylabel("Best-direction |Spearman ρ|")
    axes[1].set_title("Somatotopic ordering")
    axes[1].legend(frameon=False)
    add_panel_label(axes[1], "B")

    for axis_name, linestyle in (("U", "-"), ("V", "--")):
        subset = centroid[centroid["profile_axis"] == axis_name].sort_values(
            "depth_center_normalized"
        )
        axes[2].plot(
            subset["depth_center_normalized"],
            subset["adjacent_inversions"],
            linestyle=linestyle, marker="o", markersize=4.5,
            linewidth=1.7, label=axis_name,
        )
    axes[2].set_xlabel("Normalized cortical depth")
    axes[2].set_ylabel("Adjacent inversions")
    axes[2].set_title("Ordering violations")
    axes[2].set_ylim(bottom=0)
    add_panel_label(axes[2], "C")

    u_overlap = overlap[overlap["profile_axis"] == "U"]
    for pair in sorted(u_overlap["finger_pair"].unique()):
        subset = u_overlap[u_overlap["finger_pair"] == pair].sort_values(
            "depth_center_normalized"
        )
        axes[3].plot(
            subset["depth_center_normalized"], subset["overlap_coefficient"],
            marker="o", markersize=4.0, linewidth=1.55,
            color=pair_color(pair), label=pair,
        )
    axes[3].set_ylim(0, 1.05)
    axes[3].set_xlabel("Normalized cortical depth")
    axes[3].set_ylabel("Weighted overlap coefficient")
    axes[3].set_title("Adjacent-finger overlap")
    axes[3].legend(frameon=False, fontsize=6.5)
    add_panel_label(axes[3], "D")

    for axis in axes:
        axis.grid(axis="x", alpha=0.18, linewidth=0.6)

    apply_figure_header(
        figure,
        "Figure S18-3 | Quantitative somatotopy and overlap",
        horizontal_axis=args.horizontal_axis,
        include_coordinate_note=True,
    )
    stem = figure_stem("S18-3")
    files = export_figure(
        figure, paths["output"] / "Figure_S18_3", stem, png_dpi=args.png_dpi
    )
    append_manifest_entries(
        manifest, figure_id="S18-3", files=files,
        description="Quantitative somatotopy and overlap",
    )


def figure_s18_4(
    paths: Mapping[str, Path],
    args: argparse.Namespace,
    manifest: List[dict],
) -> None:
    robust = load_robust_laminar_tables(paths["robust"])
    ordering = robust["ordering"]
    specificity = robust["specificity"]
    metrics = robust["finger_metrics"]
    overlap = robust["overlap"]
    support = robust["support"]
    intervals = robust["intervals"]
    centroid = ordering[ordering["position_metric"] == "centroid_position"]

    figure, axes = plt.subplots(2, 3, figsize=(12, 9.0), constrained_layout=True)
    axes = axes.ravel()

    for axis_name, linestyle in (("U", "-"), ("V", "--")):
        subset = centroid[centroid["profile_axis"] == axis_name].sort_values(
            "depth_center_normalized"
        )
        axes[0].plot(
            subset["depth_center_normalized"],
            subset["spearman_rho_best_direction"],
            linestyle=linestyle, marker="o", markersize=4.2,
            linewidth=1.7, label=axis_name,
        )
    axes[0].set_ylim(0, 1)
    axes[0].set_title("Spearman ordering")
    axes[0].set_xlabel("Normalized cortical depth →")
    axes[0].set_ylabel("|ρ|")
    axes[0].legend(frameon=False)
    add_panel_label(axes[0], "A", fontsize=11)

    for axis_name, linestyle in (("U", "-"), ("V", "--")):
        subset = centroid[centroid["profile_axis"] == axis_name].sort_values(
            "depth_center_normalized"
        )
        axes[1].plot(
            subset["depth_center_normalized"],
            subset["kendall_tau_best_direction"],
            linestyle=linestyle, marker="o", markersize=4.2,
            linewidth=1.7, label=axis_name,
        )
    axes[1].set_ylim(0, 1)
    axes[1].set_title("Kendall consistency")
    axes[1].set_xlabel("Normalized cortical depth →")
    axes[1].set_ylabel("|τ|")
    add_panel_label(axes[1], "B", fontsize=11)

    axes[2].axhline(0, color="black", linewidth=0.7)
    axes[2].plot(
        specificity["depth_center_normalized"],
        specificity["u_minus_v_specificity"],
        marker="o", markersize=4.2, linewidth=1.7,
    )
    axes[2].set_title("Axis specificity")
    axes[2].set_xlabel("Normalized cortical depth →")
    axes[2].set_ylabel("|ρU| − |ρV|")
    add_panel_label(axes[2], "C", fontsize=11)

    u_metrics = metrics[metrics["profile_axis"] == "U"]
    for finger in FINGERS:
        subset = u_metrics[u_metrics["finger"] == finger].sort_values(
            "depth_center_normalized"
        )
        axes[3].plot(
            subset["depth_center_normalized"], subset["centroid_position"],
            marker="o", markersize=4.0, linewidth=1.9,
            color=FINGER_COLORS[finger], label=finger.capitalize(),
        )
    axes[3].set_title("Finger centroid trajectories")
    axes[3].set_xlabel("Normalized cortical depth →")
    axes[3].set_ylabel("Centroid along U")
    axes[3].legend(frameon=False, ncol=2)
    add_panel_label(axes[3], "D", fontsize=11)

    u_overlap = overlap[overlap["profile_axis"] == "U"]
    for pair in sorted(u_overlap["finger_pair"].unique()):
        subset = u_overlap[u_overlap["finger_pair"] == pair].sort_values(
            "depth_center_normalized"
        )
        axes[4].plot(
            subset["depth_center_normalized"], subset["overlap_coefficient"],
            marker="o", markersize=4.0, linewidth=1.7,
            color=pair_color(pair), label=pair,
        )
    axes[4].set_ylim(0, 1.05)
    axes[4].set_title("Adjacent-finger overlap")
    axes[4].set_xlabel("Normalized cortical depth →")
    axes[4].set_ylabel("Overlap coefficient")
    axes[4].legend(frameon=False, fontsize=6)
    add_panel_label(axes[4], "E", fontsize=11)

    support_centroid = support[support["position_metric"] == "centroid_position"]
    for axis_name, linestyle in (("U", "-"), ("V", "--")):
        subset = support_centroid[
            support_centroid["profile_axis"] == axis_name
        ].sort_values("depth_center_normalized")
        axes[5].plot(
            subset["depth_center_normalized"],
            subset["minimum_finger_valid_positions"],
            linestyle=linestyle, marker="o", markersize=4.2,
            linewidth=1.7, label=axis_name,
        )

    if not intervals.empty:
        best = intervals.sort_values("interval_score", ascending=False).iloc[0]
        axes[5].axvspan(
            float(best["depth_start_normalized"]),
            float(best["depth_stop_normalized"]),
            color="#4C78A8", alpha=0.20, label="Best robust interval",
        )

    axes[5].set_title("Support and robust interval")
    axes[5].set_xlabel("Normalized cortical depth →")
    axes[5].set_ylabel("Minimum valid positions")
    axes[5].legend(frameon=False)
    add_panel_label(axes[5], "F", fontsize=11)

    for axis in axes:
        axis.grid(axis="x", alpha=0.16, linewidth=0.6)

    apply_figure_header(
        figure,
        "Figure S18-4 | Reference-radius laminar organization and robustness",
        horizontal_axis=args.horizontal_axis,
        include_coordinate_note=True,
    )
    stem = figure_stem("S18-4")
    files = export_figure(
        figure, paths["output"] / "Figure_S18_4", stem, png_dpi=args.png_dpi
    )
    append_manifest_entries(
        manifest, figure_id="S18-4", files=files,
        description="Reference-radius laminar organization and robustness",
    )


def supplementary_s1(
    paths: Mapping[str, Path],
    args: argparse.Namespace,
    flat: FlatDisplayProducts,
    manifest: List[dict],
) -> None:
    raw_maps = load_depth_averaged_finger_maps(paths["huber"])
    raw_limits = finite_percentile_limits(
        raw_maps.values(), lower=2, upper=98, fallback=(0, 1)
    )
    display_limits = finite_percentile_limits(
        flat.finger_maps.values(), lower=2, upper=98, fallback=(0, 1)
    )

    figure, axes = plt.subplots(2, 5, figsize=(14, 7.8), constrained_layout=True)
    raw_image = display_image = None

    for index, finger in enumerate(FINGERS):
        axes[0, index].imshow(
            orient(flat.flat_anatomical, args.horizontal_axis),
            origin="lower", cmap="gray", vmin=0, vmax=1, aspect="auto",
        )
        raw_image = axes[0, index].imshow(
            orient(np.ma.masked_invalid(raw_maps[finger]), args.horizontal_axis),
            origin="lower", cmap="viridis", vmin=raw_limits[0], vmax=raw_limits[1],
            alpha=0.78, aspect="auto", interpolation="nearest",
        )
        axes[0, index].set_title(f"{FINGER_LABELS[finger]}: {finger.capitalize()}")

        axes[1, index].imshow(
            orient(flat.flat_anatomical, args.horizontal_axis),
            origin="lower", cmap="gray", vmin=0, vmax=1, aspect="auto",
        )
        display_image = axes[1, index].imshow(
            orient(np.ma.masked_invalid(flat.finger_maps[finger]), args.horizontal_axis),
            origin="lower", cmap="viridis",
            vmin=display_limits[0], vmax=display_limits[1],
            alpha=0.66, aspect="auto", interpolation="nearest",
        )
        axes[1, index].set_title(f"{FINGER_LABELS[finger]}: {finger.capitalize()}")

    axes[0, 0].set_ylabel("Raw sampled maps", fontweight="bold")
    axes[1, 0].set_ylabel("Display-only Gaussian maps", fontweight="bold")

    raw_cbar = figure.colorbar(
        raw_image, ax=list(axes[0, :]), orientation="horizontal",
        shrink=0.74, pad=0.06,
    )
    raw_cbar.set_label("Raw dominance fraction")
    display_cbar = figure.colorbar(
        display_image, ax=list(axes[1, :]), orientation="horizontal",
        shrink=0.74, pad=0.06,
    )
    display_cbar.set_label("Display-processed dominance fraction")

    apply_figure_header(
        figure,
        "Figure S18-S1 | Raw versus display-processed flattened maps",
        horizontal_axis=args.horizontal_axis,
        include_coordinate_note=True,
    )
    figure.text(
        0.5,
        0.938,
        "Quantitative analyses use only the raw sampled maps.",
        ha="center",
        va="top",
        fontsize=7.5,
    )
    stem = figure_stem("S18-S1")
    files = export_figure(
        figure, paths["output"] / "Figure_S18_S1", stem, png_dpi=args.png_dpi
    )
    append_manifest_entries(
        manifest, figure_id="S18-S1", files=files,
        description="Raw versus display-processed flattened maps",
    )


def supplementary_s2(
    paths: Mapping[str, Path],
    args: argparse.Namespace,
    flat: FlatDisplayProducts,
    manifest: List[dict],
) -> None:
    figure, axes = plt.subplots(2, 2, figsize=(10, 9.0), constrained_layout=True)
    axes = axes.ravel()
    background = orient(flat.flat_anatomical, args.horizontal_axis)

    axes[0].imshow(background, origin="lower", cmap="gray", vmin=0, vmax=1, aspect="auto")
    image = axes[0].imshow(
        orient(np.ma.masked_invalid(flat.winner_strength), args.horizontal_axis),
        origin="lower", cmap="viridis", vmin=0, vmax=1,
        alpha=0.76, aspect="auto", interpolation="nearest",
    )
    axes[0].set_title("Winning dominance (maximum)")
    add_colorbar(figure, image, axes[0], label="Maximum dominance")
    add_panel_label(axes[0], "A")

    axes[1].imshow(background, origin="lower", cmap="gray", vmin=0, vmax=1, aspect="auto")
    margin_limits = finite_percentile_limits(
        [flat.winner_margin], lower=0, upper=99, fallback=(0, 1)
    )
    image = axes[1].imshow(
        orient(np.ma.masked_invalid(flat.winner_margin), args.horizontal_axis),
        origin="lower", cmap="magma", vmin=0, vmax=margin_limits[1],
        alpha=0.76, aspect="auto", interpolation="nearest",
    )
    axes[1].set_title("Winner margin (largest − second-largest)")
    add_colorbar(figure, image, axes[1], label="Largest − second-largest dominance")
    add_panel_label(axes[1], "B")

    axes[2].imshow(background, origin="lower", cmap="gray", vmin=0, vmax=1, aspect="auto")
    sampled = orient(flat.raw_support, args.horizontal_axis)
    rows, cols = np.nonzero(sampled)
    axes[2].scatter(cols, rows, s=2.0, c="black", alpha=0.85, linewidths=0)
    axes[2].set_title("Raw sampled locations")
    add_panel_label(axes[2], "C")

    axes[3].imshow(background, origin="lower", cmap="gray", vmin=0, vmax=1, aspect="auto")
    provenance_class = np.zeros(flat.raw_support.shape, dtype=int)
    provenance_class[flat.display_domain] = 1
    provenance_class[flat.raw_support] = 2
    axes[3].imshow(
        orient(np.ma.masked_where(provenance_class == 0, provenance_class),
               args.horizontal_axis),
        origin="lower", cmap=ListedColormap(["#BDBDBD", "black"]),
        vmin=1, vmax=2, alpha=0.62, aspect="auto", interpolation="nearest",
    )
    axes[3].set_title("Display interpolation provenance")
    axes[3].legend(
        handles=[
            Patch(facecolor="black", label="Raw sampled"),
            Patch(facecolor="#BDBDBD", label="Display-filled"),
        ],
        frameon=False,
    )
    add_panel_label(axes[3], "D")

    apply_figure_header(
        figure,
        "Figure S18-S2 | Display confidence and provenance",
        horizontal_axis=args.horizontal_axis,
        include_coordinate_note=True,
    )
    stem = figure_stem("S18-S2")
    files = export_figure(
        figure, paths["output"] / "Figure_S18_S2", stem, png_dpi=args.png_dpi
    )
    append_manifest_entries(
        manifest, figure_id="S18-S2", files=files,
        description="Display confidence and provenance",
    )

def supplementary_s3_radius_sensitivity(
    paths: Mapping[str, Path],
    args: argparse.Namespace,
    manifest: List[dict],
) -> None:
    metrics_path = paths["radius_sensitivity_metrics"]
    comparison_path = paths["radius_sensitivity_comparison"]
    summary_path = paths["radius_sensitivity_summary"]

    for required in (metrics_path, comparison_path, summary_path):
        if not required.is_file():
            raise FileNotFoundError(
                "Required Step-14 sensitivity output not found:\n"
                f"  {required}\n"
                "Run Step 14 before Step 15."
            )

    metrics = pd.read_csv(metrics_path).sort_values("radius_mm")
    comparison = pd.read_csv(comparison_path).sort_values("radius_mm")
    with summary_path.open("r", encoding="utf-8") as stream:
        summary = json.load(stream)

    reference_radius = float(summary["frozen_reference_radius_mm"])
    reference_axis = str(summary["reference_step11_axis"])

    figure, axes = plt.subplots(
        2, 2, figsize=(11.5, 8.6), constrained_layout=True
    )
    axes = axes.ravel()

    # A — ordering strength.
    axes[0].plot(
        metrics["radius_mm"],
        metrics["supported_interval_mean_rho"],
        marker="o", linewidth=1.8, label="Mean |rho|",
    )
    axes[0].plot(
        metrics["radius_mm"],
        metrics["supported_interval_minimum_rho"],
        marker="o", linewidth=1.8, label="Minimum |rho|",
    )
    axes[0].axvline(
        reference_radius, linestyle="--", linewidth=1.0,
        color="black", label=f"Reference ({reference_radius:g} mm)",
    )
    axes[0].set_xlabel("Multilateration radius (mm)")
    axes[0].set_ylabel("Supported-interval ordering")
    axes[0].set_ylim(0, 1)
    axes[0].set_title("Ordering strength")
    axes[0].legend(frameon=False, fontsize=7)
    add_panel_label(axes[0], "A", fontsize=11)

    # B — supported-axis specificity.
    axes[1].axhline(0, linewidth=0.8, color="black")
    axes[1].plot(
        metrics["radius_mm"],
        metrics["supported_interval_mean_specificity"],
        marker="o", linewidth=1.8, label="Mean specificity",
    )
    axes[1].plot(
        metrics["radius_mm"],
        metrics["supported_interval_minimum_specificity"],
        marker="o", linewidth=1.8, label="Minimum specificity",
    )
    axes[1].axvline(
        reference_radius, linestyle="--", linewidth=1.0, color="black"
    )
    axes[1].set_xlabel("Multilateration radius (mm)")
    axes[1].set_ylabel("Supported-axis specificity")
    axes[1].set_title("Axis specificity")
    axes[1].legend(frameon=False, fontsize=7)
    add_panel_label(axes[1], "B", fontsize=11)

    # C — show every supported interval explicitly; U and V use fixed,
    # easily distinguishable colors. Do not let a legend cover the 40-mm row.
    axis_colors = {"U": "#3C5488", "V": "#E64B35"}
    axis_styles = {"U": "-", "V": "--"}

    plotted_axes = set()
    for row in metrics.itertuples():
        if not bool(row.supported_interval_present):
            continue

        axis_name = str(row.supported_interval_axis)
        start_depth = float(row.supported_interval_start)
        stop_depth = float(row.supported_interval_stop)
        radius = float(row.radius_mm)

        label = axis_name if axis_name not in plotted_axes else None
        plotted_axes.add(axis_name)

        axes[2].plot(
            [start_depth, stop_depth],
            [radius, radius],
            linewidth=7,
            linestyle=axis_styles.get(axis_name, "-"),
            color=axis_colors.get(axis_name, "black"),
            solid_capstyle="butt",
            label=label,
            zorder=3,
        )
        axes[2].scatter(
            [(start_depth + stop_depth) / 2.0],
            [radius],
            s=36,
            color=axis_colors.get(axis_name, "black"),
            zorder=4,
        )
        is_reference = np.isclose(
            radius,
            reference_radius,
            atol=1e-9,
            rtol=0.0,
        )
        label_offset = 0.22 if is_reference else -0.22
        label_va = "bottom" if is_reference else "top"
        axes[2].text(
            (start_depth + stop_depth) / 2.0,
            radius + label_offset,
            f"{axis_name}: {start_depth:.2f}-{stop_depth:.2f}",
            ha="center",
            va=label_va,
            fontsize=7.5,
            color=axis_colors.get(axis_name, "black"),
        )

    axes[2].axhline(
        reference_radius, linestyle=":", linewidth=1.0, color="black"
    )
    axes[2].set_xlim(0, 1)
    candidate_radii = metrics["radius_mm"].to_numpy(dtype=float)
    if candidate_radii.size:
        axes[2].set_ylim(
            float(np.min(candidate_radii)) - 1.2,
            float(np.max(candidate_radii)) + 1.2,
        )
        axes[2].set_yticks(candidate_radii)
    axes[2].set_xlabel("Normalized cortical depth")
    axes[2].set_ylabel("Multilateration radius (mm)")
    axes[2].set_title("Supported interval location and axis")
    if plotted_axes:
        axes[2].legend(
            title="Supported axis",
            frameon=False,
            fontsize=7,
            title_fontsize=7,
            loc="center left",
            bbox_to_anchor=(1.01, 0.5),
        )
    add_panel_label(axes[2], "C", fontsize=11)

    # D — concise sensitivity summary.
    axes[3].axis("off")
    lines = []
    for row in comparison.itertuples():
        kind = "reference" if bool(row.is_frozen_reference) else "candidate"
        lines.append(
            f"{float(row.radius_mm):g} mm ({kind})"
            f"  |  Step-11 axis match: "
            f"{'yes' if bool(row.same_step11_axis_as_reference) else 'no'}"
            f"  |  supported-axis match: "
            f"{'yes' if bool(row.same_supported_axis_as_reference) else 'no'}"
            f"  |  depth Jaccard: {float(row.depth_jaccard):.3f}"
        )

    fraction = float(
        summary.get("fraction_nonreference_conclusion_concordant", 0.0)
    )
    all_concordant = bool(
        summary.get("all_nonreference_conclusions_concordant", False)
    )

    interpretation = (
        "Strict depth-localized result is stable across tested radii."
        if all_concordant
        else (
            "Whole-depth U preference is retained, but the strict "
            "depth-localized axis/interval is radius-sensitive."
        )
    )

    block = (
        f"Frozen reference radius: {reference_radius:g} mm\n"
        f"Reference whole-depth axis: {reference_axis}\n\n"
        + "\n".join(lines)
        + "\n\n"
        + f"Criterion concordance across non-reference radii: "
        f"{100.0 * fraction:.1f}%\n"
        + interpretation
        + "\n\n"
        + "Sensitivity analysis only; production radius unchanged."
    )

    axes[3].text(
        0.02, 0.97, block,
        transform=axes[3].transAxes,
        ha="left", va="top", fontsize=8.0,
        linespacing=1.5,
        bbox=dict(
            boxstyle="round,pad=0.5",
            facecolor="white",
            alpha=0.92,
        ),
    )
    axes[3].set_title("Sensitivity summary")
    add_panel_label(axes[3], "D", fontsize=11)

    for axis in axes[:3]:
        axis.grid(alpha=0.18, linewidth=0.6)

    apply_figure_header(
        figure,
        "Figure S18-S3 | Multilateration-radius sensitivity",
        horizontal_axis=args.horizontal_axis,
        include_coordinate_note=False,
    )

    stem = figure_stem("S18-S3")
    files = export_figure(
        figure,
        paths["output"] / "Figure_S18_S3",
        stem,
        png_dpi=args.png_dpi,
    )
    append_manifest_entries(
        manifest,
        figure_id="S18-S3",
        files=files,
        description=(
            "Sensitivity of somatotopic conclusions to multilateration radius"
        ),
    )

    write_dataframe(
        comparison,
        paths["output"] / "figure_data" /
        "Figure_S18_S3_supported_interval_comparison.csv",
    )



def main() -> None:
    args = parse_args()
    configure_publication_style(
        font_family=args.font_family,
        base_font_size=8,
    )
    paths = resolve_paths(args)

    paths["output"].mkdir(parents=True, exist_ok=True)
    (paths["output"] / "figure_data").mkdir(
        parents=True,
        exist_ok=True,
    )

    if paths["depth_metric"].name == "layers_metric_equidist.nii":
        raise RuntimeError(
            "Obsolete Step-15 depth-metric filename detected: "
            "layers_metric_equidist.nii. "
            "Production Step 02 uses depth3_metric_equidist.nii."
        )

    print("Resolved Step-15 inputs:")
    print(f"  depth metric: {paths['depth_metric']}")
    print(f"  middle GM:    {paths['middle_gm']}")
    print(f"  WTA palette:  {FINGER_COLORS}")
    print(f"  radius:       {float(paths['radius_mm']):g} mm")
    print("Preparing flattened display products...")
    flat = prepare_flat_products(paths, args)

    manifest: List[dict] = []

    print("Generating Figure S18-1...")
    figure_s18_1(paths, args, flat, manifest)

    print("Generating Figure S18-2A native...")
    figure_s18_2a_native(paths, args, manifest)

    print("Generating Figure S18-2B flattened...")
    figure_s18_2b_flat(paths, args, flat, manifest)

    print("Generating Figure S18-3...")
    figure_s18_3(paths, args, manifest)

    print("Generating Figure S18-4...")
    figure_s18_4(paths, args, manifest)

    print("Generating Figure S18-S1...")
    supplementary_s1(paths, args, flat, manifest)

    print("Generating Figure S18-S2...")
    supplementary_s2(paths, args, flat, manifest)

    print("Generating Figure S18-S3 radius sensitivity...")
    supplementary_s3_radius_sensitivity(paths, args, manifest)

    write_manifest(
        manifest,
        paths["output"] / "figure_manifest.csv",
    )
    captions_path = write_captions_file(paths["output"])

    metadata = {
        "figure_version": FIGURE_VERSION,
        "generator_release": PIPELINE_FIGURE_RELEASE,
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "configuration_file": str(paths["config"]),
        "configuration_sha256": sha256_file(paths["config"]),
        "git_commit": current_git_commit(Path(__file__).resolve().parent),
        "subject_session_base": str(paths["base"]),
        "session": args.session,
        "multilateration_radius_mm": float(paths["radius_mm"]),
        "horizontal_axis": args.horizontal_axis,
        "vertical_axis": "V" if args.horizontal_axis == "U" else "U",
        "display_mode": args.display_mode,
        "display_domain": args.display_domain,
        "gaussian_sigma_bins": args.gaussian_sigma_bins,
        "finger_colors": FINGER_COLORS,
        "captions_file": str(captions_path),
        "radius_sensitivity_summary": str(paths["radius_sensitivity_summary"]),
        "radius_selected_from_functional_results": False,
        "production_radius_changed_by_step14": False,
    }
    with (paths["output"] / "figure_manifest.json").open(
        "w", encoding="utf-8"
    ) as stream:
        json.dump(metadata, stream, indent=2)

    write_provenance_json(
        {
            "figure_version": FIGURE_VERSION,
            "generator_release": PIPELINE_FIGURE_RELEASE,
            "config": str(paths["config"]),
            "session": args.session,
            "base": str(paths["base"]),
            "anatomical": str(paths["anatomical"]),
            "m1_roi": str(paths["m1_roi"]),
            "native_maps": {
                finger: str(paths[f"native_{finger}"])
                for finger in FINGERS
            },
            "native_display_threshold": args.native_display_threshold,
            "native_slice_axis": args.native_slice_axis,
            "native_slice_index_requested": args.native_slice_index,
            "flat_anatomical_source": flat.flat_anatomical_source,
            "display_mode": args.display_mode,
            "display_domain": args.display_domain,
            "gaussian_sigma_bins": args.gaussian_sigma_bins,
            "horizontal_axis": args.horizontal_axis,
            "quantitative_source": "raw_non_voronoi",
            "display_outputs_used_for_statistics": False,
            "wta_labels_smoothed_directly": False,
            "finger_colors": FINGER_COLORS,
            "native_maps_inferred_from_flat_maps": False,
            "hand_correspondence_figure_included": False,
            "multilateration_radius_mm": float(paths["radius_mm"]),
            "radius_sensitivity_reported": True,
            "radius_selected_from_functional_results": False,
            "production_radius_changed_by_step14": False,
        },
        paths["output"] / "figure_provenance.json",
    )

    print()
    print("Step 15 completed successfully.")
    print(f"Configuration: {paths['config']}")
    print(f"Session:       {args.session}")
    print(f"Output:        {paths['output']}")
    print("Generated:")
    print("  Figure S18-1")
    print("  Figure S18-2A native")
    print("  Figure S18-2B flattened")
    print("  Figure S18-3")
    print("  Figure S18-4")
    print("  Figure S18-S1")
    print("  Figure S18-S2")
    print("  Figure S18-S3 radius sensitivity")
    print(f"  Captions: {captions_path}")
    print(f"  Figure manifest JSON: {paths['output'] / 'figure_manifest.json'}")


if __name__ == "__main__":
    try:
        main()
    except (
        FileNotFoundError,
        RuntimeError,
        TypeError,
        ValueError,
    ) as exc:
        sys.exit(f"ERROR: {exc}")
