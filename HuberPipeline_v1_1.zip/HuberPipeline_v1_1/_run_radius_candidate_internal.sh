#!/usr/bin/env bash
set -euo pipefail

# =============================================================================
# HuberPipeline — Run one multilateration-radius sensitivity candidate
# =============================================================================
#
# Purpose
# -------
# Run the cleaned production Steps 09–13 for ONE already-generated Step-08
# radius branch, while enforcing radius-specific provenance at every stage.
#
# This wrapper is intentionally conservative:
#   - it does NOT rerun Steps 01–08;
#   - it does NOT change the production radius in the main config;
#   - it does NOT compare radii;
#   - it does NOT select/optimize a radius from functional results.
#
# Typical use
# -----------
#   ./run_radius_candidate.sh 00_config.yaml ses-18
#   ./run_radius_candidate.sh 00_config_radius40.yaml ses-18
#
# Then, once two or more candidates exist:
#   python 14_compare_multilaterate_radius.py \
#       00_config.yaml ses-18 --radii 30 40
#
# Optional flags
# --------------
#   --from-step N     Start at Step N (9..13), default 9
#   --to-step N       Stop after Step N (9..13), default 13
#   --qc-only-step09  Run Step 09 in QC-only mode instead of recomputing
#   --no-figures      Pass --no-figures to Python Steps 10–13 where supported
#
# =============================================================================

CONFIG="${1:-}"
SESSION="${2:-}"
shift $(( $# >= 2 ? 2 : $# ))

if [[ -z "${CONFIG}" || -z "${SESSION}" ]]; then
    echo "Usage: $0 CONFIG SESSION [--from-step N] [--to-step N] [--qc-only-step09] [--no-figures]" >&2
    exit 2
fi

[[ -f "${CONFIG}" ]] || {
    echo "ERROR: configuration file not found: ${CONFIG}" >&2
    exit 1
}

FROM_STEP=9
TO_STEP=13
QC_ONLY_STEP09=0
NO_FIGURES=0

while [[ $# -gt 0 ]]; do
    case "$1" in
        --from-step)
            [[ $# -ge 2 ]] || { echo "ERROR: --from-step requires a value." >&2; exit 2; }
            FROM_STEP="$2"
            shift 2
            ;;
        --to-step)
            [[ $# -ge 2 ]] || { echo "ERROR: --to-step requires a value." >&2; exit 2; }
            TO_STEP="$2"
            shift 2
            ;;
        --qc-only-step09)
            QC_ONLY_STEP09=1
            shift
            ;;
        --no-figures)
            NO_FIGURES=1
            shift
            ;;
        *)
            echo "ERROR: unknown argument: $1" >&2
            exit 2
            ;;
    esac
done

for n in "${FROM_STEP}" "${TO_STEP}"; do
    [[ "${n}" =~ ^[0-9]+$ ]] || {
        echo "ERROR: step limits must be integers." >&2
        exit 2
    }
    if (( n < 9 || n > 13 )); then
        echo "ERROR: step limits must lie between 9 and 13." >&2
        exit 2
    fi
done

if (( FROM_STEP > TO_STEP )); then
    echo "ERROR: --from-step cannot exceed --to-step." >&2
    exit 2
fi

PYTHON_DEFAULT="/home/carolyn.wagner/envs/layerfmri/bin/python"
PYTHON="${PYTHON:-${PYTHON_DEFAULT}}"

[[ -x "${PYTHON}" ]] || {
    echo "ERROR: Python executable not found: ${PYTHON}" >&2
    exit 1
}

# -----------------------------------------------------------------------------
# Resolve subject/session/radius/path information directly from YAML.
# -----------------------------------------------------------------------------

RESOLVED="$(
env -u PYTHONPATH -u PYTHONHOME "${PYTHON}" - "${CONFIG}" "${SESSION}" <<'PY'
import sys
from pathlib import Path
import yaml

cfg_path = Path(sys.argv[1])
session = sys.argv[2]

with cfg_path.open("r", encoding="utf-8") as stream:
    cfg = yaml.safe_load(stream)
if not isinstance(cfg, dict):
    raise SystemExit("ERROR: YAML root must be a mapping.")

dataset = cfg.get("dataset", {}) or {}
subject = str(cfg.get("subject") or dataset.get("subject") or "")
if not subject:
    raise SystemExit("ERROR: could not resolve subject from YAML.")

paths = cfg.get("paths", {}) or {}
project_root = str(paths.get("project_root", ""))
roi_root = str(paths.get("roi_root", ""))
pipeline_root = str(paths.get("pipeline_root", ""))

mapping = {
    "dataset.subject": subject,
    "dataset.session": session,
    "paths.project_root": project_root,
    "paths.roi_root": roi_root,
    "paths.pipeline_root": pipeline_root,
}

def expand(value):
    value = str(value)
    for _ in range(12):
        new = value
        for key, replacement in mapping.items():
            new = new.replace("${" + key + "}", str(replacement))
        if new == value:
            return new
        value = new
    return value

project_root = expand(project_root)
mapping["paths.project_root"] = project_root
roi_root = expand(roi_root)
mapping["paths.roi_root"] = roi_root
pipeline_root = expand(pipeline_root)
mapping["paths.pipeline_root"] = pipeline_root

subject_root = paths.get("subject_root")
if subject_root:
    subject_root = expand(subject_root)
else:
    subject_root = str(Path(pipeline_root) / "outputs" / subject)
mapping["paths.subject_root"] = subject_root

session_root = paths.get("session_root")
if session_root:
    session_root = expand(session_root)
else:
    session_root = str(Path(subject_root) / session)

frozen = cfg.get("frozen", {}) or {}
radius = float(frozen.get("multilateration_radius_mm", 30))
radius_tag = f"{radius:g}"
session_compact = session.replace("-", "")

print(f"SUBJECT={subject}")
print(f"SESSION_ROOT={session_root}")
print(f"RADIUS_MM={radius_tag}")
print(f"SESSION_COMPACT={session_compact}")
print(f"FLAT_ROOT={Path(session_root) / ('flat_uvd_radius' + radius_tag)}")
print(f"HUBER_ROOT={Path(session_root) / ('huber_style_maps_radius' + radius_tag)}")
print(f"UV_ROOT={Path(session_root) / 'true_uv'}")
PY
)"

eval "${RESOLVED}"

RADIUS_TOKEN="radius${RADIUS_MM}"

UV_COORD="${UV_ROOT}/${SESSION_COMPACT}_multilaterate_${RADIUS_TOKEN}_corrected_UV_coordinates.nii"
UV_DOMAIN="${UV_ROOT}/${SESSION_COMPACT}_multilaterate_${RADIUS_TOKEN}_corrected_perimeter_chunk.nii"

STEP09_SUMMARY="${FLAT_ROOT}/qc/flatten_summary.json"
STEP10_SUMMARY="${HUBER_ROOT}/qc/step10_summary.json"
STEP11_SUMMARY="${HUBER_ROOT}/somatotopy_qc/step11_summary.json"
STEP12_SUMMARY="${HUBER_ROOT}/depth_resolved_somatotopy/step12_summary.json"
STEP13_SUMMARY="${HUBER_ROOT}/robust_continuous_laminar_somatotopy/step13_summary.json"

LOG_DIR="${SESSION_ROOT}/radius_candidate_logs"
mkdir -p "${LOG_DIR}"
TIMESTAMP="$(date +%Y%m%d_%H%M%S)"
LOG_FILE="${LOG_DIR}/${SESSION_COMPACT}_${RADIUS_TOKEN}_${TIMESTAMP}.log"

exec > >(tee -a "${LOG_FILE}") 2>&1

echo "============================================================"
echo "HuberPipeline radius-candidate wrapper"
echo "============================================================"
echo "Config:        ${CONFIG}"
echo "Subject:       ${SUBJECT}"
echo "Session:       ${SESSION}"
echo "Radius:        ${RADIUS_MM} mm"
echo "Session root:  ${SESSION_ROOT}"
echo "Flat root:     ${FLAT_ROOT}"
echo "Huber root:    ${HUBER_ROOT}"
echo "Run range:     ${FROM_STEP} -> ${TO_STEP}"
echo "Log:           ${LOG_FILE}"
echo

# -----------------------------------------------------------------------------
# Helpers
# -----------------------------------------------------------------------------

die() {
    echo "ERROR: $*" >&2
    exit 1
}

require_file() {
    local f="$1"
    [[ -f "${f}" ]] || die "Required file not found: ${f}"
}

require_dir() {
    local d="$1"
    [[ -d "${d}" ]] || die "Required directory not found: ${d}"
}

json_assert() {
    local file="$1"
    local expr="$2"
    local message="$3"

    env -u PYTHONPATH -u PYTHONHOME "${PYTHON}" - "${file}" "${expr}" "${message}" <<'PY'
import json, sys
from pathlib import Path

path = Path(sys.argv[1])
expr = sys.argv[2]
message = sys.argv[3]

if not path.is_file():
    raise SystemExit(f"ERROR: JSON file missing: {path}")

with path.open("r", encoding="utf-8") as stream:
    data = json.load(stream)

# Controlled evaluation against one object only.
ok = eval(expr, {"__builtins__": {}}, {"d": data})
if not ok:
    raise SystemExit(f"ERROR: {message}\nJSON: {path}")
PY
}

assert_path_has_radius() {
    local path="$1"
    [[ "${path}" == *"${RADIUS_TOKEN}"* ]] || {
        die "Radius provenance mismatch: expected token ${RADIUS_TOKEN} in ${path}"
    }
}

run_python_step() {
    local script="$1"
    shift

    [[ -f "${script}" ]] || die "Pipeline script not found: ${script}"

    echo
    echo "------------------------------------------------------------"
    echo "Running: ${script} $*"
    echo "------------------------------------------------------------"

    env -u PYTHONPATH -u PYTHONHOME \
        MPLBACKEND=Agg \
        "${PYTHON}" \
        "${script}" \
        "$@"
}

# -----------------------------------------------------------------------------
# Preflight
# -----------------------------------------------------------------------------

for script in \
    09_patch_flatten.sh \
    10_build_huber_style_maps.py \
    11_identify_somatotopic_axis.py \
    12_depth_band_somatotopy.py \
    13_robust_laminar_somatotopy.py
do
    [[ -f "${script}" ]] || die "Required production script missing: ${script}"
done

require_file "${UV_COORD}"
require_file "${UV_DOMAIN}"
assert_path_has_radius "${UV_COORD}"
assert_path_has_radius "${UV_DOMAIN}"
assert_path_has_radius "${FLAT_ROOT}"
assert_path_has_radius "${HUBER_ROOT}"

echo "Preflight PASS"
echo "Step-08 radius-specific UV inputs exist and match ${RADIUS_TOKEN}."

# -----------------------------------------------------------------------------
# Step 09
# -----------------------------------------------------------------------------

if (( FROM_STEP <= 9 && TO_STEP >= 9 )); then
    echo
    echo "============================================================"
    echo "STEP 09"
    echo "============================================================"

    if (( QC_ONLY_STEP09 == 1 )); then
        ./09_patch_flatten.sh "${CONFIG}" "${SESSION}" --qc-only
    else
        ./09_patch_flatten.sh "${CONFIG}" "${SESSION}"
    fi

    require_file "${STEP09_SUMMARY}"
    assert_path_has_radius "${FLAT_ROOT}"

    json_assert \
        "${STEP09_SUMMARY}" \
        'd.get("status") == "PASS"' \
        "Step 09 summary does not report PASS."

    echo "Step 09 provenance PASS: ${FLAT_ROOT}"
fi

# If starting after 9, enforce that the correct branch already exists.
if (( FROM_STEP > 9 )); then
    require_file "${STEP09_SUMMARY}"
    json_assert \
        "${STEP09_SUMMARY}" \
        'd.get("status") == "PASS"' \
        "Existing Step 09 summary does not report PASS."
fi

# -----------------------------------------------------------------------------
# Step 10
# -----------------------------------------------------------------------------

if (( FROM_STEP <= 10 && TO_STEP >= 10 )); then
    echo
    echo "============================================================"
    echo "STEP 10"
    echo "============================================================"

    EXTRA=()
    (( NO_FIGURES == 1 )) && EXTRA+=(--no-figures)

    run_python_step \
        10_build_huber_style_maps.py \
        "${CONFIG}" "${SESSION}" "${EXTRA[@]}"

    require_file "${STEP10_SUMMARY}"
    assert_path_has_radius "${HUBER_ROOT}"

    json_assert \
        "${STEP10_SUMMARY}" \
        'd.get("status") == "PASS"' \
        "Step 10 summary does not report PASS."

    json_assert \
        "${STEP10_SUMMARY}" \
        'd.get("flat_root") == "'"${FLAT_ROOT}"'"' \
        "Step 10 did not read the expected radius-specific flat root."

    json_assert \
        "${STEP10_SUMMARY}" \
        'd.get("output_dir") == "'"${HUBER_ROOT}"'"' \
        "Step 10 did not write to the expected radius-specific Huber root."

    json_assert \
        "${STEP10_SUMMARY}" \
        'd.get("radius_token") == "'"${RADIUS_TOKEN}"'"' \
        "Step 10 summary radius token does not match the configured branch."

    json_assert \
        "${STEP10_SUMMARY}" \
        'd.get("quantitative_source") == "raw_non_voronoi"' \
        "Step 10 is not using raw_non_voronoi as the quantitative source."

    json_assert \
        "${STEP10_SUMMARY}" \
        'd.get("voronoi_used_quantitatively") is False' \
        "Step 10 reports quantitative use of Voronoi products."

    echo "Step 10 provenance PASS: ${HUBER_ROOT}"
fi

if (( FROM_STEP > 10 )); then
    require_file "${STEP10_SUMMARY}"
fi

# -----------------------------------------------------------------------------
# Step 11
# -----------------------------------------------------------------------------

if (( FROM_STEP <= 11 && TO_STEP >= 11 )); then
    echo
    echo "============================================================"
    echo "STEP 11"
    echo "============================================================"

    EXTRA=()
    (( NO_FIGURES == 1 )) && EXTRA+=(--no-figures)

    run_python_step \
        11_identify_somatotopic_axis.py \
        "${CONFIG}" "${SESSION}" "${EXTRA[@]}"

    require_file "${STEP11_SUMMARY}"

    json_assert \
        "${STEP11_SUMMARY}" \
        'd.get("status") == "PASS"' \
        "Step 11 summary does not report PASS."

    json_assert \
        "${STEP11_SUMMARY}" \
        'd.get("coordinate_geometry_modified") is False' \
        "Step 11 reports coordinate-geometry modification."

    json_assert \
        "${STEP11_SUMMARY}" \
        'd.get("axis_flipped_on_disk") is False' \
        "Step 11 reports an on-disk axis flip."

    echo "Step 11 provenance PASS."
fi

if (( FROM_STEP > 11 )); then
    require_file "${STEP11_SUMMARY}"
fi

# -----------------------------------------------------------------------------
# Step 12
# -----------------------------------------------------------------------------

if (( FROM_STEP <= 12 && TO_STEP >= 12 )); then
    echo
    echo "============================================================"
    echo "STEP 12"
    echo "============================================================"

    EXTRA=()
    (( NO_FIGURES == 1 )) && EXTRA+=(--no-figures)

    run_python_step \
        12_depth_band_somatotopy.py \
        "${CONFIG}" "${SESSION}" "${EXTRA[@]}"

    require_file "${STEP12_SUMMARY}"

    json_assert \
        "${STEP12_SUMMARY}" \
        'd.get("status") == "PASS"' \
        "Step 12 summary does not report PASS."

    json_assert \
        "${STEP12_SUMMARY}" \
        'd.get("coordinate_geometry_modified") is False' \
        "Step 12 reports coordinate-geometry modification."

    echo "Step 12 provenance PASS."
fi

if (( FROM_STEP > 12 )); then
    require_file "${STEP12_SUMMARY}"
fi

# -----------------------------------------------------------------------------
# Step 13
# -----------------------------------------------------------------------------

if (( FROM_STEP <= 13 && TO_STEP >= 13 )); then
    echo
    echo "============================================================"
    echo "STEP 13"
    echo "============================================================"

    EXTRA=()
    (( NO_FIGURES == 1 )) && EXTRA+=(--no-figures)

    run_python_step \
        13_robust_laminar_somatotopy.py \
        "${CONFIG}" "${SESSION}" "${EXTRA[@]}"

    require_file "${STEP13_SUMMARY}"

    json_assert \
        "${STEP13_SUMMARY}" \
        'd.get("status") == "PASS"' \
        "Step 13 summary does not report PASS."

    json_assert \
        "${STEP13_SUMMARY}" \
        'd.get("coordinate_geometry_modified") is False' \
        "Step 13 reports coordinate-geometry modification."

    json_assert \
        "${STEP13_SUMMARY}" \
        'd.get("axis_flipped_on_disk") is False' \
        "Step 13 reports an on-disk axis flip."

    json_assert \
        "${STEP13_SUMMARY}" \
        'd.get("voronoi_used_quantitatively") is False' \
        "Step 13 reports quantitative use of Voronoi data."

    echo "Step 13 provenance PASS."
fi

# -----------------------------------------------------------------------------
# Final candidate manifest
# -----------------------------------------------------------------------------

MANIFEST_DIR="${SESSION_ROOT}/radius_candidates"
mkdir -p "${MANIFEST_DIR}"
MANIFEST="${MANIFEST_DIR}/${SESSION_COMPACT}_${RADIUS_TOKEN}_candidate_manifest.json"

env -u PYTHONPATH -u PYTHONHOME "${PYTHON}" - \
    "${CONFIG}" \
    "${SESSION}" \
    "${RADIUS_MM}" \
    "${UV_COORD}" \
    "${UV_DOMAIN}" \
    "${FLAT_ROOT}" \
    "${HUBER_ROOT}" \
    "${STEP09_SUMMARY}" \
    "${STEP10_SUMMARY}" \
    "${STEP11_SUMMARY}" \
    "${STEP12_SUMMARY}" \
    "${STEP13_SUMMARY}" \
    "${MANIFEST}" <<'PY'
import json
import sys
from pathlib import Path
from datetime import datetime

(
    config,
    session,
    radius,
    uv_coord,
    uv_domain,
    flat_root,
    huber_root,
    step09,
    step10,
    step11,
    step12,
    step13,
    manifest,
) = sys.argv[1:]

def maybe_json(path):
    p = Path(path)
    if not p.is_file():
        return None
    with p.open("r", encoding="utf-8") as stream:
        return json.load(stream)

data = {
    "status": "PASS",
    "created_at": datetime.now().isoformat(timespec="seconds"),
    "config": str(Path(config).resolve()),
    "session": session,
    "radius_mm": float(radius),
    "uv_coordinates": uv_coord,
    "uv_domain": uv_domain,
    "flat_root": flat_root,
    "huber_root": huber_root,
    "step09_summary": maybe_json(step09),
    "step10_summary": maybe_json(step10),
    "step11_summary": maybe_json(step11),
    "step12_summary": maybe_json(step12),
    "step13_summary": maybe_json(step13),
    "production_radius_selected_from_functional_results": False,
    "radius_candidate_role": "sensitivity_analysis",
}

Path(manifest).write_text(
    json.dumps(data, indent=2),
    encoding="utf-8",
)
PY

echo
echo "============================================================"
echo "Radius candidate COMPLETE"
echo "============================================================"
echo "Radius:         ${RADIUS_MM} mm"
echo "Flat branch:    ${FLAT_ROOT}"
echo "Huber branch:   ${HUBER_ROOT}"
echo "Manifest:       ${MANIFEST}"
echo "Log:            ${LOG_FILE}"
echo
echo "This wrapper did NOT select or change the production radius."
echo "When at least two radius candidates are complete, run Step 14."
