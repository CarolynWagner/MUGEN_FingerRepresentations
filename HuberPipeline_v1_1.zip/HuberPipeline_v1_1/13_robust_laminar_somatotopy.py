#!/usr/bin/env python3
"""
HuberPipeline Step 13 - Robust continuous laminar somatotopy.

This corrected version addresses sparse and unstable depth-bin estimates.

Improvements
------------
1. Reports effective support for every finger and depth bin.
2. Requires all five fingers to meet minimum support criteria.
3. Rejects constant centroid/peak configurations without warnings.
4. Computes both single-bin and sliding-window estimates.
5. Identifies the best contiguous valid depth interval, rather than the
   largest isolated correlation.
6. Quantifies axis specificity:
       |rho_U| - |rho_V|
7. Keeps single-bin estimates as diagnostics but recommends the most stable
   contiguous U/V interval.

Input
-----
Step-10 long-format raw quantitative table:

    dominance_fraction_profiles_long.csv

Default validity criteria
-------------------------
--minimum-position-support 1
--minimum-valid-positions 5
--minimum-profile-mass 1
--minimum-position-range 1
--window-size 3
--minimum-contiguous-bins 3

Outputs
-------
single_bin_finger_metrics.csv
single_bin_ordering_summary.csv
single_bin_adjacent_overlap.csv
single_bin_support_qc.csv
sliding_window_finger_metrics.csv
sliding_window_ordering_summary.csv
sliding_window_axis_specificity.csv
contiguous_interval_summary.csv
robust_laminar_summary.txt

Optional figures
----------------
U_single_bin_ordering.png
V_single_bin_ordering.png
U_sliding_window_ordering.png
V_sliding_window_ordering.png
axis_specificity_vs_depth.png
support_qc_vs_depth.png

Usage
-----
env -u PYTHONPATH -u PYTHONHOME \
  /home/carolyn.wagner/envs/layerfmri/bin/python \
  13_robust_laminar_somatotopy.py \
  00_config.yaml ses-18
"""

import argparse
import json
import sys
from pathlib import Path
from typing import Dict, List, Tuple

import numpy as np
import pandas as pd
import yaml
from scipy.stats import kendalltau, spearmanr


FINGERS = ("thumb", "index", "middle", "ring", "little")
FINGER_ORDER = {finger: index for index, finger in enumerate(FINGERS)}
ADJACENT_PAIRS = tuple(zip(FINGERS[:-1], FINGERS[1:]))
AXES = ("U", "V")

# Frozen HuberPipeline v1.0 laminar-analysis settings.
WINDOW_SIZE = 3
MINIMUM_POSITION_SUPPORT = 1.0
MINIMUM_VALID_POSITIONS = 5
MINIMUM_PROFILE_MASS = 1.0
MINIMUM_POSITION_RANGE = 1.0
MINIMUM_CONTIGUOUS_WINDOWS = 3

# Additional v1.0 robustness gates for declaring a supported somatotopic
# interval. These are fixed before cohort-scale analysis and are not optimized
# per subject:
#   1. the window must pass the existing support/range validity criteria;
#   2. ordinal ordering must reach at least |rho| = 0.4;
#   3. the candidate axis must outperform the orthogonal axis (> 0
#      specificity) at that same depth window.
MINIMUM_SUPPORTED_RHO = 0.4
REQUIRE_POSITIVE_AXIS_SPECIFICITY = True


def parse_args():
    parser = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
        description=(
            "Run the frozen HuberPipeline v1.0 robust laminar somatotopy "
            "analysis using single depth bins, three-bin sliding windows, "
            "axis specificity, and contiguous-interval summaries."
        ),
    )
    parser.add_argument(
        "config",
        help="HuberPipeline YAML configuration.",
    )
    parser.add_argument(
        "session",
        help="Session key, e.g. ses-18.",
    )
    parser.add_argument(
        "--no-figures",
        action="store_true",
        help="Skip Step-13 QC figures.",
    )

    args = parser.parse_args()

    # Methodological parameters are frozen in v1.0. Changing any of these
    # requires a new pipeline version rather than a per-run command-line flag.
    args.minimum_position_support = MINIMUM_POSITION_SUPPORT
    args.minimum_valid_positions = MINIMUM_VALID_POSITIONS
    args.minimum_profile_mass = MINIMUM_PROFILE_MASS
    args.minimum_position_range = MINIMUM_POSITION_RANGE
    args.window_size = WINDOW_SIZE
    args.minimum_contiguous_bins = MINIMUM_CONTIGUOUS_WINDOWS
    return args


def _expand_config_string(value, mapping):
    value = str(value)
    for _ in range(12):
        new = value
        for key, replacement in mapping.items():
            new = new.replace("${" + key + "}", str(replacement))
        if new == value:
            return new
        value = new
    return value


def resolve_production_paths(config_path: Path, session: str):
    if not config_path.is_file():
        raise FileNotFoundError(config_path)

    with config_path.open("r", encoding="utf-8") as stream:
        cfg = yaml.safe_load(stream)
    if not isinstance(cfg, dict):
        raise ValueError("YAML root must be a mapping.")

    dataset = cfg.get("dataset", {}) or {}
    subject = str(cfg.get("subject") or dataset.get("subject") or "")
    if not subject:
        raise ValueError("Could not resolve subject from configuration.")

    paths = cfg.get("paths", {}) or {}
    project_root = str(paths.get("project_root", ""))
    roi_root = str(paths.get("roi_root", ""))
    pipeline_root = str(paths.get("pipeline_root", ""))

    mapping = {
        "dataset.subject": subject,
        "dataset.session": session,
        "paths.project_root": project_root,
        "paths.roi_root": roi_root,
        "paths.pipeline_root": pipeline_root,
    }

    project_root = _expand_config_string(project_root, mapping)
    mapping["paths.project_root"] = project_root
    roi_root = _expand_config_string(roi_root, mapping)
    mapping["paths.roi_root"] = roi_root
    pipeline_root = _expand_config_string(pipeline_root, mapping)
    mapping["paths.pipeline_root"] = pipeline_root

    subject_root = paths.get("subject_root")
    if subject_root:
        subject_root = _expand_config_string(subject_root, mapping)
    else:
        subject_root = str(Path(pipeline_root) / "outputs" / subject)
    mapping["paths.subject_root"] = subject_root

    session_root = paths.get("session_root")
    if session_root:
        session_root = _expand_config_string(session_root, mapping)
    else:
        session_root = str(Path(subject_root) / session)

    frozen_cfg = cfg.get("frozen", {}) or {}
    radius = float(frozen_cfg.get("multilateration_radius_mm", 30))
    radius_tag = f"{radius:g}"

    step10_root = (
        Path(session_root) / f"huber_style_maps_radius{radius_tag}"
    )
    input_path = (
        step10_root / "tables" / "dominance_fraction_profiles_long.csv"
    )
    output_dir = step10_root / "robust_continuous_laminar_somatotopy"

    return input_path, output_dir, step10_root, radius


def validate_input(data: pd.DataFrame):
    required = {
        "finger",
        "profile_axis",
        "position_bin",
        "depth_bin",
        "dominance_fraction",
        "density_weight",
    }
    missing = sorted(required - set(data.columns))
    if missing:
        raise RuntimeError(
            "Missing required columns: " + ", ".join(missing)
        )

    unknown_fingers = sorted(
        set(data["finger"].dropna().unique()) - set(FINGERS)
    )
    if unknown_fingers:
        raise RuntimeError(
            f"Unexpected finger labels: {unknown_fingers}"
        )

    unknown_axes = sorted(
        set(data["profile_axis"].dropna().unique()) - set(AXES)
    )
    if unknown_axes:
        raise RuntimeError(
            f"Unexpected axes: {unknown_axes}"
        )


def reconstruct_matrix(
    data: pd.DataFrame,
    axis_name: str,
    finger: str,
) -> Tuple[np.ndarray, np.ndarray]:
    subset = data[
        (data["profile_axis"] == axis_name)
        & (data["finger"] == finger)
    ].copy()

    if subset.empty:
        raise RuntimeError(
            f"No rows for axis={axis_name}, finger={finger}."
        )

    n_position = int(subset["position_bin"].max()) + 1
    n_depth = int(subset["depth_bin"].max()) + 1

    values = np.full(
        (n_position, n_depth),
        np.nan,
        dtype=np.float64,
    )
    support = np.zeros(
        (n_position, n_depth),
        dtype=np.float64,
    )

    position = subset["position_bin"].astype(int).to_numpy()
    depth = subset["depth_bin"].astype(int).to_numpy()

    values[position, depth] = subset[
        "dominance_fraction"
    ].to_numpy(dtype=float)
    support[position, depth] = subset[
        "density_weight"
    ].to_numpy(dtype=float)

    values[support <= 0] = np.nan

    return values, support


def combine_depth_window(
    matrix: np.ndarray,
    support: np.ndarray,
    start: int,
    stop: int,
) -> Tuple[np.ndarray, np.ndarray]:
    values = matrix[:, start:stop]
    weights = support[:, start:stop]

    valid = (
        np.isfinite(values)
        & np.isfinite(weights)
        & (weights > 0)
    )

    numerator = np.sum(
        np.where(valid, values * weights, 0.0),
        axis=1,
    )
    denominator = np.sum(
        np.where(valid, weights, 0.0),
        axis=1,
    )

    profile = np.full(
        matrix.shape[0],
        np.nan,
        dtype=np.float64,
    )
    np.divide(
        numerator,
        denominator,
        out=profile,
        where=denominator > 0,
    )

    return profile, denominator


def position_metrics(
    profile: np.ndarray,
    support: np.ndarray,
    minimum_position_support: float,
) -> Dict[str, float]:
    position = np.arange(profile.size, dtype=np.float64)

    valid = (
        np.isfinite(profile)
        & np.isfinite(support)
        & (support >= minimum_position_support)
        & (profile > 0)
    )

    n_valid = int(np.count_nonzero(valid))

    if n_valid == 0:
        return {
            "centroid_position": np.nan,
            "peak_position": np.nan,
            "profile_spread": np.nan,
            "profile_mass": 0.0,
            "n_valid_positions": 0,
            "support_sum": 0.0,
        }

    weight = profile[valid] * support[valid]
    valid_position = position[valid]
    total = float(np.sum(weight))
    support_sum = float(np.sum(support[valid]))

    if total <= 0:
        return {
            "centroid_position": np.nan,
            "peak_position": np.nan,
            "profile_spread": np.nan,
            "profile_mass": 0.0,
            "n_valid_positions": n_valid,
            "support_sum": support_sum,
        }

    centroid = float(
        np.sum(valid_position * weight) / total
    )
    variance = float(
        np.sum(
            ((valid_position - centroid) ** 2) * weight
        ) / total
    )

    valid_indices = np.flatnonzero(valid)
    peak = int(
        valid_indices[
            np.argmax(profile[valid] * support[valid])
        ]
    )

    return {
        "centroid_position": centroid,
        "peak_position": float(peak),
        "profile_spread": float(np.sqrt(max(variance, 0.0))),
        "profile_mass": total,
        "n_valid_positions": n_valid,
        "support_sum": support_sum,
    }


def inversion_counts(values: np.ndarray) -> Tuple[int, int]:
    adjacent = 0
    all_pairs = 0

    for index in range(values.size - 1):
        if values[index + 1] < values[index]:
            adjacent += 1

    for first in range(values.size):
        for second in range(first + 1, values.size):
            if values[second] < values[first]:
                all_pairs += 1

    return adjacent, all_pairs


def safe_rank_metrics(
    positions: np.ndarray,
) -> Dict[str, float]:
    if not np.all(np.isfinite(positions)):
        return {
            "spearman_rho_raw": np.nan,
            "spearman_p_raw": np.nan,
            "kendall_tau_raw": np.nan,
            "kendall_p_raw": np.nan,
            "spearman_rho_best_direction": np.nan,
            "kendall_tau_best_direction": np.nan,
            "best_direction": "undetermined",
            "adjacent_inversions": np.nan,
            "all_pair_inversions": np.nan,
            "position_range": np.nan,
            "mean_adjacent_spacing": np.nan,
            "minimum_adjacent_spacing": np.nan,
            "maximum_adjacent_spacing": np.nan,
            "constant_positions": False,
        }

    position_range = float(np.max(positions) - np.min(positions))

    if np.allclose(positions, positions[0], atol=1e-12, rtol=0.0):
        return {
            "spearman_rho_raw": np.nan,
            "spearman_p_raw": np.nan,
            "kendall_tau_raw": np.nan,
            "kendall_p_raw": np.nan,
            "spearman_rho_best_direction": np.nan,
            "kendall_tau_best_direction": np.nan,
            "best_direction": "constant",
            "adjacent_inversions": np.nan,
            "all_pair_inversions": np.nan,
            "position_range": 0.0,
            "mean_adjacent_spacing": 0.0,
            "minimum_adjacent_spacing": 0.0,
            "maximum_adjacent_spacing": 0.0,
            "constant_positions": True,
        }

    order = np.arange(len(FINGERS), dtype=float)
    rho, rho_p = spearmanr(order, positions)
    tau, tau_p = kendalltau(order, positions)

    if not np.isfinite(rho):
        return {
            "spearman_rho_raw": np.nan,
            "spearman_p_raw": np.nan,
            "kendall_tau_raw": np.nan,
            "kendall_p_raw": np.nan,
            "spearman_rho_best_direction": np.nan,
            "kendall_tau_best_direction": np.nan,
            "best_direction": "undetermined",
            "adjacent_inversions": np.nan,
            "all_pair_inversions": np.nan,
            "position_range": position_range,
            "mean_adjacent_spacing": np.nan,
            "minimum_adjacent_spacing": np.nan,
            "maximum_adjacent_spacing": np.nan,
            "constant_positions": False,
        }

    if rho >= 0:
        oriented = positions
        direction = "increasing"
        best_rho = float(rho)
        best_tau = float(tau)
    else:
        oriented = -positions
        direction = "decreasing"
        best_rho = float(-rho)
        best_tau = float(-tau)

    adjacent, all_pairs = inversion_counts(oriented)
    spacing = np.diff(oriented)

    return {
        "spearman_rho_raw": float(rho),
        "spearman_p_raw": float(rho_p),
        "kendall_tau_raw": float(tau),
        "kendall_p_raw": float(tau_p),
        "spearman_rho_best_direction": best_rho,
        "kendall_tau_best_direction": best_tau,
        "best_direction": direction,
        "adjacent_inversions": adjacent,
        "all_pair_inversions": all_pairs,
        "position_range": position_range,
        "mean_adjacent_spacing": float(np.mean(spacing)),
        "minimum_adjacent_spacing": float(np.min(spacing)),
        "maximum_adjacent_spacing": float(np.max(spacing)),
        "constant_positions": False,
    }


def evaluate_window(
    finger_metrics: pd.DataFrame,
    axis_name: str,
    window_id: int,
    metric_name: str,
    args,
    normalized_center: float,
) -> Dict[str, object]:
    subset = (
        finger_metrics[
            (finger_metrics["profile_axis"] == axis_name)
            & (finger_metrics["window_id"] == window_id)
        ]
        .set_index("finger")
        .loc[list(FINGERS)]
    )

    positions = subset[metric_name].to_numpy(dtype=float)

    support_valid = (
        (subset["n_valid_positions"].to_numpy(dtype=float)
         >= args.minimum_valid_positions)
        & (subset["profile_mass"].to_numpy(dtype=float)
           >= args.minimum_profile_mass)
        & np.isfinite(positions)
    )
    all_fingers_valid = bool(np.all(support_valid))

    rank = safe_rank_metrics(positions)

    range_valid = (
        np.isfinite(rank["position_range"])
        and rank["position_range"] >= args.minimum_position_range
    )

    valid_window = (
        all_fingers_valid
        and range_valid
        and not rank["constant_positions"]
        and np.isfinite(rank["spearman_rho_best_direction"])
    )

    return {
        "profile_axis": axis_name,
        "window_id": window_id,
        "depth_center_normalized": normalized_center,
        "position_metric": metric_name,
        "all_fingers_valid": all_fingers_valid,
        "range_valid": bool(range_valid),
        "valid_window": bool(valid_window),
        "minimum_finger_valid_positions": int(
            np.nanmin(
                subset["n_valid_positions"].to_numpy(dtype=float)
            )
        ),
        "minimum_finger_profile_mass": float(
            np.nanmin(
                subset["profile_mass"].to_numpy(dtype=float)
            )
        ),
        **rank,
    }


def weighted_overlap(
    profile_a: np.ndarray,
    support_a: np.ndarray,
    profile_b: np.ndarray,
    support_b: np.ndarray,
    minimum_support: float,
) -> Tuple[float, float, int]:
    joint_support = np.minimum(support_a, support_b)

    valid = (
        np.isfinite(profile_a)
        & np.isfinite(profile_b)
        & np.isfinite(joint_support)
        & (joint_support >= minimum_support)
        & (profile_a >= 0)
        & (profile_b >= 0)
    )

    n_valid = int(np.count_nonzero(valid))

    if n_valid < 3:
        return np.nan, np.nan, n_valid

    a = profile_a[valid]
    b = profile_b[valid]
    w = joint_support[valid]

    overlap_num = float(np.sum(np.minimum(a, b) * w))
    overlap_den = float(min(np.sum(a * w), np.sum(b * w)))
    overlap = overlap_num / overlap_den if overlap_den > 0 else np.nan

    w_sum = float(np.sum(w))
    mean_a = float(np.sum(a * w) / w_sum)
    mean_b = float(np.sum(b * w) / w_sum)

    covariance = float(
        np.sum(w * (a - mean_a) * (b - mean_b)) / w_sum
    )
    variance_a = float(
        np.sum(w * (a - mean_a) ** 2) / w_sum
    )
    variance_b = float(
        np.sum(w * (b - mean_b) ** 2) / w_sum
    )

    denominator = np.sqrt(variance_a * variance_b)
    correlation = covariance / denominator if denominator > 0 else np.nan

    return overlap, correlation, n_valid


def add_axis_specificity(ordering: pd.DataFrame) -> pd.DataFrame:
    centroid = ordering[
        ordering["position_metric"] == "centroid_position"
    ].copy()

    u = centroid[
        centroid["profile_axis"] == "U"
    ].set_index("window_id")
    v = centroid[
        centroid["profile_axis"] == "V"
    ].set_index("window_id")

    common = sorted(set(u.index) & set(v.index))
    rows = []

    for window_id in common:
        u_row = u.loc[window_id]
        v_row = v.loc[window_id]

        u_rho = u_row["spearman_rho_best_direction"]
        v_rho = v_row["spearman_rho_best_direction"]

        specificity_u_minus_v = (
            float(u_rho - v_rho)
            if np.isfinite(u_rho) and np.isfinite(v_rho)
            else np.nan
        )

        rows.append(
            {
                "window_id": int(window_id),
                "depth_center_normalized": float(
                    u_row["depth_center_normalized"]
                ),
                "u_valid": bool(u_row["valid_window"]),
                "v_valid": bool(v_row["valid_window"]),
                "u_best_rho": float(u_rho)
                if np.isfinite(u_rho) else np.nan,
                "v_best_rho": float(v_rho)
                if np.isfinite(v_rho) else np.nan,
                "u_minus_v_specificity": specificity_u_minus_v,
            }
        )

    return pd.DataFrame(rows)


def contiguous_runs(valid_mask: np.ndarray) -> List[Tuple[int, int]]:
    runs = []
    start = None

    for index, valid in enumerate(valid_mask):
        if valid and start is None:
            start = index
        elif not valid and start is not None:
            runs.append((start, index))
            start = None

    if start is not None:
        runs.append((start, len(valid_mask)))

    return runs


def summarize_contiguous_intervals(
    ordering: pd.DataFrame,
    specificity: pd.DataFrame,
    minimum_bins: int,
    *,
    supported_only: bool,
) -> pd.DataFrame:
    """
    Summarize contiguous depth-window intervals.

    `supported_only=False` reproduces the earlier descriptive definition:
    any technically valid window may contribute.

    `supported_only=True` is the primary v1.0 inferential/QC definition:
      - technical/support validity must pass;
      - |Spearman rho| >= MINIMUM_SUPPORTED_RHO;
      - the candidate axis must outperform the orthogonal axis at that
        window (positive axis specificity);
      - at least `minimum_bins` consecutive windows are required.
    """
    rows = []

    centroid = ordering[
        ordering["position_metric"] == "centroid_position"
    ].copy()

    spec = specificity.set_index("window_id")

    for axis_name in AXES:
        subset = (
            centroid[centroid["profile_axis"] == axis_name]
            .sort_values("window_id")
            .reset_index(drop=True)
        )

        supported_flags = []
        axis_specificities = []

        for row in subset.itertuples():
            window_id = int(row.window_id)
            technical_valid = bool(row.valid_window)
            rho_ok = (
                np.isfinite(row.spearman_rho_best_direction)
                and float(row.spearman_rho_best_direction)
                >= MINIMUM_SUPPORTED_RHO
            )

            if window_id in spec.index:
                u_minus_v = float(
                    spec.loc[window_id, "u_minus_v_specificity"]
                )
                axis_specificity = (
                    u_minus_v if axis_name == "U" else -u_minus_v
                )
            else:
                axis_specificity = np.nan

            specificity_ok = (
                np.isfinite(axis_specificity)
                and (
                    axis_specificity > 0
                    if REQUIRE_POSITIVE_AXIS_SPECIFICITY
                    else True
                )
            )

            supported = (
                technical_valid
                and rho_ok
                and specificity_ok
            )

            supported_flags.append(bool(supported))
            axis_specificities.append(axis_specificity)

        subset = subset.copy()
        subset["axis_specificity"] = axis_specificities
        subset["supported_somatotopy_window"] = supported_flags

        if supported_only:
            valid_mask = subset[
                "supported_somatotopy_window"
            ].to_numpy(dtype=bool)
        else:
            valid_mask = subset["valid_window"].to_numpy(dtype=bool)

        runs = contiguous_runs(valid_mask)

        for run_id, (start, stop) in enumerate(runs):
            length = stop - start
            if length < minimum_bins:
                continue

            block = subset.iloc[start:stop]

            rows.append(
                {
                    "interval_definition": (
                        "supported"
                        if supported_only
                        else "descriptive_valid"
                    ),
                    "profile_axis": axis_name,
                    "run_id": run_id,
                    "start_window_id": int(
                        block["window_id"].iloc[0]
                    ),
                    "stop_window_id_exclusive": int(
                        block["window_id"].iloc[-1] + 1
                    ),
                    "n_windows": int(length),
                    "depth_start_normalized": float(
                        block["depth_center_normalized"].iloc[0]
                    ),
                    "depth_stop_normalized": float(
                        block["depth_center_normalized"].iloc[-1]
                    ),
                    "mean_best_rho": float(
                        block[
                            "spearman_rho_best_direction"
                        ].mean()
                    ),
                    "median_best_rho": float(
                        block[
                            "spearman_rho_best_direction"
                        ].median()
                    ),
                    "minimum_best_rho": float(
                        block[
                            "spearman_rho_best_direction"
                        ].min()
                    ),
                    "mean_best_tau": float(
                        block[
                            "kendall_tau_best_direction"
                        ].mean()
                    ),
                    "mean_adjacent_inversions": float(
                        block["adjacent_inversions"].mean()
                    ),
                    "mean_all_pair_inversions": float(
                        block["all_pair_inversions"].mean()
                    ),
                    "minimum_axis_specificity": float(
                        block["axis_specificity"].min()
                    ),
                    "mean_axis_specificity": float(
                        block["axis_specificity"].mean()
                    ),
                }
            )

    intervals = pd.DataFrame(rows)

    if not intervals.empty:
        intervals["interval_score"] = (
            intervals["mean_best_rho"]
            + 0.25 * intervals["mean_best_tau"]
            + 0.25 * intervals["mean_axis_specificity"]
            - 0.10 * intervals["mean_adjacent_inversions"]
            - 0.02 * intervals["mean_all_pair_inversions"]
            + 0.01 * intervals["n_windows"]
        )
        intervals = intervals.sort_values(
            ["interval_score", "n_windows"],
            ascending=[False, False],
        )

    return intervals


def create_figures(
    output_dir: Path,
    single_ordering: pd.DataFrame,
    sliding_ordering: pd.DataFrame,
    specificity: pd.DataFrame,
    support_qc: pd.DataFrame,
):
    try:
        import matplotlib
        matplotlib.use("Agg", force=True)
        import matplotlib.pyplot as plt
    except Exception as exc:
        print(
            "WARNING: matplotlib unavailable; figures skipped.\n"
            f"  {exc}"
        )
        return

    for label, ordering in (
        ("single_bin", single_ordering),
        ("sliding_window", sliding_ordering),
    ):
        centroid = ordering[
            ordering["position_metric"] == "centroid_position"
        ]

        for axis_name in AXES:
            subset = (
                centroid[centroid["profile_axis"] == axis_name]
                .sort_values("depth_center_normalized")
            )

            figure, axes = plt.subplots(
                nrows=3,
                ncols=1,
                figsize=(10, 10),
                sharex=True,
            )

            valid = subset["valid_window"].to_numpy(dtype=bool)
            x = subset["depth_center_normalized"].to_numpy()

            axes[0].plot(
                x,
                subset["spearman_rho_best_direction"],
                marker="o",
            )
            axes[0].scatter(
                x[~valid],
                np.zeros(np.count_nonzero(~valid)),
                marker="x",
            )
            axes[0].set_ylim(0, 1)
            axes[0].set_ylabel("|Spearman rho|")
            axes[0].set_title(f"{axis_name}: {label}")

            axes[1].plot(
                x,
                subset["kendall_tau_best_direction"],
                marker="o",
            )
            axes[1].set_ylim(0, 1)
            axes[1].set_ylabel("|Kendall tau|")

            axes[2].plot(
                x,
                subset["minimum_finger_valid_positions"],
                marker="o",
                label="Min valid positions",
            )
            axes[2].plot(
                x,
                subset["minimum_finger_profile_mass"],
                marker="o",
                label="Min profile mass",
            )
            axes[2].set_xlabel("Normalized depth")
            axes[2].set_ylabel("Support")
            axes[2].legend()

            figure.tight_layout()
            figure.savefig(
                output_dir / f"{axis_name}_{label}_ordering.png",
                dpi=220,
            )
            plt.close(figure)

    if not specificity.empty:
        figure = plt.figure(figsize=(10, 6))
        axis = figure.add_subplot(111)
        axis.axhline(0.0)
        axis.plot(
            specificity["depth_center_normalized"],
            specificity["u_minus_v_specificity"],
            marker="o",
        )
        axis.set_xlabel("Normalized depth")
        axis.set_ylabel("|rho U| - |rho V|")
        axis.set_title("Axis specificity across depth")
        figure.tight_layout()
        figure.savefig(
            output_dir / "axis_specificity_vs_depth.png",
            dpi=220,
        )
        plt.close(figure)

    if not support_qc.empty:
        figure = plt.figure(figsize=(10, 6))
        axis = figure.add_subplot(111)

        for axis_name in AXES:
            subset = support_qc[
                support_qc["profile_axis"] == axis_name
            ].sort_values("depth_center_normalized")

            axis.plot(
                subset["depth_center_normalized"],
                subset["minimum_finger_valid_positions"],
                marker="o",
                label=f"{axis_name}: min valid positions",
            )

        axis.set_xlabel("Normalized depth")
        axis.set_ylabel("Minimum valid positions across fingers")
        axis.set_title("Support QC across depth")
        axis.legend()
        figure.tight_layout()
        figure.savefig(
            output_dir / "support_qc_vs_depth.png",
            dpi=220,
        )
        plt.close(figure)


def build_analysis(
    matrices,
    supports,
    n_depth,
    window_size,
    args,
    mode_name,
):
    half = window_size // 2
    metric_rows = []
    overlap_rows = []
    window_meta = []

    for center in range(n_depth):
        start = max(0, center - half)
        stop = min(n_depth, center + half + 1)

        if stop - start < window_size and n_depth >= window_size:
            continue

        normalized_center = (
            center / (n_depth - 1)
            if n_depth > 1
            else 0.0
        )

        window_id = center
        window_meta.append(
            {
                "window_id": window_id,
                "depth_start": start,
                "depth_stop_exclusive": stop,
                "depth_center": center,
                "depth_center_normalized": normalized_center,
                "window_size_actual": stop - start,
                "analysis_mode": mode_name,
            }
        )

        for axis_name in AXES:
            profiles = {}
            profile_supports = {}

            for finger in FINGERS:
                profile, support = combine_depth_window(
                    matrices[axis_name][finger],
                    supports[axis_name][finger],
                    start,
                    stop,
                )
                profiles[finger] = profile
                profile_supports[finger] = support

                metrics = position_metrics(
                    profile,
                    support,
                    args.minimum_position_support,
                )

                metric_rows.append(
                    {
                        "analysis_mode": mode_name,
                        "profile_axis": axis_name,
                        "window_id": window_id,
                        "depth_start": start,
                        "depth_stop_exclusive": stop,
                        "depth_center": center,
                        "depth_center_normalized": normalized_center,
                        "finger": finger,
                        "finger_order": FINGER_ORDER[finger],
                        **metrics,
                    }
                )

            for finger_a, finger_b in ADJACENT_PAIRS:
                overlap, correlation, n_valid = weighted_overlap(
                    profiles[finger_a],
                    profile_supports[finger_a],
                    profiles[finger_b],
                    profile_supports[finger_b],
                    args.minimum_position_support,
                )
                overlap_rows.append(
                    {
                        "analysis_mode": mode_name,
                        "profile_axis": axis_name,
                        "window_id": window_id,
                        "depth_center_normalized": normalized_center,
                        "finger_a": finger_a,
                        "finger_b": finger_b,
                        "finger_pair": f"{finger_a}-{finger_b}",
                        "overlap_coefficient": overlap,
                        "weighted_profile_correlation": correlation,
                        "n_valid_positions": n_valid,
                    }
                )

    finger_metrics = pd.DataFrame(metric_rows)
    overlap = pd.DataFrame(overlap_rows)
    window_meta = pd.DataFrame(window_meta)

    ordering_rows = []

    for axis_name in AXES:
        for window_id in sorted(
            finger_metrics["window_id"].unique()
        ):
            normalized_center = float(
                finger_metrics[
                    finger_metrics["window_id"] == window_id
                ]["depth_center_normalized"].iloc[0]
            )

            for metric_name in (
                "centroid_position",
                "peak_position",
            ):
                ordering_rows.append(
                    evaluate_window(
                        finger_metrics,
                        axis_name,
                        int(window_id),
                        metric_name,
                        args,
                        normalized_center,
                    )
                )

    ordering = pd.DataFrame(ordering_rows)

    return finger_metrics, ordering, overlap, window_meta


def main():
    args = parse_args()

    input_path, output_dir, step10_root, radius_mm = (
        resolve_production_paths(Path(args.config), args.session)
    )
    output_dir.mkdir(parents=True, exist_ok=True)

    if not input_path.is_file():
        raise FileNotFoundError(input_path)

    data = pd.read_csv(input_path)
    validate_input(data)

    n_depth = int(data["depth_bin"].max()) + 1
    if n_depth != 20:
        raise RuntimeError(
            f"Frozen HuberPipeline v1.0 expects 20 depth bins; found {n_depth}."
        )

    matrices = {axis_name: {} for axis_name in AXES}
    supports = {axis_name: {} for axis_name in AXES}

    for axis_name in AXES:
        for finger in FINGERS:
            matrix, support = reconstruct_matrix(
                data,
                axis_name,
                finger,
            )
            matrices[axis_name][finger] = matrix
            supports[axis_name][finger] = support

    (
        single_metrics,
        single_ordering,
        single_overlap,
        single_windows,
    ) = build_analysis(
        matrices,
        supports,
        n_depth,
        1,
        args,
        "single_bin",
    )

    (
        sliding_metrics,
        sliding_ordering,
        sliding_overlap,
        sliding_windows,
    ) = build_analysis(
        matrices,
        supports,
        n_depth,
        args.window_size,
        args,
        f"sliding_{args.window_size}",
    )

    single_metrics.to_csv(
        output_dir / "single_bin_finger_metrics.csv",
        index=False,
    )
    single_ordering.to_csv(
        output_dir / "single_bin_ordering_summary.csv",
        index=False,
    )
    single_overlap.to_csv(
        output_dir / "single_bin_adjacent_overlap.csv",
        index=False,
    )

    support_qc = single_ordering[
        single_ordering["position_metric"] == "centroid_position"
    ].copy()
    support_qc.to_csv(
        output_dir / "single_bin_support_qc.csv",
        index=False,
    )

    sliding_metrics.to_csv(
        output_dir / "sliding_window_finger_metrics.csv",
        index=False,
    )
    sliding_ordering.to_csv(
        output_dir / "sliding_window_ordering_summary.csv",
        index=False,
    )
    sliding_overlap.to_csv(
        output_dir / "sliding_window_adjacent_overlap.csv",
        index=False,
    )

    specificity = add_axis_specificity(sliding_ordering)
    specificity.to_csv(
        output_dir / "sliding_window_axis_specificity.csv",
        index=False,
    )

    descriptive_intervals = summarize_contiguous_intervals(
        sliding_ordering,
        specificity,
        args.minimum_contiguous_bins,
        supported_only=False,
    )
    descriptive_intervals.to_csv(
        output_dir / "descriptive_contiguous_interval_summary.csv",
        index=False,
    )

    intervals = summarize_contiguous_intervals(
        sliding_ordering,
        specificity,
        args.minimum_contiguous_bins,
        supported_only=True,
    )
    # Compatibility contract: downstream Steps 14/15 continue to read this
    # filename, but it now contains only robust supported intervals.
    intervals.to_csv(
        output_dir / "contiguous_interval_summary.csv",
        index=False,
    )

    best_interval = None
    if not intervals.empty:
        best_interval = intervals.iloc[0]

    best_descriptive_interval = None
    if not descriptive_intervals.empty:
        best_descriptive_interval = descriptive_intervals.iloc[0]

    summary_path = output_dir / "robust_laminar_summary.txt"
    with summary_path.open("w", encoding="utf-8") as stream:
        stream.write("Robust continuous laminar somatotopy\n")
        stream.write("====================================\n\n")
        stream.write(
            f"Depth bins available: {n_depth}\n"
        )
        stream.write(
            f"Sliding-window size: {args.window_size}\n"
        )
        stream.write(
            f"Minimum valid positions per finger: "
            f"{args.minimum_valid_positions}\n"
        )
        stream.write(
            f"Minimum profile mass per finger: "
            f"{args.minimum_profile_mass}\n"
        )
        stream.write(
            f"Minimum centroid range: "
            f"{args.minimum_position_range}\n"
        )
        stream.write(
            f"Minimum contiguous windows: "
            f"{args.minimum_contiguous_bins}\n"
        )
        stream.write(
            f"Minimum supported |rho|: {MINIMUM_SUPPORTED_RHO:.2f}\n"
        )
        stream.write(
            "Require positive candidate-axis specificity: YES\n\n"
        )

        single_valid = single_ordering[
            (single_ordering["position_metric"] == "centroid_position")
            & (single_ordering["valid_window"])
        ]
        sliding_valid = sliding_ordering[
            (sliding_ordering["position_metric"] == "centroid_position")
            & (sliding_ordering["valid_window"])
        ]

        stream.write(
            f"Valid single-bin axis estimates: "
            f"{len(single_valid)}\n"
        )
        stream.write(
            f"Valid sliding-window axis estimates: "
            f"{len(sliding_valid)}\n\n"
        )

        if best_descriptive_interval is not None:
            stream.write("Best descriptive valid interval (legacy QC):\n")
            stream.write(
                f"  axis: {best_descriptive_interval['profile_axis']}\n"
            )
            stream.write(
                f"  windows: "
                f"{int(best_descriptive_interval['start_window_id'])}-"
                f"{int(best_descriptive_interval['stop_window_id_exclusive']) - 1}\n"
            )
            stream.write(
                f"  mean best rho: "
                f"{best_descriptive_interval['mean_best_rho']:.6f}\n"
            )
            stream.write(
                f"  minimum best rho: "
                f"{best_descriptive_interval['minimum_best_rho']:.6f}\n\n"
            )

        if best_interval is None:
            stream.write(
                "No supported contiguous interval met all robustness gates.\n"
            )
        else:
            stream.write("Best supported contiguous interval:\n")
            stream.write(
                f"  axis: {best_interval['profile_axis']}\n"
            )
            stream.write(
                f"  start window: "
                f"{int(best_interval['start_window_id'])}\n"
            )
            stream.write(
                f"  stop window exclusive: "
                f"{int(best_interval['stop_window_id_exclusive'])}\n"
            )
            stream.write(
                f"  number of windows: "
                f"{int(best_interval['n_windows'])}\n"
            )
            stream.write(
                f"  normalized depth range: "
                f"{best_interval['depth_start_normalized']:.6f} "
                f"to {best_interval['depth_stop_normalized']:.6f}\n"
            )
            stream.write(
                f"  mean best rho: "
                f"{best_interval['mean_best_rho']:.6f}\n"
            )
            stream.write(
                f"  minimum best rho: "
                f"{best_interval['minimum_best_rho']:.6f}\n"
            )
            stream.write(
                f"  mean best tau: "
                f"{best_interval['mean_best_tau']:.6f}\n"
            )
            stream.write(
                f"  minimum axis specificity: "
                f"{best_interval['minimum_axis_specificity']:.6f}\n"
            )
            stream.write(
                f"  mean axis specificity: "
                f"{best_interval['mean_axis_specificity']:.6f}\n"
            )
            stream.write(
                f"  interval score: "
                f"{best_interval['interval_score']:.6f}\n"
            )

        stream.write(
            "\nInterpretation:\n"
            "- Single-bin results are diagnostics.\n"
            "- Single-bin and unrestricted valid-interval results are "
            "diagnostic/descriptive.\n"
            "- The primary supported interval requires technical validity, "
            f"|rho| >= {MINIMUM_SUPPORTED_RHO:.2f}, positive axis "
            "specificity, and >=3 consecutive windows.\n"
            "- Thresholds are frozen before cohort-scale analysis and are "
            "not optimized per subject.\n"
        )

    # Read the descriptive reference decisions without altering them.
    step11_path = step10_root / "somatotopy_qc" / "step11_summary.json"
    step12_path = (
        step10_root / "depth_resolved_somatotopy" / "step12_summary.json"
    )
    step11_axis = None
    step11_direction = None
    step12_best = None

    if step11_path.is_file():
        with step11_path.open("r", encoding="utf-8") as stream:
            step11 = json.load(stream)
        step11_axis = step11.get("recommended_somatotopic_axis")
        if step11_axis in AXES:
            step11_direction = (
                step11.get("axes", {})
                .get(step11_axis, {})
                .get("direction")
            )

    if step12_path.is_file():
        with step12_path.open("r", encoding="utf-8") as stream:
            step12 = json.load(stream)
        step12_best = step12.get("best_descriptive_axis_depth_band")

    single_valid = single_ordering[
        (single_ordering["position_metric"] == "centroid_position")
        & (single_ordering["valid_window"])
    ]
    sliding_valid = sliding_ordering[
        (sliding_ordering["position_metric"] == "centroid_position")
        & (sliding_ordering["valid_window"])
    ]

    summary = {
        "status": "PASS",
        "session": args.session,
        "radius_mm": radius_mm,
        "input_csv": str(input_path),
        "n_depth_bins": n_depth,
        "primary_metric": "dominance_fraction",
        "window_size": args.window_size,
        "minimum_position_support": args.minimum_position_support,
        "minimum_valid_positions": args.minimum_valid_positions,
        "minimum_profile_mass": args.minimum_profile_mass,
        "minimum_position_range": args.minimum_position_range,
        "minimum_contiguous_windows": args.minimum_contiguous_bins,
        "minimum_supported_abs_spearman_rho": MINIMUM_SUPPORTED_RHO,
        "require_positive_axis_specificity": REQUIRE_POSITIVE_AXIS_SPECIFICITY,
        "valid_single_bin_axis_estimates": int(len(single_valid)),
        "valid_sliding_window_axis_estimates": int(len(sliding_valid)),
        "step11_recommended_axis": step11_axis,
        "step11_numerical_direction": step11_direction,
        "step12_best_descriptive_band": step12_best,
        "best_descriptive_valid_interval": (
            None
            if best_descriptive_interval is None
            else {
                "axis": str(best_descriptive_interval["profile_axis"]),
                "start_window_id": int(
                    best_descriptive_interval["start_window_id"]
                ),
                "stop_window_id_exclusive": int(
                    best_descriptive_interval["stop_window_id_exclusive"]
                ),
                "n_windows": int(best_descriptive_interval["n_windows"]),
                "depth_start_normalized": float(
                    best_descriptive_interval["depth_start_normalized"]
                ),
                "depth_stop_normalized": float(
                    best_descriptive_interval["depth_stop_normalized"]
                ),
                "mean_best_rho": float(
                    best_descriptive_interval["mean_best_rho"]
                ),
                "minimum_best_rho": float(
                    best_descriptive_interval["minimum_best_rho"]
                ),
            }
        ),
        "best_supported_contiguous_interval": (
            None
            if best_interval is None
            else {
                "axis": str(best_interval["profile_axis"]),
                "start_window_id": int(
                    best_interval["start_window_id"]
                ),
                "stop_window_id_exclusive": int(
                    best_interval["stop_window_id_exclusive"]
                ),
                "n_windows": int(best_interval["n_windows"]),
                "depth_start_normalized": float(
                    best_interval["depth_start_normalized"]
                ),
                "depth_stop_normalized": float(
                    best_interval["depth_stop_normalized"]
                ),
                "mean_best_rho": float(
                    best_interval["mean_best_rho"]
                ),
                "minimum_best_rho": float(
                    best_interval["minimum_best_rho"]
                ),
                "mean_best_tau": float(
                    best_interval["mean_best_tau"]
                ),
                "minimum_axis_specificity": float(
                    best_interval["minimum_axis_specificity"]
                ),
                "mean_axis_specificity": float(
                    best_interval["mean_axis_specificity"]
                ),
                "interval_score": float(
                    best_interval["interval_score"]
                ),
            }
        ),
        "coordinate_geometry_modified": False,
        "axis_flipped_on_disk": False,
        "functional_feedback_to_uv_construction": False,
        "voronoi_used_quantitatively": False,
    }

    with (
        output_dir / "step13_summary.json"
    ).open("w", encoding="utf-8") as stream:
        json.dump(summary, stream, indent=2)

    if not args.no_figures:
        create_figures(
            output_dir,
            single_ordering,
            sliding_ordering,
            specificity,
            support_qc,
        )

    print("HuberPipeline Step 13 completed successfully.")
    print()

    single_valid_count = int(
        np.count_nonzero(
            (single_ordering["position_metric"] == "centroid_position")
            & single_ordering["valid_window"]
        )
    )
    sliding_valid_count = int(
        np.count_nonzero(
            (sliding_ordering["position_metric"] == "centroid_position")
            & sliding_ordering["valid_window"]
        )
    )

    print(
        f"Valid single-bin axis estimates: {single_valid_count}"
    )
    print(
        f"Valid sliding-window axis estimates: "
        f"{sliding_valid_count}"
    )

    if best_descriptive_interval is not None:
        print(
            "Best descriptive valid interval: "
            f"{best_descriptive_interval['profile_axis']} / windows "
            f"{int(best_descriptive_interval['start_window_id'])}-"
            f"{int(best_descriptive_interval['stop_window_id_exclusive']) - 1}; "
            f"mean rho={best_descriptive_interval['mean_best_rho']:.4f}; "
            f"minimum rho={best_descriptive_interval['minimum_best_rho']:.4f}"
        )

    if best_interval is None:
        print(
            "Best supported contiguous interval: NONE"
        )
    else:
        print(
            "Best supported contiguous interval: "
            f"{best_interval['profile_axis']} / "
            f"windows "
            f"{int(best_interval['start_window_id'])}-"
            f"{int(best_interval['stop_window_id_exclusive']) - 1}; "
            f"mean rho={best_interval['mean_best_rho']:.4f}; "
            f"minimum rho={best_interval['minimum_best_rho']:.4f}; "
            f"minimum specificity="
            f"{best_interval['minimum_axis_specificity']:.4f}"
        )

    if step11_axis:
        print(
            f"Step-11 recommended somatotopic axis: {step11_axis}"
        )
    print(f"Output directory: {output_dir}")
    print(
        "Primary analysis: supported three-bin sliding-window intervals "
        "(valid support + |rho|>=0.4 + positive axis specificity)"
    )
    print("Coordinate geometry modified: NO")
    print("Axis flipped on disk: NO")
    print("Functional feedback to UV construction: NO")
    print("Voronoi used quantitatively: NO")
    print("Step 13 validation: PASS")


if __name__ == "__main__":
    try:
        main()
    except (
        FileNotFoundError,
        RuntimeError,
        TypeError,
        ValueError,
    ) as exc:
        sys.exit(f"ERROR: {exc}")
