#!/usr/bin/env python3
"""
Stage 2 — convert surface labels to volumetric masks in FreeSurfer fsnative space.

IMPORTANT HPC ENVIRONMENT RULE
------------------------------
The parent Python process must remain in the clean ROI venv because loading
FreeSurfer/ANTs into that shell can contaminate Python and break NumPy.

Therefore every FreeSurfer command is executed in an isolated bash subprocess:

    module purge
    module load FreeSurfer/7.4.1-centos8_x86_64
    export SUBJECTS_DIR=...
    mri_label2vol ...

The parent Python environment is not modified.
"""
from __future__ import annotations

import argparse
import shlex
import subprocess

from common import (
    DEFAULT_OUT_ROOT,
    ROI_TO_LABEL_BASENAME,
    paths,
    read_unit,
)

FREESURFER_MODULE = "FreeSurfer/7.4.1-centos8_x86_64"


def q(x):
    return shlex.quote(str(x))


def run_freesurfer(command: str, subjects_dir):
    script = f"""
set -euo pipefail
module purge
module load {shlex.quote(FREESURFER_MODULE)}
export SUBJECTS_DIR={q(subjects_dir)}
{command}
"""
    print("\n[isolated FreeSurfer subprocess]")
    print(command)
    subprocess.run(["bash", "-lc", script], check=True)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--manifest", required=True)
    ap.add_argument("--subject", required=True)
    ap.add_argument("--session")
    ap.add_argument("--out-root", default=str(DEFAULT_OUT_ROOT))
    a = ap.parse_args()

    u = read_unit(a.manifest, a.subject, a.session)
    p = paths(u, a.out_root)
    p["fsnative_rois"].mkdir(parents=True, exist_ok=True)

    print("[STAGE 2] Surface labels -> fsnative anatomical masks")
    print(f"  template: {p['orig']}")
    print("  registration: identity (same subject anatomical space)")
    print(f"  FreeSurfer module: {FREESURFER_MODULE}")

    subjects_dir = p["fs"].parent

    for roi, label_basename in ROI_TO_LABEL_BASENAME.items():
        label = (
            p["surface_labels"]
            / f"{u.hemisphere}.{label_basename}_handknob.label"
        )
        if not label.exists():
            raise FileNotFoundError(label)

        out = (
            p["fsnative_rois"]
            / f"{u.hemisphere}_{roi}_handknob_mask.nii.gz"
        )

        command = " ".join([
            "mri_label2vol",
            "--label", q(label),
            "--temp", q(p["orig"]),
            "--identity",
            "--subject", q(u.freesurfer_subject),
            "--hemi", q(u.hemisphere),
            "--proj", "frac", "0", "1", "0.1",
            "--fillthresh", "0.25",
            "--o", q(out),
        ])

        run_freesurfer(command, subjects_dir)

        if not out.exists():
            raise RuntimeError(f"mri_label2vol did not create expected output: {out}")

        print(f"  [fsnative ROI] {out}")

    print(f"\n[STAGE 2] COMPLETE -> {p['fsnative_rois']}")


if __name__ == "__main__":
    main()
