#!/usr/bin/env python3
"""
Stage 1 — build hand-knob-restricted surface labels.

Exact ROI definition:
  center = lh.white[participant-specific hand_knob_vertex]
  retain BA-label vertices whose Euclidean 3-D distance on lh.white coordinates
  is <= radius_mm (20 mm by default).

M1 = restricted BA4a union restricted BA4p
S1 = restricted BA3a union restricted BA3b union restricted BA1 union restricted BA2
"""
from __future__ import annotations

import argparse
from pathlib import Path

import nibabel as nib
import numpy as np

from common import (
    BA_LABELS,
    DEFAULT_OUT_ROOT,
    UNIONS,
    paths,
    read_unit,
)


def write_label(path: Path, label_vertices, vertices):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w") as f:
        f.write("#!ascii label\n")
        f.write(f"{len(label_vertices)}\n")
        for v in label_vertices:
            v = int(v)
            x, y, z = vertices[v]
            f.write(f"{v} {x:.3f} {y:.3f} {z:.3f} 0.000\n")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--manifest", required=True)
    ap.add_argument("--subject", required=True)
    ap.add_argument("--session")
    ap.add_argument("--out-root", default=str(DEFAULT_OUT_ROOT))
    a = ap.parse_args()

    u = read_unit(a.manifest, a.subject, a.session)
    p = paths(u, a.out_root)

    if u.hemisphere != "lh":
        raise ValueError("Current MUGEN Finger ROI definition is left hemisphere only.")

    vertices, _ = nib.freesurfer.read_geometry(str(p["white"]))

    if not (0 <= u.hand_knob_vertex < len(vertices)):
        raise IndexError(
            f"hand_knob_vertex={u.hand_knob_vertex} outside "
            f"0..{len(vertices)-1}"
        )

    center = vertices[u.hand_knob_vertex]
    p["surface_labels"].mkdir(parents=True, exist_ok=True)

    print("[STAGE 1] Surface hand-knob restriction")
    print(f"  subject/session : {u.subject}/{u.session}")
    print(f"  hand-knob vertex: {u.hand_knob_vertex}")
    print(
        f"  hand-knob xyz   : "
        f"{center[0]:.3f}, {center[1]:.3f}, {center[2]:.3f}"
    )
    print(f"  radius          : {u.radius_mm:.1f} mm")

    restricted = {}

    for roi_name, ba in BA_LABELS.items():
        src = p["fs"] / "label" / f"{u.hemisphere}.{ba}_exvivo.thresh.label"
        label_vertices = nib.freesurfer.read_label(str(src))

        distances = np.linalg.norm(
            vertices[label_vertices] - center,
            axis=1,
        )
        mask = distances <= u.radius_mm
        rv = label_vertices[mask]  # preserve individual BA label order exactly
        restricted[roi_name] = rv

        out = p["surface_labels"] / f"{u.hemisphere}.{ba}_handknob.label"
        write_label(out, rv, vertices)
        print(f"  {ba}: {len(label_vertices)} -> {len(rv)} vertices")

    for union_name, components in UNIONS.items():
        uv = np.unique(np.concatenate([restricted[x] for x in components]))
        out = p["surface_labels"] / f"{u.hemisphere}.{union_name}_handknob.label"
        write_label(out, uv, vertices)
        print(f"  {union_name} union: {len(uv)} vertices")

    print(f"[STAGE 1] COMPLETE -> {p['surface_labels']}")


if __name__ == "__main__":
    main()
