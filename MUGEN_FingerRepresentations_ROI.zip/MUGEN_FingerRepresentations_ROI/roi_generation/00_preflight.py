#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
from pathlib import Path

import nibabel as nib
import numpy as np

from common import BA_LABELS, DEFAULT_OUT_ROOT, paths, read_unit

def json_default(obj):
    """Convert NumPy/path objects to JSON-safe native Python types."""
    if isinstance(obj, np.integer):
        return int(obj)
    if isinstance(obj, np.floating):
        return float(obj)
    if isinstance(obj, np.ndarray):
        return obj.tolist()
    if isinstance(obj, Path):
        return str(obj)
    raise TypeError(
        f"Object of type {obj.__class__.__name__} is not JSON serializable"
    )

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--manifest", required=True)
    ap.add_argument("--subject", required=True)
    ap.add_argument("--session")
    ap.add_argument("--out-root", default=str(DEFAULT_OUT_ROOT))
    ap.add_argument("--report")
    a = ap.parse_args()

    u = read_unit(a.manifest, a.subject, a.session)
    p = paths(u, a.out_root)

    required = {
        "orig": p["orig"],
        "white": p["white"],
        "pial": p["pial"],
        "beta": p["beta"],
        "fsnative_to_t1w_xfm": p["xfm"],
    }
    for name, path in required.items():
        if not path.exists():
            raise FileNotFoundError(f"{name}: {path}")

    for ba in BA_LABELS.values():
        q = p["fs"] / "label" / f"{u.hemisphere}.{ba}_exvivo.thresh.label"
        if not q.exists():
            raise FileNotFoundError(q)

    beta = nib.load(str(p["beta"]))
    orig = nib.load(str(p["orig"]))

    rep = {
        "status": "PASS",
        "subject": u.subject,
        "session": u.session,
        "hand_knob_vertex": u.hand_knob_vertex,
        "radius_mm": u.radius_mm,
        "freesurfer_subject": u.freesurfer_subject,
        "orig": str(p["orig"]),
        "orig_shape": list(orig.shape),
        "beta": str(p["beta"]),
        "beta_shape": list(beta.shape),
        "fsnative_to_t1w_xfm": str(p["xfm"]),
        "output_root": str(a.out_root),
        "strategy": (
            "surface labels -> fsnative anatomical masks -> "
            "antsApplyTransforms fsnative-to-T1w -> beta grid"
        ),
        "environment_note": (
            "FreeSurfer and ANTs are loaded only inside isolated subprocesses; "
            "the parent Python environment must remain clean."
        ),
    }

    if a.report:
        report = Path(a.report)
        report.parent.mkdir(parents=True, exist_ok=True)
        report.write_text(
                json.dumps(rep, indent=2, default=json_default)
        )

    print("[PREFLIGHT] PASS")
    print(f"  subject/session: {u.subject}/{u.session}")
    print(f"  hand-knob vertex: {u.hand_knob_vertex}")
    print(f"  orig (fsnative): {p['orig']}")
    print(f"  beta (T1w): {p['beta']}")
    print(f"  fsnative->T1w: {p['xfm']}")
    print(f"  output root: {a.out_root}")
    print("  external modules: isolated inside Stages 2 and 3")


if __name__ == "__main__":
    main()
