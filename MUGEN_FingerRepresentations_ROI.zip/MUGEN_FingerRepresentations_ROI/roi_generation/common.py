from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import csv
import shutil

WORKSPACE = Path("/mnt/beegfs/workspace/2025-0422-Musicians7T")

FS_ROOT = WORKSPACE / "MUGEN_data/finger/derivatives/freesurfer"
FMRIPREP_ROOT = WORKSPACE / "MUGEN_data/finger/derivatives/fmriprep"
FIRST_LEVEL_ROOT = WORKSPACE / "MUGEN_data/finger/derivatives/first_level"

# Keep the ROI output location used by the current/validated ROI workflow.
DEFAULT_OUT_ROOT = (
    WORKSPACE
    / "MUGEN_data"
    / "finger"
    / "derivatives"
    / "rois"
)

BA_LABELS = {
    "M1_4a": "BA4a",
    "M1_4p": "BA4p",
    "S1_3a": "BA3a",
    "S1_3b": "BA3b",
    "S1_1": "BA1",
    "S1_2": "BA2",
}

UNIONS = {
    "M1": ["M1_4a", "M1_4p"],
    "S1": ["S1_3a", "S1_3b", "S1_1", "S1_2"],
}

ROI_TO_LABEL_BASENAME = {
    "M1": "M1",
    "M1_4a": "BA4a",
    "M1_4p": "BA4p",
    "S1": "S1",
    "S1_3a": "BA3a",
    "S1_3b": "BA3b",
    "S1_1": "BA1",
    "S1_2": "BA2",
}

ROI_NAMES = tuple(ROI_TO_LABEL_BASENAME)


@dataclass
class Unit:
    subject: str
    session: str
    hand_knob_vertex: int
    hemisphere: str
    radius_mm: float
    freesurfer_subject: str
    fsnative_to_t1w_xfm: str | None = None
    beta_reference: str | None = None


def norm_subject(s: str) -> str:
    s = str(s).strip()
    if s.startswith("sub-"):
        return s
    if s.startswith("sub"):
        s = s[3:].lstrip("-")
    return f"sub-{s}"


def norm_session(s: str) -> str:
    s = str(s).strip()
    if s.startswith("ses-"):
        return s
    if s.startswith("ses"):
        s = s[3:].lstrip("-")
    return f"ses-{s}"


def read_unit(manifest, subject, session=None) -> Unit:
    subject = norm_subject(subject)
    if session is not None:
        session = norm_session(session)

    with open(manifest, newline="") as f:
        rows = list(csv.DictReader(f))

    matches = []
    for row in rows:
        row_subject = norm_subject(row["subject"])
        row_session = norm_session(row["session"])
        if row_subject != subject:
            continue
        if session is not None and row_session != session:
            continue
        matches.append(row)

    if len(matches) != 1:
        raise ValueError(
            f"Expected exactly one manifest row for "
            f"{subject}/{session or '*'}, found {len(matches)}"
        )

    row = matches[0]
    ses = norm_session(row["session"])

    return Unit(
        subject=subject,
        session=ses,
        hand_knob_vertex=int(row["hand_knob_vertex"]),
        hemisphere=(row.get("hemisphere") or "lh").strip(),
        radius_mm=float(row.get("radius_mm") or 20),
        freesurfer_subject=(
            row.get("freesurfer_subject") or f"{subject}_{ses}"
        ).strip(),
        fsnative_to_t1w_xfm=(
            (row.get("fsnative_to_t1w_xfm") or "").strip() or None
        ),
        beta_reference=(
            (row.get("beta_reference") or "").strip() or None
        ),
    )


def paths(u: Unit, out_root):
    fs = FS_ROOT / u.freesurfer_subject

    beta = (
        Path(u.beta_reference)
        if u.beta_reference
        else FIRST_LEVEL_ROOT
        / u.subject
        / u.session
        / "output"
        / "run1-6"
        / "beta_0001.nii"
    )

    xfm = (
        Path(u.fsnative_to_t1w_xfm)
        if u.fsnative_to_t1w_xfm
        else FMRIPREP_ROOT
        / u.subject
        / u.session
        / "anat"
        / f"{u.subject}_{u.session}_from-fsnative_to-T1w_mode-image_xfm.txt"
    )

    base = Path(out_root) / u.subject / u.session

    return {
        "fs": fs,
        "orig": fs / "mri" / "orig.mgz",
        "white": fs / "surf" / f"{u.hemisphere}.white",
        "pial": fs / "surf" / f"{u.hemisphere}.pial",
        "beta": beta,
        "xfm": xfm,
        "base": base,
        "surface_labels": base / "surface_labels",
        "fsnative_rois": base / "fsnative_rois",
        "rois": base / "rois",
    }


def require_program(name: str) -> None:
    if shutil.which(name) is None:
        raise RuntimeError(f"Required program not on PATH: {name}")
