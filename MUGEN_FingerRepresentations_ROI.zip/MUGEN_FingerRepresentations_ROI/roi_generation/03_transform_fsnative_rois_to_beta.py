#!/usr/bin/env python3
"""
Stage 3 — transform fsnative anatomical ROI masks to the beta/T1w grid.

This reproduces the validated Subject 01 transformation:

    antsApplyTransforms
      -d 3
      -i <fsnative anatomical ROI>
      -r <beta_0001.nii>
      -t <from-fsnative_to-T1w_mode-image_xfm.txt>
      -n NearestNeighbor
      -o <final ROI>

IMPORTANT HPC ENVIRONMENT RULE
------------------------------
ANTs is loaded only inside an isolated bash subprocess. The parent Python
process stays in the clean ROI venv.
"""
from __future__ import annotations

import argparse
import shlex
import subprocess

from common import (
    DEFAULT_OUT_ROOT,
    ROI_NAMES,
    paths,
    read_unit,
)

ANTS_MODULE = "ANTs/2.5.0-foss-2022b"


def q(x):
    return shlex.quote(str(x))


def run_ants(command: str):
    script = f"""
set -euo pipefail
module purge
module load {shlex.quote(ANTS_MODULE)}
{command}
"""
    print("\n[isolated ANTs subprocess]")
    print(command)
    subprocess.run(["bash", "-lc", script], check=True)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--manifest", required=True)
    ap.add_argument("--subject", required=True)
    ap.add_argument("--session")
    ap.add_argument("--out-root", default=str(DEFAULT_OUT_ROOT))
    a = ap.parse_args()

    u = read_unit(a.manifest, a.subject, a.session)
    p = paths(u, a.out_root)
    p["rois"].mkdir(parents=True, exist_ok=True)

    print("[STAGE 3] fsnative anatomical masks -> beta/T1w grid")
    print(f"  reference beta : {p['beta']}")
    print(f"  transform      : {p['xfm']}")
    print("  interpolation  : NearestNeighbor")
    print("  BOLD->T1w      : NOT applied")
    print(f"  ANTs module    : {ANTS_MODULE}")

    for roi in ROI_NAMES:
        src = (
            p["fsnative_rois"]
            / f"{u.hemisphere}_{roi}_handknob_mask.nii.gz"
        )
        if not src.exists():
            raise FileNotFoundError(src)

        out = (
            p["rois"]
            / f"{u.subject}_{u.session}_roi-{roi}_space-beta.nii.gz"
        )

        command = " ".join([
            "antsApplyTransforms",
            "-d", "3",
            "-i", q(src),
            "-r", q(p["beta"]),
            "-t", q(p["xfm"]),
            "-n", "NearestNeighbor",
            "-o", q(out),
        ])

        run_ants(command)

        if not out.exists():
            raise RuntimeError(f"antsApplyTransforms did not create expected output: {out}")

        print(f"  [beta-space ROI] {out}")

    print(f"\n[STAGE 3] COMPLETE -> {p['rois']}")


if __name__ == "__main__":
    main()
