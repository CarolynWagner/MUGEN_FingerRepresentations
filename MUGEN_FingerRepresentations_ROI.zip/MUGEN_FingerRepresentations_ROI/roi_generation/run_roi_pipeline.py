#!/usr/bin/env python3
from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path

from common import DEFAULT_OUT_ROOT

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent

VERSION = "MUGEN_FR_ROI_CORRECTED_ISOLATED_MODULES_2026-09-03"


def run(cmd):
    print("\n" + "=" * 80)
    print(" ".join(map(str, cmd)))
    print("=" * 80 + "\n")
    subprocess.run(list(map(str, cmd)), check=True)


def main():
    ap = argparse.ArgumentParser(
        description=(
            "MUGEN Finger ROI pipeline: hand-knob surface ROIs -> "
            "fsnative anatomical masks -> ANTs fsnative-to-T1w -> beta grid. "
            "FreeSurfer and ANTs run in isolated module subprocesses."
        )
    )
    ap.add_argument("--subject")
    ap.add_argument("--session")
    ap.add_argument(
        "--manifest",
        default=str(ROOT / "participants.csv"),
    )
    ap.add_argument(
        "--out-root",
        default=str(DEFAULT_OUT_ROOT),
    )
    ap.add_argument("--version", action="store_true")
    ap.add_argument(
        "--skip-stage1",
        action="store_true",
        help="Reuse already verified surface labels.",
    )
    a = ap.parse_args()

    if a.version:
        print(VERSION)
        return

    if not a.subject:
        ap.error("--subject is required")

    common = [
        "--manifest", a.manifest,
        "--subject", a.subject,
    ]
    if a.session:
        common += ["--session", a.session]
    common += ["--out-root", a.out_root]

    py = sys.executable
    tag = f"{a.subject}_{a.session or 'auto'}"

    print(f"[PIPELINE] Python interpreter: {py}")
    print("[PIPELINE] Parent environment must NOT have FreeSurfer/ANTs loaded.")
    print("[PIPELINE] External modules are loaded only inside isolated subprocesses.")

    run([
        py,
        HERE / "00_preflight.py",
        *common,
        "--report",
        Path(a.out_root) / f"preflight_{tag}.json",
    ])

    if not a.skip_stage1:
        run([py, HERE / "01_build_hand_labels.py", *common])

    run([py, HERE / "02_labels_to_fsnative_volumes.py", *common])
    run([py, HERE / "03_transform_fsnative_rois_to_beta.py", *common])

    run([
        py,
        HERE / "04_roi_qc.py",
        *common,
        "--report",
        Path(a.out_root) / f"roi_qc_{tag}.json",
    ])

    print(f"\n[{VERSION}] COMPLETE")


if __name__ == "__main__":
    main()
