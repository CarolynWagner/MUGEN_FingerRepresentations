#!/usr/bin/env python3
"""
Stage 4 — computational QC.

Checks both the fsnative intermediate mask and the final beta/T1w mask.
This does not replace visual anatomical inspection in Freeview.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import nibabel as nib
import numpy as np

from common import DEFAULT_OUT_ROOT, ROI_NAMES, paths, read_unit


def is_binary(data):
    vals = np.unique(data[np.isfinite(data)])
    return bool(np.all(np.isin(vals, [0, 1])))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--manifest", required=True)
    ap.add_argument("--subject", required=True)
    ap.add_argument("--session")
    ap.add_argument("--out-root", default=str(DEFAULT_OUT_ROOT))
    ap.add_argument("--report")
    a = ap.parse_args()

    u = read_unit(a.manifest, a.subject, a.session)
    p = paths(u, a.out_root)

    beta = nib.load(str(p["beta"]))
    beta_data = beta.get_fdata()
    orig = nib.load(str(p["orig"]))

    rows = []
    bad = []

    for roi in ROI_NAMES:
        fs_file = (
            p["fsnative_rois"]
            / f"{u.hemisphere}_{roi}_handknob_mask.nii.gz"
        )
        final_file = (
            p["rois"]
            / f"{u.subject}_{u.session}_roi-{roi}_space-beta.nii.gz"
        )

        if not fs_file.exists():
            raise FileNotFoundError(fs_file)
        if not final_file.exists():
            raise FileNotFoundError(final_file)

        fs_img = nib.load(str(fs_file))
        fs_data = fs_img.get_fdata()

        out_img = nib.load(str(final_file))
        out_data = out_img.get_fdata()

        row = {
            "roi": roi,
            "fsnative_voxels": int(np.count_nonzero(fs_data > 0)),
            "fsnative_same_shape_orig": fs_img.shape == orig.shape,
            "fsnative_same_affine_orig": bool(
                np.allclose(fs_img.affine, orig.affine, atol=1e-4)
            ),
            "fsnative_binary": is_binary(fs_data),
            "final_voxels": int(np.count_nonzero(out_data > 0)),
            "final_finite_beta_voxels": int(
                np.count_nonzero((out_data > 0) & np.isfinite(beta_data))
            ),
            "final_same_shape_beta": out_img.shape == beta.shape,
            "final_same_affine_beta": bool(
                np.allclose(out_img.affine, beta.affine, atol=1e-4)
            ),
            "final_binary": is_binary(out_data),
        }

        rows.append(row)
        print(row)

        passed = (
            row["fsnative_voxels"] > 0
            and row["fsnative_same_shape_orig"]
            and row["fsnative_same_affine_orig"]
            and row["fsnative_binary"]
            and row["final_voxels"] > 0
            and row["final_same_shape_beta"]
            and row["final_same_affine_beta"]
            and row["final_binary"]
        )
        if not passed:
            bad.append(row)

    if a.report:
        report = Path(a.report)
        report.parent.mkdir(parents=True, exist_ok=True)
        report.write_text(json.dumps(rows, indent=2))

    if bad:
        raise RuntimeError(
            "QC failed for one or more ROIs. "
            "Inspect the report and do not use the masks for RSA."
        )

    print(
        "[ROI QC] PASS — computational geometry/binary checks. "
        "Visual anatomical inspection is still required."
    )


if __name__ == "__main__":
    main()
