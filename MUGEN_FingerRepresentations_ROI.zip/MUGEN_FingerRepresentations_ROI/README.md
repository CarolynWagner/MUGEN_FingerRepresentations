# MUGEN Finger Representations — corrected isolated-module ROI pipeline

Version: `MUGEN_FR_ROI_CORRECTED_ISOLATED_MODULES_2026-09-03`

## Why this version exists

On the CN2 HPC, the ROI Python 3.12 venv works correctly by itself:

- NumPy 2.5.2
- nibabel 5.4.2

but loading the FreeSurfer/ANTs modules into the same shell contaminates the
runtime and can make Python/NumPy fail with `Illegal instruction`.

This version therefore keeps the parent Python environment clean.

- Stages 0, 1 and 4 run with the ROI Python venv.
- Stage 2 launches FreeSurfer in its own isolated `bash -lc` subprocess.
- Stage 3 launches ANTs in its own isolated `bash -lc` subprocess.
- `module purge` inside those subprocesses does not modify the parent Python
  environment.

## Spatial workflow

1. Hand-knob-restricted BA labels on `lh.white`.
2. M1/S1 unions.
3. `mri_label2vol --identity` to `orig.mgz` geometry: fsnative anatomical ROI.
4. `antsApplyTransforms` with fMRIPrep `fsnative->T1w`.
5. `beta_0001.nii` used as reference.
6. Nearest-neighbour interpolation.
7. Computational QC + visual QC.

No `register.dat`, `lta_convert`, `bbregister`, or BOLD->T1w reapplication.

## Correct shell setup

Do NOT load FreeSurfer or ANTs manually.

```bash
module purge

source /mnt/beegfs/workspace/2025-0422-Musicians7T/SPM_Prepro_FirstLevel/ROIs/ROI_pipeline/.venv/bin/activate

unset PYTHONPATH
unset PYTHONHOME

python -c "import numpy, nibabel; print(numpy.__version__, nibabel.__version__)"
```

Expected currently:

```text
2.5.2 5.4.2
```

Then run:

```bash
python roi_generation/run_roi_pipeline.py \
  --subject sub-11 \
  --session ses-01
```

The pipeline itself loads:

- `FreeSurfer/7.4.1-centos8_x86_64` only inside Stage 2 subprocesses.
- `ANTs/2.5.0-foss-2022b` only inside Stage 3 subprocesses.

## Output root

`/mnt/beegfs/workspace/2025-0422-Musicians7T/MUGEN_data/finger/derviatives/rois`

## Current participant

`sub-11/ses-01` uses corrected hand-knob vertex `49110`.
