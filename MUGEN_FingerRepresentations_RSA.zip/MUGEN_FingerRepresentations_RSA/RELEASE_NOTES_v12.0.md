# Release notes — v12.0 migration scaffold

- Portable pipeline root (`Path(__file__)`) rather than hard-coded RSA v11 path.
- Canonical MUGEN/BIDS subject and session normalization.
- MUGEN derivatives output contract.
- Automatic manifest builder.
- Explicit `beta_lookup.tsv` contract.
- Production preflight.
- Legacy v10.3/v11 regression tests isolated under validation.
- Huber/U-V scripts removed from the production branch.
- Byte-for-byte certified-v11-core installer with SHA256 audit.
- No scientific numerical-core changes are introduced by this scaffold.
