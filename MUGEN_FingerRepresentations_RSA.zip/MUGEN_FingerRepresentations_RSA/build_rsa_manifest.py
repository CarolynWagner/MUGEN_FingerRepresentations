#!/usr/bin/env python3
"""
Build the MUGEN Finger RSA participant manifest from the corrected ROI pipeline.

This replaces the v12 auto-discovery requirement for beta_lookup.tsv / ROI
"contracts".  It uses the ROI pipeline's own participants.csv as the source of
truth for subject/session anatomy (including the manually corrected hand-knob
vertex), and writes one RSA manifest row per ROI.

Default ROI output root matches the supplied corrected ROI pipeline:
    /mnt/beegfs/workspace/2025-0422-Musicians7T/
    SPM_Prepro_FirstLevel/ROIs/RSApipeline_general_v11/
    roi_derivatives_final_t1w

Example
-------
python build_rsa_manifest.py \
    --mugen-root /mnt/beegfs/workspace/2025-0422-Musicians7T/MUGEN_data \
    --subject 11

Optional:
    --session 01
    --roi-participants /mnt/beegfs/workspace/2025-0422-Musicians7T/MUGEN_FR_ROI/participants.csv
    --output /mnt/beegfs/workspace/2025-0422-Musicians7T/MUGEN_data/finger/derivatives/rsa/manifests/participants.csv
"""

from __future__ import annotations

import argparse
import csv
from pathlib import Path


DEFAULT_WORKSPACE = Path("/mnt/beegfs/workspace/2025-0422-Musicians7T")

DEFAULT_ROI_ROOT = (
    DEFAULT_WORKSPACE
    / "SPM_Prepro_FirstLevel"
    / "ROIs"
    / "RSApipeline_general_v11"
    / "roi_derivatives_final_t1w"
)

DEFAULT_ROI_PARTICIPANTS = (
    DEFAULT_WORKSPACE
    / "MUGEN_FR_ROI"
    / "participants.csv"
)

ROI_SPECS = (
    ("M1", "M1", "whole"),
    ("M1", "M1_4a", "BA4a"),
    ("M1", "M1_4p", "BA4p"),
    ("S1", "S1", "composite"),
    ("S1", "S1_3a", "BA3a"),
    ("S1", "S1_3b", "BA3b"),
    ("S1", "S1_1", "BA1"),
    ("S1", "S1_2", "BA2"),
)

FIELDS = (
    "subject",
    "session",
    "roi_family",
    "roi_name",
    "roi_version",
    "hemisphere",
    "resolution_mm",
    "model_dir",
    "roi_path",
    "subjects_dir",
    "surface_path",
    "surface",
    "hand_knob_vertex",
    "radius_mm",
    "mean_epi_reference",
    "beta_reference",
    "xfm_chain",
)


def norm_subject(value: str) -> str:
    value = str(value).strip()
    if value.startswith("sub-"):
        return value
    if value.startswith("sub"):
        value = value[3:].lstrip("-")
    return f"sub-{value}"


def norm_session(value: str) -> str:
    value = str(value).strip()
    if value.startswith("ses-"):
        return value
    if value.startswith("ses"):
        value = value[3:].lstrip("-")
    return f"ses-{value}"


def read_roi_participants(path: Path):
    if not path.exists():
        raise FileNotFoundError(
            "Corrected ROI participant manifest not found:\n"
            f"  {path}\n\n"
            "Pass it explicitly with --roi-participants."
        )

    with path.open(newline="") as f:
        reader = csv.DictReader(f)
        required = {
            "subject",
            "session",
            "hand_knob_vertex",
            "hemisphere",
            "radius_mm",
            "freesurfer_subject",
        }
        missing = required.difference(reader.fieldnames or [])
        if missing:
            raise ValueError(
                f"{path} is missing required ROI fields: "
                + ", ".join(sorted(missing))
            )
        return list(reader)


def infer_resolution_mm(beta: Path) -> str:
    """
    Read the beta voxel size if nibabel is available.
    Fall back to 1.5 for the current MUGEN Finger acquisition.
    """
    try:
        import nibabel as nib
        img = nib.load(str(beta))
        zooms = img.header.get_zooms()[:3]
        if max(zooms) - min(zooms) < 0.02:
            value = float(sum(zooms) / 3.0)
            return f"{value:.3f}".rstrip("0").rstrip(".")
    except Exception:
        pass
    return "1.5"


def main() -> None:
    p = argparse.ArgumentParser(
        description="Build RSA participants.csv from the corrected MUGEN Finger ROI pipeline."
    )
    p.add_argument(
        "--mugen-root",
        required=True,
        help="e.g. /mnt/beegfs/workspace/2025-0422-Musicians7T/MUGEN_data",
    )
    p.add_argument(
        "--subject",
        help="optional subject selector, e.g. 11 or sub-11",
    )
    p.add_argument(
        "--session",
        help="optional session selector, e.g. 01 or ses-01",
    )
    p.add_argument(
        "--roi-participants",
        default=str(DEFAULT_ROI_PARTICIPANTS),
        help=f"corrected ROI participants.csv (default: {DEFAULT_ROI_PARTICIPANTS})",
    )
    p.add_argument(
        "--roi-root",
        default=str(DEFAULT_ROI_ROOT),
        help=f"ROI derivative root (default: {DEFAULT_ROI_ROOT})",
    )
    p.add_argument(
        "--output",
        help=(
            "output RSA manifest. Default: "
            "<mugen-root>/finger/derivatives/rsa/manifests/participants.csv"
        ),
    )
    p.add_argument(
        "--allow-missing",
        action="store_true",
        help="emit rows even when expected beta/model/ROI files are not yet present",
    )
    args = p.parse_args()

    mugen_root = Path(args.mugen_root).expanduser()
    roi_root = Path(args.roi_root).expanduser()
    roi_participants = Path(args.roi_participants).expanduser()

    output = (
        Path(args.output).expanduser()
        if args.output
        else mugen_root
        / "finger"
        / "derivatives"
        / "rsa"
        / "manifests"
        / "participants.csv"
    )

    wanted_subject = norm_subject(args.subject) if args.subject else None
    wanted_session = norm_session(args.session) if args.session else None

    source_rows = read_roi_participants(roi_participants)

    rows = []
    skipped = []

    for src in source_rows:
        subject = norm_subject(src["subject"])
        session = norm_session(src["session"])

        if wanted_subject and subject != wanted_subject:
            continue
        if wanted_session and session != wanted_session:
            continue

        fs_subject = src["freesurfer_subject"].strip() or f"{subject}_{session}"
        hemisphere = (src.get("hemisphere") or "lh").strip()
        hand_vertex = str(src["hand_knob_vertex"]).strip()
        radius_mm = str(src["radius_mm"]).strip()

        first_level = (
            mugen_root
            / "finger"
            / "derivatives"
            / "first_level"
            / subject
            / session
            / "output"
        )
        model_dir = first_level / "run1-6"
        beta = first_level / "run1-6" / "beta_0001.nii"

        subjects_dir = (
            mugen_root / "finger" / "derivatives" / "freesurfer"
        )
        surface_path = subjects_dir / fs_subject / "surf" / f"{hemisphere}.white"

        xfm = (
            mugen_root
            / "finger"
            / "derivatives"
            / "fmriprep"
            / subject
            / session
            / "anat"
            / f"{subject}_{session}_from-fsnative_to-T1w_mode-image_xfm.txt"
        )

        resolution = infer_resolution_mm(beta)

        for family, roi_name, version in ROI_SPECS:
            roi_path = (
                roi_root
                / subject
                / session
                / "rois"
                / f"{subject}_{session}_roi-{roi_name}_space-beta.nii.gz"
            )

            required = {
                "model_dir": model_dir,
                "beta_reference": beta,
                "roi_path": roi_path,
                "surface_path": surface_path,
            }
            missing = [
                f"{label}: {path}"
                for label, path in required.items()
                if not path.exists()
            ]

            if missing and not args.allow_missing:
                skipped.append(
                    f"{subject}/{session}/{roi_name}: " + "; ".join(missing)
                )
                continue

            rows.append(
                {
                    "subject": subject,
                    "session": session,
                    "roi_family": family,
                    "roi_name": roi_name,
                    "roi_version": version,
                    "hemisphere": hemisphere,
                    "resolution_mm": resolution,
                    "model_dir": str(model_dir),
                    "roi_path": str(roi_path),
                    "subjects_dir": str(subjects_dir),
                    "surface_path": str(surface_path),
                    "surface": "white",
                    "hand_knob_vertex": hand_vertex,
                    "radius_mm": radius_mm,
                    # Current corrected ROIs are directly on the beta/T1w grid.
                    "mean_epi_reference": "",
                    "beta_reference": str(beta),
                    "xfm_chain": str(xfm),
                }
            )

    if not rows:
        msg = [
            "No RSA manifest rows were emitted.",
            "",
            f"ROI participants: {roi_participants}",
            f"ROI root:         {roi_root}",
        ]
        if wanted_subject:
            msg.append(f"Subject filter:   {wanted_subject}")
        if wanted_session:
            msg.append(f"Session filter:   {wanted_session}")
        if skipped:
            msg += ["", "Missing required files:"] + [f"  {x}" for x in skipped]
        msg += [
            "",
            "If the files are intentionally not present on this machine yet, "
            "rerun with --allow-missing to generate the paths without existence checks."
        ]
        raise SystemExit("\n".join(msg))

    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=FIELDS)
        writer.writeheader()
        writer.writerows(rows)

    # Compatibility copy: the earlier RSA v12 wrapper looked here.
    v12_output = output.with_name("participants_v12.csv")
    if v12_output != output:
        with v12_output.open("w", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=FIELDS)
            writer.writeheader()
            writer.writerows(rows)

    print(f"Wrote {len(rows)} manifest rows:")
    print(f"  {output}")
    if v12_output != output:
        print(f"Compatibility copy:")
        print(f"  {v12_output}")

    print("\nSelections:")
    for row in rows:
        print(
            f"  {row['subject']} {row['session']} "
            f"{row['roi_name']} -> {row['roi_path']}"
        )

    if skipped:
        print(f"\nSkipped {len(skipped)} incomplete row(s).")


if __name__ == "__main__":
    main()

