#!/usr/bin/env python3
"""Install the COMPLETE certified v11 core into this v12 package.

The uploaded RSA_allfiles.zip is not complete: it lacks first_level/,
second_level/, shared/, and reporting/. This installer therefore expects the
actual certified v11 installation directory on the cluster.

It copies, without editing:
  first_level/
  second_level/
  shared/
  reporting/

It also records SHA256 hashes before/after copy so the migration is auditable.
"""
from __future__ import annotations
import argparse,hashlib,json,shutil
from pathlib import Path

PACKAGES=("first_level","second_level","shared","reporting")

def hashes(root):
  d={}
  for pkg in PACKAGES:
    p=root/pkg
    if not p.is_dir(): continue
    for f in sorted(p.rglob("*")):
      if f.is_file() and "__pycache__" not in f.parts:
        d[str(f.relative_to(root))]=hashlib.sha256(f.read_bytes()).hexdigest()
  return d

def main():
  ap=argparse.ArgumentParser(); ap.add_argument("certified_v11_root",type=Path); ap.add_argument("--v12-root",type=Path,default=Path(__file__).resolve().parents[1])
  a=ap.parse_args(); src=a.certified_v11_root.resolve(); dst=a.v12_root.resolve()
  missing=[src/p for p in PACKAGES if not (src/p).is_dir()]
  if missing: raise SystemExit("Incomplete certified v11 root; missing:\n  "+"\n  ".join(map(str,missing)))
  before=hashes(src)
  for pkg in PACKAGES:
    target=dst/pkg
    if target.exists(): shutil.rmtree(target)
    shutil.copytree(src/pkg,target,ignore=shutil.ignore_patterns("__pycache__","*.pyc"))
  after=hashes(dst)
  mismatches=[k for k,v in before.items() if after.get(k)!=v]
  report={"source":str(src),"destination":str(dst),"files":len(before),"mismatches":mismatches,"source_sha256":before}
  rp=dst/"validation"/"certified_v11_core_migration.json"; rp.write_text(json.dumps(report,indent=2)+"\n")
  if mismatches: raise SystemExit(f"Hash mismatch in {len(mismatches)} files; migration FAILED")
  print(f"Certified v11 core copied byte-for-byte: {len(before)} files")
  print(f"Audit report: {rp}")

if __name__=="__main__": main()
