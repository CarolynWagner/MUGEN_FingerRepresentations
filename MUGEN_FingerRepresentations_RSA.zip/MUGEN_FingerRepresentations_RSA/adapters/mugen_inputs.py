"""MUGEN/BIDS normalization helpers for RSA v12."""
def normalize_subject(value):
    s=str(value).strip()
    if s.startswith("sub-"): return s
    if s.startswith("sub"): s=s[3:]
    return f"sub-{int(s):02d}" if s.isdigit() else f"sub-{s}"

def normalize_session(value):
    s=str(value).strip()
    if s.startswith("ses-"): return s
    if s.startswith("ses"): s=s[3:]
    return f"ses-{int(s):02d}" if s.isdigit() else f"ses-{s}"
