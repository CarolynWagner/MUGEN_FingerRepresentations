# MUGEN Finger RSA v12

## Status

This is the **MUGEN-integration migration package** for the certified RSA v11
analysis. v12 is intentionally an I/O/orchestration release: the validated
Diedrichsen-style numerical core must be copied byte-for-byte from the complete
certified v11 installation.

The `RSA_allfiles.zip` supplied for this migration did **not** contain the
`first_level/`, `second_level/`, `shared/`, or `reporting/` package directories.
For that reason this release does not fabricate replacements.

## Scientific invariant

v12 does not intentionally change:
- residual-noise normalization;
- shrinkage-diagonal precision;
- Crossnobis estimation;
- run-wise crossvalidation;
- FSI definitions;
- reliability/correlation/ICC definitions;
- second-level legacy diagnostics.

## New production contract

Common MUGEN fMRI preprocessing -> Finger-specific SPM GLM -> beta_lookup.tsv
+ residuals -> Finger ROIs in beta space -> frozen RSA core.

Expected derivatives:

    MUGEN_data/finger/derivatives/
      spm_firstlevel/sub-XX/ses-YY/
        SPM.mat
        beta_*.nii
        Res_*.nii
        beta_lookup.tsv
        metadata.json
      finger_rois/sub-XX/ses-YY/
        sub-XX_ses-YY_roi-M1_space-beta.nii.gz
        ...
      rsa/
        manifests/
        first_level/
        second_level/
        roi_comparisons/
        searchlight/
        provenance/

## Install the certified core

On the cluster:

    python scripts/install_certified_v11_core.py \
      /mnt/beegfs/workspace/2025-0422-Musicians7T/SPM_Prepro_FirstLevel/ROIs/RSApipeline_general_v11

The installer refuses incomplete sources and verifies SHA256 hashes after copy.

## Build a production manifest

    python build_rsa_manifest.py \
      --mugen-root /mnt/beegfs/workspace/2025-0422-Musicians7T/MUGEN_data \
      --subject 11

Then:

    python validation/production_preflight.py \
      /.../MUGEN_data/finger/derivatives/rsa/manifests/participants_v12.csv

## Run

    python run_pipeline.py \
      --first-level \
      --mugen-root /.../MUGEN_data \
      --subject 11 \
      --session 01 \
      --roi M1

Second level across all selected sessions for that subject/ROI:

    python run_pipeline.py \
      --second-level \
      --mugen-root /.../MUGEN_data \
      --subject 11 \
      --roi M1

## U-V / Huber branch

The old U-V scripts are retained only under `validation/legacy_v11_release/`.
They are not part of the v12 production Diedrichsen RSA branch.

## Still required before prospective sub-11 RSA

The MUGEN Finger pipeline must produce:
1. a generalized SPM first-level GLM;
2. `beta_lookup.tsv`;
3. generalized anatomical M1/S1 ROI derivatives in the beta grid.

Those are explicit upstream contracts, not silently inferred by RSA v12.
