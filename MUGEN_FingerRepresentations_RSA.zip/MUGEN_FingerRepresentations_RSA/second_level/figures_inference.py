"""13_figures_inference.py

Inference/reliability figures.

Corrections in v10.2
--------------------
- Removes mathematical metric-maximum reference lines.
- Restores a metric-matched single-participant cross-session consistency
  reference band (historical "noise-ceiling" analogue) derived from the
  full run1-6 RDMs.
- The reference is explicitly labelled as descriptive, not a formal group
  RSA model-fitting noise ceiling.
- Bar-value labels use protected text boxes and adaptive placement.
- Permutation summary is split into one panel per metric instead of one
  unreadably wide axis.
- Every figure is saved as both PNG and SVG.
- Uses constrained layout and stable tick locators.
"""

from __future__ import annotations

import os
from pathlib import Path

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap
from matplotlib.ticker import MaxNLocator


EJAZ_CMAP = LinearSegmentedColormap.from_list(
    "ejaz_black_red_yellow_white",
    [
        "black",
        "red",
        "yellow",
        "white",
    ],
)

EPS = 1e-12

METRICS = [
    (
        "pearson",
        "Pearson correlation",
        "r",
    ),
    (
        "spearman",
        "Spearman correlation",
        "rho",
    ),
    (
        "fisherz",
        "Fisher-Z",
        "Z",
    ),
    (
        "icc",
        "ICC(2,1)",
        "ICC",
    ),
    (
        "cosine",
        "Cosine similarity",
        "cosine",
    ),
]


def save_png_svg(
    fig,
    png_path,
    dpi=220,
):
    png_path = Path(
        png_path
    )

    png_path.parent.mkdir(
        parents=True,
        exist_ok=True,
    )

    fig.savefig(
        png_path,
        dpi=dpi,
        bbox_inches="tight",
    )

    fig.savefig(
        png_path.with_suffix(
            ".svg"
        ),
        format="svg",
        bbox_inches="tight",
    )


def finite_values(x):
    x = np.asarray(
        x,
        dtype=float,
    ).ravel()

    return x[
        np.isfinite(x)
    ]


def data_range(
    values,
    zero_center=True,
    pad_frac=0.05,
    default=(-1.0, 1.0),
):
    vals = finite_values(
        values
    )

    if vals.size == 0:
        vmin, vmax = default
    else:
        vmin = float(
            vals.min()
        )
        vmax = float(
            vals.max()
        )

    if abs(vmax - vmin) < EPS:
        pad = max(
            abs(vmax) * 0.1,
            0.05,
        )

        vmin -= pad
        vmax += pad

    else:
        pad = (
            vmax - vmin
        ) * pad_frac

        vmin -= pad
        vmax += pad

    if zero_center:
        lim = max(
            abs(vmin),
            abs(vmax),
            0.05,
        )

        vmin, vmax = (
            -lim,
            lim,
        )

    return (
        float(vmin),
        float(vmax),
    )


def get_text_color(
    value,
    vmin,
    vmax,
    cmap=EJAZ_CMAP,
):
    norm = (
        value - vmin
    ) / (
        vmax - vmin + EPS
    )

    norm = np.clip(
        norm,
        0,
        1,
    )

    r, g, b, _ = cmap(
        norm
    )

    lum = (
        0.299 * r
        + 0.587 * g
        + 0.114 * b
    )

    return (
        "black"
        if lum > 0.55
        else "white"
    )


def plot_corr_matrix(
    ax,
    mat,
    title,
    labels,
    cbar_label,
):
    mat = np.asarray(
        mat,
        dtype=float,
    )

    vmin, vmax = data_range(
        mat,
        zero_center=True,
    )

    im = ax.imshow(
        mat,
        cmap=EJAZ_CMAP,
        vmin=vmin,
        vmax=vmax,
        aspect="equal",
    )

    n = mat.shape[0]

    ax.set_xticks(
        range(n)
    )

    ax.set_yticks(
        range(n)
    )

    ax.set_xticklabels(
        labels,
        rotation=90,
        fontsize=7,
    )

    ax.set_yticklabels(
        labels,
        fontsize=7,
    )

    ax.set_title(
        title,
        fontsize=10,
        fontweight="bold",
    )

    for i in range(n):
        for j in range(n):
            val = mat[i, j]

            if np.isfinite(val):
                ax.text(
                    j,
                    i,
                    f"{val:.3f}",
                    ha="center",
                    va="center",
                    fontsize=6,
                    color=get_text_color(
                        val,
                        vmin,
                        vmax,
                    ),
                )

    plt.colorbar(
        im,
        ax=ax,
        fraction=0.046,
        pad=0.04,
        label=(
            f"{cbar_label} "
            f"[{vmin:.3g}, {vmax:.3g}]"
        ),
    )

    return im


def metric_consistency_reference(
    contract,
    metric,
):
    """Return the metric-matched full-data consistency interval."""

    session_consistency = contract.get(
        "session_consistency",
        {},
    )

    original = session_consistency.get(
        "original_session_components",
        {},
    )

    metrics = original.get(
        "metrics",
        {},
    )

    item = metrics.get(
        metric
    )

    if item:
        low = item.get(
            "display_interval_low",
            np.nan,
        )

        high = item.get(
            "display_interval_high",
            np.nan,
        )

        if not np.isfinite(low):
            low = min(
                item.get(
                    "lower_component_mean",
                    np.nan,
                ),
                item.get(
                    "upper_component_mean",
                    np.nan,
                ),
            )

        if not np.isfinite(high):
            high = max(
                item.get(
                    "lower_component_mean",
                    np.nan,
                ),
                item.get(
                    "upper_component_mean",
                    np.nan,
                ),
            )

        return {
            "low":
                float(low),

            "high":
                float(high),

            "combo":
                original.get(
                    "combo",
                    contract.get(
                        "full_combo_label",
                        "run1-6",
                    ),
                ),

            "type":
                "cross_session_consistency_reference",
        }

    # Backward-compatible fallback: a single same-resolution reference.
    ref = contract.get(
        "test_retest_consistency_reference",
        {},
    )

    value = ref.get(
        "metrics",
        {},
    ).get(
        metric,
        np.nan,
    )

    return {
        "low":
            float(value)
            if np.isfinite(value)
            else np.nan,

        "high":
            float(value)
            if np.isfinite(value)
            else np.nan,

        "combo":
            ref.get(
                "combo",
                contract.get(
                    "full_combo_label",
                    "run1-6",
                ),
            ),

        "type":
            "same_resolution_test_retest_reference",
    }


def plot_within_session_matrices(
    contract,
    out_dir,
):
    within = contract.get(
        "within_session",
        {},
    )

    if not within:
        return

    for ses_id, ws in within.items():
        combos = ws[
            "combos"
        ]

        short = [
            c.replace(
                "run",
                "r",
            ).replace(
                "_runs",
                "",
            ).replace(
                "-",
                "",
            )
            for c in combos
        ]

        fig, axes = plt.subplots(
            1,
            len(METRICS),
            figsize=(
                6.2 * len(METRICS),
                6.2,
            ),
            layout="constrained",
        )

        axes = np.atleast_1d(
            axes
        )

        for ax, (
            metric,
            title,
            label,
        ) in zip(
            axes,
            METRICS,
        ):
            plot_corr_matrix(
                ax=ax,
                mat=ws[metric],
                title=title,
                labels=short,
                cbar_label=label,
            )

        fig.suptitle(
            f"Within-session RDM correlations - {ses_id}",
            fontsize=14,
            fontweight="bold",
        )

        save_png_svg(
            fig,
            os.path.join(
                out_dir,
                f"Fig_within_session_corr_{ses_id}.png",
            ),
        )

        plt.close(
            fig
        )


def _set_metric_axis(
    ax,
    metric,
    values,
    reference_low,
    reference_high,
):
    values = finite_values(
        list(values)
        + [
            reference_low,
            reference_high,
        ]
    )

    if values.size == 0:
        return

    lo = float(
        values.min()
    )

    hi = float(
        values.max()
    )

    # Correlation-like metrics usually benefit from a 0..1 frame if all
    # values are non-negative; retain negatives when they occur.
    if metric in {
        "pearson",
        "spearman",
        "icc",
        "cosine",
    }:
        lower = (
            min(
                -0.05,
                lo - 0.08,
            )
            if lo < 0
            else -0.05
        )

        upper = max(
            1.05,
            hi + 0.10,
        )

    else:
        span = max(
            hi - lo,
            0.25,
        )

        pad = span * 0.18

        lower = min(
            -0.05,
            lo - pad,
        )

        upper = hi + pad

    ax.set_ylim(
        lower,
        upper,
    )

    ax.yaxis.set_major_locator(
        MaxNLocator(
            nbins=7
        )
    )


def _annotate_bar_value(
    ax,
    bar,
    val,
):
    """Place a bar value without crossing the bar top or reference lines."""

    if not np.isfinite(val):
        return

    y0, y1 = ax.get_ylim()

    span = y1 - y0

    # High positive bars: put label just inside the bar to avoid the top
    # margin/reference band. Otherwise put it outside.
    if val >= 0 and val > y0 + 0.78 * span:
        y = val - 0.025 * span
        va = "top"
    elif val >= 0:
        y = val + 0.015 * span
        va = "bottom"
    else:
        y = val - 0.015 * span
        va = "top"

    ax.text(
        bar.get_x()
        + bar.get_width()
        / 2,
        y,
        f"{val:.3f}",
        ha="center",
        va=va,
        fontsize=7,
        rotation=90,
        bbox=dict(
            facecolor="white",
            alpha=0.88,
            edgecolor="none",
            pad=0.6,
        ),
        zorder=6,
        clip_on=False,
    )


def plot_between_session_bars(
    contract,
    out_dir,
):
    between = contract.get(
        "between_session",
        {},
    )

    if not between:
        return

    combos = list(
        between.keys()
    )

    first_combo = combos[
        0
    ]

    pair_labels = list(
        between[
            first_combo
        ]["pearson"].keys()
    )

    x = np.arange(
        len(combos)
    )

    width = (
        0.78
        / max(
            len(pair_labels),
            1,
        )
    )

    for (
        metric,
        title,
        ylabel,
    ) in METRICS:
        fig, ax = plt.subplots(
            figsize=(
                13,
                6.5,
            ),
            layout="constrained",
        )

        all_vals = []

        bar_groups = []

        for p_idx, pair in enumerate(
            pair_labels
        ):
            vals = np.asarray(
                [
                    float(
                        between[combo][metric].get(
                            pair,
                            np.nan,
                        )
                    )
                    for combo in combos
                ],
                dtype=float,
            )

            all_vals.extend(
                finite_values(vals)
            )

            xpos = (
                x
                + (
                    p_idx
                    - (
                        len(pair_labels)
                        - 1
                    )
                    / 2
                )
                * width
            )

            bars = ax.bar(
                xpos,
                vals,
                width=width,
                label=pair.replace(
                    "ses",
                    "",
                ).replace(
                    "_vs_",
                    "–",
                ),
                edgecolor="black",
                alpha=0.85,
                zorder=3,
            )

            bar_groups.append(
                (
                    bars,
                    vals,
                )
            )

        reference = (
            metric_consistency_reference(
                contract,
                metric,
            )
        )

        ref_low = reference[
            "low"
        ]

        ref_high = reference[
            "high"
        ]

        _set_metric_axis(
            ax,
            metric,
            all_vals,
            ref_low,
            ref_high,
        )

        # Historical "noise ceiling" analogue, now correctly labelled.
        if (
            np.isfinite(ref_low)
            and np.isfinite(ref_high)
        ):
            lo = min(
                ref_low,
                ref_high,
            )

            hi = max(
                ref_low,
                ref_high,
            )

            if abs(
                hi - lo
            ) < 1e-10:
                ax.axhline(
                    lo,
                    linestyle="--",
                    linewidth=1.5,
                    color="dimgray",
                    label=(
                        "Consistency ref. "
                        f"({lo:.3f})"
                    ),
                    zorder=2,
                )

            else:
                ax.axhspan(
                    lo,
                    hi,
                    alpha=0.12,
                    color="gray",
                    label=(
                        "Consistency ref. "
                        f"({lo:.3f}–{hi:.3f})"
                    ),
                    zorder=1,
                )

                ax.axhline(
                    lo,
                    linestyle=":",
                    linewidth=1.0,
                    color="dimgray",
                    zorder=2,
                )

                ax.axhline(
                    hi,
                    linestyle="--",
                    linewidth=1.0,
                    color="dimgray",
                    zorder=2,
                )

        ax.axhline(
            0,
            color="black",
            linewidth=0.5,
            zorder=2,
        )

        for bars, vals in bar_groups:
            for bar, val in zip(
                bars,
                vals,
            ):
                _annotate_bar_value(
                    ax,
                    bar,
                    val,
                )

        ax.set_xticks(
            x
        )

        ax.set_xticklabels(
            [
                c.replace(
                    "_",
                    " ",
                )
                for c in combos
            ],
            rotation=32,
            ha="right",
        )

        ax.set_ylabel(
            ylabel
        )

        ax.set_title(
            (
                "Between-session RDM correlations - "
                f"{title}"
            ),
            fontsize=13,
            fontweight="bold",
        )

        ax.grid(
            axis="y",
            alpha=0.25,
            zorder=0,
        )

        ax.legend(
            loc="center left",
            bbox_to_anchor=(
                1.01,
                0.5,
            ),
            fontsize=8,
            title="Session pair / reference",
            title_fontsize=8,
        )

        save_png_svg(
            fig,
            os.path.join(
                out_dir,
                f"Fig_between_session_{metric}.png",
            ),
        )

        plt.close(
            fig
        )


def plot_permutation_fdr_summary(
    contract,
    out_dir,
):
    cert = contract.get(
        "certification",
        {},
    )

    fdr = cert.get(
        "fdr_results",
        [],
    )

    if not fdr:
        return

    metric_names = [
        m[0]
        for m in METRICS
    ]

    fig, axes = plt.subplots(
        len(metric_names),
        1,
        figsize=(
            14,
            3.2 * len(metric_names),
        ),
        sharey=True,
        layout="constrained",
    )

    axes = np.atleast_1d(
        axes
    )

    for ax, metric in zip(
        axes,
        metric_names,
    ):
        rows = [
            x
            for x in fdr
            if x[
                "metric"
            ] == metric
        ]

        labels = [
            (
                f"{x['combo'].replace('_', ' ')}\n"
                f"{x['pair'].replace('_vs_', '–')}"
            )
            for x in rows
        ]

        pvals = np.asarray(
            [
                x[
                    "p_value"
                ]
                for x in rows
            ],
            dtype=float,
        )

        sig = [
            bool(
                x.get(
                    "fdr_significant_q05",
                    False,
                )
            )
            for x in rows
        ]

        xpos = np.arange(
            len(rows)
        )

        bars = ax.bar(
            xpos,
            pvals,
            edgecolor="black",
            alpha=0.85,
        )

        for bar, keep in zip(
            bars,
            sig,
        ):
            if keep:
                bar.set_hatch(
                    "//"
                )

        ax.axhline(
            0.05,
            color="red",
            linestyle="--",
            linewidth=1.0,
            label="p = 0.05",
        )

        ax.set_ylim(
            0,
            1.02,
        )

        ax.yaxis.set_major_locator(
            MaxNLocator(
                nbins=6
            )
        )

        ax.set_xticks(
            xpos
        )

        ax.set_xticklabels(
            labels,
            rotation=55,
            ha="right",
            fontsize=6,
        )

        ax.set_ylabel(
            "Exact permutation p"
        )

        metric_title = next(
            title
            for key, title, _
            in METRICS
            if key == metric
        )

        ax.set_title(
            metric_title,
            fontsize=10,
            fontweight="bold",
        )

        ax.grid(
            axis="y",
            alpha=0.25,
        )

        if ax is axes[0]:
            ax.legend(
                loc="upper right",
                fontsize=8,
            )

    fig.suptitle(
        (
            "Exact condition-label permutation tests "
            "(hatched bars survive BH-FDR q < .05)"
        ),
        fontsize=13,
        fontweight="bold",
    )

    save_png_svg(
        fig,
        os.path.join(
            out_dir,
            "Fig_permutation_fdr_summary.png",
        ),
    )

    plt.close(
        fig
    )


def make_inference_figures(
    contract,
    out_dir,
):
    os.makedirs(
        out_dir,
        exist_ok=True,
    )

    plot_within_session_matrices(
        contract,
        out_dir,
    )

    plot_between_session_bars(
        contract,
        out_dir,
    )

    plot_permutation_fdr_summary(
        contract,
        out_dir,
    )

    print(
        f"[FIGURES] Inference figures saved as PNG + SVG to {out_dir}"
    )
