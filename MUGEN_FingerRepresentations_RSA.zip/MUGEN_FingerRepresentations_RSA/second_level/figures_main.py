"""12_figures_main.py

Main publication figures for the finger-representation RSA pipeline.

Corrections in v10.2
--------------------
- Every figure is written as both PNG and SVG.
- Uses constrained layout instead of manual tight_layout/colorbar axes.
- RDM heatmaps use shared ranges within each figure type.
- Grand-mean [0,1] visualization scales only off-diagonal entries and
  explicitly preserves the zero diagonal.
- MDS panels use identical x/y limits and tick breaks within each session.
- MDS point labels use collision-aware placement.
- FSI axes use stable, readable tick locators and label placement.
"""

from __future__ import annotations

import os
from pathlib import Path

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap
from matplotlib.ticker import MaxNLocator


EJAZ_CMAP = LinearSegmentedColormap.from_list(
    "ejaz_black_red_yellow_white",
    [
        "black",
        "red",
        "yellow",
        "white",
    ],
)

EPS = 1e-12


def save_png_svg(fig, png_path, dpi=220):
    """Save one figure as both PNG and SVG."""

    png_path = Path(png_path)
    png_path.parent.mkdir(
        parents=True,
        exist_ok=True,
    )

    svg_path = png_path.with_suffix(
        ".svg"
    )

    fig.savefig(
        png_path,
        dpi=dpi,
        bbox_inches="tight",
    )

    fig.savefig(
        svg_path,
        format="svg",
        bbox_inches="tight",
    )


def finite_values(x):
    x = np.asarray(
        x,
        dtype=float,
    ).ravel()

    return x[
        np.isfinite(x)
    ]


def upper_values(rdm):
    rdm = np.asarray(
        rdm,
        dtype=float,
    )

    return rdm[
        np.triu_indices(
            rdm.shape[0],
            k=1,
        )
    ]


def data_range(
    arrays,
    pad_frac=0.03,
    fixed=None,
):
    """Return one shared display range for the arrays in a figure."""

    if fixed is not None:
        return (
            float(fixed[0]),
            float(fixed[1]),
        )

    vals = []

    for a in arrays:
        vals.extend(
            finite_values(a)
        )

    vals = np.asarray(
        vals,
        dtype=float,
    )

    if vals.size == 0:
        return 0.0, 1.0

    vmin = float(
        vals.min()
    )

    vmax = float(
        vals.max()
    )

    if abs(vmax - vmin) < EPS:
        pad = max(
            abs(vmax) * 0.1,
            0.001,
        )
    else:
        pad = (
            vmax - vmin
        ) * pad_frac

    return (
        vmin - pad,
        vmax + pad,
    )


def minmax_stack_01(mats):
    """Global off-diagonal min-max normalization across matrices.

    Crossnobis RDMs may contain negative off-diagonal estimates. The zero
    diagonal is not an empirical dissimilarity and therefore does not enter
    the normalization range. It is explicitly restored to zero afterwards.
    """

    mats = [
        np.asarray(
            m,
            dtype=float,
        )
        for m in mats
    ]

    offdiag = np.concatenate(
        [
            upper_values(m)
            for m in mats
        ]
    )

    offdiag = offdiag[
        np.isfinite(offdiag)
    ]

    if offdiag.size == 0:
        return [
            np.zeros_like(
                m,
                dtype=float,
            )
            for m in mats
        ]

    mn = float(
        offdiag.min()
    )

    mx = float(
        offdiag.max()
    )

    if mx - mn < EPS:
        return [
            np.zeros_like(
                m,
                dtype=float,
            )
            for m in mats
        ]

    out = []

    for m in mats:
        scaled = (
            m - mn
        ) / (
            mx - mn
        )

        np.fill_diagonal(
            scaled,
            0.0,
        )

        out.append(
            scaled
        )

    return out


def get_text_color(
    value,
    vmin,
    vmax,
    cmap=EJAZ_CMAP,
):
    norm = (
        value - vmin
    ) / (
        vmax - vmin + EPS
    )

    norm = np.clip(
        norm,
        0,
        1,
    )

    r, g, b, _ = cmap(
        norm
    )

    lum = (
        0.299 * r
        + 0.587 * g
        + 0.114 * b
    )

    return (
        "black"
        if lum > 0.55
        else "white"
    )


def compute_mds(rdm):
    """Classical MDS with negative eigenvalues truncated at zero."""

    rdm = np.asarray(
        rdm,
        dtype=float,
    )

    n = rdm.shape[0]

    H = (
        np.eye(n)
        - np.ones(
            (n, n)
        ) / n
    )

    B = (
        -0.5
        * H
        @ rdm
        @ H
    )

    vals, vecs = np.linalg.eigh(
        B
    )

    idx = np.argsort(
        vals
    )[::-1]

    vals = vals[idx]
    vecs = vecs[:, idx]

    coords = (
        vecs[:, :2]
        * np.sqrt(
            np.maximum(
                vals[:2],
                0,
            )
        )
    )

    return coords


def plot_rdm(
    ax,
    rdm,
    title,
    finger_names,
    vmin,
    vmax,
):
    im = ax.imshow(
        rdm,
        cmap=EJAZ_CMAP,
        vmin=vmin,
        vmax=vmax,
        aspect="equal",
    )

    n = len(
        finger_names
    )

    ax.set_xticks(
        range(n)
    )

    ax.set_yticks(
        range(n)
    )

    ax.set_xticklabels(
        [
            f.capitalize()
            for f in finger_names
        ],
        rotation=45,
        ha="right",
        fontsize=8,
    )

    ax.set_yticklabels(
        [
            f.capitalize()
            for f in finger_names
        ],
        fontsize=8,
    )

    ax.set_title(
        title,
        fontsize=9,
        fontweight="bold",
    )

    for i in range(n):
        for j in range(n):
            val = float(
                rdm[i, j]
            )

            ax.text(
                j,
                i,
                f"{val:.3f}",
                ha="center",
                va="center",
                fontsize=6,
                color=get_text_color(
                    val,
                    vmin,
                    vmax,
                ),
            )

    return im


def plot_custom_rdm_grid(
    mats,
    sessions,
    finger_names,
    title,
    out_path,
    label,
    fixed_range=None,
):
    vmin, vmax = data_range(
        mats,
        fixed=fixed_range,
    )

    fig, axes = plt.subplots(
        1,
        len(sessions),
        figsize=(
            5 * len(sessions),
            4.4,
        ),
        layout="constrained",
    )

    axes = np.atleast_1d(
        axes
    )

    im_last = None

    for ax, ses, mat in zip(
        axes,
        sessions,
        mats,
    ):
        im_last = plot_rdm(
            ax,
            mat,
            ses,
            finger_names,
            vmin,
            vmax,
        )

    fig.colorbar(
        im_last,
        ax=axes.tolist(),
        shrink=0.82,
        pad=0.03,
        label=(
            f"{label} "
            f"[{vmin:.3g}, {vmax:.3g}]"
        ),
    )

    fig.suptitle(
        title,
        fontsize=14,
        fontweight="bold",
    )

    save_png_svg(
        fig,
        out_path,
    )

    plt.close(
        fig
    )


def plot_rdm_grid(
    contract,
    representation,
    title,
    out_path,
    label,
):
    rdms = contract[
        "rdms"
    ]

    sessions = contract[
        "session_ids"
    ]

    full_combo = contract[
        "full_combo_label"
    ]

    finger_names = contract[
        "finger_names"
    ]

    mats = [
        rdms[ses][full_combo][representation]
        for ses in sessions
    ]

    fixed = (
        (0.0, 1.0)
        if representation == "vis01"
        else None
    )

    panel_sessions = [
        f"{ses} | {full_combo}"
        for ses in sessions
    ]

    plot_custom_rdm_grid(
        mats=mats,
        sessions=panel_sessions,
        finger_names=finger_names,
        title=title,
        out_path=out_path,
        label=label,
        fixed_range=fixed,
    )


def plot_grand_mean_normalized_full_combo(
    contract,
    out_dir,
):
    rdms = contract[
        "rdms"
    ]

    sessions = contract[
        "session_ids"
    ]

    full_combo = contract[
        "full_combo_label"
    ]

    finger_names = contract[
        "finger_names"
    ]

    raw_mats = [
        np.asarray(
            rdms[ses][full_combo]["raw"],
            dtype=float,
        )
        for ses in sessions
    ]

    all_upper = np.concatenate(
        [
            upper_values(m)
            for m in raw_mats
        ]
    )

    all_upper = all_upper[
        np.isfinite(all_upper)
    ]

    grand_mean = (
        float(
            np.mean(all_upper)
        )
        if all_upper.size
        else 1.0
    )

    if abs(grand_mean) < EPS:
        grand_mean = 1.0

    grand_mean_norm = [
        m / grand_mean
        for m in raw_mats
    ]

    plot_custom_rdm_grid(
        mats=grand_mean_norm,
        sessions=[
            f"{ses} | {full_combo}"
            for ses in sessions
        ],
        finger_names=finger_names,
        title=(
            "Crossnobis RDMs normalized to grand mean "
            "across sessions "
            f"({full_combo}; grand mean={grand_mean:.6g})"
        ),
        out_path=os.path.join(
            out_dir,
            "Fig_RDM_grand_mean_normalized_full_combo.png",
        ),
        label=(
            "Raw distance / "
            "grand mean across sessions"
        ),
        fixed_range=None,
    )

    grand_mean_norm_01 = (
        minmax_stack_01(
            grand_mean_norm
        )
    )

    plot_custom_rdm_grid(
        mats=grand_mean_norm_01,
        sessions=[
            f"{ses} | {full_combo}"
            for ses in sessions
        ],
        finger_names=finger_names,
        title=(
            "Grand-mean normalized Crossnobis RDMs "
            f"bounded [0,1] ({full_combo})"
        ),
        out_path=os.path.join(
            out_dir,
            "Fig_RDM_grand_mean_normalized_01_full_combo.png",
        ),
        label=(
            "Grand-mean normalized distance, "
            "global off-diagonal [0,1]"
        ),
        fixed_range=(
            0.0,
            1.0,
        ),
    )


def plot_all_combo_heatmaps(
    contract,
    out_dir,
):
    rdms = contract[
        "rdms"
    ]

    sessions = contract[
        "session_ids"
    ]

    combos = list(
        contract[
            "run_combos"
        ].keys()
    )

    finger_names = contract[
        "finger_names"
    ]

    for ses in sessions:
        mats = [
            rdms[ses][combo]["raw"]
            for combo in combos
        ]

        vmin, vmax = data_range(
            mats
        )

        cols = 3
        rows = int(
            np.ceil(
                len(combos)
                / cols
            )
        )

        fig, axes = plt.subplots(
            rows,
            cols,
            figsize=(
                cols * 3.5,
                rows * 3.25,
            ),
            layout="constrained",
        )

        axes = np.atleast_1d(
            axes
        ).ravel()

        im_last = None

        for i, combo in enumerate(
            combos
        ):
            im_last = plot_rdm(
                axes[i],
                rdms[ses][combo]["raw"],
                combo,
                finger_names,
                vmin,
                vmax,
            )

        for j in range(
            len(combos),
            len(axes),
        ):
            axes[j].set_visible(
                False
            )

        visible_axes = [
            axes[i]
            for i in range(
                len(combos)
            )
        ]

        fig.colorbar(
            im_last,
            ax=visible_axes,
            shrink=0.86,
            pad=0.02,
            label=(
                "Crossnobis distance "
                f"[{vmin:.3g}, {vmax:.3g}]"
            ),
        )

        fig.suptitle(
            f"All run-combo raw RDMs - {ses}",
            fontsize=14,
            fontweight="bold",
        )

        save_png_svg(
            fig,
            os.path.join(
                out_dir,
                f"Fig_RDM_all_combos_{ses}.png",
            ),
        )

        plt.close(
            fig
        )


def annotate_points_no_overlap(
    ax,
    coords,
    labels,
):
    """Place MDS labels without label-label or label-point overlap.

    The placement is done in normalized axis coordinates, so it is fast and
    deterministic and does not require repeated canvas rendering. With only
    five finger labels this is robust and avoids the large runtime cost of
    renderer-based collision tests.
    """

    coords = np.asarray(
        coords,
        dtype=float,
    )

    x0, x1 = ax.get_xlim()
    y0, y1 = ax.get_ylim()

    xspan = max(
        x1 - x0,
        EPS,
    )

    yspan = max(
        y1 - y0,
        EPS,
    )

    # Point positions in normalized axes coordinates.
    pts = np.column_stack(
        [
            (coords[:, 0] - x0) / xspan,
            (coords[:, 1] - y0) / yspan,
        ]
    )

    # Candidate offsets in normalized axes units.
    candidates = [
        (0.025, 0.030),
        (0.025, -0.045),
        (-0.025, 0.030),
        (-0.025, -0.045),
        (0.045, 0.000),
        (-0.045, 0.000),
        (0.000, 0.055),
        (0.000, -0.060),
        (0.050, 0.045),
        (-0.050, 0.045),
        (0.050, -0.055),
        (-0.050, -0.055),
    ]

    placed = []

    # Approximate label boxes in normalized-axis units. Width depends on label.
    for idx, (xy, label) in enumerate(
        zip(
            pts,
            labels,
        )
    ):
        label_width = max(
            0.075,
            0.014 * len(label),
        )

        label_height = 0.045

        best = None
        best_score = float("inf")

        for dx, dy in candidates:
            cx = xy[0] + dx
            cy = xy[1] + dy

            # Keep the approximate text box inside the axes.
            left = cx if dx >= 0 else cx - label_width
            right = cx + label_width if dx >= 0 else cx
            bottom = cy if dy >= 0 else cy - label_height
            top = cy + label_height if dy >= 0 else cy

            if (
                left < 0.005
                or right > 0.995
                or bottom < 0.005
                or top > 0.995
            ):
                continue

            # Penalize collisions with other points.
            point_penalty = 0.0
            for p_idx, pxy in enumerate(pts):
                if p_idx == idx:
                    continue

                if (
                    left - 0.018 <= pxy[0] <= right + 0.018
                    and bottom - 0.018 <= pxy[1] <= top + 0.018
                ):
                    point_penalty += 100.0

            # Penalize collisions with already placed labels.
            label_penalty = 0.0
            for old in placed:
                if not (
                    right + 0.008 < old[0]
                    or left - 0.008 > old[1]
                    or top + 0.008 < old[2]
                    or bottom - 0.008 > old[3]
                ):
                    label_penalty += 100.0

            distance_penalty = abs(dx) + abs(dy)

            score = (
                point_penalty
                + label_penalty
                + distance_penalty
            )

            if score < best_score:
                best_score = score
                best = (
                    dx,
                    dy,
                    left,
                    right,
                    bottom,
                    top,
                )

                if score < 1.0:
                    break

        if best is None:
            best = (
                0.030,
                0.035,
                xy[0] + 0.030,
                xy[0] + 0.030 + label_width,
                xy[1] + 0.035,
                xy[1] + 0.035 + label_height,
            )

        dx, dy, left, right, bottom, top = best

        ax.annotate(
            label,
            coords[idx],
            xytext=(
                dx * 72.0,
                dy * 72.0,
            ),
            textcoords="offset points",
            fontsize=7,
            ha=(
                "left"
                if dx >= 0
                else "right"
            ),
            va=(
                "bottom"
                if dy >= 0
                else "top"
            ),
            annotation_clip=True,
            bbox=dict(
                facecolor="white",
                alpha=0.72,
                edgecolor="none",
                pad=0.35,
            ),
            zorder=4,
        )

        placed.append(
            (
                left,
                right,
                bottom,
                top,
            )
        )


def plot_mds_all(
    contract,
    out_dir,
):
    rdms = contract[
        "rdms"
    ]

    sessions = contract[
        "session_ids"
    ]

    combos = list(
        contract[
            "run_combos"
        ].keys()
    )

    finger_names = [
        f.capitalize()
        for f in contract[
            "finger_names"
        ]
    ]

    for ses in sessions:
        coords_by_combo = {
            combo: compute_mds(
                rdms[ses][combo]["raw"]
            )
            for combo in combos
        }

        # One shared symmetric coordinate system for every panel.
        all_coords = np.vstack(
            list(
                coords_by_combo.values()
            )
        )

        max_abs = float(
            np.nanmax(
                np.abs(
                    all_coords
                )
            )
        )

        lim = max(
            max_abs * 1.18,
            0.01,
        )

        cols = 3
        rows = int(
            np.ceil(
                len(combos)
                / cols
            )
        )

        fig, axes = plt.subplots(
            rows,
            cols,
            figsize=(
                cols * 3.7,
                rows * 3.5,
            ),
            layout="constrained",
        )

        axes = np.atleast_1d(
            axes
        ).ravel()

        for i, combo in enumerate(
            combos
        ):
            ax = axes[i]

            coords = coords_by_combo[
                combo
            ]

            ax.scatter(
                coords[:, 0],
                coords[:, 1],
                s=60,
                zorder=3,
            )

            ax.axhline(
                0,
                color="gray",
                lw=0.5,
                zorder=1,
            )

            ax.axvline(
                0,
                color="gray",
                lw=0.5,
                zorder=1,
            )

            ax.set_xlim(
                -lim,
                lim,
            )

            ax.set_ylim(
                -lim,
                lim,
            )

            ax.set_aspect(
                "equal",
                adjustable="box",
            )

            ax.xaxis.set_major_locator(
                MaxNLocator(
                    nbins=5
                )
            )

            ax.yaxis.set_major_locator(
                MaxNLocator(
                    nbins=5
                )
            )

            ax.set_title(
                combo,
                fontsize=9,
            )

            ax.tick_params(
                labelsize=6,
            )

            annotate_points_no_overlap(
                ax,
                coords,
                finger_names,
            )

        for j in range(
            len(combos),
            len(axes),
        ):
            axes[j].set_visible(
                False
            )

        fig.suptitle(
            f"MDS finger geometry - {ses}",
            fontsize=14,
            fontweight="bold",
        )

        save_png_svg(
            fig,
            os.path.join(
                out_dir,
                f"Fig_MDS_all_combos_{ses}.png",
            ),
        )

        plt.close(
            fig
        )


def plot_fsi(
    contract,
    out_dir,
):
    sessions = contract[
        "session_ids"
    ]

    combos = list(
        contract[
            "run_combos"
        ].keys()
    )

    settings = [
        (
            "fsi_raw",
            "Finger Separation Index - raw",
            "Mean upper-triangle Crossnobis distance",
            "Fig_FSI_raw.png",
        ),
        (
            "fsi_normalized",
            "Finger Separation Index - normalized",
            "FSI / mean FSI across sessions per combo",
            "Fig_FSI_normalized.png",
        ),
    ]

    for (
        key,
        title,
        ylabel,
        fname,
    ) in settings:
        fig, ax = plt.subplots(
            figsize=(
                12,
                6,
            ),
            layout="constrained",
        )

        x = np.arange(
            len(combos)
        )

        all_vals = []

        for s_idx, ses in enumerate(
            sessions
        ):
            vals = np.asarray(
                [
                    contract[key][ses][c]
                    for c in combos
                ],
                dtype=float,
            )

            all_vals.extend(
                finite_values(vals)
            )

            line, = ax.plot(
                x,
                vals,
                marker="o",
                linewidth=2,
                label=ses,
            )

            # Stagger labels by session so values at similar heights remain legible.
            offsets = [
                8,
                -14,
                18,
            ]

            yoff = offsets[
                s_idx
                % len(offsets)
            ]

            for xi, val in zip(
                x,
                vals,
            ):
                ax.annotate(
                    f"{val:.3f}",
                    (
                        xi,
                        val,
                    ),
                    xytext=(
                        0,
                        yoff,
                    ),
                    textcoords="offset points",
                    ha="center",
                    va=(
                        "bottom"
                        if yoff >= 0
                        else "top"
                    ),
                    fontsize=7,
                    color=line.get_color(),
                    bbox=dict(
                        facecolor="white",
                        alpha=0.70,
                        edgecolor="none",
                        pad=0.5,
                    ),
                )

        all_vals = finite_values(
            all_vals
        )

        if all_vals.size:
            span = max(
                float(
                    all_vals.max()
                    - all_vals.min()
                ),
                0.01,
            )

            pad = max(
                span * 0.22,
                0.01
                if key == "fsi_raw"
                else 0.08,
            )

            ax.set_ylim(
                float(
                    all_vals.min()
                    - pad
                ),
                float(
                    all_vals.max()
                    + pad
                ),
            )

        ax.yaxis.set_major_locator(
            MaxNLocator(
                nbins=7
            )
        )

        ax.set_xticks(
            x
        )

        ax.set_xticklabels(
            [
                c.replace(
                    "_",
                    " ",
                )
                for c in combos
            ],
            rotation=45,
            ha="right",
        )

        ax.set_ylabel(
            ylabel
        )

        ax.set_title(
            title,
            fontsize=13,
            fontweight="bold",
        )

        ax.grid(
            True,
            axis="y",
            alpha=0.3,
        )

        ax.legend(
            loc="center left",
            bbox_to_anchor=(
                1.02,
                0.5,
            ),
        )

        save_png_svg(
            fig,
            os.path.join(
                out_dir,
                fname,
            ),
        )

        plt.close(
            fig
        )


def plot_consistency_reference(
    contract,
    out_dir,
):
    """Summary of same-resolution test-retest agreement."""

    ref = contract[
        "test_retest_consistency_reference"
    ]

    metrics = [
        "pearson",
        "spearman",
        "icc",
        "cosine",
    ]

    values = [
        ref["metrics"][m]
        for m in metrics
    ]

    labels = [
        "Pearson",
        "Spearman",
        "ICC(2,1)",
        "Cosine",
    ]

    fig, ax = plt.subplots(
        figsize=(
            8,
            5,
        ),
        layout="constrained",
    )

    bars = ax.bar(
        labels,
        values,
        edgecolor="black",
        alpha=0.85,
    )

    ymin = min(
        -0.1,
        min(values) - 0.1,
    )

    ymax = max(
        1.05,
        max(values) + 0.12,
    )

    ax.set_ylim(
        ymin,
        ymax,
    )

    for bar, val in zip(
        bars,
        values,
    ):
        ax.text(
            bar.get_x()
            + bar.get_width()
            / 2,
            val,
            f"{val:.3f}",
            ha="center",
            va=(
                "bottom"
                if val >= 0
                else "top"
            ),
            fontsize=8,
            bbox=dict(
                facecolor="white",
                alpha=0.8,
                edgecolor="none",
                pad=0.5,
            ),
        )

    ax.axhline(
        0,
        color="black",
        linewidth=0.6,
    )

    ax.set_ylabel(
        "Agreement"
    )

    ax.set_title(
        "Single-participant same-resolution "
        "test-retest RDM consistency\n"
        f"{ref['sessions'][0]} vs "
        f"{ref['sessions'][1]} "
        f"({ref['combo']})",
        fontsize=11,
        fontweight="bold",
    )

    ax.yaxis.set_major_locator(
        MaxNLocator(
            nbins=7
        )
    )

    ax.grid(
        axis="y",
        alpha=0.3,
    )

    save_png_svg(
        fig,
        os.path.join(
            out_dir,
            "Fig_test_retest_consistency.png",
        ),
    )

    plt.close(
        fig
    )


def make_main_figures(
    contract,
    out_dir,
):
    os.makedirs(
        out_dir,
        exist_ok=True,
    )

    plot_rdm_grid(
        contract,
        "raw",
        "Raw Crossnobis RDMs (full run1-6 combo)",
        os.path.join(
            out_dir,
            "Fig_RDM_raw_full_combo.png",
        ),
        "Crossnobis distance",
    )

    plot_rdm_grid(
        contract,
        "vis01",
        (
            "Crossnobis RDMs normalized 0-1 "
            "within each session (full run1-6 combo)"
        ),
        os.path.join(
            out_dir,
            "Fig_RDM_norm01_full_combo.png",
        ),
        "Normalized distance",
    )

    plot_rdm_grid(
        contract,
        "mean_norm",
        (
            "Session-mean-normalized Crossnobis RDMs "
            "(full run1-6 combo)"
        ),
        os.path.join(
            out_dir,
            "Fig_RDM_mean_normalized_full_combo.png",
        ),
        "Raw distance / session off-diagonal mean",
    )

    plot_grand_mean_normalized_full_combo(
        contract,
        out_dir,
    )

    plot_all_combo_heatmaps(
        contract,
        out_dir,
    )

    plot_mds_all(
        contract,
        out_dir,
    )

    plot_fsi(
        contract,
        out_dir,
    )

    plot_consistency_reference(
        contract,
        out_dir,
    )

    print(
        f"[FIGURES] Main figures saved as PNG + SVG to {out_dir}"
    )
