"""FSI summaries and ROI/resolution/group table."""
from __future__ import annotations
import pandas as pd

def table(records, combo="run1-6"):
    rows=[]
    for p,o in records:
        rows.append({"subject":o['subject_id'],"session":o['session_id'],"roi":o['roi']['name'],"roi_family":o['roi']['family'],"roi_version":o['roi']['version'],"resolution_mm":o['acquisition'].get('resolution_mm',''),"group":o['acquisition'].get('group',''),"instrument":o['acquisition'].get('instrument',''),"fsi_raw":o['fsi_raw'][combo],"n_valid_voxels":o['qc']['n_valid_voxels'],"source":str(p)})
    return pd.DataFrame(rows)
