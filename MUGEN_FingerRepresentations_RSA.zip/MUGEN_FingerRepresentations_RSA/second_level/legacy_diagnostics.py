
#!/usr/bin/env python3
from __future__ import annotations
import numpy as np
from second_level.legacy_metrics import metric_functions, upper_vec

INDEPENDENT_SPLITS={
    "first_half_vs_second_half":("run1-3","run4-6"),
    "odd_vs_even":("odd_runs-1-3-5","even_runs-2-4-6"),
}
RUNS_BY_COMBO={
    "run1-3":[1,2,3],
    "run4-6":[4,5,6],
    "odd_runs-1-3-5":[1,3,5],
    "even_runs-2-4-6":[2,4,6],
}
METRICS=("pearson","spearman","fisherz","icc","cosine")

def _raw(obj):
    if isinstance(obj,dict) and "raw" in obj:
        return np.asarray(obj["raw"],dtype=float)
    return np.asarray(obj,dtype=float)

def _mean_rdm(mats):
    return np.mean(np.stack([np.asarray(x,dtype=float) for x in mats]),axis=0)

def compute_between_session(rdms,session_ids,combos):
    funcs=metric_functions()
    out={}
    for combo in combos:
        out[combo]={metric:{} for metric in funcs}
        for i,sa in enumerate(session_ids):
            for sb in session_ids[i+1:]:
                a=upper_vec(_raw(rdms[sa][combo]))
                b=upper_vec(_raw(rdms[sb][combo]))
                pair=f"{sa}_vs_{sb}"
                for metric,fn in funcs.items():
                    out[combo][metric][pair]=float(fn(a,b))
    return out

def compute_independent_split_reliability(rdms,session_ids,splits=INDEPENDENT_SPLITS):
    funcs=metric_functions()
    result={}
    for session in session_ids:
        result[session]={}
        for split_name,(combo_a,combo_b) in splits.items():
            runs_a=RUNS_BY_COMBO[combo_a]
            runs_b=RUNS_BY_COMBO[combo_b]
            if set(runs_a)&set(runs_b):
                raise ValueError(f"Overlapping independent split: {split_name}")
            a=upper_vec(_raw(rdms[session][combo_a]))
            b=upper_vec(_raw(rdms[session][combo_b]))
            item={
                "combo_a":combo_a,
                "combo_b":combo_b,
                "runs_a":list(runs_a),
                "runs_b":list(runs_b),
                "interpretation":"Disjoint-run reliability estimate; no run contributes to both RDMs.",
            }
            for metric,fn in funcs.items():
                item[metric]=float(fn(a,b))
            result[session][split_name]=item
    return result

def compute_session_consistency_components(rdms,session_ids,combo,metrics=METRICS):
    funcs=metric_functions()
    mats={s:_raw(rdms[s][combo]) for s in session_ids}
    overall=_mean_rdm(list(mats.values()))
    result={
        "combo":combo,
        "session_ids":list(session_ids),
        "metrics":{},
        "type":"single_participant_cross_session_representational_consistency_components",
        "interpretation":(
            "Exploratory session-based consistency components for one participant. "
            "The lower component compares each session with the mean of the other "
            "sessions; the upper component compares each session with the overall "
            "session mean. These values are not a standard participant-level RSA "
            "noise ceiling and do not constitute a formal bound on model fit."
        ),
    }
    for metric in metrics:
        fn=funcs[metric]
        leave_one_out={}
        versus_overall={}
        for s in session_ids:
            others=[mats[x] for x in session_ids if x!=s]
            if not others:
                raise ValueError("At least two sessions are required.")
            loo_mean=_mean_rdm(others)
            session_vec=upper_vec(mats[s])
            leave_one_out[s]=float(fn(session_vec,upper_vec(loo_mean)))
            versus_overall[s]=float(fn(session_vec,upper_vec(overall)))
        lower_values=np.asarray(list(leave_one_out.values()),dtype=float)
        upper_values=np.asarray(list(versus_overall.values()),dtype=float)
        lower_mean=float(np.nanmean(lower_values))
        upper_mean=float(np.nanmean(upper_values))
        result["metrics"][metric]={
            "leave_one_session_out":leave_one_out,
            "versus_overall_session_mean":versus_overall,
            "lower_component_mean":lower_mean,
            "upper_component_mean":upper_mean,
            "display_interval_low":float(min(lower_mean,upper_mean)),
            "display_interval_high":float(max(lower_mean,upper_mean)),
            "n_sessions":int(len(session_ids)),
        }
    return result

def compute_same_resolution_reference(rdms,session_a,session_b,combo):
    funcs=metric_functions()
    a=upper_vec(_raw(rdms[session_a][combo]))
    b=upper_vec(_raw(rdms[session_b][combo]))
    return {
        "type":"single_participant_same_resolution_test_retest_reference",
        "sessions":[session_a,session_b],
        "combo":combo,
        "metrics":{k:float(fn(a,b)) for k,fn in funcs.items()},
        "interpretation":"Primary same-resolution test-retest reference for one participant; not a group noise ceiling.",
    }

def build_consistency_package(rdms,session_ids,full_combo_label,test_retest_sessions=("ses19","ses20")):
    return {
        "original_session_components":compute_session_consistency_components(
            rdms,session_ids,full_combo_label,metrics=METRICS
        ),
        "same_resolution_reference":compute_same_resolution_reference(
            rdms,test_retest_sessions[0],test_retest_sessions[1],full_combo_label
        ),
        "standard_group_noise_ceiling":{
            "status":"not_estimated",
            "reason":(
                "A standard RSA model-fitting noise ceiling requires multiple "
                "independent participants or equivalent independent sampling units."
            ),
        },
    }

