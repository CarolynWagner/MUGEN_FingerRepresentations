#!/usr/bin/env python3
"""Aggregate arbitrary first-level objects for session/subject/ROI comparisons."""
from __future__ import annotations
import argparse
from pathlib import Path
from shared.constants import *
from shared.io import atomic_pickle
from second_level.collect import collect
from second_level.pairwise import compare
from second_level.noise_ceiling import compute as group_ceiling
from second_level.fsi import table as fsi_table
from second_level.schema import validate
from second_level.report import write_report
from second_level.figures import make_figures

def main():
    p=argparse.ArgumentParser(); p.add_argument('inputs',nargs='+',help='rsa_firstlevel.pkl files and/or directories'); p.add_argument('--out-dir',default='derivatives/rsa_second_level'); p.add_argument('--combo',default=FULL_COMBO_LABEL); p.add_argument('--min-subjects-noise-ceiling',type=int,default=3); p.add_argument('--no-figures',action='store_true'); a=p.parse_args()
    rec=collect(a.inputs); pairwise=compare(rec,a.combo); ceiling=group_ceiling(rec,a.combo,a.min_subjects_noise_ceiling); fsi=fsi_table(rec,a.combo)
    obj={"schema_version":SCHEMA_VERSION_SECOND_LEVEL,"pipeline_version":PIPELINE_VERSION,"analysis_level":"second_level_comparison","inputs":[str(p) for p,_ in rec],"pairwise":pairwise,"group_noise_ceiling":ceiling,"fsi_table":fsi.to_dict(orient='records'),"full_combo_label":a.combo}
    validate(obj); out=Path(a.out_dir); out.mkdir(parents=True,exist_ok=True); atomic_pickle(obj,out/'rsa_secondlevel.pkl'); fsi.to_csv(out/'fsi_table.csv',index=False); write_report(obj,out/'secondlevel_report.txt');
    if not a.no_figures: make_figures(obj,out/'figures')
    print(f"[SECOND LEVEL] complete: {out}")
if __name__=='__main__': main()
