"""Second-level figures."""
from __future__ import annotations
from pathlib import Path
import pandas as pd
import numpy as np
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt

def _save(fig,path): path=Path(path); path.parent.mkdir(parents=True,exist_ok=True); fig.savefig(path,dpi=200,bbox_inches='tight'); fig.savefig(path.with_suffix('.svg'),bbox_inches='tight'); plt.close(fig)

def make_figures(obj,out_dir):
    out=Path(out_dir); out.mkdir(parents=True,exist_ok=True)
    df=pd.DataFrame(obj['fsi_table'])
    if not df.empty:
        labels=[f"{r.subject}\n{r.session}\n{r.roi}" for r in df.itertuples()]; y=df['fsi_raw'].astype(float).to_numpy(); fig,ax=plt.subplots(figsize=(max(8,.6*len(df)),5),layout='constrained'); ax.bar(range(len(y)),y); ax.set_xticks(range(len(y)),labels,rotation=45,ha='right',fontsize=7); ax.set_ylabel('FSI raw'); ax.set_title('First-level FSI summary'); _save(fig,out/'FSI_summary.png')
    pairs=pd.DataFrame(obj['pairwise'])
    if not pairs.empty:
        for kind,g in pairs.groupby('comparison_type'):
            fig,ax=plt.subplots(figsize=(max(8,.65*len(g)),5),layout='constrained'); x=np.arange(len(g)); ax.bar(x,g['pearson']); lab=[f"{a}/{sa}/{ra}\n{b}/{sb}/{rb}" for a,sa,ra,b,sb,rb in zip(g.subject_a,g.session_a,g.roi_a,g.subject_b,g.session_b,g.roi_b)]; ax.set_xticks(x,lab,rotation=45,ha='right',fontsize=6); ax.set_ylim(-1.05,1.05); ax.set_ylabel('Pearson r'); ax.set_title(kind.replace('_',' ')); ax.axhline(0,color='black',lw=.5); _save(fig,out/f"pairwise_{kind}.png")
