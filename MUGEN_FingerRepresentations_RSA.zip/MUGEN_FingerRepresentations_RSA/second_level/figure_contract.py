#!/usr/bin/env python3
"""
second_level/figure_contract.py

Adapter from generalized RSA v11 first-/second-level outputs to the plotting
contract expected by the frozen v10.3 publication-figure modules.

This does not alter any RSA estimate. It assembles already-computed quantities
and adds exact condition-label permutation inference needed by the legacy
permutation/FDR figure.
"""

from __future__ import annotations

from itertools import permutations
from pathlib import Path
import pickle

import numpy as np

from second_level.legacy_metrics import metric_functions, upper_vec


METRICS = ("pearson", "spearman", "fisherz", "icc", "cosine")


def load_pickle(path):
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(path)
    with path.open("rb") as f:
        return pickle.load(f)


def _session_id(obj, path):
    value = obj.get("session_id") or obj.get("session")
    if value:
        return str(value)

    for part in Path(path).parts:
        if part.startswith("ses"):
            return part

    raise KeyError(f"Cannot determine session ID for {path}")


def _rdms(obj, session_id):
    rdms = obj.get("rdms")
    if not isinstance(rdms, dict):
        raise KeyError(f"{session_id}: first-level object has no rdms dictionary")

    if session_id in rdms and isinstance(rdms[session_id], dict):
        return rdms[session_id]

    return rdms


def _normalize_fsi_across_sessions(fsi_raw, session_ids, combos):
    normalized = {s: {} for s in session_ids}
    details = {}

    for combo in combos:
        raw = np.asarray(
            [float(fsi_raw[s][combo]) for s in session_ids],
            dtype=float,
        )
        denom = float(np.mean(raw))

        if not np.isfinite(denom) or abs(denom) < 1e-12:
            denom = 1.0
            warning = "Near-zero/non-finite denominator replaced by 1.0."
        else:
            warning = None

        for s in session_ids:
            normalized[s][combo] = float(fsi_raw[s][combo] / denom)

        details[combo] = {
            "normalization": "raw_fsi_divided_by_mean_raw_fsi_across_sessions_for_this_combo",
            "mean_raw_fsi_across_sessions": denom,
            "denominator_used": denom,
            "sessions": list(session_ids),
            "raw_values": {s: float(fsi_raw[s][combo]) for s in session_ids},
            "normalized_values": {s: normalized[s][combo] for s in session_ids},
            "warning": warning,
        }

    return normalized, details


def _exact_condition_label_permutation_test(rdm_a, rdm_b, metric):
    a = np.asarray(rdm_a, dtype=np.float64)
    b = np.asarray(rdm_b, dtype=np.float64)

    if a.shape != b.shape or a.ndim != 2 or a.shape[0] != a.shape[1]:
        raise ValueError(f"RDM shape mismatch: {a.shape} vs {b.shape}")

    fn = metric_functions()[metric]

    observed = float(fn(upper_vec(a), upper_vec(b)))
    null = []

    for perm in permutations(range(a.shape[0])):
        p = np.asarray(perm, dtype=int)
        bp = b[np.ix_(p, p)]
        value = fn(upper_vec(a), upper_vec(bp))
        if np.isfinite(value):
            null.append(float(value))

    null = np.asarray(null, dtype=float)

    p_value = (
        float(np.mean(np.abs(null) >= abs(observed) - 1e-12))
        if null.size
        else 1.0
    )

    return {
        "observed": observed,
        "p_value": p_value,
        "null_mean": float(np.mean(null)) if null.size else 0.0,
        "null_std": float(np.std(null)) if null.size else 0.0,
        "n_permutations": int(null.size),
        "method": "exact simultaneous condition-label permutation of rows and columns",
    }


def _fdr_bh(pvals, q=0.05):
    if not pvals:
        return []

    p = np.asarray(pvals, dtype=float)
    p[~np.isfinite(p)] = 1.0

    order = np.argsort(p)
    ranked = p[order]
    passed = ranked <= q * np.arange(1, len(p) + 1) / len(p)

    out = np.zeros(len(p), dtype=bool)

    if np.any(passed):
        cutoff = ranked[np.where(passed)[0].max()]
        out = p <= cutoff

    return out.tolist()


def _fdr_bh_adjusted_pvalues(pvals):
    if not pvals:
        return []

    p = np.asarray(pvals, dtype=float)
    p[~np.isfinite(p)] = 1.0

    m = len(p)
    order = np.argsort(p)
    ranked = p[order]

    adjusted_ranked = ranked * m / np.arange(1, m + 1, dtype=float)
    adjusted_ranked = np.minimum.accumulate(adjusted_ranked[::-1])[::-1]
    adjusted_ranked = np.clip(adjusted_ranked, 0.0, 1.0)

    adjusted = np.empty_like(adjusted_ranked)
    adjusted[order] = adjusted_ranked

    return adjusted.tolist()


def _build_permutation_certification(rdms, between_session, session_ids, combos):
    permutation_tests = {}
    labels = []
    pvals = []

    for combo in combos:
        permutation_tests[combo] = {}

        pairs = list(
            between_session.get(combo, {})
            .get("pearson", {})
            .keys()
        )

        for pair in pairs:
            s1, s2 = pair.split("_vs_")
            permutation_tests[combo][pair] = {}

            for metric in METRICS:
                result = _exact_condition_label_permutation_test(
                    rdms[s1][combo]["raw"],
                    rdms[s2][combo]["raw"],
                    metric,
                )

                permutation_tests[combo][pair][metric] = result

                labels.append({
                    "combo": combo,
                    "pair": pair,
                    "metric": metric,
                })
                pvals.append(result["p_value"])

    fdr_mask = _fdr_bh(pvals)
    qvals = _fdr_bh_adjusted_pvalues(pvals)

    fdr_results = [
        {
            **label,
            "p_value": float(p),
            "fdr_q_value": float(qv),
            "fdr_significant_q05": bool(sig),
            "permutation_unit": "condition labels",
        }
        for label, p, qv, sig
        in zip(labels, pvals, qvals, fdr_mask)
    ]

    return {
        "permutation_tests": permutation_tests,
        "fdr_results": fdr_results,
        "permutation_mode": "exact_condition_labels",
        "n_condition_label_permutations": 120,
    }


def build_figure_contract(secondlevel_pkl):
    secondlevel_pkl = Path(secondlevel_pkl)
    second = load_pickle(secondlevel_pkl)

    inputs = second.get("inputs")
    if not isinstance(inputs, list) or not inputs:
        raise ValueError(
            "Second-level contract has no first-level `inputs` list."
        )

    first_by_session = {}

    for path in inputs:
        obj = load_pickle(path)
        sid = _session_id(obj, path)
        first_by_session[sid] = obj

    session_ids = sorted(
        first_by_session,
        key=lambda s: (
            int(s[3:])
            if s.startswith("ses") and s[3:].isdigit()
            else s
        ),
    )

    first0 = first_by_session[session_ids[0]]

    finger_names = list(first0["finger_names"])
    run_combos = dict(first0["run_combos"])
    combos = list(run_combos.keys())
    full_combo = str(first0.get("full_combo_label", second.get("full_combo_label", "run1-6")))

    rdms = {
        s: _rdms(first_by_session[s], s)
        for s in session_ids
    }

    fsi_raw = {
        s: {
            combo: float(first_by_session[s]["fsi_raw"][combo])
            for combo in combos
        }
        for s in session_ids
    }

    fsi_normalized, fsi_norm_details = _normalize_fsi_across_sessions(
        fsi_raw,
        session_ids,
        combos,
    )

    within_session = {}

    for s in session_ids:
        item = first_by_session[s].get("run_subset_stability")
        if not isinstance(item, dict):
            raise KeyError(
                f"{s}: missing first-level run_subset_stability required "
                "for Fig_within_session_corr_*"
            )
        within_session[s] = item

    between_session = second.get("between_session")
    if not isinstance(between_session, dict):
        raise KeyError(
            "Second-level contract has no restored between_session dictionary. "
            "Run second_level.augment_legacy_diagnostics first."
        )

    session_consistency = second.get("session_consistency")
    test_retest = second.get("test_retest_consistency_reference")

    if not isinstance(session_consistency, dict):
        raise KeyError(
            "Second-level contract has no session_consistency. "
            "Run second_level.augment_legacy_diagnostics first."
        )

    if not isinstance(test_retest, dict):
        raise KeyError(
            "Second-level contract has no test_retest_consistency_reference."
        )

    certification = _build_permutation_certification(
        rdms,
        between_session,
        session_ids,
        combos,
    )

    contract = {
        "schema_version": "finger_rsa_figure_contract_v11.0",
        "pipeline_version": second.get(
            "pipeline_version",
            "v11.0-generalized-crossnobis",
        ),
        "analysis_level": "publication_figure_contract",
        "subject_id": first0.get("subject_id"),
        "roi": first0.get("roi"),
        "finger_names": finger_names,
        "run_combos": run_combos,
        "full_combo_label": full_combo,
        "session_ids": session_ids,
        "rdms": rdms,
        "within_session": within_session,
        "between_session": between_session,
        "fsi_raw": fsi_raw,
        "fsi_normalized": fsi_normalized,
        "fsi_norm_details": fsi_norm_details,
        "independent_split_reliability": second.get(
            "independent_split_reliability",
            {
                s: first_by_session[s].get("independent_split_reliability", {})
                for s in session_ids
            },
        ),
        "session_consistency": session_consistency,
        "test_retest_consistency_reference": test_retest,
        "noise_ceiling": second.get("noise_ceiling"),
        "certification": certification,
        "source_secondlevel": str(secondlevel_pkl),
        "source_firstlevel": {
            s: str(inputs[session_ids.index(s)])
            for s in session_ids
        },
    }

    return contract


def save_figure_contract(contract, output_path):
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    with output_path.open("wb") as f:
        pickle.dump(
            contract,
            f,
            protocol=pickle.HIGHEST_PROTOCOL,
        )

    return output_path
