"""Second-level contract validation."""
from shared.constants import SCHEMA_VERSION_SECOND_LEVEL

def validate(obj):
    req=['schema_version','pipeline_version','analysis_level','inputs','pairwise','group_noise_ceiling','fsi_table','full_combo_label']
    for k in req:
        if k not in obj: raise KeyError(f"Missing second-level key: {k}")
    if obj['schema_version']!=SCHEMA_VERSION_SECOND_LEVEL: raise ValueError('Wrong second-level schema')
    if obj['analysis_level']!='second_level_comparison': raise ValueError('Wrong analysis level')
    return True
