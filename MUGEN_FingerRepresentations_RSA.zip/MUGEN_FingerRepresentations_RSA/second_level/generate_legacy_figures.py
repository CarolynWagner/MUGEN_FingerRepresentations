#!/usr/bin/env python3
"""
second_level/generate_legacy_figures.py

Generate the publication/diagnostic figure suite from a generalized v11
rsa_secondlevel.pkl using the validated v10.3 plotting definitions.
"""

from __future__ import annotations

import argparse
from pathlib import Path

from second_level.figure_contract import (
    build_figure_contract,
    save_figure_contract,
)
from second_level.figures_main import make_main_figures
from second_level.figures_inference import make_inference_figures
from second_level.figure_output_qc import run_qc


EXPECTED_STEMS = [
    "Fig_RDM_raw_full_combo",
    "Fig_RDM_norm01_full_combo",
    "Fig_RDM_mean_normalized_full_combo",
    "Fig_RDM_grand_mean_normalized_full_combo",
    "Fig_RDM_grand_mean_normalized_01_full_combo",
    "Fig_between_session_pearson",
    "Fig_between_session_spearman",
    "Fig_between_session_fisherz",
    "Fig_between_session_icc",
    "Fig_between_session_cosine",
    "Fig_permutation_fdr_summary",
]


def main():
    p = argparse.ArgumentParser()
    p.add_argument("secondlevel_pkl")
    p.add_argument(
        "--out-dir",
        default=None,
        help=(
            "Figure directory. Default: <second-level directory>/figures"
        ),
    )
    p.add_argument(
        "--figure-contract-out",
        default=None,
        help=(
            "Optional figure-contract pickle path. "
            "Default: <second-level directory>/rsa_figure_contract.pkl"
        ),
    )
    p.add_argument(
        "--no-qc",
        action="store_true",
    )
    args = p.parse_args()

    secondlevel_pkl = Path(args.secondlevel_pkl).resolve()
    base = secondlevel_pkl.parent

    out_dir = (
        Path(args.out_dir).resolve()
        if args.out_dir
        else base / "figures"
    )

    figure_contract_out = (
        Path(args.figure_contract_out).resolve()
        if args.figure_contract_out
        else base / "rsa_figure_contract.pkl"
    )

    contract = build_figure_contract(
        secondlevel_pkl
    )

    save_figure_contract(
        contract,
        figure_contract_out,
    )

    make_main_figures(
        contract,
        str(out_dir),
    )

    make_inference_figures(
        contract,
        str(out_dir),
    )

    # Explicitly require the figures the user identified as essential.
    missing = []

    for stem in EXPECTED_STEMS:
        for suffix in (".png", ".svg"):
            path = out_dir / f"{stem}{suffix}"
            if not path.exists() or path.stat().st_size == 0:
                missing.append(str(path))

    # Session-specific MDS and within-session correlation figures are also
    # required for every selected session.
    for session in contract["session_ids"]:
        for stem in (
            f"Fig_MDS_all_combos_{session}",
            f"Fig_within_session_corr_{session}",
        ):
            for suffix in (".png", ".svg"):
                path = out_dir / f"{stem}{suffix}"
                if not path.exists() or path.stat().st_size == 0:
                    missing.append(str(path))

    if missing:
        print("\n[FIGURES] Missing required outputs:")
        for path in missing:
            print(f"  - {path}")
        raise SystemExit(1)

    if not args.no_qc:
        qc_code = run_qc(out_dir)
        if qc_code != 0:
            raise SystemExit(qc_code)

    print()
    print("[FIGURES] Required legacy publication figures generated.")
    print(f"[FIGURES] Figure directory: {out_dir}")
    print(f"[FIGURES] Figure contract:  {figure_contract_out}")


if __name__ == "__main__":
    main()
