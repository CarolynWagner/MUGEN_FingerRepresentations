"""Collect validated first-level objects."""
from __future__ import annotations
from pathlib import Path
from shared.io import load_pickle
from first_level.schema import validate as validate_first

def collect(inputs):
    paths=[]
    for item in inputs:
        p=Path(item)
        paths.extend(sorted(p.rglob("rsa_firstlevel.pkl")) if p.is_dir() else [p])
    records=[]
    for p in paths:
        obj=load_pickle(p); validate_first(obj); records.append((p,obj))
    if not records: raise ValueError("No rsa_firstlevel.pkl files found")
    return records
