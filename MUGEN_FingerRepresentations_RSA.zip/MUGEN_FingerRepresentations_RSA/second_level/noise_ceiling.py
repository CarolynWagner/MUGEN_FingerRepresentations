"""Genuine group RSA noise ceiling across independent participants."""
from __future__ import annotations
from collections import defaultdict
import numpy as np
from shared.metrics import upper_vec, metric_functions

def compute(records, combo="run1-6", min_subjects=3):
    groups=defaultdict(list)
    for _,o in records:
        key=(o['session_id'],o['roi']['name'])
        groups[key].append(o)
    out=[]
    funcs=metric_functions()
    for (session,roi),objs in groups.items():
        subjects={o['subject_id'] for o in objs}
        if len(subjects)<min_subjects: continue
        # refuse duplicate subject entries within a session/ROI cell
        if len(subjects)!=len(objs): raise ValueError(f"Duplicate subject in group-noise-ceiling cell {session}/{roi}")
        mats=[np.asarray(o['rdms'][combo]['raw'],float) for o in objs]
        overall=np.mean(mats,axis=0)
        for metric,fn in funcs.items():
            lower=[]; upper=[]
            for i,m in enumerate(mats):
                loo=np.mean([x for j,x in enumerate(mats) if j!=i],axis=0)
                lower.append(float(fn(upper_vec(m),upper_vec(loo))))
                upper.append(float(fn(upper_vec(m),upper_vec(overall))))
            out.append({"session":session,"roi":roi,"combo":combo,"metric":metric,"n_subjects":len(objs),"lower_mean":float(np.mean(lower)),"upper_mean":float(np.mean(upper)),"lower_by_subject":lower,"upper_by_subject":upper,"type":"standard_group_rsa_noise_ceiling"})
    return out
