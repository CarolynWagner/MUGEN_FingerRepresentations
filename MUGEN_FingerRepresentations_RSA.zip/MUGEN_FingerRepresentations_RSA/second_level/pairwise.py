"""Pairwise RDM comparisons across sessions, subjects, and ROIs."""
from __future__ import annotations
from itertools import combinations
from shared.metrics import upper_vec, metric_functions

def _metrics(a,b): return {k:float(fn(upper_vec(a),upper_vec(b))) for k,fn in metric_functions().items()}

def compare(records, combo="run1-6"):
    rows=[]
    for (_,a),(_,b) in combinations(records,2):
        same_subject=a['subject_id']==b['subject_id']; same_session=a['session_id']==b['session_id']; same_roi=a['roi']['name']==b['roi']['name']
        if same_subject and same_roi and not same_session: kind='within_subject_across_sessions'
        elif same_session and same_roi and not same_subject: kind='between_subject_same_session_roi'
        elif same_subject and same_session and not same_roi: kind='within_subject_roi_comparison'
        else: kind='other_pairwise'
        r={"comparison_type":kind,"subject_a":a['subject_id'],"session_a":a['session_id'],"roi_a":a['roi']['name'],"subject_b":b['subject_id'],"session_b":b['session_id'],"roi_b":b['roi']['name'],"combo":combo}
        r.update(_metrics(a['rdms'][combo]['raw'],b['rdms'][combo]['raw'])); rows.append(r)
    return rows
