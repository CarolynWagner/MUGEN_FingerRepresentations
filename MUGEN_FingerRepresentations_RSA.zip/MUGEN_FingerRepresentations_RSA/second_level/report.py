"""Second-level report."""
from __future__ import annotations

def write_report(obj,path):
    with open(path,'w') as f:
        f.write('SECOND-LEVEL RSA REPORT\n'+'='*78+'\n')
        f.write(f"First-level inputs: {len(obj['inputs'])}\nPairwise comparisons: {len(obj['pairwise'])}\nGroup noise-ceiling rows: {len(obj['group_noise_ceiling'])}\n\n")
        f.write('PAIRWISE RDM SIMILARITY\n'+'-'*78+'\n')
        for r in obj['pairwise']:
            f.write(f"{r['comparison_type']}: {r['subject_a']}/{r['session_a']}/{r['roi_a']} vs {r['subject_b']}/{r['session_b']}/{r['roi_b']} | Pearson={r['pearson']:.4f}, Spearman={r['spearman']:.4f}, ICC={r['icc']:.4f}, cosine={r['cosine']:.4f}\n")
        f.write('\nGROUP NOISE CEILINGS\n'+'-'*78+'\n')
        if not obj['group_noise_ceiling']: f.write('Not estimated: no session/ROI cell had the required number of independent participants.\n')
        for r in obj['group_noise_ceiling']: f.write(f"{r['session']} {r['roi']} {r['metric']}: lower={r['lower_mean']:.4f}, upper={r['upper_mean']:.4f}, N={r['n_subjects']}\n")
