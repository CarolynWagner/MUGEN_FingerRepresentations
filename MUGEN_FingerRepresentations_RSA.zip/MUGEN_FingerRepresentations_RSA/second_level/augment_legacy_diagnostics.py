
#!/usr/bin/env python3
"""
second_level/augment_legacy_diagnostics.py

Augments v11 rsa_secondlevel.pkl with the validated legacy v10.3 diagnostic
contract, using the already-certified v11 first-level outputs.

Key points:
- Session IDs are read from first-level key `session_id`.
- RDMs are read from first-level key `rdms`.
- `independent_split_reliability` is copied directly from each certified
  first-level pickle rather than recomputed.
- Between-session and session-consistency quantities are computed from the
  certified first-level raw RDMs using frozen metric definitions.
"""

from __future__ import annotations

import argparse
import os
import pickle
import tempfile
from pathlib import Path

from second_level.legacy_diagnostics import (
    compute_between_session,
    build_consistency_package,
)


def load_pickle(path):
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(path)
    with path.open("rb") as f:
        return pickle.load(f)


def atomic_pickle(obj, path):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)

    fd, tmp = tempfile.mkstemp(
        prefix=path.name + ".tmp.",
        dir=str(path.parent),
    )
    os.close(fd)

    try:
        with open(tmp, "wb") as f:
            pickle.dump(obj, f, protocol=pickle.HIGHEST_PROTOCOL)
        os.replace(tmp, path)
    except Exception:
        try:
            os.remove(tmp)
        except OSError:
            pass
        raise


def get_session_id(obj, path):
    for key in ("session_id", "session"):
        value = obj.get(key)
        if value:
            return str(value)

    for part in Path(path).parts:
        if part.startswith("ses"):
            return part

    raise KeyError(f"Cannot determine session ID for {path}")


def get_rdms(obj, session_id):
    rdms = obj.get("rdms")
    if not isinstance(rdms, dict):
        raise KeyError(f"{session_id}: missing top-level rdms dictionary")

    # v11 first-level schema is rdms[combo].
    # Keep compatibility with session-nested variants.
    if session_id in rdms and isinstance(rdms[session_id], dict):
        return rdms[session_id]

    return rdms


def ordered_common_combos(rdms_by_session):
    preferred = [
        "run1-2",
        "run1-3",
        "run1-4",
        "run1-5",
        "run1-6",
        "run1_and_3",
        "run4-6",
        "odd_runs-1-3-5",
        "even_runs-2-4-6",
    ]

    sessions = list(rdms_by_session)
    common = set(rdms_by_session[sessions[0]])

    for session in sessions[1:]:
        common &= set(rdms_by_session[session])

    ordered = [combo for combo in preferred if combo in common]
    ordered.extend(sorted(common - set(ordered)))
    return ordered


def main():
    p = argparse.ArgumentParser()
    p.add_argument("secondlevel_pkl")
    p.add_argument(
        "--test-retest-sessions",
        nargs=2,
        default=("ses19", "ses20"),
    )
    p.add_argument("--backup", action="store_true")
    args = p.parse_args()

    secondlevel_path = Path(args.secondlevel_pkl)
    contract = load_pickle(secondlevel_path)

    inputs = contract.get("inputs")
    if not isinstance(inputs, list) or len(inputs) < 2:
        raise ValueError(
            "rsa_secondlevel.pkl does not contain the expected `inputs` list."
        )

    rdms_by_session = {}
    independent_by_session = {}
    source_firstlevel = {}

    for input_path in inputs:
        first = load_pickle(input_path)
        session_id = get_session_id(first, input_path)

        if session_id in rdms_by_session:
            raise ValueError(f"Duplicate session: {session_id}")

        rdms_by_session[session_id] = get_rdms(first, session_id)

        independent = first.get("independent_split_reliability")
        if not isinstance(independent, dict):
            raise KeyError(
                f"{session_id}: missing first-level "
                "`independent_split_reliability`"
            )

        independent_by_session[session_id] = independent
        source_firstlevel[session_id] = str(input_path)

    session_ids = sorted(
        rdms_by_session,
        key=lambda s: (
            int(s[3:])
            if s.startswith("ses") and s[3:].isdigit()
            else s
        ),
    )

    combos = ordered_common_combos(rdms_by_session)

    if not combos:
        raise RuntimeError("No common RDM run combinations across sessions.")

    full_combo = contract.get("full_combo_label", "run1-6")
    if full_combo not in combos:
        raise KeyError(
            f"Full run combination {full_combo!r} is missing from one or more sessions."
        )

    for session in args.test_retest_sessions:
        if session not in rdms_by_session:
            raise KeyError(
                f"Requested test-retest session {session!r} is absent."
            )

    consistency = build_consistency_package(
        rdms_by_session,
        session_ids,
        full_combo,
        tuple(args.test_retest_sessions),
    )

    additions = {
        "between_session": compute_between_session(
            rdms_by_session,
            session_ids,
            combos,
        ),
        # Copy directly from the certified first-level outputs.
        "independent_split_reliability": independent_by_session,
        "session_consistency": consistency,
        "test_retest_consistency_reference":
            consistency["same_resolution_reference"],
        "noise_ceiling":
            consistency["standard_group_noise_ceiling"],
        "legacy_diagnostics_contract": {
            "status": "restored_from_certified_v11_firstlevel_outputs",
            "source_firstlevel": source_firstlevel,
            "session_ids": session_ids,
            "run_combos": combos,
            "full_combo_label": full_combo,
            "independent_split_source":
                "copied_from_firstlevel.independent_split_reliability",
        },
    }

    if args.backup:
        backup = secondlevel_path.with_name(
            "rsa_secondlevel.pre_legacy_augmentation.pkl"
        )
        if not backup.exists():
            atomic_pickle(contract, backup)
            print(f"[AUGMENT] backup: {backup}")

    contract.update(additions)
    atomic_pickle(contract, secondlevel_path)

    print(f"[AUGMENT] updated: {secondlevel_path}")
    for key in additions:
        print(f"[AUGMENT] added: {key}")


if __name__ == "__main__":
    main()



