
#!/usr/bin/env python3
from __future__ import annotations
import numpy as np

EPS = 1e-12

def finite_1d(x):
    x = np.asarray(x, dtype=np.float64).ravel()
    return x[np.isfinite(x)]

def paired_finite(v1, v2):
    v1 = np.asarray(v1, dtype=np.float64).ravel()
    v2 = np.asarray(v2, dtype=np.float64).ravel()
    n = min(v1.size, v2.size)
    v1 = v1[:n]
    v2 = v2[:n]
    ok = np.isfinite(v1) & np.isfinite(v2)
    return v1[ok], v2[ok]

def safe_std(x, ddof=0):
    x = finite_1d(x)
    if x.size <= ddof:
        return 0.0
    return float(np.std(x, ddof=ddof))

def rankdata_simple(x):
    x = np.asarray(x, dtype=np.float64)
    order = np.argsort(x, kind="mergesort")
    ranks = np.empty_like(order, dtype=np.float64)
    ranks[order] = np.arange(len(x), dtype=np.float64)
    _, inv, counts = np.unique(x, return_inverse=True, return_counts=True)
    if np.any(counts > 1):
        for k, count in enumerate(counts):
            if count > 1:
                ranks[inv == k] = np.mean(ranks[inv == k])
    return ranks

def upper_vec(raw_rdm):
    raw_rdm = np.asarray(raw_rdm, dtype=np.float64)
    return raw_rdm[np.triu_indices(raw_rdm.shape[0], k=1)]

def corr(v1, v2):
    v1, v2 = paired_finite(v1, v2)
    if v1.size <= 1:
        return 0.0
    if safe_std(v1) < EPS or safe_std(v2) < EPS:
        return 0.0
    r = np.corrcoef(v1, v2)[0, 1]
    return float(r) if np.isfinite(r) else 0.0

def spearman_corr(v1, v2):
    v1, v2 = paired_finite(v1, v2)
    if v1.size <= 1:
        return 0.0
    return corr(rankdata_simple(v1), rankdata_simple(v2))

def cosine_similarity(v1, v2):
    v1, v2 = paired_finite(v1, v2)
    if v1.size <= 1:
        return 0.0
    denom = np.linalg.norm(v1) * np.linalg.norm(v2)
    if denom < EPS:
        return 0.0
    value = np.dot(v1, v2) / denom
    return float(value) if np.isfinite(value) else 0.0

def icc_2_1(v1, v2):
    v1, v2 = paired_finite(v1, v2)
    if v1.size <= 1:
        return 0.0

    data = np.column_stack([v1, v2])
    n = int(data.shape[0])
    k = int(data.shape[1])

    grand_mean = data.mean()
    row_means = data.mean(axis=1)
    col_means = data.mean(axis=0)

    ss_rows = k * np.sum((row_means - grand_mean) ** 2)
    ss_cols = n * np.sum((col_means - grand_mean) ** 2)
    ss_total = np.sum((data - grand_mean) ** 2)
    ss_error = ss_total - ss_rows - ss_cols

    df_rows = n - 1
    df_cols = k - 1
    df_error = (n - 1) * (k - 1)

    if df_rows <= 0 or df_cols <= 0 or df_error <= 0:
        return 0.0

    ms_rows = ss_rows / df_rows
    ms_cols = ss_cols / df_cols
    ms_error = ss_error / df_error

    denom = (
        ms_rows
        + (k - 1) * ms_error
        + k * (ms_cols - ms_error) / n
    )

    if not np.isfinite(denom) or abs(denom) < EPS:
        return 0.0

    value = (ms_rows - ms_error) / denom
    return float(value) if np.isfinite(value) else 0.0

def fisherz(r):
    if not np.isfinite(r):
        return 0.0
    return float(np.arctanh(np.clip(r, -0.9999, 0.9999)))

def fisherz_metric(v1, v2):
    return fisherz(corr(v1, v2))

def metric_functions():
    return {
        "pearson": corr,
        "spearman": spearman_corr,
        "fisherz": fisherz_metric,
        "icc": icc_2_1,
        "cosine": cosine_similarity,
    }


