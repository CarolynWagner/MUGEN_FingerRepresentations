"""20_figure_output_qc.py

Post-generation figure-output QC.

Checks:
- every PNG has a matching SVG;
- every SVG has a matching PNG;
- PNG files are readable and non-empty;
- SVG files are non-empty and contain an <svg> root;
- reports unusually extreme aspect ratios as non-fatal warnings.

This script does not replace scientific visual inspection.
"""

from __future__ import annotations

import argparse
from pathlib import Path

from PIL import Image


def run_qc(figure_dir: Path) -> int:
    figure_dir = figure_dir.resolve()

    pngs = sorted(
        figure_dir.rglob("*.png")
    )

    svgs = sorted(
        figure_dir.rglob("*.svg")
    )

    issues = []
    warnings = []

    png_stems = {
        p.with_suffix("")
        for p in pngs
    }

    svg_stems = {
        p.with_suffix("")
        for p in svgs
    }

    for stem in sorted(
        png_stems - svg_stems
    ):
        issues.append(
            f"Missing SVG: {stem}.svg"
        )

    for stem in sorted(
        svg_stems - png_stems
    ):
        issues.append(
            f"Missing PNG: {stem}.png"
        )

    for png in pngs:
        if png.stat().st_size == 0:
            issues.append(
                f"Empty PNG: {png}"
            )
            continue

        try:
            with Image.open(png) as img:
                width, height = img.size
                img.verify()
        except Exception as exc:
            issues.append(
                f"Unreadable PNG: {png}: {exc}"
            )
            continue

        if height <= 0 or width <= 0:
            issues.append(
                f"Invalid PNG dimensions: {png}: {width}x{height}"
            )
            continue

        aspect = width / height

        # Wide multi-panel figures are intentional in this package.
        # Aspect ratio alone is not a rendering failure. Only very extreme
        # shapes are reported, and they are non-fatal warnings.
        if aspect > 8.0 or aspect < 0.125:
            warnings.append(
                f"Unusual aspect ratio ({aspect:.2f}): {png}"
            )

    for svg in svgs:
        if svg.stat().st_size == 0:
            issues.append(
                f"Empty SVG: {svg}"
            )
            continue

        try:
            head = svg.read_text(
                encoding="utf-8",
                errors="ignore",
            )[:5000]
        except Exception as exc:
            issues.append(
                f"Unreadable SVG: {svg}: {exc}"
            )
            continue

        if "<svg" not in head:
            issues.append(
                f"No <svg> root detected: {svg}"
            )

    print(
        f"Figure directory: {figure_dir}"
    )
    print(
        f"PNG files: {len(pngs)}"
    )
    print(
        f"SVG files: {len(svgs)}"
    )

    if warnings:
        print("\nQC WARNINGS (non-fatal):")
        for warning in warnings:
            print(
                f"  - {warning}"
            )

    if issues:
        print("\nQC ISSUES (fatal):")
        for issue in issues:
            print(
                f"  - {issue}"
            )
        return 1

    print(
        "\n[FIGURE QC] All fatal PNG/SVG pairing and readability "
        "checks passed."
    )

    return 0


if __name__ == "__main__":
    parser = argparse.ArgumentParser()

    parser.add_argument(
        "figure_dir",
        help="Root figure directory to validate.",
    )

    args = parser.parse_args()

    raise SystemExit(
        run_qc(
            Path(
                args.figure_dir
            )
        )
    )
