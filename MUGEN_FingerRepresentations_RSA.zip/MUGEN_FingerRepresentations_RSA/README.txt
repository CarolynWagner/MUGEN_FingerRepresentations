First-level figure patch v2

Adds to the previous first-level figure set:
- Session-mean-normalized full-combo Crossnobis RDM
- 2-D classical MDS of raw Crossnobis pattern distances for every run subset

The mean-normalized RDM is read from the stored locked RDM contract (`mean_norm`);
it is not recomputed. MDS is a visualization derived from stored raw RDMs and matches
the second-level classical-MDS convention (Crossnobis is treated as squared distance;
negative eigenvalues are truncated to zero for plotting).

Replace first_level/figures.py with the supplied file. Existing first-level runs will
automatically make the new figures. To regenerate figures from an existing pickle,
use generate_firstlevel_figures.py as before.
