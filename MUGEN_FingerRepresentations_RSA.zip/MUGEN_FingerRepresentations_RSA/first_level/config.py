"""First-level configuration namespace expected by frozen loaders."""
from types import SimpleNamespace
from shared import constants as C

def make_config(roi_name):
    return SimpleNamespace(
        N_RUNS_TOTAL=C.N_RUNS_TOTAL,
        N_FINGERS=C.N_FINGERS,
        N_COLS_PER_RUN=C.N_COLS_PER_RUN,
        FINGER_NAMES=C.FINGER_NAMES,
        ROI_NAME=roi_name,
        RUN_COMBOS=C.RUN_COMBOS,
        INDEPENDENT_SPLITS=C.INDEPENDENT_SPLITS,
        FULL_COMBO_LABEL=C.FULL_COMBO_LABEL,
        RESIDUAL_STD_EPS=C.RESIDUAL_STD_EPS,
        RANDOM_SEED=C.RANDOM_SEED,
    )
