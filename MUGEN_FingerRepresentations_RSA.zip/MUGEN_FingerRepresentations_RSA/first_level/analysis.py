"""General first-level RSA analysis for one subject x session x ROI."""
from __future__ import annotations
from pathlib import Path
import numpy as np
from shared.constants import *
from shared.roi_registry import normalize_roi_metadata
from shared.module_loader import load
from first_level.config import make_config
from first_level.schema import validate

loader = load("v11_loader01", "01_data_loader.py")
qcmod = load("v11_qc02", "02_preprocess_qc.py")
rdmc = load("v11_rdmc03", "03_rdm_contract.py")
core = load("v11_core04", "04_rsa_core.py")
stab = load("v11_stab05", "05_run_subset_stability.py")
indep = load("v11_indep06", "06_independent_reliability.py")
runinf = load("v11_runinf08", "08_run_level_inference.py")


def analyze_row(row, n_boot=N_RUN_PAIR_BOOTSTRAPS):
    row = dict(row)
    roi = normalize_roi_metadata(row)
    cfg = make_config(roi["name"])
    session_cfg = {"model_dir": row["model_dir"], "roi_path": row["roi_path"]}
    if str(row.get("residual_dof", "")).strip(): session_cfg["residual_dof"] = float(row["residual_dof"])
    x = loader.load_session_inputs(str(row["session"]), session_cfg, cfg)
    betas, residuals, valid_mask, qa = qcmod.clean_session_data(x["betas_full"], x["residuals"], residual_std_eps=cfg.RESIDUAL_STD_EPS)
    pi = core.compute_precision(residuals, dof=float(x["residual_dof"]), prefer_rsatoolbox=True)
    P = pi["precision"]
    rdms = {}
    for label, runs in cfg.RUN_COMBOS.items():
        pos = [r-1 for r in runs]
        raw = core.compute_crossnobis_rdm(betas[pos], cfg.FINGER_NAMES, runs, P, roi_name=roi["name"])
        rdms[label] = rdmc.create_rdm_contract(raw, str(row["session"]), label, runs, betas.shape[2], meta={"precision_method":pi["method"],"dof":float(x["residual_dof"]),"dof_source":x["residual_dof_source"]})
    nested = {str(row["session"]): rdms}
    combos = list(cfg.RUN_COMBOS)
    within = stab.compute_within_session(nested, str(row["session"]), combos)
    independent = indep.compute_independent_split_reliability(nested, [str(row["session"])], cfg.INDEPENDENT_SPLITS)[str(row["session"])]
    fsi = {c: stab.fsi_from_raw_rdm(rdms[c]["raw"]) for c in combos}
    draws, pairs = runinf.bootstrap_rdm_from_run_pairs(betas, P, int(n_boot), cfg.RANDOM_SEED)
    run_pair_contrib, run_pair_labels = runinf.run_pair_contributions(betas, P)
    uncertainty = {
        "fsi": runinf.summarize_fsi_bootstrap(draws),
        "balanced_splits_pearson": runinf.exhaustive_balanced_splits(betas, P, "pearson"),
        "run_pair_bootstrap_n": int(n_boot),
    }
    precision_info = {k:v for k,v in pi.items() if k != "precision"}
    precision_info.update({"dof":float(x["residual_dof"]),"dof_source":x["residual_dof_source"],"n_voxels":int(betas.shape[2]),"n_residual_timepoints":int(residuals.shape[0])})
    roi.update({"n_voxels_before_qc":int(qa["n_voxels_roi"]),"n_voxels_after_qc":int(qa["n_valid_voxels"])})
    out = {
        "schema_version": SCHEMA_VERSION_FIRST_LEVEL,
        "pipeline_version": PIPELINE_VERSION,
        "analysis_level": "first_level_subject_session_roi",
        "subject_id": str(row["subject"]), "session_id": str(row["session"]),
        "roi": roi,
        "acquisition": {"resolution_mm": str(row.get("resolution_mm", "")), "group": str(row.get("group", "")), "instrument": str(row.get("instrument", ""))},
        "source_paths": {"model_dir": str(row["model_dir"]), "roi_path": str(row["roi_path"])},
        "finger_names": list(cfg.FINGER_NAMES), "run_combos": dict(cfg.RUN_COMBOS), "full_combo_label": cfg.FULL_COMBO_LABEL,
        "rdms": rdms, "fsi_raw": fsi, "run_subset_stability": within,
        "independent_split_reliability": independent, "run_level_uncertainty": uncertainty,
        "run_pair_contributions": np.asarray(run_pair_contrib, float), "run_pair_labels": [list(x) for x in run_pair_labels],
        "precision_info": precision_info, "qc": qa,
        "certification": {"status":"passed","numerical_core":"frozen_v10.3","valid_voxel_mask_count":int(valid_mask.sum())},
    }
    validate(out)
    return out
