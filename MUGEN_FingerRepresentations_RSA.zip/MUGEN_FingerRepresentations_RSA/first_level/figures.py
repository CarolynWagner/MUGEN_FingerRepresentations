"""Publication-style first-level figures for one subject x session x ROI.

Uses only values already stored in rsa_firstlevel.pkl / the first-level object.
No Crossnobis distances or reliability metrics are recomputed here.

Outputs (PNG + SVG):
  Fig_RDM_all_combos_<session>.{png,svg}
  Fig_RDM_raw_full_combo_<session>.{png,svg}
  Fig_RDM_mean_normalized_full_combo_<session>.{png,svg}
  Fig_MDS_all_combos_<session>.{png,svg}
  Fig_FSI_raw_<session>.{png,svg}
  Fig_within_session_corr_<session>.{png,svg}
  Fig_independent_split_reliability_<session>.{png,svg}  (when available)
"""
from __future__ import annotations

from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap
from matplotlib.ticker import MaxNLocator

EJAZ_CMAP = LinearSegmentedColormap.from_list(
    "ejaz_black_red_yellow_white", ["black", "red", "yellow", "white"]
)
EPS = 1e-12


def _save(fig, path, dpi=220):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(path, dpi=dpi, bbox_inches="tight")
    fig.savefig(path.with_suffix(".svg"), format="svg", bbox_inches="tight")
    plt.close(fig)


def _finite(x):
    x = np.asarray(x, dtype=float).ravel()
    return x[np.isfinite(x)]


def _data_range(arrays, pad_frac=0.03):
    vals = np.concatenate([_finite(a) for a in arrays]) if arrays else np.array([])
    if vals.size == 0:
        return 0.0, 1.0
    vmin, vmax = float(vals.min()), float(vals.max())
    pad = max((vmax - vmin) * pad_frac, abs(vmax) * 0.01, 1e-6)
    return vmin - pad, vmax + pad


def _text_color(value, vmin, vmax, cmap=EJAZ_CMAP):
    if not np.isfinite(value):
        return "black"
    if abs(vmax - vmin) < EPS:
        t = 0.5
    else:
        t = np.clip((value - vmin) / (vmax - vmin), 0, 1)
    r, g, b, _ = cmap(t)
    luminance = 0.2126*r + 0.7152*g + 0.0722*b
    return "black" if luminance > 0.58 else "white"


def _plot_rdm(ax, mat, title, finger_names, vmin, vmax):
    mat = np.asarray(mat, dtype=float)
    im = ax.imshow(mat, cmap=EJAZ_CMAP, vmin=vmin, vmax=vmax, aspect="equal")
    names = [str(x).capitalize() for x in finger_names]
    n = len(names)
    ax.set_xticks(range(n), names, rotation=45, ha="right", fontsize=8)
    ax.set_yticks(range(n), names, fontsize=8)
    ax.set_title(title, fontsize=9, fontweight="bold")
    for i in range(n):
        for j in range(n):
            val = float(mat[i, j])
            if np.isfinite(val):
                ax.text(j, i, f"{val:.3f}", ha="center", va="center", fontsize=6,
                        color=_text_color(val, vmin, vmax))
    return im


def plot_rdms(obj, out):
    combos = list(obj["run_combos"].keys())
    names = obj["finger_names"]
    mats = [np.asarray(obj["rdms"][c]["raw"], float) for c in combos]
    vmin, vmax = _data_range(mats)
    cols = 3
    rows = int(np.ceil(len(combos) / cols))
    fig, axes = plt.subplots(rows, cols, figsize=(cols*3.5, rows*3.25), layout="constrained")
    axes = np.atleast_1d(axes).ravel()
    im = None
    for i, (combo, mat) in enumerate(zip(combos, mats)):
        im = _plot_rdm(axes[i], mat, combo, names, vmin, vmax)
    for ax in axes[len(combos):]:
        ax.set_visible(False)
    fig.colorbar(im, ax=list(axes[:len(combos)]), shrink=.86, pad=.02,
                 label=f"Crossnobis distance [{vmin:.3g}, {vmax:.3g}]")
    fig.suptitle(f"All run-combo raw RDMs — {obj['subject_id']} | {obj['session_id']} | {obj['roi']['name']}",
                 fontsize=14, fontweight="bold")
    _save(fig, out / f"Fig_RDM_all_combos_{obj['session_id']}.png")

    full = obj["full_combo_label"]
    mat = np.asarray(obj["rdms"][full]["raw"], float)
    vmin, vmax = _data_range([mat])
    fig, ax = plt.subplots(figsize=(5.2, 4.7), layout="constrained")
    im = _plot_rdm(ax, mat, full, names, vmin, vmax)
    fig.colorbar(im, ax=ax, shrink=.82, pad=.03,
                 label=f"Crossnobis distance [{vmin:.3g}, {vmax:.3g}]")
    fig.suptitle(f"Raw Crossnobis RDM — {obj['subject_id']} | {obj['session_id']} | {obj['roi']['name']}",
                 fontsize=13, fontweight="bold")
    _save(fig, out / f"Fig_RDM_raw_full_combo_{obj['session_id']}.png")

    # Session-mean-normalized full-combo RDM.  This representation is already
    # stored in the locked RDM contract: raw / mean(raw upper triangle).
    # It is a visualization only; raw Crossnobis values remain the inferential
    # representation everywhere else in the pipeline.
    if "mean_norm" not in obj["rdms"][full]:
        raise KeyError(
            f"Stored RDM contract for {full!r} has no 'mean_norm' representation."
        )
    mat = np.asarray(obj["rdms"][full]["mean_norm"], float)
    vmin, vmax = _data_range([mat])
    fig, ax = plt.subplots(figsize=(5.2, 4.7), layout="constrained")
    im = _plot_rdm(ax, mat, full, names, vmin, vmax)
    fig.colorbar(
        im, ax=ax, shrink=.82, pad=.03,
        label=f"Raw distance / session off-diagonal mean [{vmin:.3g}, {vmax:.3g}]"
    )
    fig.suptitle(
        f"Session-mean-normalized Crossnobis RDM — "
        f"{obj['subject_id']} | {obj['session_id']} | {obj['roi']['name']}",
        fontsize=13, fontweight="bold"
    )
    _save(fig, out / f"Fig_RDM_mean_normalized_full_combo_{obj['session_id']}.png")


def compute_mds(rdm):
    """Classical MDS for a Crossnobis RDM, matching the second-level figure.

    Crossnobis entries estimate squared Mahalanobis distances, so the stored
    RDM is double-centred directly (rather than squared again). Negative
    eigenvalues are truncated to zero for the 2-D visualization only.
    """
    rdm = np.asarray(rdm, dtype=float)
    if rdm.ndim != 2 or rdm.shape[0] != rdm.shape[1]:
        raise ValueError(f"MDS requires a square RDM, got {rdm.shape}")
    if not np.isfinite(rdm).all():
        raise ValueError("MDS requires a finite RDM")
    n = rdm.shape[0]
    H = np.eye(n) - np.ones((n, n)) / n
    B = -0.5 * H @ rdm @ H
    vals, vecs = np.linalg.eigh(B)
    idx = np.argsort(vals)[::-1]
    vals = vals[idx]
    vecs = vecs[:, idx]
    return vecs[:, :2] * np.sqrt(np.maximum(vals[:2], 0.0))


def _annotate_mds(ax, coords, labels):
    """Deterministic, collision-aware labels for the five finger points."""
    coords = np.asarray(coords, float)
    x0, x1 = ax.get_xlim(); y0, y1 = ax.get_ylim()
    xspan = max(x1-x0, EPS); yspan = max(y1-y0, EPS)
    pts = np.column_stack(((coords[:,0]-x0)/xspan, (coords[:,1]-y0)/yspan))
    candidates = [(0.025,0.030),(0.025,-0.045),(-0.025,0.030),(-0.025,-0.045),
                  (0.045,0.000),(-0.045,0.000),(0.000,0.055),(0.000,-0.060),
                  (0.050,0.045),(-0.050,0.045),(0.050,-0.055),(-0.050,-0.055)]
    placed=[]
    for idx,(xy,label) in enumerate(zip(pts,labels)):
        w=max(0.075,0.014*len(label)); h=0.045; best=None; best_score=float("inf")
        for dx,dy in candidates:
            cx,cy=xy[0]+dx,xy[1]+dy
            left=cx if dx>=0 else cx-w; right=cx+w if dx>=0 else cx
            bottom=cy if dy>=0 else cy-h; top=cy+h if dy>=0 else cy
            if left<.005 or right>.995 or bottom<.005 or top>.995: continue
            score=abs(dx)+abs(dy)
            for j,pxy in enumerate(pts):
                if j!=idx and left-.018<=pxy[0]<=right+.018 and bottom-.018<=pxy[1]<=top+.018:
                    score += 100.0
            for old in placed:
                if not (right+.008<old[0] or left-.008>old[1] or top+.008<old[2] or bottom-.008>old[3]):
                    score += 100.0
            if score<best_score:
                best_score=score; best=(dx,dy,left,right,bottom,top)
                if score<1.0: break
        if best is None:
            dx,dy=.030,.035; best=(dx,dy,xy[0]+dx,xy[0]+dx+w,xy[1]+dy,xy[1]+dy+h)
        dx,dy,left,right,bottom,top=best
        ax.annotate(label, coords[idx], xytext=(dx*72,dy*72), textcoords="offset points",
                    fontsize=7, ha="left" if dx>=0 else "right",
                    va="bottom" if dy>=0 else "top", annotation_clip=True,
                    bbox=dict(facecolor="white",alpha=.72,edgecolor="none",pad=.35), zorder=4)
        placed.append((left,right,bottom,top))


def plot_mds_all(obj, out):
    """MDS of raw Crossnobis pattern distances for every run subset."""
    combos = list(obj["run_combos"].keys())
    labels = [str(x).capitalize() for x in obj["finger_names"]]
    coords_by_combo = {
        combo: compute_mds(np.asarray(obj["rdms"][combo]["raw"], float))
        for combo in combos
    }
    all_coords = np.vstack(list(coords_by_combo.values()))
    max_abs = float(np.nanmax(np.abs(all_coords))) if all_coords.size else 0.0
    lim = max(max_abs * 1.18, 0.01)
    cols=3; rows=int(np.ceil(len(combos)/cols))
    fig,axes=plt.subplots(rows,cols,figsize=(cols*3.7,rows*3.5),layout="constrained")
    axes=np.atleast_1d(axes).ravel()
    for i,combo in enumerate(combos):
        ax=axes[i]; coords=coords_by_combo[combo]
        ax.scatter(coords[:,0],coords[:,1],s=60,zorder=3)
        ax.axhline(0,color="gray",lw=.5,zorder=1); ax.axvline(0,color="gray",lw=.5,zorder=1)
        ax.set_xlim(-lim,lim); ax.set_ylim(-lim,lim); ax.set_aspect("equal",adjustable="box")
        ax.xaxis.set_major_locator(MaxNLocator(nbins=5)); ax.yaxis.set_major_locator(MaxNLocator(nbins=5))
        ax.set_title(combo,fontsize=9); ax.tick_params(labelsize=6)
        _annotate_mds(ax,coords,labels)
    for ax in axes[len(combos):]: ax.set_visible(False)
    fig.suptitle(
        f"MDS finger geometry — {obj['subject_id']} | {obj['session_id']} | {obj['roi']['name']}",
        fontsize=14,fontweight="bold"
    )
    _save(fig,out / f"Fig_MDS_all_combos_{obj['session_id']}.png")


def plot_fsi(obj, out):
    combos = list(obj["run_combos"].keys())
    vals = np.asarray([obj["fsi_raw"][c] for c in combos], float)
    x = np.arange(len(combos))
    fig, ax = plt.subplots(figsize=(12, 6), layout="constrained")
    line, = ax.plot(x, vals, marker="o", linewidth=2)
    finite = _finite(vals)
    if finite.size:
        span = max(float(finite.max()-finite.min()), .01)
        pad = max(span*.22, .01)
        ax.set_ylim(float(finite.min()-pad), float(finite.max()+pad))
    for xi, val in zip(x, vals):
        if np.isfinite(val):
            ax.annotate(f"{val:.3f}", (xi, val), xytext=(0, 8), textcoords="offset points",
                        ha="center", va="bottom", fontsize=8, color=line.get_color(),
                        bbox=dict(facecolor="white", alpha=.70, edgecolor="none", pad=.5))
    ax.set_xticks(x, [c.replace("_", " ") for c in combos], rotation=45, ha="right")
    ax.set_ylabel("Mean upper-triangle Crossnobis distance")
    ax.set_title(f"Finger Separation Index — {obj['subject_id']} | {obj['session_id']} | {obj['roi']['name']}",
                 fontsize=13, fontweight="bold")
    ax.grid(True, axis="y", alpha=.3)
    ax.yaxis.set_major_locator(MaxNLocator(nbins=7))
    _save(fig, out / f"Fig_FSI_raw_{obj['session_id']}.png")


def _corr_range(mat, metric):
    vals = _finite(mat)
    if metric == "fisherz":
        if vals.size == 0: return -1.0, 1.0
        lo, hi = float(vals.min()), float(vals.max())
        pad = max((hi-lo)*.05, .05)
        return lo-pad, hi+pad
    # Correlation/similarity metrics: retain negative values when present.
    lo = min(-1.0, float(vals.min())) if vals.size and vals.min() < 0 else 0.0
    return lo, 1.0


def _plot_corr_matrix(ax, mat, title, labels, metric):
    mat = np.asarray(mat, float)
    vmin, vmax = _corr_range(mat, metric)
    im = ax.imshow(mat, cmap=EJAZ_CMAP, vmin=vmin, vmax=vmax, aspect="equal")
    n = mat.shape[0]
    ax.set_xticks(range(n), labels, rotation=90, fontsize=7)
    ax.set_yticks(range(n), labels, fontsize=7)
    ax.set_title(title, fontsize=10, fontweight="bold")
    for i in range(n):
        for j in range(n):
            val = mat[i, j]
            if np.isfinite(val):
                ax.text(j, i, f"{val:.3f}", ha="center", va="center", fontsize=6,
                        color=_text_color(val, vmin, vmax))
    plt.colorbar(im, ax=ax, fraction=.046, pad=.04, label=f"{metric} [{vmin:.3g}, {vmax:.3g}]")


def plot_within_session_correlations(obj, out):
    ws = obj.get("run_subset_stability", {})
    if not ws:
        return
    combos = list(ws.get("combos", obj["run_combos"].keys()))
    labels = [c.replace("run", "r").replace("_runs", "").replace("-", "") for c in combos]
    metric_titles = [
        ("pearson", "Pearson correlation"),
        ("spearman", "Spearman correlation"),
        ("fisherz", "Fisher-Z"),
        ("icc", "ICC(2,1)"),
        ("cosine", "Cosine similarity"),
    ]
    available = [(k,t) for k,t in metric_titles if k in ws]
    if not available:
        return
    fig, axes = plt.subplots(1, len(available), figsize=(6.2*len(available), 6.2), layout="constrained")
    axes = np.atleast_1d(axes)
    for ax, (metric, title) in zip(axes, available):
        _plot_corr_matrix(ax, ws[metric], title, labels, metric)
    fig.suptitle(f"Within-session RDM correlations — {obj['subject_id']} | {obj['session_id']} | {obj['roi']['name']}",
                 fontsize=14, fontweight="bold")
    _save(fig, out / f"Fig_within_session_corr_{obj['session_id']}.png")


def plot_independent_splits(obj, out):
    splits = obj.get("independent_split_reliability", {})
    if not splits:
        return
    metrics = ["pearson", "spearman", "icc", "cosine"]
    names = list(splits)
    available = [m for m in metrics if any(m in splits[n] for n in names)]
    if not available:
        return
    x = np.arange(len(names), dtype=float)
    width = .8 / len(available)
    fig, ax = plt.subplots(figsize=(max(8, 1.6*len(names)), 5.5), layout="constrained")
    for j, metric in enumerate(available):
        vals = [float(splits[n].get(metric, np.nan)) for n in names]
        offset = (j-(len(available)-1)/2)*width
        bars = ax.bar(x+offset, vals, width=width, label=metric)
        ax.bar_label(bars, labels=[f"{v:.3f}" if np.isfinite(v) else "" for v in vals], fontsize=7, padding=2)
    ax.set_xticks(x, [n.replace("_", " ") for n in names], rotation=20, ha="right")
    ax.set_ylabel("RDM similarity")
    ax.set_ylim(-1.05, 1.05)
    ax.axhline(0, color="black", lw=.6)
    ax.grid(True, axis="y", alpha=.25)
    ax.legend()
    ax.set_title(f"Independent within-session split reliability — {obj['subject_id']} | {obj['session_id']} | {obj['roi']['name']}",
                 fontsize=13, fontweight="bold")
    _save(fig, out / f"Fig_independent_split_reliability_{obj['session_id']}.png")


def make_figures(obj, out_dir):
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    plot_rdms(obj, out)
    plot_mds_all(obj, out)
    plot_fsi(obj, out)
    plot_within_session_correlations(obj, out)
    plot_independent_splits(obj, out)
