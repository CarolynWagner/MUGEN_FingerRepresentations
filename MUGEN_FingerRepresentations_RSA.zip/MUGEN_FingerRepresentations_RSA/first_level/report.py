"""First-level text report."""
from __future__ import annotations
import numpy as np

def write_report(obj, path):
    with open(path, "w") as f:
        f.write("FIRST-LEVEL RSA REPORT\n" + "="*72 + "\n")
        f.write(f"subject: {obj['subject_id']}\nsession: {obj['session_id']}\nroi: {obj['roi']['name']} ({obj['roi']['family']}, {obj['roi']['version']})\n")
        f.write(f"resolution_mm: {obj['acquisition']['resolution_mm']}\nvalid_voxels: {obj['qc']['n_valid_voxels']} / {obj['qc']['n_voxels_roi']}\n")
        f.write(f"precision: {obj['precision_info']['method']}\ndof: {obj['precision_info']['dof']} ({obj['precision_info']['dof_source']})\n\n")
        f.write("FSI\n" + "-"*72 + "\n")
        for c,v in obj['fsi_raw'].items(): f.write(f"{c}: {v:.8f}\n")
        f.write("\nFULL-COMBO RAW RDM\n" + "-"*72 + "\n")
        r = np.asarray(obj['rdms'][obj['full_combo_label']]['raw'])
        f.write(np.array2string(r, precision=6, suppress_small=False) + "\n")
        f.write("\nINDEPENDENT SPLIT RELIABILITY\n" + "-"*72 + "\n")
        for k,v in obj['independent_split_reliability'].items(): f.write(f"{k}: {v}\n")
