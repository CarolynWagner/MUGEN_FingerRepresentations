#!/usr/bin/env python3
"""Run first-level RSA for one row or an entire manifest."""
from __future__ import annotations
import argparse
from pathlib import Path
from first_level.manifest import read_manifest
from first_level.analysis import analyze_row
from first_level.report import write_report
from first_level.figures import make_figures
from shared.io import atomic_pickle, write_json

def unit_dir(root,row):
    return Path(root)/str(row['subject'])/str(row['session'])/f"roi-{row['roi_name']}"

def run_one(row, out_root, n_boot, figures=True):
    obj=analyze_row(row,n_boot=n_boot); d=unit_dir(out_root,row); d.mkdir(parents=True,exist_ok=True)
    atomic_pickle(obj,d/"rsa_firstlevel.pkl"); write_report(obj,d/"firstlevel_report.txt"); write_json(obj['qc'],d/"qc.json")
    if figures: make_figures(obj,d/"figures")
    print(f"[FIRST LEVEL] complete: {d}")
    return d

def main():
    p=argparse.ArgumentParser(); p.add_argument('--manifest',required=True); p.add_argument('--out-root',default='derivatives/rsa_first_level'); p.add_argument('--row',type=int,help='0-based manifest row (useful for SLURM arrays)'); p.add_argument('--n-boot',type=int,default=2000); p.add_argument('--no-figures',action='store_true'); a=p.parse_args()
    df=read_manifest(a.manifest)
    rows=[df.iloc[a.row].to_dict()] if a.row is not None else [r.to_dict() for _,r in df.iterrows()]
    for row in rows: run_one(row,a.out_root,a.n_boot,figures=not a.no_figures)
if __name__=='__main__': main()
