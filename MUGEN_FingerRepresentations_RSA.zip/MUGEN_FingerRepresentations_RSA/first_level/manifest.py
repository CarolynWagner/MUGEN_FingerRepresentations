"""Manifest handling: one row = subject x session x ROI."""
from __future__ import annotations
from pathlib import Path
import pandas as pd

REQUIRED = ["subject", "session", "roi_name", "model_dir", "roi_path"]
OPTIONAL_DEFAULTS = {
    "roi_family": "", "roi_version": "", "hemisphere": "left",
    "resolution_mm": "", "group": "", "instrument": "",
    "roi_definition_method": "", "roi_source_space": "",
    "roi_analysis_space": "native_bold", "residual_dof": "",
}

def read_manifest(path):
    df = pd.read_csv(path, dtype=str).fillna("")
    missing = [c for c in REQUIRED if c not in df.columns]
    if missing: raise ValueError(f"Manifest missing required columns: {missing}")
    for c, v in OPTIONAL_DEFAULTS.items():
        if c not in df.columns: df[c] = v
    if df.duplicated(subset=["subject", "session", "roi_name"]).any():
        dup = df[df.duplicated(subset=["subject", "session", "roi_name"], keep=False)]
        raise ValueError("Duplicate subject/session/ROI rows:\n" + dup.to_string(index=False))
    return df
