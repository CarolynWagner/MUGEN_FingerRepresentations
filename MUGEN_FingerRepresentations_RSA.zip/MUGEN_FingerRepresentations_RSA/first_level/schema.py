"""First-level output contract validation."""
from __future__ import annotations
import numpy as np
from shared.constants import SCHEMA_VERSION_FIRST_LEVEL

REQUIRED = ["schema_version","pipeline_version","analysis_level","subject_id","session_id","roi","acquisition","source_paths","rdms","fsi_raw","run_subset_stability","independent_split_reliability","run_level_uncertainty","precision_info","qc","certification","finger_names","run_combos","full_combo_label"]

def validate(obj):
    for k in REQUIRED:
        if k not in obj: raise KeyError(f"Missing first-level key: {k}")
    if obj["schema_version"] != SCHEMA_VERSION_FIRST_LEVEL: raise ValueError("Unexpected first-level schema version")
    if obj["analysis_level"] != "first_level_subject_session_roi": raise ValueError("Wrong analysis_level")
    n = len(obj["finger_names"])
    for combo, rdm in obj["rdms"].items():
        raw = np.asarray(rdm["raw"], float)
        if raw.shape != (n,n): raise ValueError(f"Wrong RDM shape {combo}: {raw.shape}")
        if not np.isfinite(raw).all(): raise ValueError(f"Nonfinite RDM: {combo}")
        if not np.allclose(raw, raw.T, atol=1e-10): raise ValueError(f"Asymmetric RDM: {combo}")
        if not np.allclose(np.diag(raw), 0, atol=1e-10): raise ValueError(f"Nonzero RDM diagonal: {combo}")
    if int(obj["qc"]["n_valid_voxels"]) < 2: raise ValueError("Too few valid voxels")
    return True
