#!/usr/bin/env python3
"""
reporting/generate_full_reports.py

Corrected RSA v11 reporting layer.

This version reports BOTH:

1) WITHIN-SESSION INDEPENDENT-SPLIT INFERENCE
   - first_half_vs_second_half:
         run1_and_3  vs run4-6
   - odd_vs_even:
         odd_runs-1-3-5 vs even_runs-2-4-6
   - metrics:
         Pearson, Spearman, ICC, cosine, Fisher-z
   - exact simultaneous condition-label permutation p-values
   - Benjamini-Hochberg FDR q-values
   - q < .05 significance flags

2) BETWEEN-SESSION INFERENCE
   - existing exact condition-label permutation tests from the validated
     second_level.figure_contract machinery
   - raw p-values
   - BH-FDR q-values
   - q < .05 significance flags

IMPORTANT
---------
This is REPORTING / INFERENCE ON STORED RDMs ONLY.
It does NOT recompute Crossnobis and does NOT modify any pickle.

The exact permutation test preserves RDM dependency by simultaneously
permuting the five condition labels on rows and columns. With five fingers,
the full permutation space is 5! = 120.

Overlapping run-subset stability comparisons remain DESCRIPTIVE ONLY:
no inferential p-values are assigned to comparisons such as run1-2 vs run1-3
because the compared RDMs share runs and are not independent.

No naive bootstrap CI over the ten RDM entries is reported because those
entries are statistically dependent.

Usage
-----
First level:
    python -m reporting.generate_full_reports \
        --first-level-pkl path/to/rsa_firstlevel.pkl

Second level:
    python -m reporting.generate_full_reports \
        --second-level-pkl path/to/rsa_secondlevel.pkl
"""

from __future__ import annotations

import argparse
import itertools
import math
import pickle
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
from scipy.stats import pearsonr, spearmanr


WIDTH = 100

WITHIN_SPLITS = {
    "first_half_vs_second_half": ("run1_and_3", "run4-6"),
    "odd_vs_even": ("odd_runs-1-3-5", "even_runs-2-4-6"),
}

METRICS = ("pearson", "spearman", "icc", "cosine", "fisherz")


# ============================================================================
# Generic helpers
# ============================================================================

def load_pickle(path: Path) -> dict:
    path = Path(path)
    if not path.is_file():
        raise FileNotFoundError(path)

    with path.open("rb") as f:
        obj = pickle.load(f)

    if not isinstance(obj, dict):
        raise TypeError(f"Expected dict in {path}, got {type(obj).__name__}")

    return obj


def fmt_scalar(x: Any) -> str:
    if x is None:
        return "None"

    if isinstance(x, (np.bool_, bool)):
        return str(bool(x))

    if isinstance(x, (np.integer, int)):
        return str(int(x))

    if isinstance(x, (np.floating, float)):
        x = float(x)
        if math.isnan(x):
            return "nan"
        if math.isinf(x):
            return "inf" if x > 0 else "-inf"
        return f"{x:.12g}"

    return str(x)


def is_scalar(x: Any) -> bool:
    return x is None or isinstance(
        x,
        (
            str,
            bytes,
            bool,
            int,
            float,
            np.bool_,
            np.integer,
            np.floating,
        ),
    )


def render(value: Any, indent: int = 0, name: str | None = None) -> str:
    p = " " * indent
    label = f"{name}: " if name is not None else ""

    if is_scalar(value):
        return p + label + fmt_scalar(value)

    if isinstance(value, np.ndarray):
        with np.printoptions(
            precision=9,
            linewidth=180,
            threshold=max(10000, value.size + 1),
            suppress=False,
        ):
            body = np.array2string(value, separator=", ")

        body = "\n".join(
            " " * (indent + (2 if name else 0)) + line
            for line in body.splitlines()
        )

        if name:
            return p + f"{name}:\n" + body

        return body

    if isinstance(value, pd.DataFrame):
        body = value.to_string(index=False)
        if name:
            return p + f"{name}:\n" + "\n".join(
                " " * (indent + 2) + line
                for line in body.splitlines()
            )
        return "\n".join(p + line for line in body.splitlines())

    if isinstance(value, pd.Series):
        body = value.to_string()
        if name:
            return p + f"{name}:\n" + "\n".join(
                " " * (indent + 2) + line
                for line in body.splitlines()
            )
        return "\n".join(p + line for line in body.splitlines())

    if isinstance(value, dict):
        lines = []

        if name:
            lines.append(p + f"{name}:")
            indent += 2

        if not value:
            lines.append(" " * indent + "{}")
            return "\n".join(lines)

        for key, item in value.items():
            lines.append(render(item, indent, str(key)))

        return "\n".join(lines)

    if isinstance(value, (list, tuple)):
        lines = []

        if name:
            lines.append(p + f"{name}:")
            indent += 2
            p = " " * indent

        if not value:
            lines.append(p + "[]")
            return "\n".join(lines)

        if all(is_scalar(x) for x in value):
            lines.append(
                p + "[" + ", ".join(fmt_scalar(x) for x in value) + "]"
            )
        else:
            for i, item in enumerate(value):
                if is_scalar(item):
                    lines.append(p + f"[{i}] {fmt_scalar(item)}")
                else:
                    lines.append(p + f"[{i}]")
                    lines.append(render(item, indent + 2))

        return "\n".join(lines)

    if hasattr(value, "get_matrices"):
        try:
            return render(np.asarray(value.get_matrices()), indent, name)
        except Exception:
            pass

    return p + label + repr(value)


def section(out, title: str, value: Any) -> None:
    out.write(f"\n{title}\n{'-' * WIDTH}\n")
    out.write(render(value))
    out.write("\n")


# ============================================================================
# RDM decoding and metrics
# ============================================================================

def decode_rdm(value: Any) -> np.ndarray | None:
    if value is None:
        return None

    if hasattr(value, "get_matrices"):
        arr = np.asarray(value.get_matrices(), dtype=float)
        if arr.ndim == 3 and arr.shape[0] >= 1:
            return arr[0]

    if isinstance(value, dict):
        for key in (
            "raw",
            "matrix",
            "rdm",
            "rdm_matrix",
            "dissimilarities",
            "data",
        ):
            if key in value:
                out = decode_rdm(value[key])
                if out is not None:
                    return out

    arr = np.asarray(value)

    if arr.shape == (5, 5):
        return arr.astype(float)

    if arr.shape == (1, 10):
        arr = arr[0]

    if arr.ndim == 1 and arr.size == 10:
        m = np.zeros((5, 5), dtype=float)
        i, j = np.triu_indices(5, 1)
        m[i, j] = arr
        m[j, i] = arr
        return m

    return None


def raw_rdm(first_obj: dict, combo: str) -> np.ndarray:
    rdms = first_obj.get("rdms", {})

    if combo not in rdms:
        raise KeyError(
            f"Missing RDM combo {combo!r}. Available: {list(rdms)}"
        )

    matrix = decode_rdm(rdms[combo])

    if matrix is None:
        raise TypeError(f"Could not decode RDM {combo!r}")

    matrix = np.asarray(matrix, dtype=float)

    if matrix.shape != (5, 5):
        raise ValueError(
            f"Expected 5x5 RDM for {combo}, found {matrix.shape}"
        )

    matrix = 0.5 * (matrix + matrix.T)
    np.fill_diagonal(matrix, 0.0)

    return matrix


def vectorize_rdm(matrix: np.ndarray) -> np.ndarray:
    i, j = np.triu_indices(matrix.shape[0], 1)
    return np.asarray(matrix, dtype=float)[i, j]


def icc_2_1(v1: np.ndarray, v2: np.ndarray) -> float:
    """
    Two-way random, single-measure ICC matching the historical pipeline.
    """
    x = np.asarray(v1, dtype=float)
    y = np.asarray(v2, dtype=float)

    good = np.isfinite(x) & np.isfinite(y)
    x = x[good]
    y = y[good]

    if len(x) < 2:
        return math.nan

    data = np.column_stack([x, y])
    n = data.shape[0]

    grand_mean = data.mean()

    ss_total = np.sum((data - grand_mean) ** 2)

    row_means = data.mean(axis=1)
    ss_rows = 2 * np.sum((row_means - grand_mean) ** 2)

    col_means = data.mean(axis=0)
    ss_cols = n * np.sum((col_means - grand_mean) ** 2)

    ss_error = ss_total - ss_rows - ss_cols

    ms_rows = ss_rows / (n - 1)
    ms_cols = ss_cols
    ms_error = ss_error / (n - 1)

    denom = (
        ms_rows
        + ms_cols
        - ms_error
        + 2 * (ms_cols - ms_error) / n
    )

    if abs(denom) < 1e-15:
        return math.nan

    return float((ms_rows - ms_error) / denom)


def cosine(v1: np.ndarray, v2: np.ndarray) -> float:
    x = np.asarray(v1, dtype=float)
    y = np.asarray(v2, dtype=float)

    good = np.isfinite(x) & np.isfinite(y)
    x = x[good]
    y = y[good]

    denom = np.linalg.norm(x) * np.linalg.norm(y)

    if denom == 0:
        return math.nan

    return float(np.dot(x, y) / denom)


def metric_value(
    rdm_a: np.ndarray,
    rdm_b: np.ndarray,
    metric: str,
) -> float:

    a = vectorize_rdm(rdm_a)
    b = vectorize_rdm(rdm_b)

    good = np.isfinite(a) & np.isfinite(b)
    a = a[good]
    b = b[good]

    if len(a) < 3:
        return math.nan

    if metric == "pearson":
        if np.std(a) < 1e-15 or np.std(b) < 1e-15:
            return math.nan
        return float(pearsonr(a, b).statistic)

    if metric == "spearman":
        return float(spearmanr(a, b).statistic)

    if metric == "icc":
        return icc_2_1(a, b)

    if metric == "cosine":
        return cosine(a, b)

    if metric == "fisherz":
        if np.std(a) < 1e-15 or np.std(b) < 1e-15:
            return math.nan

        r = float(pearsonr(a, b).statistic)

        # Same safe finite transform principle as the existing pipeline.
        r = np.clip(r, -0.999999999, 0.999999999)

        return float(np.arctanh(r))

    raise ValueError(metric)


# ============================================================================
# Exact condition-label permutation inference
# ============================================================================

def permute_rdm(matrix: np.ndarray, permutation: tuple[int, ...]) -> np.ndarray:
    idx = np.asarray(permutation, dtype=int)
    return matrix[np.ix_(idx, idx)]


def exact_condition_label_permutation_test(
    rdm_a: np.ndarray,
    rdm_b: np.ndarray,
    metric: str,
) -> dict:
    """
    Exact test under the null that finger labels in RDM B are exchangeable
    relative to RDM A.

    All 5! = 120 simultaneous row/column permutations are evaluated.
    The identity permutation is part of the exact permutation space.

    The p-value is two-sided in the natural metric sense:
        |null statistic| >= |observed|
    for correlation-like metrics and ICC/cosine/Fisher-z.
    """
    if rdm_a.shape != (5, 5) or rdm_b.shape != (5, 5):
        raise ValueError("Exact permutation test requires 5x5 RDMs.")

    observed = metric_value(rdm_a, rdm_b, metric)

    null = []

    for perm in itertools.permutations(range(5)):
        permuted = permute_rdm(rdm_b, perm)
        value = metric_value(rdm_a, permuted, metric)

        if np.isfinite(value):
            null.append(float(value))

    null = np.asarray(null, dtype=float)

    if not np.isfinite(observed) or null.size == 0:
        return {
            "observed": float(observed),
            "p_value": math.nan,
            "null_mean": math.nan,
            "null_std": math.nan,
            "n_permutations": int(null.size),
            "method": (
                "exact simultaneous condition-label permutation "
                "of RDM rows and columns"
            ),
        }

    # Exact permutation probability. No +1 Monte Carlo correction is needed
    # because the complete permutation space is enumerated.
    p_value = float(
        np.mean(
            np.abs(null)
            >= abs(float(observed)) - 1e-15
        )
    )

    return {
        "observed": float(observed),
        "p_value": p_value,
        "null_mean": float(np.mean(null)),
        "null_std": float(np.std(null)),
        "n_permutations": int(null.size),
        "method": (
            "exact simultaneous condition-label permutation "
            "of RDM rows and columns"
        ),
    }


def fdr_bh_adjusted(pvals: list[float]) -> np.ndarray:
    p = np.asarray(pvals, dtype=float)

    if p.size == 0:
        return np.asarray([], dtype=float)

    p[~np.isfinite(p)] = 1.0

    m = p.size

    order = np.argsort(p)
    ranked = p[order]

    adjusted_ranked = (
        ranked
        * m
        / np.arange(1, m + 1, dtype=float)
    )

    adjusted_ranked = np.minimum.accumulate(
        adjusted_ranked[::-1]
    )[::-1]

    adjusted_ranked = np.clip(
        adjusted_ranked,
        0.0,
        1.0,
    )

    adjusted = np.empty_like(adjusted_ranked)
    adjusted[order] = adjusted_ranked

    return adjusted


def build_within_session_inference(first_obj: dict) -> tuple[pd.DataFrame, dict]:
    """
    Exact inference for the two genuinely disjoint within-session splits.

    FDR family:
        2 split definitions x 5 metrics = 10 tests
        within this session/ROI first-level object.
    """
    rows = []

    for split_name, (combo_a, combo_b) in WITHIN_SPLITS.items():

        rdm_a = raw_rdm(first_obj, combo_a)
        rdm_b = raw_rdm(first_obj, combo_b)

        for metric in METRICS:
            result = exact_condition_label_permutation_test(
                rdm_a,
                rdm_b,
                metric,
            )

            rows.append({
                "subject": first_obj.get("subject_id"),
                "session": first_obj.get("session_id"),
                "roi": (
                    first_obj.get("roi", {}).get("name")
                    if isinstance(first_obj.get("roi"), dict)
                    else first_obj.get("roi")
                ),
                "split": split_name,
                "combo_a": combo_a,
                "combo_b": combo_b,
                "metric": metric,
                "observed": result["observed"],
                "p_value": result["p_value"],
                "null_mean": result["null_mean"],
                "null_std": result["null_std"],
                "n_permutations": result["n_permutations"],
                "method": result["method"],
            })

    df = pd.DataFrame(rows)

    qvals = fdr_bh_adjusted(
        df["p_value"].to_list()
    )

    df["fdr_q_value"] = qvals
    df["fdr_significant_q05"] = (
        df["fdr_q_value"] < 0.05
    )

    meta = {
        "status": "available",
        "family": (
            "within-session independent-split reliability "
            "(2 disjoint splits x 5 metrics)"
        ),
        "n_tests": int(len(df)),
        "fdr_method": "Benjamini-Hochberg",
        "fdr_family_scope": "within this subject/session/ROI",
        "permutation_unit": "condition labels",
        "n_condition_label_permutations": 120,
        "overlapping_run_subset_stability_inference": "not_performed",
        "overlapping_reason": (
            "run-subset stability comparisons share runs and are "
            "retained as descriptive stability analyses only"
        ),
    }

    return df, meta


# ============================================================================
# Existing between-session inference
# ============================================================================

def load_or_build_figure_contract(secondlevel_pkl: Path) -> tuple[dict | None, str]:
    secondlevel_pkl = Path(secondlevel_pkl).resolve()

    existing = (
        secondlevel_pkl.parent
        / "rsa_figure_contract.pkl"
    )

    if existing.is_file():
        return load_pickle(existing), str(existing)

    try:
        from second_level.figure_contract import (
            build_figure_contract,
        )

        return (
            build_figure_contract(secondlevel_pkl),
            (
                "built in memory via "
                "second_level.figure_contract.build_figure_contract"
            ),
        )

    except Exception as exc:
        return (
            None,
            f"unavailable: {type(exc).__name__}: {exc}",
        )


def extract_between_session_inference(
    contract: dict | None,
) -> tuple[pd.DataFrame, dict]:

    columns = [
        "combo",
        "session_pair",
        "metric",
        "observed",
        "p_value",
        "fdr_q_value",
        "fdr_significant_q05",
        "null_mean",
        "null_std",
        "n_permutations",
        "method",
    ]

    if not contract:
        return (
            pd.DataFrame(columns=columns),
            {
                "status": "unavailable",
            },
        )

    cert = contract.get("certification", {})

    if not isinstance(cert, dict):
        return (
            pd.DataFrame(columns=columns),
            {
                "status": "unavailable",
                "reason": "No certification dictionary.",
            },
        )

    permutation_tests = cert.get(
        "permutation_tests",
        {},
    )

    fdr_results = cert.get(
        "fdr_results",
        [],
    )

    fdr_lookup = {}

    for row in fdr_results:
        if not isinstance(row, dict):
            continue

        key = (
            str(row.get("combo")),
            str(row.get("pair")),
            str(row.get("metric")),
        )

        fdr_lookup[key] = row

    rows = []

    for combo, by_pair in permutation_tests.items():
        if not isinstance(by_pair, dict):
            continue

        for pair, by_metric in by_pair.items():
            if not isinstance(by_metric, dict):
                continue

            for metric, result in by_metric.items():
                if not isinstance(result, dict):
                    continue

                fdr = fdr_lookup.get(
                    (
                        str(combo),
                        str(pair),
                        str(metric),
                    ),
                    {},
                )

                rows.append({
                    "combo": combo,
                    "session_pair": pair,
                    "metric": metric,
                    "observed": result.get("observed"),
                    "p_value": result.get("p_value"),
                    "fdr_q_value": fdr.get(
                        "fdr_q_value"
                    ),
                    "fdr_significant_q05": fdr.get(
                        "fdr_significant_q05"
                    ),
                    "null_mean": result.get("null_mean"),
                    "null_std": result.get("null_std"),
                    "n_permutations": result.get(
                        "n_permutations",
                        cert.get(
                            "n_condition_label_permutations"
                        ),
                    ),
                    "method": result.get(
                        "method",
                        cert.get("permutation_mode"),
                    ),
                })

    df = pd.DataFrame(
        rows,
        columns=columns,
    )

    if not df.empty:
        df = df.sort_values(
            [
                "combo",
                "session_pair",
                "metric",
            ]
        ).reset_index(drop=True)

    meta = {
        "status": (
            "available"
            if not df.empty
            else "no_tests_found"
        ),
        "family": (
            "between-session RDM similarity certification family"
        ),
        "permutation_mode": cert.get(
            "permutation_mode"
        ),
        "n_condition_label_permutations": cert.get(
            "n_condition_label_permutations"
        ),
        "n_tests": int(len(df)),
        "n_fdr_significant_q05": (
            int(
                df["fdr_significant_q05"]
                .fillna(False)
                .astype(bool)
                .sum()
            )
            if not df.empty
            else 0
        ),
    }

    return df, meta


# ============================================================================
# Aggregation of within-session inference into second-level report
# ============================================================================

def aggregate_within_from_secondlevel_inputs(
    second_obj: dict,
) -> tuple[pd.DataFrame, dict]:

    inputs = second_obj.get("inputs", [])

    rows = []

    for path in inputs:
        first = load_pickle(Path(path))

        df, _ = build_within_session_inference(
            first
        )

        rows.append(df)

    if not rows:
        return (
            pd.DataFrame(),
            {
                "status": "unavailable",
                "reason": "No first-level inputs.",
            },
        )

    combined = pd.concat(
        rows,
        ignore_index=True,
    )

    # IMPORTANT:
    # Each first-level session already has its own 10-test BH family.
    # Do not silently re-FDR across sessions here. Preserve the session-level
    # q-values and identify the scope explicitly.
    meta = {
        "status": "available",
        "n_rows": int(len(combined)),
        "fdr_scope": (
            "q-values were corrected separately within each "
            "subject/session/ROI first-level family"
        ),
        "tests_per_session": 10,
    }

    return combined, meta


# ============================================================================
# Report formatting
# ============================================================================

WITHIN_SHOW = [
    "session",
    "split",
    "metric",
    "observed",
    "p_value",
    "fdr_q_value",
    "fdr_significant_q05",
    "n_permutations",
]

BETWEEN_SHOW = [
    "combo",
    "session_pair",
    "metric",
    "observed",
    "p_value",
    "fdr_q_value",
    "fdr_significant_q05",
    "n_permutations",
]


def table_text(df: pd.DataFrame, columns: list[str]) -> str:
    if df.empty:
        return "No tests available."

    existing = [
        c for c in columns
        if c in df.columns
    ]

    return df[existing].to_string(
        index=False,
        float_format=lambda x: f"{x:.9g}",
    )


def write_first_reports(
    obj: dict,
    full_path: Path,
    qc_path: Path,
    source: Path,
    within_df: pd.DataFrame,
    within_meta: dict,
) -> None:

    with full_path.open(
        "w",
        encoding="utf-8",
    ) as out:

        out.write(
            "RSA v11 FIRST-LEVEL FULL VALUE REPORT\n"
            + "=" * WIDTH
            + "\n"
        )

        out.write(
            f"Source pickle: {source}\n"
        )

        out.write(
            "\nWITHIN-SESSION INDEPENDENT-SPLIT EXACT PERMUTATION INFERENCE\n"
        )
        out.write(
            "-" * WIDTH + "\n"
        )

        out.write(
            render(within_meta)
            + "\n\n"
        )

        out.write(
            table_text(
                within_df,
                WITHIN_SHOW,
            )
            + "\n"
        )

        out.write(
            "\nINFERENCE INTERPRETATION\n"
        )
        out.write(
            "-" * WIDTH + "\n"
        )
        out.write(
            "Independent split p-values use exact simultaneous "
            "condition-label permutation of RDM rows and columns.\n"
        )
        out.write(
            "The two disjoint split definitions are "
            "run1_and_3 vs run4-6 and odd_runs-1-3-5 vs "
            "even_runs-2-4-6.\n"
        )
        out.write(
            "BH-FDR correction is applied across the 10 tests "
            "(2 independent splits x 5 metrics) within this "
            "subject/session/ROI.\n"
        )
        out.write(
            "Overlapping run-subset stability correlations remain "
            "descriptive and intentionally have no p-values.\n"
        )

        for key, value in obj.items():
            section(
                out,
                key.upper(),
                value,
            )

    with qc_path.open(
        "w",
        encoding="utf-8",
    ) as out:

        out.write(
            "RSA v11 FIRST-LEVEL QC / RELIABILITY / INFERENCE REPORT\n"
            + "=" * WIDTH
            + "\n"
        )

        out.write(
            f"Source pickle: {source}\n"
        )

        for key, title in [
            (
                "qc",
                "VOXEL / DATA QC",
            ),
            (
                "precision_info",
                "PRECISION / EFFECTIVE DOF",
            ),
            (
                "independent_split_reliability",
                "INDEPENDENT SPLIT RELIABILITY — STORED VALUES",
            ),
            (
                "run_subset_stability",
                "OVERLAPPING RUN-SUBSET STABILITY — DESCRIPTIVE ONLY",
            ),
            (
                "run_level_uncertainty",
                "RUN-LEVEL UNCERTAINTY",
            ),
            (
                "certification",
                "CERTIFICATION",
            ),
        ]:
            if key in obj:
                section(
                    out,
                    title,
                    obj[key],
                )

        out.write(
            "\nINDEPENDENT-SPLIT EXACT PERMUTATION TESTS\n"
        )
        out.write(
            "-" * WIDTH + "\n"
        )
        out.write(
            render(within_meta)
            + "\n\n"
        )
        out.write(
            table_text(
                within_df,
                WITHIN_SHOW,
            )
            + "\n"
        )

        out.write(
            "\nINFERENCE NOTES\n"
        )
        out.write(
            "-" * WIDTH + "\n"
        )
        out.write(
            "p_value = exact condition-label permutation p-value.\n"
        )
        out.write(
            "fdr_q_value = Benjamini-Hochberg adjusted p-value "
            "within this session's 10-test independent-split family.\n"
        )
        out.write(
            "No p-values are assigned to overlapping run-subset "
            "stability comparisons because they share runs.\n"
        )


def write_second_reports(
    obj: dict,
    full_path: Path,
    qc_path: Path,
    source: Path,
    between_df: pd.DataFrame,
    between_meta: dict,
    between_source: str,
    within_df: pd.DataFrame,
    within_meta: dict,
) -> None:

    with full_path.open(
        "w",
        encoding="utf-8",
    ) as out:

        out.write(
            "RSA v11 SECOND-LEVEL FULL VALUE REPORT\n"
            + "=" * WIDTH
            + "\n"
        )

        out.write(
            f"Source pickle: {source}\n"
        )

        out.write(
            f"Between-session inference source: {between_source}\n"
        )

        out.write(
            "\nWITHIN-SESSION INDEPENDENT-SPLIT INFERENCE\n"
        )
        out.write(
            "-" * WIDTH + "\n"
        )
        out.write(
            render(within_meta)
            + "\n\n"
        )
        out.write(
            table_text(
                within_df,
                WITHIN_SHOW,
            )
            + "\n"
        )

        out.write(
            "\nBETWEEN-SESSION EXACT PERMUTATION INFERENCE\n"
        )
        out.write(
            "-" * WIDTH + "\n"
        )
        out.write(
            render(between_meta)
            + "\n\n"
        )
        out.write(
            table_text(
                between_df,
                BETWEEN_SHOW,
            )
            + "\n"
        )

        out.write(
            "\nINFERENCE INTERPRETATION\n"
        )
        out.write(
            "-" * WIDTH + "\n"
        )
        out.write(
            "Within-session q-values are corrected separately "
            "within each first-level session's 10-test family.\n"
        )
        out.write(
            "Between-session q-values are those produced by the "
            "validated figure-contract certification family.\n"
        )
        out.write(
            "No overlapping-run stability p-values and no naive "
            "entry-wise bootstrap CIs are reported.\n"
        )

        for key, value in obj.items():
            section(
                out,
                key.upper(),
                value,
            )

    with qc_path.open(
        "w",
        encoding="utf-8",
    ) as out:

        out.write(
            "RSA v11 SECOND-LEVEL QC / RELIABILITY / INFERENCE REPORT\n"
            + "=" * WIDTH
            + "\n"
        )

        out.write(
            f"Source pickle: {source}\n"
        )

        for key, title in [
            (
                "pairwise",
                "PAIRWISE SESSION COMPARISONS",
            ),
            (
                "between_session",
                "BETWEEN-SESSION DIAGNOSTICS",
            ),
            (
                "independent_split_reliability",
                "RESTORED INDEPENDENT-SPLIT DIAGNOSTICS",
            ),
            (
                "session_consistency",
                "SESSION CONSISTENCY",
            ),
            (
                "test_retest_consistency_reference",
                "SAME-RESOLUTION TEST-RETEST REFERENCE",
            ),
            (
                "noise_ceiling",
                "NOISE CEILING STATUS",
            ),
            (
                "group_noise_ceiling",
                "GROUP NOISE CEILING",
            ),
            (
                "legacy_diagnostics_contract",
                "LEGACY DIAGNOSTICS CONTRACT",
            ),
        ]:
            if key in obj:
                section(
                    out,
                    title,
                    obj[key],
                )

        out.write(
            "\nWITHIN-SESSION INDEPENDENT-SPLIT EXACT PERMUTATION TESTS\n"
        )
        out.write(
            "-" * WIDTH + "\n"
        )
        out.write(
            render(within_meta)
            + "\n\n"
        )
        out.write(
            table_text(
                within_df,
                WITHIN_SHOW,
            )
            + "\n"
        )

        out.write(
            "\nBETWEEN-SESSION EXACT CONDITION-LABEL PERMUTATION TESTS\n"
        )
        out.write(
            "-" * WIDTH + "\n"
        )
        out.write(
            render(between_meta)
            + "\n\n"
        )
        out.write(
            table_text(
                between_df,
                BETWEEN_SHOW,
            )
            + "\n"
        )

        full_combo = str(
            obj.get(
                "full_combo_label",
                "run1-6",
            )
        )

        if not between_df.empty:
            primary = between_df[
                between_df["combo"].astype(str)
                == full_combo
            ]

            if not primary.empty:
                out.write(
                    "\nPRIMARY FULL-COMBO BETWEEN-SESSION INFERENCE\n"
                )
                out.write(
                    "-" * WIDTH + "\n"
                )
                out.write(
                    table_text(
                        primary,
                        BETWEEN_SHOW,
                    )
                    + "\n"
                )

        out.write(
            "\nINFERENCE NOTES\n"
        )
        out.write(
            "-" * WIDTH + "\n"
        )
        out.write(
            "Within-session inference is restricted to genuinely "
            "disjoint run partitions.\n"
        )
        out.write(
            "Overlapping run-subset stability comparisons remain "
            "descriptive only.\n"
        )
        out.write(
            "Exact condition-label inference enumerates all 120 "
            "permutations of the five finger labels.\n"
        )
        out.write(
            "BH-FDR is applied separately to the defined within-session "
            "and between-session test families; the two families are not "
            "silently pooled.\n"
        )


# ============================================================================
# Driver
# ============================================================================

def main() -> None:

    p = argparse.ArgumentParser(
        description=(
            "Generate complete RSA v11 reports including "
            "within-session independent-split and between-session "
            "exact permutation inference."
        )
    )

    group = p.add_mutually_exclusive_group(
        required=True
    )

    group.add_argument(
        "--first-level-pkl",
        type=Path,
    )

    group.add_argument(
        "--second-level-pkl",
        type=Path,
    )

    p.add_argument(
        "--out-dir",
        type=Path,
        default=None,
    )

    args = p.parse_args()

    source = (
        args.first_level_pkl
        or args.second_level_pkl
    ).resolve()

    obj = load_pickle(source)

    out_dir = (
        args.out_dir.resolve()
        if args.out_dir
        else source.parent
    )

    out_dir.mkdir(
        parents=True,
        exist_ok=True,
    )

    full_path = (
        out_dir
        / "full_value_report.txt"
    )

    qc_path = (
        out_dir
        / "qc_report.txt"
    )

    if args.first_level_pkl:

        within_df, within_meta = (
            build_within_session_inference(
                obj
            )
        )

        within_csv = (
            out_dir
            / "within_session_inference_table.csv"
        )

        within_df.to_csv(
            within_csv,
            index=False,
        )

        write_first_reports(
            obj,
            full_path,
            qc_path,
            source,
            within_df,
            within_meta,
        )

        print(
            "[REPORTS] FIRST LEVEL complete"
        )
        print(
            "[REPORTS] within-session inference:",
            within_csv,
        )

    else:

        contract, between_source = (
            load_or_build_figure_contract(
                source
            )
        )

        between_df, between_meta = (
            extract_between_session_inference(
                contract
            )
        )

        within_df, within_meta = (
            aggregate_within_from_secondlevel_inputs(
                obj
            )
        )

        between_csv = (
            out_dir
            / "between_session_inference_table.csv"
        )

        within_csv = (
            out_dir
            / "within_session_inference_table.csv"
        )

        between_df.to_csv(
            between_csv,
            index=False,
        )

        within_df.to_csv(
            within_csv,
            index=False,
        )

        write_second_reports(
            obj,
            full_path,
            qc_path,
            source,
            between_df,
            between_meta,
            between_source,
            within_df,
            within_meta,
        )

        print(
            "[REPORTS] SECOND LEVEL complete"
        )
        print(
            "[REPORTS] within-session inference:",
            within_csv,
        )
        print(
            "[REPORTS] between-session inference:",
            between_csv,
        )

    print(
        "[REPORTS] full values:",
        full_path,
    )
    print(
        "[REPORTS] QC / inference:",
        qc_path,
    )


if __name__ == "__main__":
    main()


