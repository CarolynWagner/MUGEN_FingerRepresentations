#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, pickle
from pathlib import Path
import numpy as np

V10=Path("/mnt/beegfs/workspace/2025-0422-Musicians7T/SPM_Prepro_FirstLevel/ROIs/RSApipeline_v10/results/rsa_final_locked.pkl")
V11=Path("/mnt/beegfs/workspace/2025-0422-Musicians7T/SPM_Prepro_FirstLevel/ROIs/RSApipeline_general_v11/results/second_level/sub-01/roi-M1_legacy/rsa_secondlevel.pkl")
RTOL=1e-10
ATOL=1e-12

def load(p):
    with Path(p).open("rb") as f:return pickle.load(f)

def numeric(x):
    return isinstance(x,(int,float,np.integer,np.floating)) and not isinstance(x,bool)

def cmp(a,b,rtol,atol):
    aa=np.asarray(a,dtype=float); bb=np.asarray(b,dtype=float)
    if np.array_equal(aa,bb,equal_nan=True): return "EXACT",0.0,0.0
    d=np.abs(aa-bb); ma=float(np.nanmax(d))
    mr=float(np.nanmax(d/np.maximum(np.abs(bb),atol)))
    if np.allclose(aa,bb,rtol=rtol,atol=atol,equal_nan=True):
        return "WITHIN_TOLERANCE",ma,mr
    return "FAIL",ma,mr

def recurse(path,a,b,records,rtol,atol):
    if isinstance(a,dict) and isinstance(b,dict):
        if set(a)!=set(b):
            records.append({"field":path,"status":"FAIL","reason":f"key mismatch v10-only={sorted(set(a)-set(b))} v11-only={sorted(set(b)-set(a))}"})
            return
        for k in a: recurse(f"{path}.{k}" if path else k,a[k],b[k],records,rtol,atol)
        return
    if isinstance(a,(list,tuple)) and isinstance(b,(list,tuple)):
        records.append({"field":path,"status":"EXACT_METADATA" if list(a)==list(b) else "FAIL"})
        return
    if numeric(a) and numeric(b):
        s,ma,mr=cmp(a,b,rtol,atol)
        records.append({"field":path,"status":s,"max_abs_diff":ma,"max_rel_diff":mr})
        return
    records.append({"field":path,"status":"EXACT_METADATA" if a==b else "FAIL"})

def main():
    p=argparse.ArgumentParser()
    p.add_argument("--v10",type=Path,default=V10)
    p.add_argument("--v11",type=Path,default=V11)
    p.add_argument("--rtol",type=float,default=RTOL)
    p.add_argument("--atol",type=float,default=ATOL)
    p.add_argument("--report",type=Path,default=Path("results/v10_v11_secondlevel_complete_validation.json"))
    a=p.parse_args()
    x,y=load(a.v10),load(a.v11)

    keys=[
        "between_session",
        "independent_split_reliability",
        "session_consistency",
        "test_retest_consistency_reference",
        "noise_ceiling",
    ]
    records=[]
    for k in keys:
        if k not in x or k not in y:
            records.append({"field":k,"status":"FAIL","reason":f"missing v10={k in x}, v11={k in y}"})
        else:
            recurse(k,x[k],y[k],records,a.rtol,a.atol)

    counts={}
    for r in records: counts[r["status"]]=counts.get(r["status"],0)+1
    verdict="PASS" if counts.get("FAIL",0)==0 else "FAIL"
    report={"validation":"complete restored second-level diagnostics","status_counts":counts,"verdict":verdict,"records":records}
    a.report.parent.mkdir(parents=True,exist_ok=True)
    a.report.write_text(json.dumps(report,indent=2,default=str))

    print("="*80)
    print("V10.3 -> V11 COMPLETE SECOND-LEVEL DIAGNOSTICS")
    print("="*80)
    for r in records:
        if r["status"]=="FAIL":
            print("FAIL",r["field"],r.get("reason",""))
    print()
    for k in ("EXACT","WITHIN_TOLERANCE","EXACT_METADATA","FAIL"):
        print(f"{k:20s}: {counts.get(k,0)}")
    print()
    print("FINAL RESTORED-DIAGNOSTICS VERDICT:",verdict)
    print("Report:",a.report)
    if verdict!="PASS": raise SystemExit(1)

if __name__=="__main__":main()





