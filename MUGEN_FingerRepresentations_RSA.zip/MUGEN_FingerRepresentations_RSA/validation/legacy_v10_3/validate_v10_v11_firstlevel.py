#!/usr/bin/env python3
"""
validate_v10_v11_firstlevel.py

Formal regression validator:
    frozen RSA v10.3 whole-M1 analysis
vs
    generalized RSA v11 first-level M1_legacy outputs

Purpose
-------
This script checks whether the v11 refactor reproduces the deterministic
first-level quantities in the frozen v10.3 contract for ses18/ses19/ses20.

It is deliberately defensive: it first inspects the v11 first-level objects,
then extracts only quantities that can be mapped unambiguously to the frozen
v10.3 contract. It reports:

    EXACT
    WITHIN_TOLERANCE
    FAIL
    NOT_COMPARABLE

and ends with an overall regression verdict.

Default paths are configured for the current sub-01 validation.

Scientific scope
----------------
Primary regression targets:
- full-run and run-combination crossnobis RDMs
- RDM representations raw / vis01 / mean_norm
- n_voxels where available
- FSI raw / normalized where represented in both objects
- within-session quantities where represented in both objects
- precision metadata / residual DOF where represented in both objects

Bootstrap/stochastic outputs are NOT required to be bitwise identical unless
they are stored deterministically in both contracts.

No scientific result is modified by this script.
"""

from __future__ import annotations

import argparse
import json
import math
import pickle
from pathlib import Path
from typing import Any

import numpy as np


DEFAULT_V10 = Path(
    "/mnt/beegfs/workspace/2025-0422-Musicians7T/"
    "SPM_Prepro_FirstLevel/ROIs/RSApipeline_v10/results/rsa_final_locked.pkl"
)

DEFAULT_V11_ROOT = Path(
    "/mnt/beegfs/workspace/2025-0422-Musicians7T/"
    "SPM_Prepro_FirstLevel/ROIs/RSApipeline_general_v11/results/first_level"
)

SESSIONS = ("ses18", "ses19", "ses20")
DEFAULT_SUBJECT = "sub-01"
DEFAULT_ROI = "M1_legacy"

RTOL = 1e-10
ATOL = 1e-12


def load_pickle(path: Path) -> Any:
    if not path.exists():
        raise FileNotFoundError(path)
    with path.open("rb") as f:
        return pickle.load(f)


def is_number(x: Any) -> bool:
    return isinstance(x, (int, float, np.number)) and not isinstance(x, bool)


def normalize_array(x: Any) -> np.ndarray:
    return np.asarray(x, dtype=np.float64)


def compare_numeric(a: Any, b: Any, rtol: float, atol: float) -> dict:
    aa = normalize_array(a)
    bb = normalize_array(b)

    if aa.shape != bb.shape:
        return {
            "status": "FAIL",
            "reason": f"shape mismatch {aa.shape} vs {bb.shape}",
        }

    if not (np.isfinite(aa).all() and np.isfinite(bb).all()):
        same_nan = np.array_equal(np.isnan(aa), np.isnan(bb))
        same_inf = np.array_equal(np.isinf(aa), np.isinf(bb))
        if not (same_nan and same_inf):
            return {
                "status": "FAIL",
                "reason": "non-finite pattern mismatch",
            }

    if np.array_equal(aa, bb, equal_nan=True):
        return {
            "status": "EXACT",
            "max_abs_diff": 0.0,
            "max_rel_diff": 0.0,
        }

    finite = np.isfinite(aa) & np.isfinite(bb)
    if finite.any():
        diff = np.abs(aa[finite] - bb[finite])
        max_abs = float(np.max(diff))
        denom = np.maximum(np.abs(bb[finite]), atol)
        max_rel = float(np.max(diff / denom))
    else:
        max_abs = math.nan
        max_rel = math.nan

    if np.allclose(aa, bb, rtol=rtol, atol=atol, equal_nan=True):
        return {
            "status": "WITHIN_TOLERANCE",
            "max_abs_diff": max_abs,
            "max_rel_diff": max_rel,
        }

    return {
        "status": "FAIL",
        "max_abs_diff": max_abs,
        "max_rel_diff": max_rel,
    }


def safe_get(obj: Any, path: tuple[str, ...]) -> Any:
    cur = obj
    for key in path:
        if not isinstance(cur, dict) or key not in cur:
            raise KeyError(path)
        cur = cur[key]
    return cur


def find_first_key(obj: Any, candidates: tuple[str, ...]) -> tuple[str, Any] | None:
    if not isinstance(obj, dict):
        return None
    for key in candidates:
        if key in obj:
            return key, obj[key]
    return None


def describe_object(obj: Any, max_depth: int = 2, depth: int = 0) -> Any:
    if depth >= max_depth:
        if isinstance(obj, dict):
            return f"<dict n={len(obj)}>"
        if isinstance(obj, np.ndarray):
            return f"<ndarray shape={obj.shape} dtype={obj.dtype}>"
        if isinstance(obj, (list, tuple)):
            return f"<{type(obj).__name__} n={len(obj)}>"
        return f"<{type(obj).__name__}>"

    if isinstance(obj, dict):
        return {
            str(k): describe_object(v, max_depth, depth + 1)
            for k, v in obj.items()
        }
    if isinstance(obj, np.ndarray):
        return f"<ndarray shape={obj.shape} dtype={obj.dtype}>"
    if isinstance(obj, (list, tuple)):
        return f"<{type(obj).__name__} n={len(obj)}>"
    return obj if isinstance(obj, (str, int, float, bool, type(None))) else f"<{type(obj).__name__}>"


def get_v10_rdm_object(v10: dict, session: str, combo: str) -> dict:
    return v10["rdms"][session][combo]


def get_v11_rdms(v11: dict) -> dict | None:
    hit = find_first_key(
        v11,
        (
            "rdms",
            "RDMs",
            "rdm_contract",
            "rdm_objects",
        ),
    )
    if hit is not None and isinstance(hit[1], dict):
        return hit[1]

    # Some first-level objects may nest outputs under "results".
    if isinstance(v11.get("results"), dict):
        hit = find_first_key(
            v11["results"],
            ("rdms", "RDMs", "rdm_contract", "rdm_objects"),
        )
        if hit is not None and isinstance(hit[1], dict):
            return hit[1]

    return None


def normalize_v11_combo_map(rdms: dict, session: str) -> dict:
    """
    Return combo -> RDM object.

    Supports:
      rdms[combo]
      rdms[session][combo]
    """
    if session in rdms and isinstance(rdms[session], dict):
        return rdms[session]
    return rdms


def compare_rdm_sets(
    v10: dict,
    v11: dict,
    session: str,
    rtol: float,
    atol: float,
) -> list[dict]:

    records = []

    v10_map = v10["rdms"][session]
    v11_rdms = get_v11_rdms(v11)

    if v11_rdms is None:
        records.append({
            "session": session,
            "category": "RDM",
            "field": "*",
            "status": "NOT_COMPARABLE",
            "reason": "No recognizable RDM container in v11 first-level object",
        })
        return records

    v11_map = normalize_v11_combo_map(v11_rdms, session)

    for combo, v10_obj in v10_map.items():
        if combo not in v11_map:
            records.append({
                "session": session,
                "category": "RDM",
                "field": combo,
                "status": "FAIL",
                "reason": "combo missing in v11",
            })
            continue

        v11_obj = v11_map[combo]

        # v11 may store a raw matrix directly.
        if not isinstance(v11_obj, dict):
            result = compare_numeric(v10_obj["raw"], v11_obj, rtol, atol)
            result.update({
                "session": session,
                "category": "RDM",
                "field": f"{combo}.raw",
            })
            records.append(result)
            continue

        for rep in ("raw", "vis01", "mean_norm"):
            if rep not in v11_obj:
                records.append({
                    "session": session,
                    "category": "RDM",
                    "field": f"{combo}.{rep}",
                    "status": "NOT_COMPARABLE",
                    "reason": f"{rep} missing in v11 RDM object",
                })
                continue

            result = compare_numeric(
                v10_obj[rep],
                v11_obj[rep],
                rtol,
                atol,
            )
            result.update({
                "session": session,
                "category": "RDM",
                "field": f"{combo}.{rep}",
            })
            records.append(result)

        if "n_voxels" in v10_obj and "n_voxels" in v11_obj:
            status = (
                "EXACT"
                if int(v10_obj["n_voxels"]) == int(v11_obj["n_voxels"])
                else "FAIL"
            )
            records.append({
                "session": session,
                "category": "RDM",
                "field": f"{combo}.n_voxels",
                "status": status,
                "v10": int(v10_obj["n_voxels"]),
                "v11": int(v11_obj["n_voxels"]),
            })

    return records


def compare_scalar_candidates(
    v10: dict,
    v11: dict,
    session: str,
    category: str,
    v10_candidates: tuple[tuple[str, ...], ...],
    v11_candidates: tuple[tuple[str, ...], ...],
    rtol: float,
    atol: float,
) -> list[dict]:
    records = []

    v10_value = None
    v10_path = None
    for path in v10_candidates:
        try:
            val = safe_get(v10, path)
            if is_number(val) or isinstance(val, (list, tuple, np.ndarray)):
                v10_value = val
                v10_path = path
                break
        except KeyError:
            pass

    v11_value = None
    v11_path = None
    for path in v11_candidates:
        try:
            val = safe_get(v11, path)
            if is_number(val) or isinstance(val, (list, tuple, np.ndarray)):
                v11_value = val
                v11_path = path
                break
        except KeyError:
            pass

    if v10_value is None or v11_value is None:
        records.append({
            "session": session,
            "category": category,
            "field": category,
            "status": "NOT_COMPARABLE",
            "reason": (
                f"v10 path={v10_path}; v11 path={v11_path}"
            ),
        })
        return records

    result = compare_numeric(v10_value, v11_value, rtol, atol)
    result.update({
        "session": session,
        "category": category,
        "field": category,
        "v10_path": ".".join(v10_path),
        "v11_path": ".".join(v11_path),
    })
    records.append(result)
    return records


def compare_metadata(v10: dict, v11: dict, session: str) -> list[dict]:
    records = []

    # Compare residual DOF if unambiguously available.
    v10_dof = None
    if isinstance(v10.get("precision_info"), dict):
        pi = v10["precision_info"].get(session)
        if isinstance(pi, dict):
            for k in ("dof", "residual_dof"):
                if k in pi and is_number(pi[k]):
                    v10_dof = float(pi[k])
                    break

    v11_dof = None
    for container in (v11, v11.get("meta", {}), v11.get("qc", {})):
        if isinstance(container, dict):
            for k in ("residual_dof", "dof"):
                if k in container and is_number(container[k]):
                    v11_dof = float(container[k])
                    break
        if v11_dof is not None:
            break

    if v10_dof is not None and v11_dof is not None:
        records.append({
            "session": session,
            "category": "metadata",
            "field": "residual_dof",
            "status": "EXACT" if v10_dof == v11_dof else "FAIL",
            "v10": v10_dof,
            "v11": v11_dof,
        })
    else:
        records.append({
            "session": session,
            "category": "metadata",
            "field": "residual_dof",
            "status": "NOT_COMPARABLE",
            "reason": f"v10={v10_dof}, v11={v11_dof}",
        })

    return records


def session_v11_path(root: Path, subject: str, session: str, roi: str) -> Path:
    return root / subject / session / f"roi-{roi}" / "rsa_firstlevel.pkl"


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("--v10", type=Path, default=DEFAULT_V10)
    p.add_argument("--v11-root", type=Path, default=DEFAULT_V11_ROOT)
    p.add_argument("--subject", default=DEFAULT_SUBJECT)
    p.add_argument("--roi", default=DEFAULT_ROI)
    p.add_argument("--rtol", type=float, default=RTOL)
    p.add_argument("--atol", type=float, default=ATOL)
    p.add_argument(
        "--report",
        type=Path,
        default=Path("results/v10_v11_firstlevel_regression.json"),
    )
    p.add_argument(
        "--schema-report",
        type=Path,
        default=Path("results/v11_firstlevel_schema_summary.json"),
    )
    args = p.parse_args()

    v10 = load_pickle(args.v10)

    if not isinstance(v10, dict):
        raise TypeError("Frozen v10 object is not a dict")

    records = []
    schema_summary = {}

    for session in SESSIONS:
        v11_path = session_v11_path(
            args.v11_root,
            args.subject,
            session,
            args.roi,
        )
        v11 = load_pickle(v11_path)

        if not isinstance(v11, dict):
            raise TypeError(
                f"{session}: v11 first-level object is not a dict"
            )

        schema_summary[session] = describe_object(v11, max_depth=3)

        records.extend(
            compare_rdm_sets(
                v10,
                v11,
                session,
                args.rtol,
                args.atol,
            )
        )

        # Candidate scalar mappings. These are intentionally conservative.
        records.extend(
            compare_scalar_candidates(
                v10,
                v11,
                session,
                "fsi_raw",
                (
                    ("fsi_raw", session),
                    ("fsi_raw", session, "value"),
                ),
                (
                    ("fsi_raw",),
                    ("results", "fsi_raw"),
                    ("fsi", "raw"),
                ),
                args.rtol,
                args.atol,
            )
        )

        records.extend(
            compare_scalar_candidates(
                v10,
                v11,
                session,
                "fsi_normalized",
                (
                    ("fsi_normalized", session),
                    ("fsi_normalized", session, "value"),
                ),
                (
                    ("fsi_normalized",),
                    ("results", "fsi_normalized"),
                    ("fsi", "normalized"),
                ),
                args.rtol,
                args.atol,
            )
        )

        records.extend(
            compare_metadata(v10, v11, session)
        )

    counts = {}
    for rec in records:
        counts[rec["status"]] = counts.get(rec["status"], 0) + 1

    # Certification logic:
    # Any FAIL => FAIL.
    # Otherwise at least one exact/tolerance comparison must exist.
    n_fail = counts.get("FAIL", 0)
    n_compared = (
        counts.get("EXACT", 0)
        + counts.get("WITHIN_TOLERANCE", 0)
    )

    if n_fail:
        verdict = "FAIL"
    elif n_compared == 0:
        verdict = "INCONCLUSIVE"
    else:
        verdict = "PASS"

    report = {
        "validation": "v10.3 -> v11 first-level regression",
        "subject": args.subject,
        "roi": args.roi,
        "sessions": list(SESSIONS),
        "v10": str(args.v10),
        "v11_root": str(args.v11_root),
        "rtol": args.rtol,
        "atol": args.atol,
        "status_counts": counts,
        "overall_verdict": verdict,
        "records": records,
    }

    args.report.parent.mkdir(parents=True, exist_ok=True)
    args.schema_report.parent.mkdir(parents=True, exist_ok=True)

    args.report.write_text(
        json.dumps(report, indent=2)
    )
    args.schema_report.write_text(
        json.dumps(schema_summary, indent=2)
    )

    print()
    print("=" * 80)
    print("V10.3 -> V11 FIRST-LEVEL REGRESSION")
    print("=" * 80)
    print(f"Subject: {args.subject}")
    print(f"ROI:     {args.roi}")
    print(f"RTOL:    {args.rtol:g}")
    print(f"ATOL:    {args.atol:g}")
    print()

    for session in SESSIONS:
        print(f"--- {session} ---")
        for rec in records:
            if rec["session"] != session:
                continue

            field = f"{rec['category']}::{rec['field']}"
            status = rec["status"]

            extra = ""
            if "max_abs_diff" in rec:
                extra = (
                    f" | max_abs={rec['max_abs_diff']:.3e}"
                    f" max_rel={rec['max_rel_diff']:.3e}"
                )
            elif "reason" in rec:
                extra = f" | {rec['reason']}"

            print(f"{status:18s} {field}{extra}")
        print()

    print("STATUS COUNTS:")
    for key in (
        "EXACT",
        "WITHIN_TOLERANCE",
        "NOT_COMPARABLE",
        "FAIL",
    ):
        print(f"  {key:18s}: {counts.get(key, 0)}")

    print()
    print(f"OVERALL VERDICT: {verdict}")
    print(f"Report: {args.report}")
    print(f"Schema summary: {args.schema_report}")
    print()

    if verdict == "FAIL":
        raise SystemExit(1)

    if verdict == "INCONCLUSIVE":
        raise SystemExit(2)


if __name__ == "__main__":
    main()
