#!/usr/bin/env python3
"""
validate_v10_v11_firstlevel_gate2b.py

Gate 2b validator for RSA v11.

Purpose
-------
The primary v10.3 -> v11 first-level regression has already passed with
108 EXACT RDM/voxel comparisons and 0 failures.

This script addresses the remaining nine NOT_COMPARABLE fields:
    - fsi_raw
    - fsi_normalized
    - residual_dof
for:
    - ses18
    - ses19
    - ses20

Rather than guessing a fixed schema, the script:
1. loads the frozen v10.3 contract;
2. loads each v11 first-level pickle;
3. recursively searches both objects for FSI- and DOF-related fields;
4. extracts session-appropriate numeric candidates;
5. compares unambiguous matches;
6. writes a detailed discovery report showing exactly where each value lives;
7. certifies Gate 2b only if all three fields can be mapped and compared for
   all three sessions without numerical mismatch.

No scientific quantity is recomputed. This is a schema-mapping and regression
validation script only.
"""

from __future__ import annotations

import argparse
import json
import math
import pickle
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable

import numpy as np


DEFAULT_V10 = Path(
    "/mnt/beegfs/workspace/2025-0422-Musicians7T/"
    "SPM_Prepro_FirstLevel/ROIs/RSApipeline_v10/results/rsa_final_locked.pkl"
)

DEFAULT_V11_ROOT = Path(
    "/mnt/beegfs/workspace/2025-0422-Musicians7T/"
    "SPM_Prepro_FirstLevel/ROIs/RSApipeline_general_v11/results/first_level"
)

DEFAULT_SUBJECT = "sub-01"
DEFAULT_ROI = "M1_legacy"
SESSIONS = ("ses18", "ses19", "ses20")

RTOL = 1e-10
ATOL = 1e-12


# ---------------------------------------------------------------------------
# Utilities
# ---------------------------------------------------------------------------

def load_pickle(path: Path) -> Any:
    if not path.exists():
        raise FileNotFoundError(path)
    with path.open("rb") as f:
        return pickle.load(f)


def is_scalar_numeric(x: Any) -> bool:
    return (
        isinstance(x, (int, float, np.integer, np.floating))
        and not isinstance(x, bool)
    )


def numeric_array(x: Any) -> np.ndarray | None:
    """
    Convert a numeric scalar/list/tuple/array to float64 array.

    Returns None if x cannot be interpreted as a numeric quantity.
    """
    if is_scalar_numeric(x):
        return np.asarray(x, dtype=np.float64)

    if isinstance(x, np.ndarray):
        try:
            arr = np.asarray(x, dtype=np.float64)
            return arr
        except Exception:
            return None

    if isinstance(x, (list, tuple)):
        try:
            arr = np.asarray(x, dtype=np.float64)
            if arr.dtype.kind in "fiu":
                return arr
        except Exception:
            return None

    return None


def compare_numeric(a: Any, b: Any, rtol: float, atol: float) -> dict:
    aa = numeric_array(a)
    bb = numeric_array(b)

    if aa is None or bb is None:
        return {
            "status": "FAIL",
            "reason": "one or both values are not numeric",
        }

    if aa.shape != bb.shape:
        # Allow scalar vs length-1 array.
        if aa.size == 1 and bb.size == 1:
            aa = aa.reshape(())
            bb = bb.reshape(())
        else:
            return {
                "status": "FAIL",
                "reason": f"shape mismatch {aa.shape} vs {bb.shape}",
            }

    if np.array_equal(aa, bb, equal_nan=True):
        return {
            "status": "EXACT",
            "max_abs_diff": 0.0,
            "max_rel_diff": 0.0,
        }

    finite = np.isfinite(aa) & np.isfinite(bb)

    if finite.any():
        diff = np.abs(aa[finite] - bb[finite])
        max_abs = float(np.max(diff))
        denom = np.maximum(np.abs(bb[finite]), atol)
        max_rel = float(np.max(diff / denom))
    else:
        max_abs = math.nan
        max_rel = math.nan

    if np.allclose(aa, bb, rtol=rtol, atol=atol, equal_nan=True):
        return {
            "status": "WITHIN_TOLERANCE",
            "max_abs_diff": max_abs,
            "max_rel_diff": max_rel,
        }

    return {
        "status": "FAIL",
        "max_abs_diff": max_abs,
        "max_rel_diff": max_rel,
    }


def path_to_string(path: tuple[str, ...]) -> str:
    return ".".join(path)


def safe_json_value(x: Any) -> Any:
    if isinstance(x, np.ndarray):
        return x.tolist()
    if isinstance(x, np.generic):
        return x.item()
    if isinstance(x, Path):
        return str(x)
    if isinstance(x, (str, int, float, bool, type(None))):
        return x
    if isinstance(x, (list, tuple)):
        return [safe_json_value(v) for v in x]
    if isinstance(x, dict):
        return {str(k): safe_json_value(v) for k, v in x.items()}
    return repr(x)


# ---------------------------------------------------------------------------
# Recursive discovery
# ---------------------------------------------------------------------------

@dataclass
class Candidate:
    path: tuple[str, ...]
    value: Any
    score: int
    reason: str


def walk_object(
    obj: Any,
    path: tuple[str, ...] = (),
    max_depth: int = 8,
) -> Iterable[tuple[tuple[str, ...], Any]]:
    """
    Yield nested paths and values for dict/list/tuple structures.

    NumPy arrays are treated as leaf values.
    """
    yield path, obj

    if len(path) >= max_depth:
        return

    if isinstance(obj, dict):
        for key, value in obj.items():
            yield from walk_object(
                value,
                path + (str(key),),
                max_depth=max_depth,
            )

    elif isinstance(obj, (list, tuple)):
        # Avoid exploding very large vectors.
        if len(obj) <= 50:
            for i, value in enumerate(obj):
                yield from walk_object(
                    value,
                    path + (f"[{i}]",),
                    max_depth=max_depth,
                )


def keyword_score(
    path: tuple[str, ...],
    target: str,
    session: str | None,
) -> tuple[int, list[str]]:
    """
    Score how well a path matches a requested semantic field.
    """
    text = ".".join(path).lower()
    reasons = []
    score = 0

    if target == "fsi_raw":
        if "fsi_raw" in text:
            score += 100
            reasons.append("contains fsi_raw")
        elif "fsi" in text and "raw" in text:
            score += 80
            reasons.append("contains fsi + raw")

    elif target == "fsi_normalized":
        if "fsi_normalized" in text:
            score += 100
            reasons.append("contains fsi_normalized")
        elif "fsi_norm" in text:
            score += 95
            reasons.append("contains fsi_norm")
        elif "fsi" in text and ("normalized" in text or "normalised" in text):
            score += 80
            reasons.append("contains fsi + normalized")

    elif target == "residual_dof":
        if "residual_dof" in text:
            score += 100
            reasons.append("contains residual_dof")
        elif "residual" in text and "dof" in text:
            score += 90
            reasons.append("contains residual + dof")
        elif text.endswith(".dof") or ".dof." in text:
            score += 60
            reasons.append("contains dof")

    if session:
        if session.lower() in text:
            score += 30
            reasons.append(f"contains {session}")

        # Also recognize session number without "ses".
        session_number = session.lower().replace("ses", "")
        if session_number and session_number in text:
            score += 5

    # Prefer shallower, direct contract paths slightly.
    score -= max(0, len(path) - 4)

    return score, reasons


def discover_candidates(
    obj: Any,
    target: str,
    session: str | None,
) -> list[Candidate]:
    candidates = []

    for path, value in walk_object(obj):
        arr = numeric_array(value)
        if arr is None:
            continue

        score, reasons = keyword_score(
            path,
            target,
            session,
        )

        if score <= 0:
            continue

        candidates.append(
            Candidate(
                path=path,
                value=value,
                score=score,
                reason=", ".join(reasons),
            )
        )

    candidates.sort(
        key=lambda c: (
            -c.score,
            len(c.path),
            path_to_string(c.path),
        )
    )

    return candidates


def choose_candidate(
    candidates: list[Candidate],
    target: str,
    side: str,
) -> tuple[Candidate | None, str]:
    """
    Choose a candidate only when the best match is unambiguous enough.

    If several candidates tie for the best score but contain identical numeric
    values, choosing the first is safe and reported as duplicate-equivalent.
    """
    if not candidates:
        return None, f"no {target} candidate found in {side}"

    best_score = candidates[0].score
    best = [c for c in candidates if c.score == best_score]

    if len(best) == 1:
        return best[0], "unique best-scoring candidate"

    # If all tied values are numerically identical, ambiguity is only structural.
    first_arr = numeric_array(best[0].value)
    all_same = True

    for candidate in best[1:]:
        arr = numeric_array(candidate.value)
        if (
            first_arr is None
            or arr is None
            or first_arr.shape != arr.shape
            or not np.array_equal(first_arr, arr, equal_nan=True)
        ):
            all_same = False
            break

    if all_same:
        return (
            best[0],
            f"{len(best)} tied paths with numerically identical values",
        )

    return (
        None,
        (
            f"ambiguous {target} mapping in {side}: "
            f"{len(best)} top-scoring candidates differ numerically"
        ),
    )


# ---------------------------------------------------------------------------
# Session extraction / special handling
# ---------------------------------------------------------------------------

def v11_path(
    root: Path,
    subject: str,
    session: str,
    roi: str,
) -> Path:
    return (
        root
        / subject
        / session
        / f"roi-{roi}"
        / "rsa_firstlevel.pkl"
    )


def session_specific_view(
    obj: Any,
    session: str,
) -> Any:
    """
    If a top-level/session-level container exists, return it.

    Otherwise return the full object and let recursive discovery find the field.
    """
    if isinstance(obj, dict):
        if session in obj:
            return obj[session]

        for key in (
            "sessions",
            "session_results",
            "results_by_session",
        ):
            container = obj.get(key)
            if isinstance(container, dict) and session in container:
                return container[session]

    return obj


def extract_field(
    obj: Any,
    target: str,
    session: str,
    side: str,
) -> dict:
    """
    Discover, choose, and describe a candidate.
    """
    view = session_specific_view(obj, session)
    candidates = discover_candidates(
        view,
        target,
        session=session,
    )

    chosen, decision = choose_candidate(
        candidates,
        target,
        side,
    )

    return {
        "chosen": chosen,
        "decision": decision,
        "candidates": candidates[:20],
    }


# ---------------------------------------------------------------------------
# Main validation
# ---------------------------------------------------------------------------

def main() -> None:
    p = argparse.ArgumentParser()

    p.add_argument(
        "--v10",
        type=Path,
        default=DEFAULT_V10,
    )

    p.add_argument(
        "--v11-root",
        type=Path,
        default=DEFAULT_V11_ROOT,
    )

    p.add_argument(
        "--subject",
        default=DEFAULT_SUBJECT,
    )

    p.add_argument(
        "--roi",
        default=DEFAULT_ROI,
    )

    p.add_argument(
        "--rtol",
        type=float,
        default=RTOL,
    )

    p.add_argument(
        "--atol",
        type=float,
        default=ATOL,
    )

    p.add_argument(
        "--report",
        type=Path,
        default=Path(
            "results/v10_v11_firstlevel_gate2b.json"
        ),
    )

    args = p.parse_args()

    v10 = load_pickle(args.v10)

    if not isinstance(v10, dict):
        raise TypeError(
            "Frozen v10.3 contract must be a dictionary."
        )

    fields = (
        "fsi_raw",
        "fsi_normalized",
        "residual_dof",
    )

    records = []

    for session in SESSIONS:
        v11_file = v11_path(
            args.v11_root,
            args.subject,
            session,
            args.roi,
        )

        v11 = load_pickle(v11_file)

        print()
        print("=" * 80)
        print(f"{session}")
        print("=" * 80)

        for field in fields:
            left = extract_field(
                v10,
                field,
                session,
                side="v10",
            )

            right = extract_field(
                v11,
                field,
                session,
                side="v11",
            )

            rec = {
                "session": session,
                "field": field,
                "v10_decision": left["decision"],
                "v11_decision": right["decision"],
            }

            lchosen = left["chosen"]
            rchosen = right["chosen"]

            rec["v10_candidates"] = [
                {
                    "path": path_to_string(c.path),
                    "score": c.score,
                    "reason": c.reason,
                    "value": safe_json_value(c.value),
                }
                for c in left["candidates"]
            ]

            rec["v11_candidates"] = [
                {
                    "path": path_to_string(c.path),
                    "score": c.score,
                    "reason": c.reason,
                    "value": safe_json_value(c.value),
                }
                for c in right["candidates"]
            ]

            if lchosen is None or rchosen is None:
                rec["status"] = "UNMAPPED"

                print(
                    f"{'UNMAPPED':18s} {field}"
                )
                print(
                    f"  v10: {left['decision']}"
                )
                print(
                    f"  v11: {right['decision']}"
                )

                records.append(rec)
                continue

            rec["v10_path"] = path_to_string(
                lchosen.path
            )
            rec["v11_path"] = path_to_string(
                rchosen.path
            )

            rec["v10_value"] = safe_json_value(
                lchosen.value
            )
            rec["v11_value"] = safe_json_value(
                rchosen.value
            )

            comparison = compare_numeric(
                lchosen.value,
                rchosen.value,
                args.rtol,
                args.atol,
            )

            rec.update(comparison)

            extra = ""

            if "max_abs_diff" in comparison:
                extra = (
                    f" | max_abs={comparison['max_abs_diff']:.3e}"
                    f" max_rel={comparison['max_rel_diff']:.3e}"
                )

            elif "reason" in comparison:
                extra = (
                    f" | {comparison['reason']}"
                )

            print(
                f"{comparison['status']:18s} {field}{extra}"
            )
            print(
                f"  v10: {rec['v10_path']} = {rec['v10_value']}"
            )
            print(
                f"  v11: {rec['v11_path']} = {rec['v11_value']}"
            )

            records.append(rec)

    counts = {}

    for rec in records:
        status = rec["status"]
        counts[status] = (
            counts.get(status, 0) + 1
        )

    if counts.get("FAIL", 0) > 0:
        verdict = "FAIL"

    elif counts.get("UNMAPPED", 0) > 0:
        verdict = "INCONCLUSIVE"

    elif (
        counts.get("EXACT", 0)
        + counts.get("WITHIN_TOLERANCE", 0)
        == len(SESSIONS) * len(fields)
    ):
        verdict = "PASS"

    else:
        verdict = "INCONCLUSIVE"

    report = {
        "validation": (
            "RSA v10.3 -> v11 Gate 2b: "
            "FSI raw, FSI normalized, residual DOF"
        ),
        "subject": args.subject,
        "roi": args.roi,
        "sessions": list(SESSIONS),
        "fields": list(fields),
        "rtol": args.rtol,
        "atol": args.atol,
        "status_counts": counts,
        "overall_verdict": verdict,
        "records": records,
    }

    args.report.parent.mkdir(
        parents=True,
        exist_ok=True,
    )

    args.report.write_text(
        json.dumps(
            report,
            indent=2,
        )
    )

    print()
    print("=" * 80)
    print("GATE 2b SUMMARY")
    print("=" * 80)

    for key in (
        "EXACT",
        "WITHIN_TOLERANCE",
        "UNMAPPED",
        "FAIL",
    ):
        print(
            f"{key:18s}: {counts.get(key, 0)}"
        )

    print()
    print(
        f"OVERALL VERDICT: {verdict}"
    )
    print(
        f"Report: {args.report}"
    )

    if verdict == "FAIL":
        raise SystemExit(1)

    if verdict == "INCONCLUSIVE":
        raise SystemExit(2)


if __name__ == "__main__":
    main()




