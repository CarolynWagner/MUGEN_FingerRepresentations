#!/usr/bin/env python3
"""
validate_v10_v11_firstlevel_gate2c.py

Definitive first-level regression validator for RSA v11 against frozen v10.3.

Validated comparison set
------------------------
Primary RDM/voxel regression (already established conceptually):
    108 comparisons

Gate 2c adds:
    residual DOF:                         3
    raw FSI:                             27
    reconstructed normalized FSI:        27

Total first-level numerical comparisons:
    165

Important design point
----------------------
v10.3 stores:
    fsi_raw[session][combo]
    fsi_normalized[session][combo]

v11 first-level stores only:
    fsi_raw[combo]
inside each session pickle.

This is appropriate because v10.3 normalized FSI is defined across sessions:
    raw FSI for one session
    divided by
    mean raw FSI across sessions for that run combination

Therefore this validator reconstructs the normalized FSI from the three v11
session-level raw FSI dictionaries using the exact frozen v10.3 rule, and then
compares the reconstructed values to v10.3.

No scientific quantity is modified and no first-level analysis is rerun.
"""

from __future__ import annotations

import argparse
import json
import math
import pickle
from pathlib import Path
from typing import Any

import numpy as np


DEFAULT_V10 = Path(
    "/mnt/beegfs/workspace/2025-0422-Musicians7T/"
    "SPM_Prepro_FirstLevel/ROIs/RSApipeline_v10/results/rsa_final_locked.pkl"
)

DEFAULT_V11_ROOT = Path(
    "/mnt/beegfs/workspace/2025-0422-Musicians7T/"
    "SPM_Prepro_FirstLevel/ROIs/RSApipeline_general_v11/results/first_level"
)

DEFAULT_SUBJECT = "sub-01"
DEFAULT_ROI = "M1_legacy"

SESSIONS = ("ses18", "ses19", "ses20")

RTOL = 1e-10
ATOL = 1e-12


def load_pickle(path: Path) -> Any:
    if not path.exists():
        raise FileNotFoundError(path)
    with path.open("rb") as f:
        return pickle.load(f)


def compare_numeric(a: Any, b: Any, rtol: float, atol: float) -> dict:
    aa = np.asarray(a, dtype=np.float64)
    bb = np.asarray(b, dtype=np.float64)

    if aa.shape != bb.shape:
        if aa.size == 1 and bb.size == 1:
            aa = aa.reshape(())
            bb = bb.reshape(())
        else:
            return {
                "status": "FAIL",
                "reason": f"shape mismatch {aa.shape} vs {bb.shape}",
            }

    if np.array_equal(aa, bb, equal_nan=True):
        return {
            "status": "EXACT",
            "max_abs_diff": 0.0,
            "max_rel_diff": 0.0,
        }

    finite = np.isfinite(aa) & np.isfinite(bb)

    if finite.any():
        diff = np.abs(aa[finite] - bb[finite])
        max_abs = float(np.max(diff))
        denom = np.maximum(np.abs(bb[finite]), atol)
        max_rel = float(np.max(diff / denom))
    else:
        max_abs = math.nan
        max_rel = math.nan

    if np.allclose(
        aa,
        bb,
        rtol=rtol,
        atol=atol,
        equal_nan=True,
    ):
        return {
            "status": "WITHIN_TOLERANCE",
            "max_abs_diff": max_abs,
            "max_rel_diff": max_rel,
        }

    return {
        "status": "FAIL",
        "max_abs_diff": max_abs,
        "max_rel_diff": max_rel,
    }


def v11_file(
    root: Path,
    subject: str,
    session: str,
    roi: str,
) -> Path:
    return (
        root
        / subject
        / session
        / f"roi-{roi}"
        / "rsa_firstlevel.pkl"
    )


def extract_v11_dof(obj: dict) -> float:
    if isinstance(obj.get("precision_info"), dict):
        pi = obj["precision_info"]
        for key in ("dof", "residual_dof"):
            if key in pi:
                return float(pi[key])

    for container_name in ("meta", "qc"):
        container = obj.get(container_name)
        if isinstance(container, dict):
            for key in ("dof", "residual_dof"):
                if key in container:
                    return float(container[key])

    raise KeyError("Could not find residual DOF in v11 first-level object.")


def extract_v10_dof(v10: dict, session: str) -> float:
    pi = v10["precision_info"][session]

    for key in ("dof", "residual_dof"):
        if key in pi:
            return float(pi[key])

    raise KeyError(
        f"Could not find residual DOF in frozen v10 precision_info[{session}]"
    )


def main() -> None:
    p = argparse.ArgumentParser()

    p.add_argument(
        "--v10",
        type=Path,
        default=DEFAULT_V10,
    )

    p.add_argument(
        "--v11-root",
        type=Path,
        default=DEFAULT_V11_ROOT,
    )

    p.add_argument(
        "--subject",
        default=DEFAULT_SUBJECT,
    )

    p.add_argument(
        "--roi",
        default=DEFAULT_ROI,
    )

    p.add_argument(
        "--rtol",
        type=float,
        default=RTOL,
    )

    p.add_argument(
        "--atol",
        type=float,
        default=ATOL,
    )

    p.add_argument(
        "--report",
        type=Path,
        default=Path(
            "results/v10_v11_firstlevel_gate2c.json"
        ),
    )

    args = p.parse_args()

    v10 = load_pickle(args.v10)

    if not isinstance(v10, dict):
        raise TypeError(
            "Frozen v10.3 contract must be a dictionary."
        )

    required_v10 = (
        "fsi_raw",
        "fsi_normalized",
        "precision_info",
    )

    for key in required_v10:
        if key not in v10:
            raise KeyError(
                f"Frozen v10.3 contract missing required key: {key}"
            )

    # ------------------------------------------------------------------
    # Load all v11 first-level session objects.
    # ------------------------------------------------------------------
    v11 = {}

    for session in SESSIONS:
        path = v11_file(
            args.v11_root,
            args.subject,
            session,
            args.roi,
        )

        obj = load_pickle(path)

        if not isinstance(obj, dict):
            raise TypeError(
                f"{session}: v11 first-level object must be a dict"
            )

        if "fsi_raw" not in obj:
            raise KeyError(
                f"{session}: v11 first-level object missing fsi_raw"
            )

        if not isinstance(obj["fsi_raw"], dict):
            raise TypeError(
                f"{session}: v11 fsi_raw must be a dictionary"
            )

        v11[session] = obj

    # ------------------------------------------------------------------
    # Establish run-combination contract.
    # ------------------------------------------------------------------
    combo_sets = []

    for session in SESSIONS:
        combo_sets.append(
            set(v10["fsi_raw"][session].keys())
        )
        combo_sets.append(
            set(v11[session]["fsi_raw"].keys())
        )

    first = combo_sets[0]

    for i, combo_set in enumerate(combo_sets[1:], start=1):
        if combo_set != first:
            raise ValueError(
                "FSI run-combination keys differ across v10/v11 objects. "
                f"Reference={sorted(first)}; comparison[{i}]={sorted(combo_set)}"
            )

    combos = list(
        v10["fsi_raw"][SESSIONS[0]].keys()
    )

    # ------------------------------------------------------------------
    # Comparison records.
    # ------------------------------------------------------------------
    records = []

    # 1. Residual DOF: 3 comparisons.
    for session in SESSIONS:
        v10_dof = extract_v10_dof(
            v10,
            session,
        )

        v11_dof = extract_v11_dof(
            v11[session]
        )

        result = compare_numeric(
            v10_dof,
            v11_dof,
            args.rtol,
            args.atol,
        )

        result.update({
            "category": "residual_dof",
            "session": session,
            "combo": None,
            "v10": v10_dof,
            "v11": v11_dof,
        })

        records.append(result)

    # 2. Raw FSI: 27 comparisons.
    for session in SESSIONS:
        for combo in combos:
            v10_value = float(
                v10["fsi_raw"][session][combo]
            )

            v11_value = float(
                v11[session]["fsi_raw"][combo]
            )

            result = compare_numeric(
                v10_value,
                v11_value,
                args.rtol,
                args.atol,
            )

            result.update({
                "category": "fsi_raw",
                "session": session,
                "combo": combo,
                "v10": v10_value,
                "v11": v11_value,
            })

            records.append(result)

    # 3. Reconstruct normalized FSI from v11 raw values using the exact
    #    v10.3 definition:
    #
    #    normalized(session, combo)
    #      = raw(session, combo)
    #        /
    #        mean(raw(all sessions, combo))
    #
    #    This produces 27 comparisons.
    reconstructed_norm = {}
    denominator_by_combo = {}

    for combo in combos:
        raw_values = np.asarray(
            [
                float(
                    v11[session]["fsi_raw"][combo]
                )
                for session in SESSIONS
            ],
            dtype=np.float64,
        )

        denominator = float(
            np.mean(raw_values)
        )

        if (
            not np.isfinite(denominator)
            or abs(denominator) <= args.atol
        ):
            raise ValueError(
                f"{combo}: invalid normalization denominator {denominator}"
            )

        denominator_by_combo[combo] = denominator

        reconstructed_norm[combo] = {
            session: float(
                v11[session]["fsi_raw"][combo]
                / denominator
            )
            for session in SESSIONS
        }

    for session in SESSIONS:
        for combo in combos:
            v10_value = float(
                v10["fsi_normalized"][session][combo]
            )

            v11_value = float(
                reconstructed_norm[combo][session]
            )

            result = compare_numeric(
                v10_value,
                v11_value,
                args.rtol,
                args.atol,
            )

            result.update({
                "category": "fsi_normalized_reconstructed",
                "session": session,
                "combo": combo,
                "v10": v10_value,
                "v11_reconstructed": v11_value,
                "denominator": denominator_by_combo[combo],
                "definition": (
                    "v11_raw_fsi_for_session_divided_by_mean_v11_raw_fsi_"
                    "across_ses18_ses19_ses20_for_this_combo"
                ),
            })

            records.append(result)

    # ------------------------------------------------------------------
    # Validate v10's own stored normalization metadata if available.
    # This is an integrity check, not counted as a primary Gate 2c
    # comparison.
    # ------------------------------------------------------------------
    normalization_metadata_checks = []

    details = v10.get(
        "fsi_norm_details",
        {}
    )

    if isinstance(details, dict):
        for combo in combos:
            if combo not in details:
                continue

            detail = details[combo]

            if not isinstance(detail, dict):
                continue

            if "denominator_used" in detail:
                stored = float(
                    detail["denominator_used"]
                )

                reconstructed = float(
                    denominator_by_combo[combo]
                )

                result = compare_numeric(
                    stored,
                    reconstructed,
                    args.rtol,
                    args.atol,
                )

                result.update({
                    "combo": combo,
                    "stored_v10_denominator": stored,
                    "reconstructed_from_v11_raw": reconstructed,
                })

                normalization_metadata_checks.append(
                    result
                )

    # ------------------------------------------------------------------
    # Summary.
    # ------------------------------------------------------------------
    counts = {}

    for rec in records:
        status = rec["status"]
        counts[status] = (
            counts.get(status, 0) + 1
        )

    expected_primary = (
        len(SESSIONS)
        + len(SESSIONS) * len(combos)
        + len(SESSIONS) * len(combos)
    )

    if len(records) != expected_primary:
        raise RuntimeError(
            f"Expected {expected_primary} Gate 2c comparisons, "
            f"generated {len(records)}"
        )

    if counts.get("FAIL", 0) > 0:
        verdict = "FAIL"

    elif (
        counts.get("EXACT", 0)
        + counts.get("WITHIN_TOLERANCE", 0)
        == expected_primary
    ):
        verdict = "PASS"

    else:
        verdict = "INCONCLUSIVE"

    # Combined first-level certification includes the 108 previously
    # established exact RDM/voxel comparisons.
    previous_exact = 108

    gate2c_compared = (
        counts.get("EXACT", 0)
        + counts.get("WITHIN_TOLERANCE", 0)
    )

    total_compared = (
        previous_exact
        + gate2c_compared
    )

    total_expected = (
        previous_exact
        + expected_primary
    )

    full_firstlevel_verdict = (
        "PASS"
        if verdict == "PASS"
        and total_compared == total_expected
        else "FAIL"
        if verdict == "FAIL"
        else "INCONCLUSIVE"
    )

    report = {
        "validation": (
            "RSA v10.3 -> v11 definitive first-level regression, Gate 2c"
        ),
        "subject": args.subject,
        "roi": args.roi,
        "sessions": list(SESSIONS),
        "run_combinations": combos,
        "tolerances": {
            "rtol": args.rtol,
            "atol": args.atol,
        },
        "gate2c": {
            "expected_comparisons": expected_primary,
            "status_counts": counts,
            "verdict": verdict,
        },
        "previous_gate": {
            "rdm_and_voxel_exact_comparisons": previous_exact,
            "failures": 0,
        },
        "combined_firstlevel_certification": {
            "expected_total_comparisons": total_expected,
            "successful_comparisons": total_compared,
            "verdict": full_firstlevel_verdict,
        },
        "normalization_rule": (
            "For each run combination: normalized FSI for one session equals "
            "that session's raw FSI divided by the mean raw FSI across "
            "ses18, ses19, and ses20."
        ),
        "denominator_by_combo_reconstructed_from_v11_raw": (
            denominator_by_combo
        ),
        "records": records,
        "v10_normalization_metadata_checks": (
            normalization_metadata_checks
        ),
    }

    args.report.parent.mkdir(
        parents=True,
        exist_ok=True,
    )

    args.report.write_text(
        json.dumps(
            report,
            indent=2,
        )
    )

    # ------------------------------------------------------------------
    # Console output.
    # ------------------------------------------------------------------
    print()
    print("=" * 80)
    print("RSA V10.3 -> V11 GATE 2c")
    print("=" * 80)

    print()
    print("RESIDUAL DOF")
    print("-" * 80)

    for rec in records:
        if rec["category"] != "residual_dof":
            continue

        print(
            f"{rec['status']:18s} "
            f"{rec['session']:6s} "
            f"v10={rec['v10']:.15g} "
            f"v11={rec['v11']:.15g}"
        )

    print()
    print("RAW FSI")
    print("-" * 80)

    for session in SESSIONS:
        print(f"[{session}]")

        for rec in records:
            if (
                rec["category"] == "fsi_raw"
                and rec["session"] == session
            ):
                print(
                    f"  {rec['status']:18s} "
                    f"{rec['combo']:20s} "
                    f"v10={rec['v10']:.15g} "
                    f"v11={rec['v11']:.15g}"
                )

    print()
    print("NORMALIZED FSI RECONSTRUCTED FROM V11 RAW FSI")
    print("-" * 80)

    for combo in combos:
        print(
            f"{combo:20s} denominator="
            f"{denominator_by_combo[combo]:.15g}"
        )

        for session in SESSIONS:
            rec = next(
                r
                for r in records
                if (
                    r["category"]
                    == "fsi_normalized_reconstructed"
                    and r["session"] == session
                    and r["combo"] == combo
                )
            )

            print(
                f"  {rec['status']:18s} "
                f"{session:6s} "
                f"v10={rec['v10']:.15g} "
                f"v11_reconstructed={rec['v11_reconstructed']:.15g}"
            )

    print()
    print("=" * 80)
    print("GATE 2c SUMMARY")
    print("=" * 80)

    for key in (
        "EXACT",
        "WITHIN_TOLERANCE",
        "FAIL",
    ):
        print(
            f"{key:18s}: {counts.get(key, 0)}"
        )

    print()
    print(
        f"Gate 2c comparisons: {expected_primary}"
    )
    print(
        f"Gate 2c verdict: {verdict}"
    )

    print()
    print(
        "Previous exact RDM/voxel comparisons: "
        f"{previous_exact}"
    )
    print(
        "Combined first-level comparisons: "
        f"{total_compared}/{total_expected}"
    )
    print(
        "FULL FIRST-LEVEL CERTIFICATION: "
        f"{full_firstlevel_verdict}"
    )

    print()
    print(
        f"Report: {args.report}"
    )

    if full_firstlevel_verdict == "FAIL":
        raise SystemExit(1)

    if full_firstlevel_verdict == "INCONCLUSIVE":
        raise SystemExit(2)


if __name__ == "__main__":
    main()

