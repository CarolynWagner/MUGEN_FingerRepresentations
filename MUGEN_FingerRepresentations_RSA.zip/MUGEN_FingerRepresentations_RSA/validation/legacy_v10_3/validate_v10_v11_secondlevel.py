#!/usr/bin/env python3
"""
validate_v10_v11_secondlevel.py

Regression validator for the generalized RSA v11 second-level output against the
frozen v10.3 contract.

This validator is intentionally schema-aware but defensive. It compares the
second-level quantities that are expected to be shared between v10.3 and v11:

- between-session RDM correlations
- independent-split reliability
- session consistency / test-retest reference
- noise-ceiling quantities
- normalized FSI
- stored statistical quantities where they can be mapped unambiguously

It also writes a schema summary of the v11 second-level pickle so that any
unmapped field can be resolved without rerunning the analysis.

No scientific quantity is recomputed except normalized FSI, where v11 may
legitimately derive it from first-level raw FSI values. That rule is identical
to the already validated Gate 2c procedure.
"""

from __future__ import annotations

import argparse
import json
import math
import pickle
from pathlib import Path
from typing import Any

import numpy as np


DEFAULT_V10 = Path(
    "/mnt/beegfs/workspace/2025-0422-Musicians7T/"
    "SPM_Prepro_FirstLevel/ROIs/RSApipeline_v10/results/rsa_final_locked.pkl"
)

DEFAULT_V11 = Path(
    "/mnt/beegfs/workspace/2025-0422-Musicians7T/"
    "SPM_Prepro_FirstLevel/ROIs/RSApipeline_general_v11/results/"
    "second_level/sub-01/roi-M1_legacy/rsa_secondlevel.pkl"
)

DEFAULT_V11_FIRSTLEVEL = Path(
    "/mnt/beegfs/workspace/2025-0422-Musicians7T/"
    "SPM_Prepro_FirstLevel/ROIs/RSApipeline_general_v11/results/first_level"
)

SESSIONS = ("ses18", "ses19", "ses20")
DEFAULT_SUBJECT = "sub-01"
DEFAULT_ROI = "M1_legacy"

RTOL = 1e-10
ATOL = 1e-12


def load_pickle(path: Path) -> Any:
    if not path.exists():
        raise FileNotFoundError(path)
    with path.open("rb") as f:
        return pickle.load(f)


def to_numeric(x: Any) -> np.ndarray | None:
    try:
        arr = np.asarray(x, dtype=np.float64)
    except Exception:
        return None
    if arr.dtype.kind not in "fiu":
        return None
    return arr


def compare_numeric(a: Any, b: Any, rtol: float, atol: float) -> dict:
    aa = to_numeric(a)
    bb = to_numeric(b)

    if aa is None or bb is None:
        return {"status": "FAIL", "reason": "non-numeric value"}

    if aa.shape != bb.shape:
        if aa.size == 1 and bb.size == 1:
            aa = aa.reshape(())
            bb = bb.reshape(())
        else:
            return {
                "status": "FAIL",
                "reason": f"shape mismatch {aa.shape} vs {bb.shape}",
            }

    if np.array_equal(aa, bb, equal_nan=True):
        return {
            "status": "EXACT",
            "max_abs_diff": 0.0,
            "max_rel_diff": 0.0,
        }

    finite = np.isfinite(aa) & np.isfinite(bb)
    if finite.any():
        diff = np.abs(aa[finite] - bb[finite])
        max_abs = float(diff.max())
        denom = np.maximum(np.abs(bb[finite]), atol)
        max_rel = float((diff / denom).max())
    else:
        max_abs = math.nan
        max_rel = math.nan

    if np.allclose(aa, bb, rtol=rtol, atol=atol, equal_nan=True):
        return {
            "status": "WITHIN_TOLERANCE",
            "max_abs_diff": max_abs,
            "max_rel_diff": max_rel,
        }

    return {
        "status": "FAIL",
        "max_abs_diff": max_abs,
        "max_rel_diff": max_rel,
    }


def safe_json(x: Any) -> Any:
    if isinstance(x, np.ndarray):
        return x.tolist()
    if isinstance(x, np.generic):
        return x.item()
    if isinstance(x, dict):
        return {str(k): safe_json(v) for k, v in x.items()}
    if isinstance(x, (list, tuple)):
        return [safe_json(v) for v in x]
    if isinstance(x, (str, int, float, bool, type(None))):
        return x
    return repr(x)


def schema_summary(obj: Any, depth: int = 0, max_depth: int = 4) -> Any:
    if depth >= max_depth:
        if isinstance(obj, dict):
            return f"<dict n={len(obj)}>"
        if isinstance(obj, np.ndarray):
            return f"<ndarray shape={obj.shape} dtype={obj.dtype}>"
        if isinstance(obj, (list, tuple)):
            return f"<{type(obj).__name__} n={len(obj)}>"
        return f"<{type(obj).__name__}>"

    if isinstance(obj, dict):
        return {
            str(k): schema_summary(v, depth + 1, max_depth)
            for k, v in obj.items()
        }

    if isinstance(obj, np.ndarray):
        return f"<ndarray shape={obj.shape} dtype={obj.dtype}>"

    if isinstance(obj, (list, tuple)):
        return [
            schema_summary(v, depth + 1, max_depth)
            for v in obj[:20]
        ]

    return safe_json(obj)


def walk(obj: Any, path=()):
    yield path, obj

    if isinstance(obj, dict):
        for k, v in obj.items():
            yield from walk(v, path + (str(k),))

    elif isinstance(obj, (list, tuple)) and len(obj) <= 50:
        for i, v in enumerate(obj):
            yield from walk(v, path + (f"[{i}]",))


def path_string(path) -> str:
    return ".".join(path)


def find_keypaths(obj: Any, keyword_sets: list[tuple[str, ...]]) -> list[tuple[tuple[str, ...], Any]]:
    """
    Return numeric leaf paths matching any supplied keyword set.
    Each tuple in keyword_sets means all listed keywords must occur in the path.
    """
    hits = []

    for path, value in walk(obj):
        arr = to_numeric(value)
        if arr is None:
            continue

        text = path_string(path).lower()

        for kws in keyword_sets:
            if all(kw.lower() in text for kw in kws):
                hits.append((path, value))
                break

    return hits


def exact_path(obj: Any, path: tuple[str, ...]) -> Any:
    cur = obj
    for p in path:
        if not isinstance(cur, dict) or p not in cur:
            raise KeyError(path)
        cur = cur[p]
    return cur


def compare_explicit_dicts(
    records: list[dict],
    category: str,
    v10_value: Any,
    v11_value: Any,
    rtol: float,
    atol: float,
):
    """
    Recursively compare dictionaries with matching keys and numeric leaves.
    """
    if isinstance(v10_value, dict) and isinstance(v11_value, dict):
        k10 = set(v10_value)
        k11 = set(v11_value)

        if k10 != k11:
            records.append({
                "category": category,
                "field": category,
                "status": "FAIL",
                "reason": (
                    f"key mismatch; v10-only={sorted(k10-k11)}, "
                    f"v11-only={sorted(k11-k10)}"
                ),
            })
            return

        for key in v10_value:
            compare_explicit_dicts(
                records,
                f"{category}.{key}",
                v10_value[key],
                v11_value[key],
                rtol,
                atol,
            )
        return

    a = to_numeric(v10_value)
    b = to_numeric(v11_value)

    if a is not None and b is not None:
        result = compare_numeric(v10_value, v11_value, rtol, atol)
        result.update({
            "category": category.split(".")[0],
            "field": category,
            "v10": safe_json(v10_value),
            "v11": safe_json(v11_value),
        })
        records.append(result)
        return

    # Non-numeric metadata: compare exactly when simple.
    if isinstance(v10_value, (str, bool, type(None))) and isinstance(
        v11_value, (str, bool, type(None))
    ):
        records.append({
            "category": category.split(".")[0],
            "field": category,
            "status": "EXACT" if v10_value == v11_value else "FAIL",
            "v10": v10_value,
            "v11": v11_value,
        })


def choose_top_level_mapping(v10: dict, v11: dict, v10_key: str, aliases: tuple[str, ...]):
    """
    Prefer exact top-level v11 key; otherwise accept a unique alias.
    """
    if v10_key in v11:
        return v10_key, v11[v10_key]

    found = [(a, v11[a]) for a in aliases if a in v11]

    if len(found) == 1:
        return found[0]

    return None


def reconstruct_v11_normalized_fsi(
    firstlevel_root: Path,
    subject: str,
    roi: str,
) -> dict:
    raw = {}

    for session in SESSIONS:
        path = (
            firstlevel_root
            / subject
            / session
            / f"roi-{roi}"
            / "rsa_firstlevel.pkl"
        )
        obj = load_pickle(path)
        raw[session] = obj["fsi_raw"]

    combos = list(raw[SESSIONS[0]].keys())

    normalized = {s: {} for s in SESSIONS}

    for combo in combos:
        vals = np.asarray(
            [float(raw[s][combo]) for s in SESSIONS],
            dtype=np.float64,
        )
        denominator = float(vals.mean())

        for s in SESSIONS:
            normalized[s][combo] = float(raw[s][combo] / denominator)

    return normalized


def main():
    p = argparse.ArgumentParser()

    p.add_argument("--v10", type=Path, default=DEFAULT_V10)
    p.add_argument("--v11", type=Path, default=DEFAULT_V11)
    p.add_argument(
        "--v11-firstlevel-root",
        type=Path,
        default=DEFAULT_V11_FIRSTLEVEL,
    )
    p.add_argument("--subject", default=DEFAULT_SUBJECT)
    p.add_argument("--roi", default=DEFAULT_ROI)
    p.add_argument("--rtol", type=float, default=RTOL)
    p.add_argument("--atol", type=float, default=ATOL)
    p.add_argument(
        "--report",
        type=Path,
        default=Path("results/v10_v11_secondlevel_regression.json"),
    )
    p.add_argument(
        "--schema-report",
        type=Path,
        default=Path("results/v11_secondlevel_schema_summary.json"),
    )

    args = p.parse_args()

    v10 = load_pickle(args.v10)
    v11 = load_pickle(args.v11)

    if not isinstance(v10, dict):
        raise TypeError("v10 contract must be a dict")
    if not isinstance(v11, dict):
        raise TypeError("v11 second-level object must be a dict")

    records = []
    mappings = {}

    # ------------------------------------------------------------------
    # Explicit top-level mappings expected from the frozen contract.
    # ------------------------------------------------------------------

    targets = {
        "between_session": (
            "between_session",
            ("between", "between_sessions", "pairwise_across_sessions"),
        ),
        "independent_split_reliability": (
            "independent_split_reliability",
            ("split_reliability", "independent_reliability"),
        ),
        "session_consistency": (
            "session_consistency",
            ("consistency", "session_reliability"),
        ),
        "test_retest_consistency_reference": (
            "test_retest_consistency_reference",
            ("test_retest_reference", "consistency_reference"),
        ),
        "noise_ceiling": (
            "noise_ceiling",
            ("noise_ceilings",),
        ),
    }

    for logical_name, (v10_key, aliases) in targets.items():
        if v10_key not in v10:
            records.append({
                "category": logical_name,
                "field": logical_name,
                "status": "NOT_COMPARABLE",
                "reason": f"{v10_key} missing from v10",
            })
            continue

        mapping = choose_top_level_mapping(v10, v11, v10_key, aliases)

        if mapping is None:
            records.append({
                "category": logical_name,
                "field": logical_name,
                "status": "NOT_COMPARABLE",
                "reason": (
                    "No unique recognized top-level mapping in v11. "
                    f"Available v11 keys: {sorted(v11.keys())}"
                ),
            })
            continue

        v11_key, v11_value = mapping
        mappings[logical_name] = {
            "v10_key": v10_key,
            "v11_key": v11_key,
        }

        compare_explicit_dicts(
            records,
            logical_name,
            v10[v10_key],
            v11_value,
            args.rtol,
            args.atol,
        )

    # ------------------------------------------------------------------
    # Normalized FSI: compare stored v11 value if available; otherwise
    # reconstruct from the already-certified first-level raw FSI.
    # ------------------------------------------------------------------

    reconstructed_norm = reconstruct_v11_normalized_fsi(
        args.v11_firstlevel_root,
        args.subject,
        args.roi,
    )

    if "fsi_normalized" in v11:
        v11_norm = v11["fsi_normalized"]
        fsi_source = "stored_secondlevel"
    else:
        v11_norm = reconstructed_norm
        fsi_source = "reconstructed_from_certified_firstlevel_raw_fsi"

    if "fsi_normalized" in v10:
        compare_explicit_dicts(
            records,
            "fsi_normalized",
            v10["fsi_normalized"],
            v11_norm,
            args.rtol,
            args.atol,
        )
        mappings["fsi_normalized"] = {
            "v10_key": "fsi_normalized",
            "v11_source": fsi_source,
        }

    # ------------------------------------------------------------------
    # Discover statistical/inference fields for reporting.
    # We do not automatically certify ambiguous inferred paths.
    # ------------------------------------------------------------------

    stat_keywords = [
        ("p", "value"),
        ("pvalue",),
        ("p_value",),
        ("df",),
        ("rho",),
        ("spearman",),
        ("pearson",),
        ("ci",),
        ("confidence",),
    ]

    v10_stats = find_keypaths(v10, stat_keywords)
    v11_stats = find_keypaths(v11, stat_keywords)

    stat_discovery = {
        "v10": [
            {"path": path_string(p), "value": safe_json(v)}
            for p, v in v10_stats
        ],
        "v11": [
            {"path": path_string(p), "value": safe_json(v)}
            for p, v in v11_stats
        ],
    }

    # ------------------------------------------------------------------
    # Summary.
    # ------------------------------------------------------------------

    counts = {}
    for rec in records:
        counts[rec["status"]] = counts.get(rec["status"], 0) + 1

    if counts.get("FAIL", 0):
        verdict = "FAIL"
    elif counts.get("NOT_COMPARABLE", 0):
        verdict = "INCONCLUSIVE"
    elif (
        counts.get("EXACT", 0)
        + counts.get("WITHIN_TOLERANCE", 0)
        > 0
    ):
        verdict = "PASS"
    else:
        verdict = "INCONCLUSIVE"

    report = {
        "validation": "v10.3 -> v11 second-level regression",
        "subject": args.subject,
        "roi": args.roi,
        "v10": str(args.v10),
        "v11": str(args.v11),
        "rtol": args.rtol,
        "atol": args.atol,
        "mappings": mappings,
        "status_counts": counts,
        "overall_verdict": verdict,
        "records": records,
        "statistical_field_discovery": stat_discovery,
    }

    args.report.parent.mkdir(parents=True, exist_ok=True)
    args.schema_report.parent.mkdir(parents=True, exist_ok=True)

    args.report.write_text(json.dumps(report, indent=2))
    args.schema_report.write_text(
        json.dumps(schema_summary(v11), indent=2)
    )

    print()
    print("=" * 80)
    print("V10.3 -> V11 SECOND-LEVEL REGRESSION")
    print("=" * 80)
    print(f"Subject: {args.subject}")
    print(f"ROI:     {args.roi}")
    print()

    for rec in records:
        extra = ""
        if "max_abs_diff" in rec:
            extra = (
                f" | max_abs={rec['max_abs_diff']:.3e}"
                f" max_rel={rec['max_rel_diff']:.3e}"
            )
        elif "reason" in rec:
            extra = f" | {rec['reason']}"

        print(
            f"{rec['status']:18s} "
            f"{rec['field']}{extra}"
        )

    print()
    print("STATUS COUNTS:")
    for key in (
        "EXACT",
        "WITHIN_TOLERANCE",
        "NOT_COMPARABLE",
        "FAIL",
    ):
        print(f"  {key:18s}: {counts.get(key, 0)}")

    print()
    print(f"OVERALL VERDICT: {verdict}")
    print(f"Report: {args.report}")
    print(f"Schema summary: {args.schema_report}")
    print()

    print(
        "Statistical-field discovery was written to the JSON report. "
        "If second-level statistics use a different schema from v10.3, "
        "those paths can be mapped explicitly in a final Gate 3b without "
        "rerunning the RSA."
    )

    if verdict == "FAIL":
        raise SystemExit(1)

    if verdict == "INCONCLUSIVE":
        raise SystemExit(2)


if __name__ == "__main__":
    main()






