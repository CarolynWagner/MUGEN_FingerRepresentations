#!/usr/bin/env python3
"""
validate_v10_v11_secondlevel_gate3b.py

Final explicit v10.3 -> v11 second-level regression validator for sub-01 /
M1_legacy.

Important scope:
- v11 second level currently stores pairwise results only for full combo run1-6.
- v10.3 stores between-session results for all 9 run combinations.
- Therefore Gate 3b validates the overlapping second-level contract exactly:
    3 session pairs x 5 metrics = 15 pairwise values
  plus:
    5 same-resolution test-retest values
    group noise-ceiling status
- The 27 normalized-FSI values were already validated exactly by Gate 3a.
- Independent split reliability and the exploratory session-consistency
  components are NOT present in rsa_secondlevel.pkl and are therefore not
  falsely claimed as second-level regression-tested here. They were derived
  from already-certified first-level RDMs in v10.3 and can be ported to v11
  separately if they are required as v11 outputs.
"""

from __future__ import annotations
import argparse, json, math, pickle
from pathlib import Path
import numpy as np

V10_DEFAULT = Path(
    "/mnt/beegfs/workspace/2025-0422-Musicians7T/"
    "SPM_Prepro_FirstLevel/ROIs/RSApipeline_v10/results/rsa_final_locked.pkl"
)
V11_DEFAULT = Path(
    "/mnt/beegfs/workspace/2025-0422-Musicians7T/"
    "SPM_Prepro_FirstLevel/ROIs/RSApipeline_general_v11/results/"
    "second_level/sub-01/roi-M1_legacy/rsa_secondlevel.pkl"
)

METRICS = ("cosine", "fisherz", "icc", "pearson", "spearman")
FULL_COMBO = "run1-6"
RTOL = 1e-10
ATOL = 1e-12


def load(path):
    with Path(path).open("rb") as f:
        return pickle.load(f)


def cmp(a, b, rtol, atol):
    aa = np.asarray(a, dtype=float)
    bb = np.asarray(b, dtype=float)
    if np.array_equal(aa, bb, equal_nan=True):
        return {"status":"EXACT","max_abs_diff":0.0,"max_rel_diff":0.0}
    finite = np.isfinite(aa) & np.isfinite(bb)
    if finite.any():
        d = np.abs(aa[finite] - bb[finite])
        ma = float(d.max())
        mr = float((d / np.maximum(np.abs(bb[finite]), atol)).max())
    else:
        ma = mr = math.nan
    if np.allclose(aa, bb, rtol=rtol, atol=atol, equal_nan=True):
        return {"status":"WITHIN_TOLERANCE","max_abs_diff":ma,"max_rel_diff":mr}
    return {"status":"FAIL","max_abs_diff":ma,"max_rel_diff":mr}


def pair_label(a, b):
    return f"{a}_vs_{b}"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--v10", type=Path, default=V10_DEFAULT)
    ap.add_argument("--v11", type=Path, default=V11_DEFAULT)
    ap.add_argument("--rtol", type=float, default=RTOL)
    ap.add_argument("--atol", type=float, default=ATOL)
    ap.add_argument(
        "--report", type=Path,
        default=Path("results/v10_v11_secondlevel_gate3b.json")
    )
    a = ap.parse_args()

    v10, v11 = load(a.v10), load(a.v11)
    rec = []

    if v11.get("full_combo_label") != FULL_COMBO:
        raise ValueError(
            f"Expected v11 full_combo_label={FULL_COMBO!r}; "
            f"found {v11.get('full_combo_label')!r}"
        )

    # ---------------------------------------------------------------
    # A. Explicit mapping:
    # v10 between_session['run1-6'][metric][sesX_vs_sesY]
    # -> v11 pairwise row metric
    # ---------------------------------------------------------------
    rows = v11["pairwise"]
    expected_pairs = {
        ("ses18","ses19"),
        ("ses18","ses20"),
        ("ses19","ses20"),
    }
    seen = set()

    for row in rows:
        if row.get("combo") != FULL_COMBO:
            continue
        if row.get("comparison_type") != "within_subject_across_sessions":
            continue

        sa, sb = row["session_a"], row["session_b"]
        pair = (sa, sb)
        if pair not in expected_pairs:
            raise ValueError(f"Unexpected v11 session pair: {pair}")
        if pair in seen:
            raise ValueError(f"Duplicate v11 session pair: {pair}")
        seen.add(pair)

        vk = pair_label(sa, sb)
        for metric in METRICS:
            x = v10["between_session"][FULL_COMBO][metric][vk]
            y = row[metric]
            r = cmp(x, y, a.rtol, a.atol)
            r.update({
                "category":"between_session_full_combo",
                "field":f"{FULL_COMBO}.{metric}.{vk}",
                "v10":float(x), "v11":float(y),
            })
            rec.append(r)

    if seen != expected_pairs:
        raise ValueError(
            f"Missing v11 pairs: {sorted(expected_pairs-seen)}"
        )

    # ---------------------------------------------------------------
    # B. Same-resolution test-retest reference.
    #
    # v10 says this is ses19 vs ses20, run1-6. v11 pairwise already
    # contains exactly that row. Compare the five metrics again under
    # the semantic test-retest contract, because this validates the
    # mapping of the named v10 reference rather than merely its source.
    # ---------------------------------------------------------------
    ref = v10["test_retest_consistency_reference"]
    sessions = tuple(ref["sessions"])
    if sessions != ("ses19","ses20"):
        raise ValueError(f"Unexpected v10 test-retest sessions: {sessions}")
    if ref["combo"] != FULL_COMBO:
        raise ValueError(f"Unexpected v10 test-retest combo: {ref['combo']}")

    row = next(
        r for r in rows
        if r.get("combo") == FULL_COMBO
        and r.get("session_a") == sessions[0]
        and r.get("session_b") == sessions[1]
    )

    for metric in METRICS:
        x = ref["metrics"][metric]
        y = row[metric]
        r = cmp(x, y, a.rtol, a.atol)
        r.update({
            "category":"same_resolution_test_retest_reference",
            "field":f"{sessions[0]}_vs_{sessions[1]}.{metric}",
            "v10":float(x), "v11":float(y),
        })
        rec.append(r)

    # ---------------------------------------------------------------
    # C. Group noise ceiling semantics.
    #
    # v10: not_estimated because one participant is insufficient.
    # v11: [] means no group noise ceiling was estimated.
    # This is semantic equivalence, not a floating-point comparison.
    # ---------------------------------------------------------------
    v10_nc = v10["noise_ceiling"]
    v11_nc = v11["group_noise_ceiling"]

    nc_ok = (
        isinstance(v10_nc, dict)
        and v10_nc.get("status") == "not_estimated"
        and isinstance(v11_nc, list)
        and len(v11_nc) == 0
    )
    rec.append({
        "category":"group_noise_ceiling",
        "field":"single_subject_group_noise_ceiling",
        "status":"SEMANTIC_EXACT" if nc_ok else "FAIL",
        "v10":v10_nc,
        "v11":v11_nc,
        "interpretation":(
            "v10 explicitly records not_estimated; v11 represents the same "
            "state by an empty group_noise_ceiling list."
        ),
    })

    # ---------------------------------------------------------------
    # D. Explicitly document fields not stored by v11 second level.
    # ---------------------------------------------------------------
    not_stored = {
        "independent_split_reliability": (
            "Present in frozen v10.3, but not stored in v11 rsa_secondlevel.pkl."
        ),
        "session_consistency.original_session_components": (
            "Present in frozen v10.3, but not stored in v11 rsa_secondlevel.pkl."
        ),
    }

    counts = {}
    for r in rec:
        counts[r["status"]] = counts.get(r["status"], 0) + 1

    failed = counts.get("FAIL", 0)
    numerical_success = counts.get("EXACT",0) + counts.get("WITHIN_TOLERANCE",0)
    semantic_success = counts.get("SEMANTIC_EXACT",0)

    verdict = "PASS" if failed == 0 else "FAIL"

    report = {
        "validation":"RSA v10.3 -> v11 second-level Gate 3b explicit mapping",
        "scope":{
            "combo":FULL_COMBO,
            "metrics":list(METRICS),
            "pairwise_numeric_comparisons":15,
            "test_retest_semantic_contract_numeric_comparisons":5,
            "group_noise_ceiling_semantic_comparisons":1,
            "previous_gate3a_normalized_fsi_exact":27,
        },
        "status_counts":counts,
        "gate3b_verdict":verdict,
        "records":rec,
        "not_stored_in_v11_secondlevel":not_stored,
        "important_note":(
            "Gate 3b certifies the second-level quantities actually emitted by "
            "v11. It does not claim that v11 currently reproduces every legacy "
            "v10.3 diagnostic output. In particular, independent-split "
            "reliability and exploratory session-consistency components are "
            "not stored in rsa_secondlevel.pkl."
        ),
    }

    a.report.parent.mkdir(parents=True, exist_ok=True)
    a.report.write_text(json.dumps(report, indent=2))

    print("="*80)
    print("RSA V10.3 -> V11 SECOND-LEVEL GATE 3b")
    print("="*80)

    for r in rec:
        if "max_abs_diff" in r:
            print(
                f"{r['status']:18s} {r['field']} | "
                f"max_abs={r['max_abs_diff']:.3e} "
                f"max_rel={r['max_rel_diff']:.3e}"
            )
        else:
            print(f"{r['status']:18s} {r['field']}")

    print()
    print("SUMMARY")
    for k in ("EXACT","WITHIN_TOLERANCE","SEMANTIC_EXACT","FAIL"):
        print(f"{k:18s}: {counts.get(k,0)}")
    print()
    print(f"Numerical comparisons passed: {numerical_success}/20")
    print(f"Semantic comparisons passed:  {semantic_success}/1")
    print("Previously exact normalized-FSI comparisons: 27/27")
    print()
    print(f"GATE 3b VERDICT: {verdict}")
    print(f"Report: {a.report}")
    print()
    print("Not currently stored by v11 second level:")
    for k, v in not_stored.items():
        print(f"  - {k}: {v}")

    if verdict != "PASS":
        raise SystemExit(1)


if __name__ == "__main__":
    main()
