#!/usr/bin/env python3
"""
diagnose_run_order_drift.py

Targeted run-order diagnostic for v11 M1 subregion analyses.

Purpose
-------
Use the stored run_pair_contributions (30 x 5 x 5 for six runs) to test the
hypothesis that the discrepant independent-split reliability reflects temporal
/run-order structure rather than a general failure of the ROI or RSA estimate.

The script does NOT refit the GLM or recompute Crossnobis estimates from images.
It analyzes the already-stored first-level run-pair contribution matrices.

For six runs, v11 stores 30 directed run-pair matrices (6 * 5). The script:
1. verifies / quantifies directed-pair symmetry;
2. averages reciprocal directions into 15 unordered run pairs;
3. computes an FSI-like mean upper-triangle contribution for every run pair;
4. computes each run pair's RDM correlation with the session-average geometry;
5. labels each pair by temporal separation, midpoint, half/odd-even category;
6. tests linear drift with pair midpoint and temporal separation;
7. computes run-involvement summaries (all pairs containing each run);
8. tests finger-pair-specific temporal slopes;
9. compares early-early, late-late, cross-half, odd-odd, even-even, and
   odd-even pair groups.

This is descriptive single-participant diagnostics. The pairwise observations
are not independent, so ordinary regression p-values are intentionally not
reported.

Outputs
-------
CSV:
  directed_run_pair_metrics.csv
  unordered_run_pair_metrics.csv
  run_involvement_summary.csv
  temporal_group_summary.csv
  finger_pair_temporal_slopes.csv
  drift_summary.csv

Figures (PNG + SVG):
  <ROI>_<session>_pair_fsi_by_midpoint
  <ROI>_<session>_pair_fsi_by_separation
  <ROI>_<session>_geometry_similarity_by_midpoint
  <ROI>_<session>_run_involvement
  <ROI>_<session>_finger_pair_temporal_slopes
  <ROI>_<session>_unordered_pair_heatmap

Text:
  diagnostic_summary.txt

Example
-------
python diagnose_run_order_drift.py \
  --subject sub-01 \
  --rois M1_4a M1_4p \
  --sessions ses19 ses20
"""

from __future__ import annotations

import argparse
import ast
import math
import pickle
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt


DEFAULT_ROOT = Path("results/first_level")
DEFAULT_OUT = Path("results/roi_comparisons/M1_run_order_drift")
DEFAULT_SUBJECT = "sub-01"
DEFAULT_ROIS = ("M1_4a", "M1_4p")
DEFAULT_SESSIONS = ("ses19", "ses20")


def load_pickle(path: Path) -> dict:
    if not path.exists():
        raise FileNotFoundError(path)
    with path.open("rb") as f:
        obj = pickle.load(f)
    if not isinstance(obj, dict):
        raise TypeError(f"Expected dict in {path}")
    return obj


def firstlevel_path(root: Path, subject: str, session: str, roi: str) -> Path:
    return root / subject / session / f"roi-{roi}" / "rsa_firstlevel.pkl"


def upper_vec(matrix: np.ndarray) -> np.ndarray:
    m = np.asarray(matrix, dtype=float)
    return m[np.triu_indices(m.shape[0], k=1)]


def finite_pair(a, b):
    a = np.asarray(a, dtype=float).ravel()
    b = np.asarray(b, dtype=float).ravel()
    n = min(a.size, b.size)
    a, b = a[:n], b[:n]
    ok = np.isfinite(a) & np.isfinite(b)
    return a[ok], b[ok]


def pearson(a, b) -> float:
    a, b = finite_pair(a, b)
    if len(a) < 2 or np.std(a) < 1e-12 or np.std(b) < 1e-12:
        return math.nan
    return float(np.corrcoef(a, b)[0, 1])


def safe_mean(x) -> float:
    x = np.asarray(x, dtype=float)
    x = x[np.isfinite(x)]
    return float(np.mean(x)) if x.size else math.nan


def safe_std(x) -> float:
    x = np.asarray(x, dtype=float)
    x = x[np.isfinite(x)]
    return float(np.std(x)) if x.size else math.nan


def linear_slope(x, y) -> dict:
    x, y = finite_pair(x, y)
    if len(x) < 2 or np.std(x) < 1e-12:
        return {
            "slope": math.nan,
            "intercept": math.nan,
            "r": math.nan,
            "n": int(len(x)),
        }
    slope, intercept = np.polyfit(x, y, 1)
    return {
        "slope": float(slope),
        "intercept": float(intercept),
        "r": pearson(x, y),
        "n": int(len(x)),
    }


def parse_pair_label(label: Any) -> tuple[int, int]:
    """
    v11 current schema uses labels such as [0, 1]. Convert to 1-based run IDs.
    Also tolerate tuples and stringified lists/tuples.
    """
    if isinstance(label, np.ndarray):
        label = label.tolist()

    if isinstance(label, (list, tuple)) and len(label) == 2:
        a, b = int(label[0]), int(label[1])
        return a + 1, b + 1

    text = str(label).strip()

    try:
        parsed = ast.literal_eval(text)
        if isinstance(parsed, (list, tuple)) and len(parsed) == 2:
            return int(parsed[0]) + 1, int(parsed[1]) + 1
    except Exception:
        pass

    for sep in ("_vs_", " vs ", ",", "-", "–"):
        if sep in text:
            left, right = text.split(sep, 1)
            a, b = int(left.strip()), int(right.strip())
            # If explicit labels already look 1-based, retain them.
            if a >= 1 and b >= 1:
                return a, b
            return a + 1, b + 1

    raise ValueError(f"Cannot parse run-pair label: {label!r}")


def pair_category(a: int, b: int) -> dict:
    lo, hi = sorted((a, b))
    separation = hi - lo
    midpoint = (lo + hi) / 2.0

    if hi <= 3:
        half_category = "early_early"
    elif lo >= 4:
        half_category = "late_late"
    else:
        half_category = "cross_half"

    odd_a = (a % 2 == 1)
    odd_b = (b % 2 == 1)

    if odd_a and odd_b:
        parity_category = "odd_odd"
    elif (not odd_a) and (not odd_b):
        parity_category = "even_even"
    else:
        parity_category = "odd_even"

    return {
        "run_low": lo,
        "run_high": hi,
        "temporal_separation": separation,
        "pair_midpoint": midpoint,
        "half_category": half_category,
        "parity_category": parity_category,
    }


def save_png_svg(fig, base: Path):
    base.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(base.with_suffix(".png"), dpi=300, bbox_inches="tight")
    fig.savefig(base.with_suffix(".svg"), bbox_inches="tight")
    plt.close(fig)


def extract_data(obj: dict):
    contributions = np.asarray(obj["run_pair_contributions"], dtype=float)
    labels = obj["run_pair_labels"]

    if contributions.ndim != 3:
        raise ValueError(
            "Expected run_pair_contributions with shape "
            f"(n_pairs, n_fingers, n_fingers), got {contributions.shape}"
        )

    if contributions.shape[0] != len(labels):
        raise ValueError(
            f"Contribution count {contributions.shape[0]} != "
            f"label count {len(labels)}"
        )

    fingers = list(obj["finger_names"])
    if contributions.shape[1:] != (len(fingers), len(fingers)):
        raise ValueError(
            f"Contribution matrix shape {contributions.shape[1:]} "
            f"does not match {len(fingers)} fingers"
        )

    return contributions, labels, fingers


def directed_metrics(roi, session, obj) -> tuple[pd.DataFrame, dict]:
    contrib, labels, fingers = extract_data(obj)

    full_combo = obj.get("full_combo_label", "run1-6")
    full_obj = obj["rdms"][full_combo]
    full_rdm = np.asarray(
        full_obj["raw"] if isinstance(full_obj, dict) else full_obj,
        dtype=float,
    )
    full_vec = upper_vec(full_rdm)

    rows = []

    for idx, (matrix, label) in enumerate(zip(contrib, labels)):
        run_a, run_b = parse_pair_label(label)
        cats = pair_category(run_a, run_b)
        vec = upper_vec(matrix)

        row = {
            "roi": roi,
            "session": session,
            "directed_index": idx,
            "run_a": run_a,
            "run_b": run_b,
            "directed_label": f"{run_a}->{run_b}",
            "fsi_like": safe_mean(vec),
            "geometry_r_to_full": pearson(vec, full_vec),
            **cats,
        }

        for i in range(len(fingers)):
            for j in range(i + 1, len(fingers)):
                row[f"pair__{fingers[i]}__{fingers[j]}"] = float(matrix[i, j])

        rows.append(row)

    return pd.DataFrame(rows), {
        "fingers": fingers,
        "full_rdm": full_rdm,
        "full_vec": full_vec,
        "contrib": contrib,
        "labels": labels,
    }


def reciprocal_symmetry(directed_df: pd.DataFrame, data: dict) -> pd.DataFrame:
    contrib = data["contrib"]
    labels = data["labels"]

    lookup = {}
    for idx, label in enumerate(labels):
        a, b = parse_pair_label(label)
        lookup[(a, b)] = idx

    rows = []
    seen = set()

    for (a, b), idx_ab in lookup.items():
        key = tuple(sorted((a, b)))
        if key in seen:
            continue
        seen.add(key)

        idx_ba = lookup.get((b, a))
        if idx_ba is None:
            rows.append({
                "run_low": min(a, b),
                "run_high": max(a, b),
                "reciprocal_available": False,
                "max_abs_difference": math.nan,
                "pearson": math.nan,
            })
            continue

        va = upper_vec(contrib[idx_ab])
        vb = upper_vec(contrib[idx_ba])

        rows.append({
            "run_low": min(a, b),
            "run_high": max(a, b),
            "reciprocal_available": True,
            "max_abs_difference": float(np.nanmax(np.abs(va - vb))),
            "pearson": pearson(va, vb),
        })

    return pd.DataFrame(rows)


def unordered_metrics(roi, session, obj, data) -> pd.DataFrame:
    contrib = data["contrib"]
    labels = data["labels"]
    fingers = data["fingers"]
    full_vec = data["full_vec"]

    lookup = {}
    for idx, label in enumerate(labels):
        a, b = parse_pair_label(label)
        lookup[(a, b)] = idx

    unordered = sorted({tuple(sorted(pair)) for pair in lookup})

    rows = []

    for lo, hi in unordered:
        mats = []

        if (lo, hi) in lookup:
            mats.append(contrib[lookup[(lo, hi)]])
        if (hi, lo) in lookup:
            mats.append(contrib[lookup[(hi, lo)]])

        if not mats:
            continue

        matrix = np.mean(np.stack(mats), axis=0)
        vec = upper_vec(matrix)
        cats = pair_category(lo, hi)

        row = {
            "roi": roi,
            "session": session,
            "run_low": lo,
            "run_high": hi,
            "unordered_label": f"{lo}-{hi}",
            "n_directions": len(mats),
            "fsi_like": safe_mean(vec),
            "geometry_r_to_full": pearson(vec, full_vec),
            **cats,
        }

        for i in range(len(fingers)):
            for j in range(i + 1, len(fingers)):
                row[f"pair__{fingers[i]}__{fingers[j]}"] = float(matrix[i, j])

        rows.append(row)

    return pd.DataFrame(rows)


def run_involvement_summary(unordered_df: pd.DataFrame) -> pd.DataFrame:
    rows = []

    for run in range(1, 7):
        sub = unordered_df[
            (unordered_df["run_low"] == run)
            | (unordered_df["run_high"] == run)
        ]

        rows.append({
            "roi": unordered_df["roi"].iloc[0],
            "session": unordered_df["session"].iloc[0],
            "run": run,
            "n_pairs_involving_run": len(sub),
            "mean_pair_fsi": safe_mean(sub["fsi_like"]),
            "std_pair_fsi": safe_std(sub["fsi_like"]),
            "mean_geometry_r_to_full": safe_mean(
                sub["geometry_r_to_full"]
            ),
        })

    return pd.DataFrame(rows)


def temporal_group_summary(unordered_df: pd.DataFrame) -> pd.DataFrame:
    rows = []

    for group_var in ("half_category", "parity_category", "temporal_separation"):
        for group, sub in unordered_df.groupby(group_var):
            rows.append({
                "roi": unordered_df["roi"].iloc[0],
                "session": unordered_df["session"].iloc[0],
                "group_variable": group_var,
                "group": str(group),
                "n_pairs": len(sub),
                "mean_fsi_like": safe_mean(sub["fsi_like"]),
                "std_fsi_like": safe_std(sub["fsi_like"]),
                "mean_geometry_r_to_full": safe_mean(
                    sub["geometry_r_to_full"]
                ),
            })

    return pd.DataFrame(rows)


def finger_pair_temporal_slopes(unordered_df: pd.DataFrame) -> pd.DataFrame:
    pair_columns = [
        c for c in unordered_df.columns if c.startswith("pair__")
    ]

    rows = []

    for col in pair_columns:
        _, finger_a, finger_b = col.split("__", 2)

        midpoint_fit = linear_slope(
            unordered_df["pair_midpoint"],
            unordered_df[col],
        )
        sep_fit = linear_slope(
            unordered_df["temporal_separation"],
            unordered_df[col],
        )

        rows.append({
            "roi": unordered_df["roi"].iloc[0],
            "session": unordered_df["session"].iloc[0],
            "finger_pair": f"{finger_a}–{finger_b}",
            "midpoint_slope": midpoint_fit["slope"],
            "midpoint_r": midpoint_fit["r"],
            "separation_slope": sep_fit["slope"],
            "separation_r": sep_fit["r"],
        })

    return pd.DataFrame(rows)


def drift_summary(unordered_df, symmetry_df) -> pd.DataFrame:
    midpoint_fsi = linear_slope(
        unordered_df["pair_midpoint"],
        unordered_df["fsi_like"],
    )
    separation_fsi = linear_slope(
        unordered_df["temporal_separation"],
        unordered_df["fsi_like"],
    )
    midpoint_geometry = linear_slope(
        unordered_df["pair_midpoint"],
        unordered_df["geometry_r_to_full"],
    )
    separation_geometry = linear_slope(
        unordered_df["temporal_separation"],
        unordered_df["geometry_r_to_full"],
    )

    early = unordered_df[
        unordered_df["half_category"] == "early_early"
    ]["fsi_like"]
    late = unordered_df[
        unordered_df["half_category"] == "late_late"
    ]["fsi_like"]
    cross = unordered_df[
        unordered_df["half_category"] == "cross_half"
    ]["fsi_like"]

    return pd.DataFrame([{
        "roi": unordered_df["roi"].iloc[0],
        "session": unordered_df["session"].iloc[0],
        "fsi_midpoint_slope": midpoint_fsi["slope"],
        "fsi_midpoint_r": midpoint_fsi["r"],
        "fsi_separation_slope": separation_fsi["slope"],
        "fsi_separation_r": separation_fsi["r"],
        "geometry_midpoint_slope": midpoint_geometry["slope"],
        "geometry_midpoint_r": midpoint_geometry["r"],
        "geometry_separation_slope": separation_geometry["slope"],
        "geometry_separation_r": separation_geometry["r"],
        "mean_fsi_early_early": safe_mean(early),
        "mean_fsi_late_late": safe_mean(late),
        "mean_fsi_cross_half": safe_mean(cross),
        "late_minus_early_fsi": safe_mean(late) - safe_mean(early),
        "max_reciprocal_abs_difference": safe_mean(
            [symmetry_df["max_abs_difference"].max()]
        ),
        "mean_reciprocal_pearson": safe_mean(symmetry_df["pearson"]),
    }])


def plot_scatter_with_fit(df, xcol, ycol, xlabel, ylabel, title, base):
    fig, ax = plt.subplots(figsize=(7, 5), layout="constrained")

    x = df[xcol].to_numpy(dtype=float)
    y = df[ycol].to_numpy(dtype=float)

    ax.scatter(x, y)

    fit = linear_slope(x, y)

    if np.isfinite(fit["slope"]):
        xx = np.linspace(np.nanmin(x), np.nanmax(x), 100)
        yy = fit["intercept"] + fit["slope"] * xx
        ax.plot(xx, yy, linewidth=1.5)

    for _, row in df.iterrows():
        ax.annotate(
            row["unordered_label"],
            (row[xcol], row[ycol]),
            xytext=(4, 4),
            textcoords="offset points",
            fontsize=7,
        )

    ax.set_xlabel(xlabel)
    ax.set_ylabel(ylabel)
    ax.set_title(
        title
        + (
            f"\nslope={fit['slope']:.5f}, r={fit['r']:.3f}"
            if np.isfinite(fit["slope"])
            else ""
        )
    )
    ax.grid(alpha=0.25)

    save_png_svg(fig, base)


def plot_run_involvement(df, title, base):
    fig, ax = plt.subplots(figsize=(8, 5), layout="constrained")

    ax.plot(
        df["run"],
        df["mean_pair_fsi"],
        marker="o",
        linewidth=2,
    )

    ax.set_xticks(range(1, 7))
    ax.set_xlabel("Run")
    ax.set_ylabel("Mean FSI-like contribution\n(all unordered pairs involving run)")
    ax.set_title(title)
    ax.grid(alpha=0.25)

    save_png_svg(fig, base)


def plot_finger_slopes(df, title, base):
    ordered = df.sort_values("midpoint_slope")

    fig, ax = plt.subplots(figsize=(10, 5), layout="constrained")

    x = np.arange(len(ordered))
    ax.bar(x, ordered["midpoint_slope"])
    ax.axhline(0, linewidth=0.8)

    ax.set_xticks(x)
    ax.set_xticklabels(
        ordered["finger_pair"],
        rotation=35,
        ha="right",
    )
    ax.set_ylabel("Slope vs run-pair midpoint")
    ax.set_title(title)
    ax.grid(axis="y", alpha=0.25)

    save_png_svg(fig, base)


def plot_pair_heatmap(df, title, base):
    matrix = np.full((6, 6), np.nan, dtype=float)

    for _, row in df.iterrows():
        a = int(row["run_low"]) - 1
        b = int(row["run_high"]) - 1
        matrix[a, b] = row["fsi_like"]
        matrix[b, a] = row["fsi_like"]

    fig, ax = plt.subplots(figsize=(6, 5.5), layout="constrained")

    im = ax.imshow(matrix, aspect="equal")

    ax.set_xticks(range(6))
    ax.set_yticks(range(6))
    ax.set_xticklabels([f"run{i}" for i in range(1, 7)])
    ax.set_yticklabels([f"run{i}" for i in range(1, 7)])
    ax.set_title(title)

    for i in range(6):
        for j in range(6):
            if np.isfinite(matrix[i, j]):
                ax.text(
                    j,
                    i,
                    f"{matrix[i,j]:.3f}",
                    ha="center",
                    va="center",
                    fontsize=7,
                )

    fig.colorbar(
        im,
        ax=ax,
        label="Mean upper-triangle run-pair contribution",
    )

    save_png_svg(fig, base)


def write_summary(path, drift_df, group_df, slopes_df):
    with path.open("w") as f:
        f.write("RUN-ORDER / TEMPORAL-DRIFT DIAGNOSTIC\n")
        f.write("=" * 78 + "\n\n")
        f.write(
            "Interpretation note: the 15 unordered run pairs are overlapping,\n"
            "non-independent observations. Slopes and correlations below are\n"
            "descriptive diagnostics; no ordinary regression p-values are used.\n\n"
        )

        for _, row in drift_df.iterrows():
            roi = row["roi"]
            session = row["session"]

            f.write(f"{roi} | {session}\n")
            f.write("-" * 78 + "\n")
            f.write(
                f"FSI-like slope vs pair midpoint: "
                f"{row['fsi_midpoint_slope']:.6f} "
                f"(r={row['fsi_midpoint_r']:.3f})\n"
            )
            f.write(
                f"FSI-like slope vs temporal separation: "
                f"{row['fsi_separation_slope']:.6f} "
                f"(r={row['fsi_separation_r']:.3f})\n"
            )
            f.write(
                f"Geometry-to-full slope vs midpoint: "
                f"{row['geometry_midpoint_slope']:.6f} "
                f"(r={row['geometry_midpoint_r']:.3f})\n"
            )
            f.write(
                f"Mean early-early FSI-like contribution: "
                f"{row['mean_fsi_early_early']:.6f}\n"
            )
            f.write(
                f"Mean late-late FSI-like contribution: "
                f"{row['mean_fsi_late_late']:.6f}\n"
            )
            f.write(
                f"Late minus early: "
                f"{row['late_minus_early_fsi']:.6f}\n"
            )
            f.write(
                f"Mean reciprocal-direction Pearson: "
                f"{row['mean_reciprocal_pearson']:.6f}\n"
            )

            gs = group_df[
                (group_df["roi"] == roi)
                & (group_df["session"] == session)
            ]

            f.write("\nTemporal/parity groups:\n")
            f.write(gs.to_string(index=False))
            f.write("\n\n")

            ss = slopes_df[
                (slopes_df["roi"] == roi)
                & (slopes_df["session"] == session)
            ].copy()

            ss["abs_midpoint_slope"] = np.abs(ss["midpoint_slope"])
            ss = ss.sort_values("abs_midpoint_slope", ascending=False)

            f.write("Finger pairs with largest absolute midpoint slopes:\n")
            f.write(
                ss[
                    [
                        "finger_pair",
                        "midpoint_slope",
                        "midpoint_r",
                        "separation_slope",
                        "separation_r",
                    ]
                ]
                .head(10)
                .to_string(index=False)
            )
            f.write("\n\n")


def main():
    p = argparse.ArgumentParser()

    p.add_argument("--subject", default=DEFAULT_SUBJECT)
    p.add_argument("--rois", nargs="+", default=list(DEFAULT_ROIS))
    p.add_argument("--sessions", nargs="+", default=list(DEFAULT_SESSIONS))
    p.add_argument(
        "--first-level-root",
        type=Path,
        default=DEFAULT_ROOT,
    )
    p.add_argument(
        "--out-dir",
        type=Path,
        default=DEFAULT_OUT,
    )

    args = p.parse_args()

    args.out_dir.mkdir(parents=True, exist_ok=True)

    directed_all = []
    unordered_all = []
    run_all = []
    group_all = []
    finger_slope_all = []
    drift_all = []

    for roi in args.rois:
        for session in args.sessions:
            path = firstlevel_path(
                args.first_level_root,
                args.subject,
                session,
                roi,
            )

            obj = load_pickle(path)

            directed_df, data = directed_metrics(
                roi,
                session,
                obj,
            )

            symmetry_df = reciprocal_symmetry(
                directed_df,
                data,
            )

            unordered_df = unordered_metrics(
                roi,
                session,
                obj,
                data,
            )

            run_df = run_involvement_summary(
                unordered_df
            )

            group_df = temporal_group_summary(
                unordered_df
            )

            slope_df = finger_pair_temporal_slopes(
                unordered_df
            )

            drift_df = drift_summary(
                unordered_df,
                symmetry_df,
            )

            directed_all.append(directed_df)
            unordered_all.append(unordered_df)
            run_all.append(run_df)
            group_all.append(group_df)
            finger_slope_all.append(slope_df)
            drift_all.append(drift_df)

            stem = f"{roi}_{session}"

            plot_scatter_with_fit(
                unordered_df,
                "pair_midpoint",
                "fsi_like",
                "Run-pair midpoint",
                "Mean upper-triangle contribution",
                f"Run-pair FSI-like contribution vs temporal midpoint — {roi} {session}",
                args.out_dir / f"{stem}_pair_fsi_by_midpoint",
            )

            plot_scatter_with_fit(
                unordered_df,
                "temporal_separation",
                "fsi_like",
                "Temporal separation between runs",
                "Mean upper-triangle contribution",
                f"Run-pair FSI-like contribution vs run separation — {roi} {session}",
                args.out_dir / f"{stem}_pair_fsi_by_separation",
            )

            plot_scatter_with_fit(
                unordered_df,
                "pair_midpoint",
                "geometry_r_to_full",
                "Run-pair midpoint",
                "Pearson r with full-session RDM",
                f"Run-pair geometry similarity vs temporal midpoint — {roi} {session}",
                args.out_dir / f"{stem}_geometry_similarity_by_midpoint",
            )

            plot_run_involvement(
                run_df,
                f"Run involvement in pairwise representational magnitude — {roi} {session}",
                args.out_dir / f"{stem}_run_involvement",
            )

            plot_finger_slopes(
                slope_df,
                f"Finger-pair temporal slopes — {roi} {session}",
                args.out_dir / f"{stem}_finger_pair_temporal_slopes",
            )

            plot_pair_heatmap(
                unordered_df,
                f"Unordered run-pair FSI-like contributions — {roi} {session}",
                args.out_dir / f"{stem}_unordered_pair_heatmap",
            )

    directed_all = pd.concat(directed_all, ignore_index=True)
    unordered_all = pd.concat(unordered_all, ignore_index=True)
    run_all = pd.concat(run_all, ignore_index=True)
    group_all = pd.concat(group_all, ignore_index=True)
    finger_slope_all = pd.concat(finger_slope_all, ignore_index=True)
    drift_all = pd.concat(drift_all, ignore_index=True)

    directed_all.to_csv(
        args.out_dir / "directed_run_pair_metrics.csv",
        index=False,
    )
    unordered_all.to_csv(
        args.out_dir / "unordered_run_pair_metrics.csv",
        index=False,
    )
    run_all.to_csv(
        args.out_dir / "run_involvement_summary.csv",
        index=False,
    )
    group_all.to_csv(
        args.out_dir / "temporal_group_summary.csv",
        index=False,
    )
    finger_slope_all.to_csv(
        args.out_dir / "finger_pair_temporal_slopes.csv",
        index=False,
    )
    drift_all.to_csv(
        args.out_dir / "drift_summary.csv",
        index=False,
    )

    write_summary(
        args.out_dir / "diagnostic_summary.txt",
        drift_all,
        group_all,
        finger_slope_all,
    )

    print()
    print("Run-order diagnostic complete.")
    print("Output:", args.out_dir)
    print()
    print("Primary files:")
    print("  diagnostic_summary.txt")
    print("  drift_summary.csv")
    print("  temporal_group_summary.csv")
    print("  run_involvement_summary.csv")
    print("  finger_pair_temporal_slopes.csv")


if __name__ == "__main__":
    main()


