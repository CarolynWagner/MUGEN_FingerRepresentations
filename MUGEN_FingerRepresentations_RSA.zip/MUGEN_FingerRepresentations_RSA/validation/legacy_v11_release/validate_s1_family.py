#!/usr/bin/env python3
"""
validate_s1_family.py

Family-level validation and comparison for generalized RSA v11 S1 ROIs:
S1, S1_1, S1_2, S1_3a, S1_3b.

Reads existing first- and second-level outputs only. Does NOT recompute RSA.
"""

from __future__ import annotations
import argparse, math, pickle
from pathlib import Path
from typing import Any
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

DEFAULT_SUBJECT = "sub-01"
DEFAULT_ROIS = ("S1", "S1_1", "S1_2", "S1_3a", "S1_3b")
DEFAULT_SESSIONS = ("ses18", "ses19", "ses20")
DEFAULT_FIRST_ROOT = Path("results/first_level")
DEFAULT_SECOND_ROOT = Path("results/second_level")
DEFAULT_OUT = Path("results/roi_comparisons/S1_family")
FULL_COMBO = "run1-6"

def load_pickle(path):
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(path)
    with path.open("rb") as f:
        obj = pickle.load(f)
    if not isinstance(obj, dict):
        raise TypeError(path)
    return obj

def ffloat(x):
    try:
        y = float(x)
    except Exception:
        return math.nan
    return y if np.isfinite(y) else math.nan

def upper_vec(rdm):
    rdm = np.asarray(rdm, float)
    return rdm[np.triu_indices(rdm.shape[0], k=1)]

def pearson(a, b):
    a = np.asarray(a, float).ravel()
    b = np.asarray(b, float).ravel()
    n = min(a.size, b.size)
    a, b = a[:n], b[:n]
    ok = np.isfinite(a) & np.isfinite(b)
    a, b = a[ok], b[ok]
    if len(a) < 2 or np.std(a) < 1e-12 or np.std(b) < 1e-12:
        return math.nan
    return float(np.corrcoef(a, b)[0, 1])

def save_png_svg(fig, base):
    base = Path(base)
    base.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(base.with_suffix(".png"), dpi=300, bbox_inches="tight")
    fig.savefig(base.with_suffix(".svg"), bbox_inches="tight")
    plt.close(fig)

def collect_first(subject, rois, sessions, root):
    objs, qc, fsi, split = {}, [], [], []
    for roi in rois:
        objs[roi] = {}
        for ses in sessions:
            p = root / subject / ses / f"roi-{roi}" / "rsa_firstlevel.pkl"
            o = load_pickle(p)
            objs[roi][ses] = o
            qm, rm, acq = o.get("qc", {}), o.get("roi", {}), o.get("acquisition", {})
            before = ffloat(rm.get("n_voxels_before_qc", qm.get("n_voxels_roi")))
            after = ffloat(rm.get("n_voxels_after_qc", qm.get("n_valid_voxels")))
            retention = ffloat(qm.get("voxel_retention", after / before if before else math.nan))
            qc.append(dict(
                roi=roi, session=ses, resolution_mm=acq.get("resolution_mm"),
                n_voxels_before_qc=before, n_voxels_after_qc=after,
                n_removed_voxels=before-after if np.isfinite(before) and np.isfinite(after) else math.nan,
                voxel_retention=retention,
                n_bad_beta_voxels=ffloat(qm.get("n_bad_beta_voxels")),
                n_bad_residual_voxels=ffloat(qm.get("n_bad_residual_voxels")),
                n_low_variance_residual_voxels=ffloat(qm.get("n_low_variance_residual_voxels")),
            ))
            combo = o.get("full_combo_label", FULL_COMBO)
            if combo in o.get("fsi_raw", {}):
                fsi.append(dict(roi=roi, session=ses, combo=combo, fsi_raw=ffloat(o["fsi_raw"][combo])))
            for split_name, item in o.get("independent_split_reliability", {}).items():
                if not isinstance(item, dict):
                    continue
                for metric in ("pearson","spearman","icc","cosine","fisherz"):
                    if metric in item:
                        split.append(dict(
                            roi=roi, session=ses, split=split_name,
                            metric=metric, value=ffloat(item[metric])
                        ))
    return objs, pd.DataFrame(qc), pd.DataFrame(fsi), pd.DataFrame(split)

def collect_second(subject, rois, root):
    pairwise, testretest = [], []
    for roi in rois:
        o = load_pickle(root / subject / f"roi-{roi}" / "rsa_secondlevel.pkl")
        for row in o.get("pairwise", []):
            if row.get("comparison_type") != "within_subject_across_sessions":
                continue
            item = dict(
                roi=roi,
                session_a=row.get("session_a"),
                session_b=row.get("session_b"),
                session_pair=f"{row.get('session_a')}_vs_{row.get('session_b')}",
                combo=row.get("combo", o.get("full_combo_label", FULL_COMBO)),
            )
            for metric in ("pearson","spearman","icc","cosine","fisherz"):
                if metric in row:
                    item[metric] = ffloat(row[metric])
            pairwise.append(item)
        ref = o.get("test_retest_consistency_reference", {})
        for metric, value in ref.get("metrics", {}).items():
            if isinstance(value, (int,float,np.integer,np.floating)):
                testretest.append(dict(
                    roi=roi, session_pair="_vs_".join(ref.get("sessions", [])),
                    combo=ref.get("combo", FULL_COMBO), metric=metric, value=ffloat(value)
                ))
    return pd.DataFrame(pairwise), pd.DataFrame(testretest)

def geometry_tables(objs, rois, sessions):
    combined, allpairs = [], []
    combined_roi = rois[0]
    for ses in sessions:
        combo = objs[combined_roi][ses].get("full_combo_label", FULL_COMBO)
        base = upper_vec(objs[combined_roi][ses]["rdms"][combo]["raw"])
        for roi in rois[1:]:
            vec = upper_vec(objs[roi][ses]["rdms"][combo]["raw"])
            combined.append(dict(session=ses, combined_roi=combined_roi, subdivision=roi,
                                 combo=combo, pearson_rdm_geometry=pearson(base, vec)))
        for i, ra in enumerate(rois):
            va = upper_vec(objs[ra][ses]["rdms"][combo]["raw"])
            for rb in rois[i+1:]:
                vb = upper_vec(objs[rb][ses]["rdms"][combo]["raw"])
                allpairs.append(dict(session=ses, roi_a=ra, roi_b=rb, combo=combo,
                                     pearson_rdm_geometry=pearson(va, vb)))
    return pd.DataFrame(combined), pd.DataFrame(allpairs)

def make_flags(qc, fsi, split, pairwise):
    rows = []
    for _, r in qc.iterrows():
        if np.isfinite(r.voxel_retention) and r.voxel_retention < .80:
            rows.append(dict(roi=r.roi, session_or_pair=r.session, category="QC",
                             flag="voxel_retention_below_0.80", value=r.voxel_retention))
    ps = split[split.metric == "pearson"]
    for _, r in ps.iterrows():
        if np.isfinite(r.value) and r.value < .60:
            rows.append(dict(roi=r.roi, session_or_pair=r.session, category="reliability",
                             flag=f"split_pearson_below_0.60::{r.split}", value=r.value))
    for (roi, ses), g in ps.groupby(["roi","session"]):
        vals = g.value.to_numpy(float); vals = vals[np.isfinite(vals)]
        if vals.size >= 2:
            spread = float(vals.max()-vals.min())
            if spread >= .20:
                rows.append(dict(roi=roi, session_or_pair=ses, category="reliability",
                                 flag="split_pearson_spread_ge_0.20", value=spread))
    if "pearson" in pairwise.columns:
        for _, r in pairwise.iterrows():
            if np.isfinite(r.pearson) and r.pearson < .75:
                rows.append(dict(roi=r.roi, session_or_pair=r.session_pair, category="test_retest",
                                 flag="cross_session_pearson_below_0.75", value=r.pearson))
    for roi, g in fsi.groupby("roi"):
        x = g.set_index("session").fsi_raw
        if "ses19" in x.index and "ses20" in x.index:
            a, b = ffloat(x["ses19"]), ffloat(x["ses20"])
            if np.isfinite(a) and abs(a) > 1e-12 and np.isfinite(b):
                ratio = b/a
                if ratio < .65 or ratio > 1.50:
                    rows.append(dict(roi=roi, session_or_pair="ses19_vs_ses20", category="magnitude",
                                     flag="fsi_ratio_outside_0.65_to_1.50", value=ratio))
    return pd.DataFrame(rows)

def grouped_bars(df, rois, sessions, value_col, ylabel, title, base, ylim=None, hline=None):
    fig, ax = plt.subplots(figsize=(10,5), layout="constrained")
    x = np.arange(len(rois)); width=.22
    for i, ses in enumerate(sessions):
        vals = df[df.session==ses].set_index("roi").reindex(rois)[value_col].astype(float).values
        ax.bar(x+(i-(len(sessions)-1)/2)*width, vals, width=width, label=ses)
    if hline is not None: ax.axhline(hline, ls="--", lw=1)
    ax.set_xticks(x); ax.set_xticklabels(rois); ax.set_ylabel(ylabel); ax.set_title(title); ax.legend()
    if ylim: ax.set_ylim(*ylim)
    ax.grid(axis="y", alpha=.25)
    save_png_svg(fig, base)

def plot_split(split, rois, sessions, out):
    d = split[split.metric=="pearson"]
    splits = list(dict.fromkeys(d["split"]))
    fig, axes = plt.subplots(len(splits),1,figsize=(11,4.4*len(splits)),layout="constrained")
    axes=np.atleast_1d(axes)
    for ax, sp in zip(axes,splits):
        x=np.arange(len(rois)); width=.22; sub=d[d["split"]==sp]
        for i,ses in enumerate(sessions):
            vals=sub[sub.session==ses].set_index("roi").reindex(rois).value.astype(float).values
            ax.bar(x+(i-(len(sessions)-1)/2)*width, vals,width=width,label=ses)
        ax.axhline(.60,ls="--",lw=1); ax.set_xticks(x); ax.set_xticklabels(rois)
        ax.set_ylim(-.1,1.05); ax.set_ylabel("Pearson"); ax.set_title(sp.replace("_"," "))
        ax.legend(); ax.grid(axis="y",alpha=.25)
    save_png_svg(fig,out/"s1_family_independent_split_reliability")

def plot_cross(pairwise, rois, out):
    pairs=list(dict.fromkeys(pairwise.session_pair))
    metrics=[m for m in ("pearson","spearman","icc","cosine") if m in pairwise.columns]
    fig,axes=plt.subplots(len(metrics),1,figsize=(11,4.1*len(metrics)),layout="constrained")
    axes=np.atleast_1d(axes)
    for ax,m in zip(axes,metrics):
        x=np.arange(len(rois)); width=min(.24,.75/max(len(pairs),1))
        for i,pair in enumerate(pairs):
            vals=pairwise[pairwise.session_pair==pair].set_index("roi").reindex(rois)[m].astype(float).values
            ax.bar(x+(i-(len(pairs)-1)/2)*width, vals,width=width,label=pair)
        if m=="pearson": ax.axhline(.75,ls="--",lw=1)
        ax.set_xticks(x); ax.set_xticklabels(rois); ax.set_ylim(-.1,1.05)
        ax.set_ylabel(m.capitalize()); ax.set_title(f"Across-session {m}"); ax.legend()
        ax.grid(axis="y",alpha=.25)
    save_png_svg(fig,out/"s1_family_cross_session_reliability")

def plot_geometry(combined, pairgeom, rois, sessions, out):
    subs=rois[1:]
    grouped_bars(combined.rename(columns={"subdivision":"roi"}),subs,sessions,
                 "pearson_rdm_geometry","Pearson RDM correlation",
                 "Combined S1 vs subdivisions",out/"s1_combined_vs_subdivision_geometry",
                 ylim=(-.1,1.05))
    pairs=list(dict.fromkeys((pairgeom.roi_a+" vs "+pairgeom.roi_b).tolist()))
    fig,ax=plt.subplots(figsize=(14,6),layout="constrained"); x=np.arange(len(pairs)); width=.22
    for i,ses in enumerate(sessions):
        sub=pairgeom[pairgeom.session==ses].copy(); sub["pair"]=sub.roi_a+" vs "+sub.roi_b
        vals=sub.set_index("pair").reindex(pairs).pearson_rdm_geometry.astype(float).values
        ax.bar(x+(i-(len(sessions)-1)/2)*width,vals,width=width,label=ses)
    ax.set_xticks(x); ax.set_xticklabels(pairs,rotation=35,ha="right"); ax.set_ylim(-.1,1.05)
    ax.set_ylabel("Pearson RDM correlation"); ax.set_title("S1 family pairwise RDM geometry")
    ax.legend(); ax.grid(axis="y",alpha=.25)
    save_png_svg(fig,out/"s1_family_pairwise_rdm_geometry")

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--subject",default=DEFAULT_SUBJECT)
    ap.add_argument("--rois",nargs="+",default=list(DEFAULT_ROIS))
    ap.add_argument("--sessions",nargs="+",default=list(DEFAULT_SESSIONS))
    ap.add_argument("--first-level-root",type=Path,default=DEFAULT_FIRST_ROOT)
    ap.add_argument("--second-level-root",type=Path,default=DEFAULT_SECOND_ROOT)
    ap.add_argument("--out-dir",type=Path,default=DEFAULT_OUT)
    a=ap.parse_args(); rois=list(a.rois); sessions=list(a.sessions)
    objs,qc,fsi,split=collect_first(a.subject,rois,sessions,a.first_level_root)
    pairwise,testretest=collect_second(a.subject,rois,a.second_level_root)
    combined,pairgeom=geometry_tables(objs,rois,sessions)
    flags=make_flags(qc,fsi,split,pairwise)
    a.out_dir.mkdir(parents=True,exist_ok=True)

    qc.to_csv(a.out_dir/"s1_family_qc.csv",index=False)
    fsi.to_csv(a.out_dir/"s1_family_fsi.csv",index=False)
    split.to_csv(a.out_dir/"s1_family_independent_split_reliability.csv",index=False)
    pairwise.to_csv(a.out_dir/"s1_family_cross_session_similarity.csv",index=False)
    testretest.to_csv(a.out_dir/"s1_family_test_retest.csv",index=False)
    combined.to_csv(a.out_dir/"s1_combined_vs_subdivision_geometry.csv",index=False)
    pairgeom.to_csv(a.out_dir/"s1_family_pairwise_rdm_geometry.csv",index=False)
    flags.to_csv(a.out_dir/"s1_family_flags.csv",index=False)

    grouped_bars(qc,rois,sessions,"voxel_retention","Voxel retention",
                 "S1 family voxel retention",a.out_dir/"s1_family_voxel_retention",
                 ylim=(0,1.05),hline=.80)
    grouped_bars(qc,rois,sessions,"n_voxels_after_qc","Valid voxels after QC",
                 "S1 family valid voxel counts",a.out_dir/"s1_family_voxel_counts")
    grouped_bars(fsi,rois,sessions,"fsi_raw","Raw FSI",
                 "S1 family full-combo FSI",a.out_dir/"s1_family_fsi_full_combo")
    plot_split(split,rois,sessions,a.out_dir)
    plot_cross(pairwise,rois,a.out_dir)
    plot_geometry(combined,pairgeom,rois,sessions,a.out_dir)

    with (a.out_dir/"s1_family_validation_summary.txt").open("w") as f:
        f.write("S1 FAMILY VALIDATION SUMMARY\n"+"="*80+"\n\n")
        f.write("QC\n"+"-"*80+"\n"+qc.to_string(index=False)+"\n\n")
        f.write("FULL-COMBO FSI\n"+"-"*80+"\n"+fsi.to_string(index=False)+"\n\n")
        f.write("INDEPENDENT SPLIT PEARSON\n"+"-"*80+"\n")
        f.write(split[split.metric=="pearson"][["roi","session","split","value"]].to_string(index=False)+"\n\n")
        f.write("CROSS-SESSION SIMILARITY\n"+"-"*80+"\n")
        cols=[c for c in ("roi","session_pair","pearson","spearman","icc","cosine") if c in pairwise.columns]
        f.write(pairwise[cols].to_string(index=False)+"\n\n")
        f.write("COMBINED S1 VS SUBDIVISIONS\n"+"-"*80+"\n"+combined.to_string(index=False)+"\n\n")
        f.write("AUTOMATIC FLAGS\n"+"-"*80+"\n")
        f.write("No threshold-based flags.\n" if flags.empty else flags.to_string(index=False))

    print("S1 family validation complete.")
    print("Output:",a.out_dir)

if __name__=="__main__":
    main()

