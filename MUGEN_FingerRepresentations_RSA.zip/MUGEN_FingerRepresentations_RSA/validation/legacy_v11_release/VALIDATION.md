# Validation status and certification gates

## Already preserved

The numerical first-level core is copied byte-for-byte from the attached frozen v10.3 pipeline for:

- beta/residual loading;
- finite-first voxel QC;
- RDM contract construction;
- rsatoolbox Crossnobis computation;
- run-subset stability metrics;
- independent split reliability;
- run-pair uncertainty.

The package build verifies byte identity for these source modules and its internal unit tests pass.

## Required before calling v11 numerically certified

Run the pilot data through v11 using `roi_name=M1_old` and execute:

```bash
python tests/regression_against_v10_3.py \
  --v10 /path/to/v10.3/results/rsa_final_locked.pkl \
  --v11 /path/to/v11/ses18/roi-M1_old/rsa_firstlevel.pkl \
        /path/to/v11/ses19/roi-M1_old/rsa_firstlevel.pkl \
        /path/to/v11/ses20/roi-M1_old/rsa_firstlevel.pkl
```

Certification criterion: all raw RDM entries and raw FSI values reproduce frozen v10.3 within the specified numerical tolerance (default `1e-10`).

## New second-level code

The second-level architecture is new. It is deliberately separated from the frozen first-level estimator. It has synthetic unit tests for pairwise classification and group-noise-ceiling construction, but scientific certification requires running it on the pilot first-level objects and checking that the ses18/ses19/ses20 M1_old pairwise metrics reproduce the frozen v10.3 between-session results.

No claim of group-level noise-ceiling validation is possible from the one-participant pilot; that component becomes applicable once multiple independent participants are available.
