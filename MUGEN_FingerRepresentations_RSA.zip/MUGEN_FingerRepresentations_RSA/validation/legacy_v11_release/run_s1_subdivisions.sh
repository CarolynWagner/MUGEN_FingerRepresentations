#!/usr/bin/env bash
set -euo pipefail

SUBJECT="${1:-sub-01}"

ROIS=(
  S1_1
  S1_2
  S1_3a
  S1_3b
)

echo "============================================================"
echo "RSA v11 S1 SUBDIVISION PIPELINE"
echo "Subject: ${SUBJECT}"
echo "ROIs: ${ROIS[*]}"
echo "============================================================"
echo

for roi in "${ROIS[@]}"; do
    echo
    echo "============================================================"
    echo "FIRST LEVEL: ${roi}"
    echo "============================================================"

    python run_pipeline.py \
      --first-level \
      --subject "${SUBJECT}" \
      --roi "${roi}"
done

for roi in "${ROIS[@]}"; do
    echo
    echo "============================================================"
    echo "SECOND LEVEL: ${roi}"
    echo "============================================================"

    python run_pipeline.py \
      --second-level \
      --subject "${SUBJECT}" \
      --roi "${roi}"
done

echo
echo "============================================================"
echo "S1 FAMILY VALIDATION"
echo "============================================================"

python validate_s1_family.py \
  --subject "${SUBJECT}"

echo
echo "============================================================"
echo "S1 SUBDIVISION WORKFLOW COMPLETE"
echo "============================================================"
echo "Comparison output:"
echo "  results/roi_comparisons/S1_family/"
