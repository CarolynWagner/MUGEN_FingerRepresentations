#!/usr/bin/env python3
from first_level.run_first_level import main
if __name__=='__main__': main()
