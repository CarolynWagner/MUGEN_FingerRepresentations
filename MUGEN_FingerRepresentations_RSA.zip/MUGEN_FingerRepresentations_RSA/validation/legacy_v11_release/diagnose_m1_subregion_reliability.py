#!/usr/bin/env python3
"""
diagnose_m1_subregion_reliability.py

Targeted diagnostic for M1_4a and M1_4p after the generalized RSA v11
pipeline has completed.

Questions addressed
-------------------
1. Which voxels are removed by QC in each ROI/session?
2. Why are they removed?
3. Which individual finger-pair Crossnobis distances drive the session-level FSI?
4. Is the M1_4p ses20 FSI reduction a global scaling effect or concentrated
   in particular finger pairs?
5. Do run-pair contributions explain discrepancies between independent split
   reliability estimates (especially first-half vs second-half versus odd-even)?

The script does NOT recompute the RSA model. It reads existing
rsa_firstlevel.pkl files and summarizes the already-computed diagnostics.

Expected v11 first-level fields
-------------------------------
- finger_names
- full_combo_label
- rdms
- fsi_raw
- independent_split_reliability
- run_pair_contributions
- run_pair_labels
- run_level_uncertainty
- roi
- qc

Outputs
-------
CSV:
  qc_breakdown.csv
  finger_pair_distances.csv
  finger_pair_session_change.csv
  independent_split_reliability.csv
  run_pair_contributions_long.csv
  run_pair_summary.csv
  diagnostic_flags.csv

Figures (PNG + SVG):
  qc_voxel_retention
  qc_removed_voxels_by_reason
  finger_pair_distances
  finger_pair_change_ses19_to_ses20
  independent_split_reliability
  run_pair_contribution_means
  run_pair_contribution_heatmap_<ROI>_<session>   [when schema permits]

Run from RSApipeline_general_v11 root, for example:

    python diagnose_m1_subregion_reliability.py \
        --subject sub-01 \
        --rois M1_4a M1_4p

"""

from __future__ import annotations

import argparse
import csv
import math
import pickle
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt


SESSIONS = ("ses18", "ses19", "ses20")
DEFAULT_SUBJECT = "sub-01"
DEFAULT_ROIS = ("M1_4a", "M1_4p")
DEFAULT_FIRST_LEVEL_ROOT = Path("results/first_level")
DEFAULT_OUT_DIR = Path("results/roi_comparisons/M1_subregion_diagnostics")
FULL_COMBO_FALLBACK = "run1-6"


def load_pickle(path: Path) -> dict:
    if not path.exists():
        raise FileNotFoundError(path)

    with path.open("rb") as f:
        obj = pickle.load(f)

    if not isinstance(obj, dict):
        raise TypeError(f"Expected dictionary in {path}")

    return obj


def firstlevel_path(
    root: Path,
    subject: str,
    session: str,
    roi: str,
) -> Path:
    return (
        root
        / subject
        / session
        / f"roi-{roi}"
        / "rsa_firstlevel.pkl"
    )


def save_png_svg(fig, base: Path) -> None:
    base.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(
        base.with_suffix(".png"),
        dpi=300,
        bbox_inches="tight",
    )
    fig.savefig(
        base.with_suffix(".svg"),
        bbox_inches="tight",
    )
    plt.close(fig)


def finite_float(x: Any) -> float:
    try:
        value = float(x)
    except Exception:
        return math.nan

    return value if np.isfinite(value) else math.nan


def upper_pairs(
    rdm: np.ndarray,
    finger_names: list[str],
) -> list[dict]:
    rdm = np.asarray(rdm, dtype=float)

    if rdm.ndim != 2 or rdm.shape[0] != rdm.shape[1]:
        raise ValueError(f"RDM must be square, got {rdm.shape}")

    if rdm.shape[0] != len(finger_names):
        raise ValueError(
            f"RDM size {rdm.shape[0]} != "
            f"{len(finger_names)} finger labels"
        )

    rows = []

    for i in range(len(finger_names)):
        for j in range(i + 1, len(finger_names)):
            rows.append({
                "finger_i": finger_names[i],
                "finger_j": finger_names[j],
                "pair": f"{finger_names[i]}–{finger_names[j]}",
                "distance": finite_float(rdm[i, j]),
            })

    return rows


def qc_row(
    roi: str,
    session: str,
    obj: dict,
) -> dict:
    roi_meta = obj.get("roi", {})
    qc = obj.get("qc", {})

    before = roi_meta.get(
        "n_voxels_before_qc",
        qc.get("n_voxels_roi"),
    )

    after = roi_meta.get(
        "n_voxels_after_qc",
        qc.get("n_valid_voxels"),
    )

    before = finite_float(before)
    after = finite_float(after)

    removed_total = (
        before - after
        if np.isfinite(before) and np.isfinite(after)
        else math.nan
    )

    return {
        "roi": roi,
        "session": session,
        "resolution_mm": obj.get(
            "acquisition",
            {},
        ).get("resolution_mm"),
        "n_voxels_before_qc": before,
        "n_voxels_after_qc": after,
        "n_removed_total": removed_total,
        "voxel_retention": finite_float(
            qc.get(
                "voxel_retention",
                after / before
                if np.isfinite(before)
                and before > 0
                and np.isfinite(after)
                else math.nan,
            )
        ),
        "n_bad_beta_voxels": finite_float(
            qc.get("n_bad_beta_voxels")
        ),
        "n_bad_residual_voxels": finite_float(
            qc.get("n_bad_residual_voxels")
        ),
        "n_low_variance_residual_voxels": finite_float(
            qc.get("n_low_variance_residual_voxels")
        ),
        "n_nonfinite_beta_values": finite_float(
            qc.get("n_nonfinite_beta_values")
        ),
        "n_nonfinite_residual_values": finite_float(
            qc.get("n_nonfinite_residual_values")
        ),
        "residual_std_min_valid": finite_float(
            qc.get("residual_std_min_valid")
        ),
        "residual_std_max_valid": finite_float(
            qc.get("residual_std_max_valid")
        ),
        "qa_method": qc.get("qa_method"),
    }


def collect_independent_split_rows(
    roi: str,
    session: str,
    obj: dict,
) -> list[dict]:
    out = []

    indep = obj.get("independent_split_reliability", {})

    if not isinstance(indep, dict):
        return out

    for split_name, item in indep.items():
        if not isinstance(item, dict):
            continue

        for metric in (
            "pearson",
            "spearman",
            "icc",
            "cosine",
            "fisherz",
        ):
            if metric in item:
                out.append({
                    "roi": roi,
                    "session": session,
                    "split": split_name,
                    "metric": metric,
                    "value": finite_float(item[metric]),
                    "combo_a": item.get("combo_a"),
                    "combo_b": item.get("combo_b"),
                    "runs_a": item.get("runs_a"),
                    "runs_b": item.get("runs_b"),
                })

    return out


def parse_run_pair_label(label: Any) -> tuple[str, str]:
    """
    Return a robust pair of display strings without assuming one exact v11
    label representation.
    """
    if isinstance(label, (list, tuple)) and len(label) == 2:
        return str(label[0]), str(label[1])

    text = str(label)

    for sep in (
        "_vs_",
        " vs ",
        "–",
        "-vs-",
        "__",
        ",",
    ):
        if sep in text:
            left, right = text.split(sep, 1)
            return left.strip(), right.strip()

    return text, ""


def contribution_array_to_long(
    roi: str,
    session: str,
    obj: dict,
) -> tuple[list[dict], dict]:
    """
    Convert run_pair_contributions into a long table when possible.

    Known/anticipated shapes:
      (n_pairs,)                  one scalar per run pair
      (n_pairs, n_distances)      pair-specific RDM vectors
      (n_pairs, n_fingers, n_fingers) pair-specific RDM matrices

    Unknown shapes are still recorded in the summary instead of failing.
    """

    values = obj.get("run_pair_contributions")
    labels = obj.get("run_pair_labels")

    summary = {
        "roi": roi,
        "session": session,
        "available": False,
        "shape": None,
        "n_run_pairs": 0,
        "mean_contribution": math.nan,
        "std_contribution": math.nan,
        "min_contribution": math.nan,
        "max_contribution": math.nan,
        "schema_note": None,
    }

    if values is None:
        summary["schema_note"] = "run_pair_contributions absent"
        return [], summary

    arr = np.asarray(values, dtype=float)

    summary["available"] = True
    summary["shape"] = str(tuple(arr.shape))

    finite = arr[np.isfinite(arr)]

    if finite.size:
        summary["mean_contribution"] = float(np.mean(finite))
        summary["std_contribution"] = float(np.std(finite))
        summary["min_contribution"] = float(np.min(finite))
        summary["max_contribution"] = float(np.max(finite))

    if not isinstance(labels, (list, tuple)):
        labels = []

    n_pairs = (
        arr.shape[0]
        if arr.ndim >= 1
        else 1
    )

    summary["n_run_pairs"] = int(n_pairs)

    if labels and len(labels) != n_pairs:
        summary["schema_note"] = (
            f"label count {len(labels)} != first array dimension {n_pairs}"
        )

    rows = []

    # scalar or one value per pair
    if arr.ndim == 1:
        for idx in range(n_pairs):
            label = (
                labels[idx]
                if idx < len(labels)
                else f"pair_{idx+1}"
            )
            run_a, run_b = parse_run_pair_label(label)

            rows.append({
                "roi": roi,
                "session": session,
                "run_pair_index": idx,
                "run_pair_label": str(label),
                "run_a": run_a,
                "run_b": run_b,
                "element": "scalar",
                "value": finite_float(arr[idx]),
            })

        return rows, summary

    # Flatten each run pair's contribution object into deterministic elements.
    if arr.ndim >= 2:
        for idx in range(n_pairs):
            label = (
                labels[idx]
                if idx < len(labels)
                else f"pair_{idx+1}"
            )
            run_a, run_b = parse_run_pair_label(label)

            flat = np.asarray(arr[idx], dtype=float).ravel()

            for element_idx, value in enumerate(flat):
                rows.append({
                    "roi": roi,
                    "session": session,
                    "run_pair_index": idx,
                    "run_pair_label": str(label),
                    "run_a": run_a,
                    "run_b": run_b,
                    "element": element_idx,
                    "value": finite_float(value),
                })

        return rows, summary

    summary["schema_note"] = "Unhandled zero-dimensional contribution array"
    return rows, summary


def collect(
    subject: str,
    rois: list[str],
    first_level_root: Path,
):
    objects: dict[str, dict[str, dict]] = {}

    qc_rows = []
    distance_rows = []
    split_rows = []
    contribution_rows = []
    run_pair_summary_rows = []

    for roi in rois:
        objects[roi] = {}

        for session in SESSIONS:
            path = firstlevel_path(
                first_level_root,
                subject,
                session,
                roi,
            )

            obj = load_pickle(path)
            objects[roi][session] = obj

            qc_rows.append(
                qc_row(
                    roi,
                    session,
                    obj,
                )
            )

            fingers = list(obj["finger_names"])
            full_combo = obj.get(
                "full_combo_label",
                FULL_COMBO_FALLBACK,
            )

            rdm_obj = obj["rdms"][full_combo]
            rdm = (
                rdm_obj["raw"]
                if isinstance(rdm_obj, dict)
                else rdm_obj
            )

            for row in upper_pairs(
                rdm,
                fingers,
            ):
                row.update({
                    "roi": roi,
                    "session": session,
                    "combo": full_combo,
                    "fsi_raw": finite_float(
                        obj.get(
                            "fsi_raw",
                            {},
                        ).get(
                            full_combo
                        )
                    ),
                })
                distance_rows.append(row)

            split_rows.extend(
                collect_independent_split_rows(
                    roi,
                    session,
                    obj,
                )
            )

            long_rows, pair_summary = contribution_array_to_long(
                roi,
                session,
                obj,
            )

            contribution_rows.extend(long_rows)
            run_pair_summary_rows.append(pair_summary)

    return (
        objects,
        pd.DataFrame(qc_rows),
        pd.DataFrame(distance_rows),
        pd.DataFrame(split_rows),
        pd.DataFrame(contribution_rows),
        pd.DataFrame(run_pair_summary_rows),
    )


def finger_pair_change_table(
    distance_df: pd.DataFrame,
) -> pd.DataFrame:
    """
    Quantify ses19 -> ses20 distance changes for each ROI/finger pair.

    In addition to absolute change, calculate the ratio and the change after
    normalizing each session's pair distances by its own mean. The latter
    helps distinguish global scale changes from geometry-specific changes.
    """

    rows = []

    for roi in distance_df["roi"].drop_duplicates():
        d = distance_df[distance_df["roi"] == roi]

        s19 = (
            d[d["session"] == "ses19"]
            .set_index("pair")
            ["distance"]
        )

        s20 = (
            d[d["session"] == "ses20"]
            .set_index("pair")
            ["distance"]
        )

        common = s19.index.intersection(s20.index)

        mean19 = float(np.nanmean(s19.loc[common]))
        mean20 = float(np.nanmean(s20.loc[common]))

        for pair in common:
            a = finite_float(s19[pair])
            b = finite_float(s20[pair])

            rows.append({
                "roi": roi,
                "pair": pair,
                "ses19_distance": a,
                "ses20_distance": b,
                "absolute_change": b - a,
                "ratio_ses20_over_ses19": (
                    b / a
                    if np.isfinite(a)
                    and abs(a) > 1e-12
                    else math.nan
                ),
                "ses19_distance_div_session_mean": (
                    a / mean19
                    if np.isfinite(mean19)
                    and abs(mean19) > 1e-12
                    else math.nan
                ),
                "ses20_distance_div_session_mean": (
                    b / mean20
                    if np.isfinite(mean20)
                    and abs(mean20) > 1e-12
                    else math.nan
                ),
                "normalized_geometry_change": (
                    b / mean20 - a / mean19
                    if np.isfinite(mean19)
                    and np.isfinite(mean20)
                    and abs(mean19) > 1e-12
                    and abs(mean20) > 1e-12
                    else math.nan
                ),
                "session_mean_ses19": mean19,
                "session_mean_ses20": mean20,
                "global_scale_ratio_mean20_over_mean19": (
                    mean20 / mean19
                    if np.isfinite(mean19)
                    and abs(mean19) > 1e-12
                    else math.nan
                ),
            })

    return pd.DataFrame(rows)


def diagnostic_flags(
    qc_df: pd.DataFrame,
    split_df: pd.DataFrame,
    change_df: pd.DataFrame,
) -> pd.DataFrame:
    rows = []

    # QC flags
    for _, r in qc_df.iterrows():
        retention = finite_float(r["voxel_retention"])

        if np.isfinite(retention) and retention < 0.80:
            rows.append({
                "roi": r["roi"],
                "session": r["session"],
                "category": "QC",
                "flag": "voxel_retention_below_0.80",
                "value": retention,
            })

    # Split discrepancy flags, Pearson only
    pearson = split_df[
        split_df["metric"] == "pearson"
    ]

    for (roi, session), g in pearson.groupby(
        ["roi", "session"]
    ):
        vals = {
            row["split"]: row["value"]
            for _, row in g.iterrows()
        }

        if len(vals) >= 2:
            finite_vals = np.asarray(
                [
                    v
                    for v in vals.values()
                    if np.isfinite(v)
                ],
                dtype=float,
            )

            if finite_vals.size >= 2:
                spread = float(
                    finite_vals.max()
                    - finite_vals.min()
                )

                if spread >= 0.20:
                    rows.append({
                        "roi": roi,
                        "session": session,
                        "category": "reliability",
                        "flag": "independent_split_pearson_spread_ge_0.20",
                        "value": spread,
                    })

    # Geometry-specific change flag: normalized finger-pair deviation
    for (roi,), g in change_df.groupby(["roi"]):
        vals = np.abs(
            g["normalized_geometry_change"]
            .to_numpy(dtype=float)
        )
        vals = vals[np.isfinite(vals)]

        if vals.size:
            max_change = float(vals.max())

            if max_change >= 0.25:
                rows.append({
                    "roi": roi,
                    "session": "ses19_vs_ses20",
                    "category": "geometry",
                    "flag": "max_normalized_pair_change_ge_0.25",
                    "value": max_change,
                })

    return pd.DataFrame(rows)


def plot_qc_retention(
    qc_df: pd.DataFrame,
    rois: list[str],
    out_dir: Path,
):
    fig, ax = plt.subplots(
        figsize=(9, 5),
        layout="constrained",
    )

    x = np.arange(len(rois))
    width = 0.22

    for i, session in enumerate(SESSIONS):
        sub = (
            qc_df[qc_df["session"] == session]
            .set_index("roi")
            .reindex(rois)
        )

        vals = (
            sub["voxel_retention"]
            .astype(float)
            .values
        )

        xpos = (
            x
            + (
                i
                - (len(SESSIONS) - 1) / 2
            )
            * width
        )

        ax.bar(
            xpos,
            vals,
            width=width,
            label=session,
        )

    ax.axhline(
        0.80,
        linestyle="--",
        linewidth=1,
    )
    ax.set_xticks(x)
    ax.set_xticklabels(rois)
    ax.set_ylim(0, 1.05)
    ax.set_ylabel("Voxel retention")
    ax.set_title("ROI voxel retention after QC")
    ax.legend()
    ax.grid(
        axis="y",
        alpha=0.25,
    )

    save_png_svg(
        fig,
        out_dir / "qc_voxel_retention",
    )


def plot_qc_reasons(
    qc_df: pd.DataFrame,
    rois: list[str],
    out_dir: Path,
):
    reasons = [
        "n_bad_beta_voxels",
        "n_bad_residual_voxels",
        "n_low_variance_residual_voxels",
    ]

    labels = [
        "Bad beta",
        "Bad residual",
        "Low residual variance",
    ]

    for roi in rois:
        sub = (
            qc_df[qc_df["roi"] == roi]
            .set_index("session")
            .reindex(SESSIONS)
        )

        fig, ax = plt.subplots(
            figsize=(9, 5),
            layout="constrained",
        )

        x = np.arange(len(SESSIONS))
        bottom = np.zeros(len(SESSIONS))

        for reason, label in zip(
            reasons,
            labels,
        ):
            vals = (
                sub[reason]
                .fillna(0)
                .astype(float)
                .values
            )

            ax.bar(
                x,
                vals,
                bottom=bottom,
                label=label,
            )

            bottom += vals

        ax.set_xticks(x)
        ax.set_xticklabels(SESSIONS)
        ax.set_ylabel("Number of voxels")
        ax.set_title(
            f"QC removal reasons — {roi}"
        )
        ax.legend()
        ax.grid(
            axis="y",
            alpha=0.25,
        )

        save_png_svg(
            fig,
            out_dir
            / f"qc_removed_voxels_by_reason_{roi}",
        )


def plot_pair_distances(
    distance_df: pd.DataFrame,
    rois: list[str],
    out_dir: Path,
):
    pairs = list(
        dict.fromkeys(
            distance_df["pair"].tolist()
        )
    )

    for roi in rois:
        sub = distance_df[
            distance_df["roi"] == roi
        ]

        fig, ax = plt.subplots(
            figsize=(12, 5),
            layout="constrained",
        )

        x = np.arange(len(pairs))

        for session in SESSIONS:
            vals = (
                sub[sub["session"] == session]
                .set_index("pair")
                .reindex(pairs)
                ["distance"]
                .astype(float)
                .values
            )

            ax.plot(
                x,
                vals,
                marker="o",
                linewidth=1.8,
                label=session,
            )

        ax.axhline(
            0,
            linewidth=0.7,
        )
        ax.set_xticks(x)
        ax.set_xticklabels(
            pairs,
            rotation=35,
            ha="right",
        )
        ax.set_ylabel(
            "Crossnobis distance"
        )
        ax.set_title(
            f"Full-combo finger-pair distances — {roi}"
        )
        ax.legend()
        ax.grid(
            axis="y",
            alpha=0.25,
        )

        save_png_svg(
            fig,
            out_dir
            / f"finger_pair_distances_{roi}",
        )


def plot_pair_change(
    change_df: pd.DataFrame,
    rois: list[str],
    out_dir: Path,
):
    pairs = list(
        dict.fromkeys(
            change_df["pair"].tolist()
        )
    )

    for roi in rois:
        sub = (
            change_df[
                change_df["roi"] == roi
            ]
            .set_index("pair")
            .reindex(pairs)
        )

        fig, ax = plt.subplots(
            figsize=(12, 5),
            layout="constrained",
        )

        x = np.arange(len(pairs))

        vals = (
            sub["normalized_geometry_change"]
            .astype(float)
            .values
        )

        ax.bar(
            x,
            vals,
        )

        ax.axhline(
            0,
            linewidth=0.7,
        )
        ax.set_xticks(x)
        ax.set_xticklabels(
            pairs,
            rotation=35,
            ha="right",
        )
        ax.set_ylabel(
            "Change after within-session mean scaling\n"
            "(ses20 − ses19)"
        )
        ax.set_title(
            f"Finger-pair geometry change independent of global scale — {roi}"
        )
        ax.grid(
            axis="y",
            alpha=0.25,
        )

        save_png_svg(
            fig,
            out_dir
            / f"finger_pair_change_ses19_to_ses20_{roi}",
        )


def plot_split_reliability(
    split_df: pd.DataFrame,
    rois: list[str],
    out_dir: Path,
):
    d = split_df[
        split_df["metric"] == "pearson"
    ].copy()

    if d.empty:
        return

    splits = list(
        dict.fromkeys(
            d["split"].tolist()
        )
    )

    for roi in rois:
        sub = d[d["roi"] == roi]

        fig, ax = plt.subplots(
            figsize=(10, 5),
            layout="constrained",
        )

        x = np.arange(len(SESSIONS))
        width = (
            0.75 / max(len(splits), 1)
        )

        for i, split in enumerate(splits):
            vals = (
                sub[sub["split"] == split]
                .set_index("session")
                .reindex(SESSIONS)
                ["value"]
                .astype(float)
                .values
            )

            xpos = (
                x
                + (
                    i
                    - (len(splits) - 1) / 2
                )
                * width
            )

            ax.bar(
                xpos,
                vals,
                width=width,
                label=split.replace("_", " "),
            )

        ax.set_xticks(x)
        ax.set_xticklabels(SESSIONS)
        ax.set_ylim(-0.1, 1.05)
        ax.set_ylabel("Pearson reliability")
        ax.set_title(
            f"Independent split reliability — {roi}"
        )
        ax.legend()
        ax.grid(
            axis="y",
            alpha=0.25,
        )

        save_png_svg(
            fig,
            out_dir
            / f"independent_split_reliability_{roi}",
        )


def plot_run_pair_summary(
    contribution_df: pd.DataFrame,
    rois: list[str],
    out_dir: Path,
):
    if contribution_df.empty:
        return

    grouped = (
        contribution_df
        .groupby(
            [
                "roi",
                "session",
                "run_pair_label",
            ],
            dropna=False,
        )["value"]
        .mean()
        .reset_index()
    )

    for roi in rois:
        sub = grouped[
            grouped["roi"] == roi
        ]

        labels = list(
            dict.fromkeys(
                sub["run_pair_label"].astype(str)
            )
        )

        if not labels:
            continue

        fig, axes = plt.subplots(
            len(SESSIONS),
            1,
            figsize=(
                12,
                3.5 * len(SESSIONS),
            ),
            layout="constrained",
        )

        axes = np.atleast_1d(axes)

        for ax, session in zip(
            axes,
            SESSIONS,
        ):
            vals = (
                sub[sub["session"] == session]
                .set_index("run_pair_label")
                .reindex(labels)
                ["value"]
                .astype(float)
                .values
            )

            x = np.arange(len(labels))

            ax.bar(
                x,
                vals,
            )
            ax.axhline(
                0,
                linewidth=0.7,
            )
            ax.set_xticks(x)
            ax.set_xticklabels(
                labels,
                rotation=35,
                ha="right",
                fontsize=8,
            )
            ax.set_ylabel(
                "Mean run-pair contribution"
            )
            ax.set_title(
                session
            )
            ax.grid(
                axis="y",
                alpha=0.25,
            )

        fig.suptitle(
            f"Run-pair contribution summary — {roi}",
            fontsize=13,
            fontweight="bold",
        )

        save_png_svg(
            fig,
            out_dir
            / f"run_pair_contribution_means_{roi}",
        )


def write_text_summary(
    out_dir: Path,
    qc_df: pd.DataFrame,
    change_df: pd.DataFrame,
    split_df: pd.DataFrame,
    run_summary_df: pd.DataFrame,
    flags_df: pd.DataFrame,
):
    path = out_dir / "diagnostic_summary.txt"

    with path.open("w") as f:
        f.write(
            "M1 SUBREGION TARGETED DIAGNOSTIC\n"
        )
        f.write("=" * 78 + "\n\n")

        f.write("QC\n")
        f.write("-" * 78 + "\n")
        f.write(
            qc_df.to_string(
                index=False
            )
        )
        f.write("\n\n")

        f.write("SES19 -> SES20 GLOBAL SCALE AND FINGER-PAIR CHANGE\n")
        f.write("-" * 78 + "\n")

        for roi, g in change_df.groupby("roi"):
            scale = (
                g["global_scale_ratio_mean20_over_mean19"]
                .dropna()
            )

            f.write(f"\n{roi}\n")

            if len(scale):
                f.write(
                    "global_scale_ratio_mean20_over_mean19: "
                    f"{scale.iloc[0]:.6f}\n"
                )

            ordered = (
                g.assign(
                    abs_normalized_change=np.abs(
                        g["normalized_geometry_change"]
                    )
                )
                .sort_values(
                    "abs_normalized_change",
                    ascending=False,
                )
            )

            f.write(
                ordered[
                    [
                        "pair",
                        "ses19_distance",
                        "ses20_distance",
                        "ratio_ses20_over_ses19",
                        "normalized_geometry_change",
                    ]
                ]
                .to_string(
                    index=False
                )
            )
            f.write("\n")

        f.write("\n\nINDEPENDENT SPLIT PEARSON\n")
        f.write("-" * 78 + "\n")

        pearson = split_df[
            split_df["metric"] == "pearson"
        ]

        f.write(
            pearson[
                [
                    "roi",
                    "session",
                    "split",
                    "value",
                ]
            ].to_string(
                index=False
            )
        )

        f.write("\n\nRUN-PAIR CONTRIBUTION SCHEMA\n")
        f.write("-" * 78 + "\n")

        f.write(
            run_summary_df.to_string(
                index=False
            )
        )

        f.write("\n\nFLAGS\n")
        f.write("-" * 78 + "\n")

        if flags_df.empty:
            f.write("No threshold-based diagnostic flags.\n")
        else:
            f.write(
                flags_df.to_string(
                    index=False
                )
            )


def main():
    p = argparse.ArgumentParser()

    p.add_argument(
        "--subject",
        default=DEFAULT_SUBJECT,
    )

    p.add_argument(
        "--rois",
        nargs="+",
        default=list(DEFAULT_ROIS),
        help=(
            "Exact ROI names. Default: M1_4a M1_4p"
        ),
    )

    p.add_argument(
        "--first-level-root",
        type=Path,
        default=DEFAULT_FIRST_LEVEL_ROOT,
    )

    p.add_argument(
        "--out-dir",
        type=Path,
        default=DEFAULT_OUT_DIR,
    )

    args = p.parse_args()

    rois = list(args.rois)

    print("Subject:", args.subject)
    print("ROIs:", rois)

    (
        objects,
        qc_df,
        distance_df,
        split_df,
        contribution_df,
        run_summary_df,
    ) = collect(
        args.subject,
        rois,
        args.first_level_root,
    )

    change_df = finger_pair_change_table(
        distance_df
    )

    flags_df = diagnostic_flags(
        qc_df,
        split_df,
        change_df,
    )

    args.out_dir.mkdir(
        parents=True,
        exist_ok=True,
    )

    qc_df.to_csv(
        args.out_dir / "qc_breakdown.csv",
        index=False,
    )

    distance_df.to_csv(
        args.out_dir / "finger_pair_distances.csv",
        index=False,
    )

    change_df.to_csv(
        args.out_dir / "finger_pair_session_change.csv",
        index=False,
    )

    split_df.to_csv(
        args.out_dir / "independent_split_reliability.csv",
        index=False,
    )

    contribution_df.to_csv(
        args.out_dir / "run_pair_contributions_long.csv",
        index=False,
    )

    run_summary_df.to_csv(
        args.out_dir / "run_pair_summary.csv",
        index=False,
    )

    flags_df.to_csv(
        args.out_dir / "diagnostic_flags.csv",
        index=False,
    )

    plot_qc_retention(
        qc_df,
        rois,
        args.out_dir,
    )

    plot_qc_reasons(
        qc_df,
        rois,
        args.out_dir,
    )

    plot_pair_distances(
        distance_df,
        rois,
        args.out_dir,
    )

    plot_pair_change(
        change_df,
        rois,
        args.out_dir,
    )

    plot_split_reliability(
        split_df,
        rois,
        args.out_dir,
    )

    plot_run_pair_summary(
        contribution_df,
        rois,
        args.out_dir,
    )

    write_text_summary(
        args.out_dir,
        qc_df,
        change_df,
        split_df,
        run_summary_df,
        flags_df,
    )

    print()
    print("Diagnostic complete.")
    print("Output:", args.out_dir)
    print()
    print(
        "Most useful files:\n"
        "  diagnostic_summary.txt\n"
        "  qc_breakdown.csv\n"
        "  finger_pair_session_change.csv\n"
        "  run_pair_summary.csv\n"
        "  diagnostic_flags.csv"
    )


if __name__ == "__main__":
    main()
