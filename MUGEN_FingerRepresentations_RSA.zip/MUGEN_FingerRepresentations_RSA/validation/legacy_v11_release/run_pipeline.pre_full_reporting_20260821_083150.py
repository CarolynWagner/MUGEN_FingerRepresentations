
#!/usr/bin/env python3
"""
Top-level wrapper for RSApipeline_general_v11.

Key corrections incorporated
----------------------------
1. Uses the project-local venv deterministically.
2. Re-executes itself under that venv when needed.
3. Resolves all paths relative to the pipeline root.
4. Writes a filtered temporary manifest for the requested subject/ROI/session.
5. Launches first-level and second-level code as Python packages:

       python -m first_level.run_first_level
       python -m second_level.run_second_level

   rather than executing package files directly.

6. Runs child modules with cwd=PIPELINE_ROOT, so imports such as

       from first_level.manifest import read_manifest

   resolve correctly.

7. Performs package-layout and dependency preflight before analysis.
8. Keeps --dry-run available for checking row selection.
9. Uses the corrected ROI naming convention:
       M1
       M1_legacy
       M1_4a
       M1_4p
       S1
       S1_3a
       S1_3b
       S1_1
       S1_2

Normal use
----------
    python run_pipeline.py --first-level --subject sub-01 --roi M1_legacy

Dry run
-------
    python run_pipeline.py --first-level --subject sub-01 --roi M1_legacy --dry-run
"""

from __future__ import annotations

import argparse
import csv
import importlib
import importlib.metadata
import os
import subprocess
import sys
from pathlib import Path
from typing import Iterable


# =============================================================================
# PATHS / FROZEN ENVIRONMENT
# =============================================================================

PIPELINE_ROOT = Path(
    "/mnt/beegfs/workspace/2025-0422-Musicians7T/SPM_Prepro_FirstLevel/ROIs/RSApipeline_general_v11"
).resolve()

VENV_PYTHON = PIPELINE_ROOT / ".venv" / "bin" / "python"

DEFAULT_MANIFEST = PIPELINE_ROOT / "participants.csv"
DEFAULT_OUTPUT_ROOT = PIPELINE_ROOT / "results"

FIRST_LEVEL_OUT = DEFAULT_OUTPUT_ROOT / "first_level"
SECOND_LEVEL_OUT = DEFAULT_OUTPUT_ROOT / "second_level"

SELECTED_MANIFEST = DEFAULT_OUTPUT_ROOT / "_selected_manifest.csv"

BOOTSTRAP_FLAG = "RSA_V11_BOOTSTRAPPED"

VALID_ROIS = (
    "M1",
    "M1_legacy",
    "M1_4a",
    "M1_4p",
    "S1",
    "S1_3a",
    "S1_3b",
    "S1_1",
    "S1_2",
)


# =============================================================================
# UTILITIES
# =============================================================================

def die(message: str, code: int = 2) -> None:
    print(f"ERROR: {message}", file=sys.stderr)
    raise SystemExit(code)


def bootstrap_venv() -> None:
    """
    Re-execute this wrapper with the project-local venv Python.

    We do not load cluster-wide scientific Python modules here. The v11 venv is
    intended to be self-contained and currently contains the validated stack:
    numpy, scipy, pandas, matplotlib, nibabel and scikit-learn.
    """
    if os.environ.get(BOOTSTRAP_FLAG) == "1":
        return

    if not VENV_PYTHON.exists():
        die(
            "RSA v11 virtual environment not found:\n"
            f"  {VENV_PYTHON}\n"
            "Create the .venv before running the pipeline."
        )

    env = os.environ.copy()
    env[BOOTSTRAP_FLAG] = "1"

    cmd = [
        str(VENV_PYTHON),
        str(Path(__file__).resolve()),
        *sys.argv[1:],
    ]

    os.execve(
        str(VENV_PYTHON),
        cmd,
        env,
    )


def ensure_current_python() -> None:
    current = Path(sys.executable).resolve()
    expected = VENV_PYTHON.resolve()

    if current != expected:
        die(
            "RSA wrapper is not running under the expected venv Python.\n"
            f"Expected: {expected}\n"
            f"Current:  {current}"
        )


def ensure_package_layout() -> None:
    required = [
        PIPELINE_ROOT / "first_level",
        PIPELINE_ROOT / "second_level",
        PIPELINE_ROOT / "first_level" / "run_first_level.py",
        PIPELINE_ROOT / "second_level" / "run_second_level.py",
    ]

    missing = [p for p in required if not p.exists()]
    if missing:
        die(
            "RSA v11 installation is incomplete. Missing:\n"
            + "\n".join(f"  - {p}" for p in missing)
        )

    # Ensure package markers exist. Empty __init__.py files are sufficient.
    for package in ("first_level", "second_level"):
        init_file = PIPELINE_ROOT / package / "__init__.py"
        if not init_file.exists():
            init_file.touch()
            print(f"[PACKAGE] Created {init_file}")


def preflight_imports() -> None:
    dependencies = {
        "numpy": "numpy",
        "scipy": "scipy",
        "pandas": "pandas",
        "matplotlib": "matplotlib",
        "nibabel": "nibabel",
        "sklearn": "scikit-learn",
        "rsatoolbox": "rsatoolbox",
        "future": "future",
    }

    failures = []
    versions = []

    for import_name, dist_name in dependencies.items():
        try:
            importlib.import_module(import_name)
            try:
                version = importlib.metadata.version(dist_name)
            except importlib.metadata.PackageNotFoundError:
                version = "unknown"
            versions.append((import_name, version))
        except Exception as exc:
            failures.append((import_name, repr(exc)))

    if failures:
        die(
            "RSA Python environment preflight failed:\n"
            + "\n".join(
                f"  {name}: {error}"
                for name, error in failures
            )
        )

    print("[ENVIRONMENT] RSA v11 Python stack:")
    print(f"  Python: {sys.executable}")
    for name, version in versions:
        print(f"  {name}: {version}")


def read_manifest(path: Path) -> tuple[list[dict], list[str]]:
    if not path.exists():
        die(f"Manifest not found: {path}")

    with path.open(newline="") as f:
        reader = csv.DictReader(f)
        fieldnames = reader.fieldnames or []
        rows = list(reader)

    required = {'subject', 'session', 'roi_family', 'roi_name', 'roi_version', 'resolution_mm', 'model_dir', 'roi_path'}

    missing = sorted(required - set(fieldnames))
    if missing:
        die(
            "Manifest is missing required columns: "
            + ", ".join(missing)
        )

    return rows, fieldnames


def filter_rows(
    rows: Iterable[dict],
    *,
    subject: str | None,
    roi: str | None,
    session: str | None,
) -> list[dict]:

    selected = list(rows)

    if subject:
        selected = [
            r for r in selected
            if str(r.get("subject", "")).strip() == subject
        ]

    if roi:
        selected = [
            r for r in selected
            if str(r.get("roi_name", "")).strip() == roi
        ]

    if session:
        selected = [
            r for r in selected
            if str(r.get("session", "")).strip() == session
        ]

    return selected


def write_selected_manifest(
    rows: list[dict],
    fieldnames: list[str],
    path: Path,
) -> None:
    path.parent.mkdir(
        parents=True,
        exist_ok=True,
    )

    with path.open(
        "w",
        newline="",
    ) as f:
        writer = csv.DictWriter(
            f,
            fieldnames=fieldnames,
        )
        writer.writeheader()
        writer.writerows(rows)


def print_selection(
    all_rows: list[dict],
    selected: list[dict],
    manifest: Path,
    output_root: Path,
) -> None:

    first_level_out = output_root / "first_level"
    second_level_out = output_root / "second_level"

    print()
    print("=" * 80)
    print("RSA v11 TOP-LEVEL WRAPPER")
    print("=" * 80)
    print(f"Pipeline root: {PIPELINE_ROOT}")
    print(f"Python: {sys.executable}")
    print(f"Manifest: {manifest}")
    print(f"Output root: {output_root}")
    print(f"First-level out: {first_level_out}")
    print(f"Second-level out: {second_level_out}")
    print(f"Selected rows: {len(selected)} / {len(all_rows)}")

    subjects = sorted(
        {r["subject"] for r in selected}
    )
    rois = sorted(
        {r["roi_name"] for r in selected}
    )

    print(f"Subjects: {subjects}")
    print(f"ROIs: {rois}")
    print()

    columns = [
        "subject",
        "session",
        "roi_family",
        "roi_name",
        "roi_version",
        "resolution_mm",
    ]

    widths = {
        col: max(
            len(col),
            *[
                len(str(r.get(col, "")))
                for r in selected
            ],
        )
        for col in columns
    }

    print(
        " ".join(
            col.ljust(widths[col])
            for col in columns
        )
    )

    for row in selected:
        print(
            " ".join(
                str(row.get(col, "")).ljust(widths[col])
                for col in columns
            )
        )

    print()


def run_command(
    cmd: list[str],
) -> None:
    print()
    print("[RUN]")
    print(" ".join(cmd))
    print()

    subprocess.run(
        cmd,
        check=True,
        cwd=PIPELINE_ROOT,
    )


# =============================================================================
# PIPELINE STAGES
# =============================================================================

def run_first_level(
    selected_manifest: Path,
    out_root: Path,
    n_boot: int,
) -> None:

    out_root.mkdir(
        parents=True,
        exist_ok=True,
    )

    cmd = [
        str(VENV_PYTHON),
        "-m",
        "first_level.run_first_level",
        "--manifest",
        str(selected_manifest),
        "--out-root",
        str(out_root),
        "--n-boot",
        str(n_boot),
    ]

    run_command(cmd)


def run_second_level(
    selected_rows: list[dict],
    first_level_root: Path,
    out_root: Path,
) -> None:
    """
    Match second_level.run_second_level's actual CLI:

        python -m second_level.run_second_level \
            INPUT1.pkl INPUT2.pkl ... \
            --out-dir OUTDIR

    The second-level script does not accept --manifest, --first-level-root,
    or --n-boot.
    """

    if not selected_rows:
        die("No selected rows available for second-level analysis.")

    roi_names = {r["roi_name"] for r in selected_rows}
    subjects = {r["subject"] for r in selected_rows}

    if len(roi_names) != 1:
        die(
            "Second-level analysis requires exactly one ROI. "
            f"Selected ROIs: {sorted(roi_names)}"
        )

    roi_name = next(iter(roi_names))

    input_files = []

    for row in selected_rows:
        pkl = (
            first_level_root
            / row["subject"]
            / row["session"]
            / f"roi-{row['roi_name']}"
            / "rsa_firstlevel.pkl"
        )

        if not pkl.exists():
            die(
                "Missing first-level input required for second level:\n"
                f"  {pkl}"
            )

        input_files.append(pkl)

    # Use a scoped directory so different ROI/subject comparisons do not
    # overwrite each other.
    if len(subjects) == 1:
        subject_label = next(iter(subjects))
    else:
        subject_label = "multi_subject"

    scoped_out = (
        out_root
        / subject_label
        / f"roi-{roi_name}"
    )
    scoped_out.mkdir(parents=True, exist_ok=True)

    cmd = [
        str(VENV_PYTHON),
        "-m",
        "second_level.run_second_level",
        *[str(p) for p in input_files],
        "--out-dir",
        str(scoped_out),
    ]

    run_command(cmd)

    # Restore validated legacy diagnostics from already-certified first-level RDMs.
    secondlevel_pkl = scoped_out / "rsa_secondlevel.pkl"
    if not secondlevel_pkl.exists():
        die(
            "Second-level analysis completed but rsa_secondlevel.pkl is missing:\n"
            f"  {secondlevel_pkl}"
        )

    run_command([
        str(VENV_PYTHON),
        "-m",
        "second_level.augment_legacy_diagnostics",
        str(secondlevel_pkl),
        "--backup",
    ])

    # Generate the restored v10.3 publication/diagnostic figure suite
    # automatically for every second-level ROI analysis.
    run_command([
        str(VENV_PYTHON),
        "-m",
        "second_level.generate_legacy_figures",
        str(secondlevel_pkl),
    ])

    figure_dir = scoped_out / "figures"

    print()
    print(f"[FIGURES] complete: {figure_dir}")


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        description=(
            "Top-level wrapper for generalized RSA v11."
        )
    )

    stage = p.add_mutually_exclusive_group(
        required=True,
    )

    stage.add_argument(
        "--first-level",
        action="store_true",
        help="Run first-level RSA for selected manifest rows.",
    )

    stage.add_argument(
        "--second-level",
        action="store_true",
        help="Run second-level RSA for selected manifest rows.",
    )

    p.add_argument(
        "--manifest",
        default=str(DEFAULT_MANIFEST),
        help=(
            "Participant manifest. Default: "
            f"{DEFAULT_MANIFEST}"
        ),
    )

    p.add_argument(
        "--output-root",
        default=str(DEFAULT_OUTPUT_ROOT),
        help=(
            "RSA result root. Default: "
            f"{DEFAULT_OUTPUT_ROOT}"
        ),
    )

    p.add_argument(
        "--subject",
        help="Filter by exact subject ID, e.g. sub-01.",
    )

    p.add_argument(
        "--roi",
        choices=VALID_ROIS,
        help="Filter by exact roi_name.",
    )

    p.add_argument(
        "--session",
        help="Optional exact session filter, e.g. ses19.",
    )

    p.add_argument(
        "--n-boot",
        type=int,
        default=2000,
        help="Number of bootstrap samples. Default: 2000.",
    )

    p.add_argument(
        "--dry-run",
        action="store_true",
        help="Show selected rows without running an analysis.",
    )

    return p


def main() -> None:
    bootstrap_venv()
    ensure_current_python()
    ensure_package_layout()
    preflight_imports()

    args = build_parser().parse_args()

    manifest = Path(args.manifest).resolve()
    output_root = Path(args.output_root).resolve()

    rows, fieldnames = read_manifest(
        manifest
    )

    selected = filter_rows(
        rows,
        subject=args.subject,
        roi=args.roi,
        session=args.session,
    )

    if not selected:
        die(
            "No manifest rows match the requested filters."
        )

    # Guard against accidental cross-ROI second-level analyses.
    if args.second_level:
        roi_names = {
            r["roi_name"]
            for r in selected
        }
        if len(roi_names) != 1:
            die(
                "Second-level analysis requires exactly one ROI at a time. "
                f"Selected ROIs: {sorted(roi_names)}"
            )

    selected_manifest = (
        output_root
        / "_selected_manifest.csv"
    )

    write_selected_manifest(
        selected,
        fieldnames,
        selected_manifest,
    )

    print_selection(
        rows,
        selected,
        manifest,
        output_root,
    )

    if args.dry_run:
        print(
            "[DRY RUN] No analyses executed."
        )
        return

    first_level_out = (
        output_root
        / "first_level"
    )

    second_level_out = (
        output_root
        / "second_level"
    )

    if args.first_level:
        run_first_level(
            selected_manifest,
            first_level_out,
            args.n_boot,
        )

    elif args.second_level:
        run_second_level(
            selected,
            first_level_out,
            second_level_out,
        )

    print()
    print("[RSA v11] Requested stage completed.")


if __name__ == "__main__":
    main()


