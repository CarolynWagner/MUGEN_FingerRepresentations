# v11.0 generalized — release notes

- Split frozen monolithic pipeline into first-level and second-level analysis layers.
- Atomic first-level unit: subject × session × ROI.
- ROI dimension generalized to M1_old, M1_new, S1 and S1 subfields, with custom ROI support.
- Preserved frozen v10.3 numerical modules unchanged.
- Added portable manifest-driven execution and SLURM-array support.
- Added second-level within-subject, between-subject and ROI-comparison engine.
- Added standard group RSA noise-ceiling estimator across independent participants.
- Added v10.3 → v11 M1_old numerical regression certification script.
- v10.3 remains the frozen reference implementation; v11 is an architectural generalization.
