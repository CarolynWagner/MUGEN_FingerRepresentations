#!/usr/bin/env bash
set -euo pipefail

ROOT="/mnt/beegfs/workspace/2025-0422-Musicians7T/SPM_Prepro_FirstLevel/ROIs/RSApipeline_general_v11"
VENV="$ROOT/.venv"

if [[ ! -x "$VENV/bin/python" ]]; then
    echo "ERROR: RSA v11 venv not found: $VENV" >&2
    exit 2
fi

"$VENV/bin/python" -m pip freeze > "$ROOT/requirements.txt"

"$VENV/bin/python" - <<'PY' > "$ROOT/environment_report.txt"
import importlib.metadata
import sys

packages = [
    ("numpy", "numpy"),
    ("scipy", "scipy"),
    ("pandas", "pandas"),
    ("matplotlib", "matplotlib"),
    ("nibabel", "nibabel"),
    ("sklearn", "scikit-learn"),
    ("rsatoolbox", "rsatoolbox"),
    ("future", "future"),
]

print("Python executable:", sys.executable)
print("Python version:", sys.version.replace("\n", " "))

for import_name, dist_name in packages:
    try:
        version = importlib.metadata.version(dist_name)
    except importlib.metadata.PackageNotFoundError:
        version = "NOT INSTALLED"
    print(import_name + ": " + version)
PY

echo "Wrote:"
echo "  $ROOT/requirements.txt"
echo "  $ROOT/environment_report.txt"
