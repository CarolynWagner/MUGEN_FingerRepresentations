#!/usr/bin/env bash
set -euo pipefail

# =============================================================================
# Matched-resolution U-V local RSA: ses19 + ses20
# CORRECTED: does not require any Huber top-level runner.
# =============================================================================

SUBJECT="${SUBJECT:-sub-01}"
PROJECT_ROOT="${PROJECT_ROOT:-/mnt/beegfs/workspace/2025-0422-Musicians7T}"

HUBER_ROOT="${HUBER_ROOT:-${PROJECT_ROOT}/SPM_Prepro_FirstLevel/ROIs/HuberPipeline_v1_0}"
RSA_ROOT="${RSA_ROOT:-${PROJECT_ROOT}/SPM_Prepro_FirstLevel/ROIs/RSApipeline_general_v11}"

CONFIG="${CONFIG:-${HUBER_ROOT}/00_config.yaml}"

HUBER_PYTHON="${HUBER_PYTHON:-/home/carolyn.wagner/envs/layerfmri/bin/python}"
RSA_PYTHON="${RSA_PYTHON:-${RSA_ROOT}/.venv/bin/python}"

LOCAL_GENERATOR="${LOCAL_GENERATOR:-${RSA_ROOT}/generate_local_rdms_uv.py}"
LOCAL_VALIDATOR="${LOCAL_VALIDATOR:-${RSA_ROOT}/validate_local_uv_rsa.py}"

NEIGHBORHOOD_RADIUS_MM="${NEIGHBORHOOD_RADIUS_MM:-3.0}"
CENTER_SPACING_MM="${CENTER_SPACING_MM:-1.5}"
MIN_VALID_VOXELS="${MIN_VALID_VOXELS:-20}"

SESSIONS=("ses19" "ses20")

die () {
    echo "ERROR: $*" >&2
    exit 1
}

require_file () {
    [[ -f "$1" ]] || die "Missing required file: $1"
}

require_exec () {
    [[ -x "$1" ]] || die "Missing/non-executable program: $1"
}

echo "================================================================================"
echo "MATCHED-RESOLUTION U-V LOCAL RSA"
echo "================================================================================"
echo "Subject:                  ${SUBJECT}"
echo "HuberPipeline root:       ${HUBER_ROOT}"
echo "RSA v11 root:             ${RSA_ROOT}"
echo "Huber config:             ${CONFIG}"
echo "Huber Python:             ${HUBER_PYTHON}"
echo "RSA Python:               ${RSA_PYTHON}"
echo "Neighborhood radius:      ${NEIGHBORHOOD_RADIUS_MM} mm"
echo "Center spacing:           ${CENTER_SPACING_MM} mm"
echo "Minimum valid voxels:     ${MIN_VALID_VOXELS}"
echo "Sessions:                 ${SESSIONS[*]}"
echo

require_file "${CONFIG}"
require_exec "${HUBER_PYTHON}"
require_exec "${RSA_PYTHON}"
require_file "${LOCAL_GENERATOR}"
require_file "${LOCAL_VALIDATOR}"

# We invoke the frozen Huber steps directly. No top-level Huber runner is needed.
for f in \
    01_build_rim_from_freesurfer.py \
    02_generate_laynii_depths.sh \
    06_generate_intrinsic_uv_control_points.py \
    07_prepare_multilaterate_control_image.py \
    08_run_multilaterate.sh
do
    require_file "${HUBER_ROOT}/${f}"
done


# =============================================================================
# PHASE 1: anatomy-only U/V construction
# =============================================================================

echo "================================================================================"
echo "PHASE 1 — FROZEN HUBER U/V CONSTRUCTION"
echo "================================================================================"

cd "${HUBER_ROOT}"

for session in "${SESSIONS[@]}"; do

    huber_session="ses-${session#ses}"
    session_compact="${huber_session//-/}"

    uv_file="${HUBER_ROOT}/outputs/${SUBJECT}/${huber_session}/true_uv/${session_compact}_multilaterate_radius30_corrected_UV_coordinates.nii"

    echo
    echo "--------------------------------------------------------------------------------"
    echo "U/V construction: ${huber_session}"
    echo "--------------------------------------------------------------------------------"

    if [[ -f "${uv_file}" ]]; then
        echo "[UV] Existing coordinate file found:"
        echo "     ${uv_file}"
        echo "[UV] Skipping U/V construction for ${huber_session}."
        continue
    fi

    echo "[UV] No existing U/V file."
    echo "[UV] Running frozen anatomy-only Steps 01, 02, 06, 07, 08."
    echo "[UV] Functional Steps 03-05 are deliberately not used for coordinate construction."
    echo

    env -u PYTHONPATH -u PYTHONHOME \
        "${HUBER_PYTHON}" \
        01_build_rim_from_freesurfer.py \
        "${CONFIG}" "${huber_session}"

    bash 02_generate_laynii_depths.sh \
        "${huber_session}"

    env -u PYTHONPATH -u PYTHONHOME \
        "${HUBER_PYTHON}" \
        06_generate_intrinsic_uv_control_points.py \
        "${CONFIG}" "${huber_session}"

    env -u PYTHONPATH -u PYTHONHOME \
        "${HUBER_PYTHON}" \
        07_prepare_multilaterate_control_image.py \
        "${CONFIG}" "${huber_session}"

    bash 08_run_multilaterate.sh \
        "${CONFIG}" "${huber_session}"

    require_file "${uv_file}"

    echo "[UV] Complete: ${uv_file}"
done


# =============================================================================
# PHASE 2: local Crossnobis RDM generation
# =============================================================================

echo
echo "================================================================================"
echo "PHASE 2 — LOCAL CROSSNOBIS RDM GENERATION"
echo "================================================================================"

cd "${RSA_ROOT}"

for session in "${SESSIONS[@]}"; do

    huber_session="ses-${session#ses}"
    session_compact="${huber_session//-/}"

    uv_file="${HUBER_ROOT}/outputs/${SUBJECT}/${huber_session}/true_uv/${session_compact}_multilaterate_radius30_corrected_UV_coordinates.nii"

    firstlevel_pkl="${RSA_ROOT}/results/first_level/${SUBJECT}/${session}/roi-M1/rsa_firstlevel.pkl"

    domain_mask="${RSA_ROOT}/roi_derivatives/${SUBJECT}/${session}/rois/${SUBJECT}_${session}_roi-M1_space-beta.nii.gz"

    out_dir="${RSA_ROOT}/results/roi_comparisons/uv_local_rdms/${session}"

    require_file "${uv_file}"
    require_file "${firstlevel_pkl}"
    require_file "${domain_mask}"

    echo
    echo "--------------------------------------------------------------------------------"
    echo "Local RDMs: ${session}"
    echo "--------------------------------------------------------------------------------"

    "${RSA_PYTHON}" "${LOCAL_GENERATOR}" \
        --session "${session}" \
        --reference-firstlevel-pkl "${firstlevel_pkl}" \
        --uv-coordinates "${uv_file}" \
        --domain-mask "${domain_mask}" \
        --neighborhood-radius-mm "${NEIGHBORHOOD_RADIUS_MM}" \
        --center-spacing-mm "${CENTER_SPACING_MM}" \
        --min-valid-voxels "${MIN_VALID_VOXELS}" \
        --out-dir "${out_dir}"
done


# =============================================================================
# PHASE 3: validation
# =============================================================================

echo
echo "================================================================================"
echo "PHASE 3 — LOCAL U/V RSA VALIDATION"
echo "================================================================================"

for session in "${SESSIONS[@]}"; do

    huber_session="ses-${session#ses}"
    session_compact="${huber_session//-/}"

    uv_file="${HUBER_ROOT}/outputs/${SUBJECT}/${huber_session}/true_uv/${session_compact}_multilaterate_radius30_corrected_UV_coordinates.nii"

    firstlevel_pkl="${RSA_ROOT}/results/first_level/${SUBJECT}/${session}/roi-M1/rsa_firstlevel.pkl"

    domain_mask="${RSA_ROOT}/roi_derivatives/${SUBJECT}/${session}/rois/${SUBJECT}_${session}_roi-M1_space-beta.nii.gz"

    local_dir="${RSA_ROOT}/results/roi_comparisons/uv_local_rdms/${session}"

    echo
    echo "--------------------------------------------------------------------------------"
    echo "Validation: ${session}"
    echo "--------------------------------------------------------------------------------"

    "${RSA_PYTHON}" "${LOCAL_VALIDATOR}" \
        --generator "${LOCAL_GENERATOR}" \
        --session "${session}" \
        --reference-firstlevel-pkl "${firstlevel_pkl}" \
        --uv-coordinates "${uv_file}" \
        --domain-mask "${domain_mask}" \
        --local-qc "${local_dir}/local_centers_qc.csv" \
        --local-rdms "${local_dir}/local_rdms_uv.csv" \
        --out-dir "${local_dir}/validation"
done


# =============================================================================
# PHASE 4: hard validation check + merge
# =============================================================================

echo
echo "================================================================================"
echo "PHASE 4 — CHECK BOTH GATES AND COMBINE TABLES"
echo "================================================================================"

combined_dir="${RSA_ROOT}/results/roi_comparisons/uv_local_rdms/matched_resolution"
mkdir -p "${combined_dir}"

"${RSA_PYTHON}" - <<'PY'
from pathlib import Path
import json
import pandas as pd

root = Path("results/roi_comparisons/uv_local_rdms")
sessions = ("ses19", "ses20")

for session in sessions:
    report = root / session / "validation" / "validation_report.json"
    if not report.is_file():
        raise SystemExit(f"Missing validation report: {report}")

    obj = json.loads(report.read_text())
    verdict = obj.get("verdict")
    ge = obj.get("global_equivalence", {}).get("status")

    print(f"{session}: validation={verdict}, global_equivalence={ge}")

    if verdict != "PASS":
        raise SystemExit(
            f"STOP: {session} local-RDM validation did not PASS."
        )

paths = [
    root / "ses19" / "local_rdms_uv.csv",
    root / "ses20" / "local_rdms_uv.csv",
]

frames = [pd.read_csv(p) for p in paths]
combined = pd.concat(frames, ignore_index=True)

out = (
    root
    / "matched_resolution"
    / "local_rdms_uv_ses19_ses20.csv"
)

combined.to_csv(out, index=False)

print()
print("Combined rows:", len(combined))
print("Sessions:", sorted(combined["session"].astype(str).unique()))
print("Centers per session:")
print(
    combined.groupby("session")["center_id"]
    .nunique()
    .to_string()
)
print("Output:", out)
PY


echo
echo "================================================================================"
echo "MATCHED-RESOLUTION LOCAL RSA STAGE COMPLETE"
echo "================================================================================"
echo
echo "Next command:"
echo
echo "  ${RSA_PYTHON} uv_local_geometry.py \\"
echo "    ${combined_dir}/local_rdms_uv_ses19_ses20.csv \\"
echo "    --sessions ses19 ses20 \\"
echo "    --match-radius-mm 2.0 \\"
echo "    --grid-step-mm 1.5"
echo
