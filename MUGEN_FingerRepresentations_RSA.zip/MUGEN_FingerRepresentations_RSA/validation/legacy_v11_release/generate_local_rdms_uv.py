
#!/usr/bin/env python3
"""
generate_local_rdms_uv.py

Generate the missing local_rdms_uv.csv for continuous U-V RSA.

IMPORTANT
---------
This is a NEW local extension of the validated ROI RSA, not a replacement for
the validated first-level pipeline.

It preserves the validated numerical method:
- six independent runs x five finger conditions;
- SPM effective residual DOF taken from an already-validated rsa_firstlevel.pkl;
- finite beta/residual QC + residual SD > 1e-8;
- rsatoolbox shrinkage_diag precision from GLM residuals;
- crossvalidated Mahalanobis (Crossnobis);
- condition descriptor = finger;
- CV descriptor = run_number;
- raw negative Crossnobis values retained.

The spatial change is the only substantive extension: instead of one whole ROI,
the same Crossnobis estimate is repeated in local neighborhoods defined in the
LN2 intrinsic U-V coordinate sheet.

CURRENT DATA LIMITATION
-----------------------
The currently validated LN2 U-V coordinates in the existing HuberPipeline are
for ses18 and the M1 hand patch. This script can run that dataset now.

For ses19/ses20 test-retest, or for a continuous M1->S1 sheet, you must first
provide U-V coordinate NIfTIs covering the desired anatomical domain in each
corresponding beta space. The script deliberately refuses to invent or
transform those coordinates.

Required inputs
---------------
--reference-firstlevel-pkl
    Existing validated v11 rsa_firstlevel.pkl for the same subject/session.
    Used to obtain:
      * model_dir
      * SPM effective residual DOF
      * finger names
      * reference beta-space geometry via source paths

--uv-coordinates
    4-D NIfTI (..., 2) where volume 0 is U (mm) and volume 1 is V (mm),
    aligned exactly to the beta grid.

Optional:
--domain-mask
    Binary anatomical/domain mask on the same grid. Strongly recommended.
    If omitted, finite U/V voxels define the domain.

Output
------
local_rdms_uv.csv
local_centers_qc.csv
local_rdm_generation_summary.txt

The CSV is directly consumable by uv_local_geometry.py.

Example: existing ses18 M1 patch
--------------------------------
python generate_local_rdms_uv.py \
  --session ses18 \
  --reference-firstlevel-pkl results/first_level/sub-01/ses18/roi-M1/rsa_firstlevel.pkl \
  --uv-coordinates /mnt/beegfs/workspace/2025-0422-Musicians7T/SPM_Prepro_FirstLevel/ROIs/HuberPipeline_v1_0/outputs/sub-01/ses-18/true_uv/ses18_multilaterate_radius30_corrected_UV_coordinates.nii \
  --domain-mask /mnt/beegfs/workspace/2025-0422-Musicians7T/SPM_Prepro_FirstLevel/ROIs/RSApipeline_general_v11/roi_derivatives/sub-01/ses18/rois/sub-01_ses18_roi-M1_space-beta.nii.gz \
  --neighborhood-radius-mm 3.0 \
  --center-spacing-mm 1.5 \
  --min-valid-voxels 20 \
  --out-dir results/roi_comparisons/uv_local_rdms/ses18
"""

from __future__ import annotations

import argparse
import json
import math
import pickle
import re
from pathlib import Path

import nibabel as nib
import numpy as np
import pandas as pd
import rsatoolbox as rsa


AFFINE_ATOL = 1e-4
N_RUNS = 6
N_FINGERS = 5
N_COLS_PER_RUN = 11
RESIDUAL_STD_EPS = 1e-8


# -------------------------------------------------------------------------
# I/O and validation
# -------------------------------------------------------------------------

def load_pickle(path: Path) -> dict:
    if not path.is_file():
        raise FileNotFoundError(path)
    with path.open("rb") as f:
        obj = pickle.load(f)
    if not isinstance(obj, dict):
        raise TypeError(f"Expected dict in {path}")
    return obj


def load_nifti(path: Path):
    if not path.is_file():
        raise FileNotFoundError(path)
    img = nib.load(str(path))
    return img, img.get_fdata(dtype=np.float32)


def same_grid(ref, moving, ref_name, moving_name):
    if ref.shape[:3] != moving.shape[:3]:
        raise RuntimeError(
            f"Grid shape mismatch:\n"
            f"  {ref_name}: {ref.shape[:3]}\n"
            f"  {moving_name}: {moving.shape[:3]}"
        )
    if not np.allclose(
        ref.affine,
        moving.affine,
        atol=AFFINE_ATOL,
        rtol=0.0,
    ):
        raise RuntimeError(
            f"Affine mismatch between {ref_name} and {moving_name}"
        )


def resolve_model_dir(reference: dict) -> Path:
    src = reference.get("source_paths", {})
    model_dir = src.get("model_dir")
    if not model_dir:
        raise KeyError(
            "reference pickle has no source_paths.model_dir"
        )
    path = Path(model_dir)
    if not path.is_dir():
        raise FileNotFoundError(path)
    return path


def resolve_dof(reference: dict) -> float:
    p = reference.get("precision_info", {})
    dof = p.get("dof")
    if dof is None:
        raise KeyError(
            "reference pickle has no precision_info.dof"
        )
    dof = float(dof)
    if not np.isfinite(dof) or dof <= 0:
        raise ValueError(f"Invalid residual DOF: {dof}")
    return dof


def resolve_fingers(reference: dict):
    fingers = list(reference.get("finger_names", []))
    if len(fingers) != N_FINGERS:
        raise ValueError(
            f"Expected 5 finger names, got {fingers}"
        )
    return fingers


def beta_numbers():
    """
    Locked beta-index contract:
      run1:  1..5
      run2: 12..16
      run3: 23..27
      run4: 34..38
      run5: 45..49
      run6: 56..60
    """
    return [
        [run * N_COLS_PER_RUN + finger + 1 for finger in range(N_FINGERS)]
        for run in range(N_RUNS)
    ]


def beta_path(model_dir: Path, number: int) -> Path:
    candidates = [
        model_dir / f"beta_{number:04d}.nii",
        model_dir / f"beta_{number:04d}.nii.gz",
    ]
    for p in candidates:
        if p.is_file():
            return p
    raise FileNotFoundError(
        "Missing beta image; checked:\n  "
        + "\n  ".join(map(str, candidates))
    )


def residual_files(model_dir: Path):
    files = list(model_dir.glob("Res_*.nii")) + list(model_dir.glob("Res_*.nii.gz"))

    def key(p):
        m = re.search(r"Res_(\d+)", p.name)
        return int(m.group(1)) if m else p.name

    files = sorted(set(files), key=key)

    if not files:
        raise FileNotFoundError(f"No Res_* files in {model_dir}")

    return files


# -------------------------------------------------------------------------
# Load all voxelwise first-level data once
# -------------------------------------------------------------------------

def load_full_data(model_dir, uv_path, domain_mask_path):
    # First beta is the spatial reference.
    first_beta = beta_path(model_dir, beta_numbers()[0][0])
    ref_img = nib.load(str(first_beta))

    uv_img, uv = load_nifti(uv_path)
    same_grid(ref_img, uv_img, "beta grid", "U-V coordinates")

    if uv.ndim != 4 or uv.shape[3] < 2:
        raise RuntimeError(
            f"Expected U-V NIfTI shape (X,Y,Z,2), found {uv.shape}"
        )

    U = uv[..., 0].astype(np.float64)
    V = uv[..., 1].astype(np.float64)

    domain = np.isfinite(U) & np.isfinite(V)

    if domain_mask_path is not None:
        mask_img, mask_data = load_nifti(domain_mask_path)
        same_grid(ref_img, mask_img, "beta grid", "domain mask")
        domain &= mask_data > 0

    ijk = np.column_stack(np.nonzero(domain)).astype(np.int32)
    if len(ijk) == 0:
        raise RuntimeError("U-V analysis domain is empty.")

    linear = np.ravel_multi_index(ijk.T, ref_img.shape[:3])
    u = U.ravel()[linear]
    v = V.ravel()[linear]

    # Load 30 finger betas only within the U-V domain.
    betas = np.empty((N_RUNS, N_FINGERS, len(linear)), dtype=np.float64)

    for run, nums in enumerate(beta_numbers()):
        for finger, num in enumerate(nums):
            p = beta_path(model_dir, num)
            img = nib.load(str(p))
            same_grid(ref_img, img, "beta grid", p.name)
            betas[run, finger] = img.get_fdata(dtype=np.float32).ravel()[linear]

    res_paths = residual_files(model_dir)
    residuals = np.empty((len(res_paths), len(linear)), dtype=np.float64)

    for t, p in enumerate(res_paths):
        img = nib.load(str(p))
        same_grid(ref_img, img, "beta grid", p.name)
        residuals[t] = img.get_fdata(dtype=np.float32).ravel()[linear]

    world = nib.affines.apply_affine(ref_img.affine, ijk)

    return {
        "ref_img": ref_img,
        "ijk": ijk,
        "world": world,
        "u": u,
        "v": v,
        "betas": betas,
        "residuals": residuals,
        "residual_files": res_paths,
    }


# -------------------------------------------------------------------------
# U-V center selection
# -------------------------------------------------------------------------

def select_centers(u, v, spacing_mm):
    """
    Deterministic regular U-V lattice.

    Each occupied lattice cell contributes the domain voxel nearest its cell
    center. This avoids treating every highly overlapping voxel as a center.
    """
    umin, umax = float(np.min(u)), float(np.max(u))
    vmin, vmax = float(np.min(v)), float(np.max(v))

    u_centers = np.arange(
        math.floor(umin / spacing_mm) * spacing_mm,
        math.ceil(umax / spacing_mm) * spacing_mm + 0.5 * spacing_mm,
        spacing_mm,
    )
    v_centers = np.arange(
        math.floor(vmin / spacing_mm) * spacing_mm,
        math.ceil(vmax / spacing_mm) * spacing_mm + 0.5 * spacing_mm,
        spacing_mm,
    )

    selected = []
    used_voxels = set()

    for vc in v_centers:
        for uc in u_centers:
            d2 = (u - uc) ** 2 + (v - vc) ** 2
            idx = int(np.argmin(d2))

            # Only accept a center if a real voxel lies reasonably close to
            # this lattice point.
            if math.sqrt(float(d2[idx])) > spacing_mm / math.sqrt(2):
                continue

            if idx in used_voxels:
                continue

            used_voxels.add(idx)

            selected.append({
                "voxel_index": idx,
                "u_mm": float(u[idx]),
                "v_mm": float(v[idx]),
            })

    return selected


# -------------------------------------------------------------------------
# Validated-method local Crossnobis
# -------------------------------------------------------------------------

def local_valid_mask(betas, residuals):
    finite_beta = np.isfinite(betas).all(axis=(0, 1))
    finite_res = np.isfinite(residuals).all(axis=0)

    # finite-first standard deviation, matching the v11 QC principle.
    residual_std = np.full(residuals.shape[1], np.nan, dtype=float)
    finite_cols = finite_res
    if np.any(finite_cols):
        residual_std[finite_cols] = residuals[:, finite_cols].std(axis=0)

    variance_ok = residual_std > RESIDUAL_STD_EPS

    return finite_beta & finite_res & variance_ok


def make_dataset(betas_clean, fingers):
    measurements = betas_clean.reshape(
        N_RUNS * N_FINGERS,
        betas_clean.shape[2],
    )
    conditions = np.tile(np.asarray(fingers, dtype=object), N_RUNS)
    run_numbers = np.repeat(np.arange(1, N_RUNS + 1), N_FINGERS)

    return rsa.data.Dataset(
        measurements=measurements,
        descriptors={"analysis": "local_uv_crossnobis"},
        obs_descriptors={
            "condition": conditions,
            "run_number": run_numbers,
        },
        channel_descriptors={
            "voxel": np.arange(betas_clean.shape[2]),
        },
    )


def crossnobis_rdm(betas_clean, residuals_clean, fingers, dof):
    precision = rsa.data.noise.prec_from_residuals(
        residuals=residuals_clean,
        dof=float(dof),
        method="shrinkage_diag",
    )

    precision = np.asarray(precision, dtype=float)

    if not np.all(np.isfinite(precision)):
        raise RuntimeError("Non-finite local precision matrix.")

    ds = make_dataset(betas_clean, fingers)

    rdm_obj = rsa.rdm.calc_rdm(
        ds,
        method="crossnobis",
        descriptor="condition",
        noise=precision,
        cv_descriptor="run_number",
    )

    matrix = np.asarray(rdm_obj.get_matrices()[0], dtype=float)
    matrix = 0.5 * (matrix + matrix.T)
    np.fill_diagonal(matrix, 0.0)

    return matrix


def upper_rows(matrix, fingers):
    rows = []
    for i in range(len(fingers)):
        for j in range(i + 1, len(fingers)):
            rows.append(
                (
                    f"{fingers[i]}-{fingers[j]}",
                    float(matrix[i, j]),
                )
            )
    return rows


# -------------------------------------------------------------------------
# Main session analysis
# -------------------------------------------------------------------------

def run(args):
    ref = load_pickle(args.reference_firstlevel_pkl)
    model_dir = resolve_model_dir(ref)
    dof = resolve_dof(ref)
    fingers = resolve_fingers(ref)

    ref_session = str(ref.get("session_id", ""))
    if ref_session and ref_session != args.session:
        raise ValueError(
            f"--session={args.session} but reference pickle says {ref_session}"
        )

    data = load_full_data(
        model_dir,
        args.uv_coordinates,
        args.domain_mask,
    )

    centers = select_centers(
        data["u"],
        data["v"],
        args.center_spacing_mm,
    )

    print(f"Session: {args.session}")
    print(f"Model dir: {model_dir}")
    print(f"Effective residual DOF: {dof}")
    print(f"U-V domain voxels: {len(data['u'])}")
    print(f"Candidate centers: {len(centers)}")
    print(f"Neighborhood radius: {args.neighborhood_radius_mm:.3f} mm")
    print(f"Minimum valid voxels: {args.min_valid_voxels}")

    rdm_rows = []
    qc_rows = []

    for number, center in enumerate(centers, start=1):
        uc = center["u_mm"]
        vc = center["v_mm"]

        uv_dist = np.sqrt(
            (data["u"] - uc) ** 2
            + (data["v"] - vc) ** 2
        )
        local = uv_dist <= args.neighborhood_radius_mm

        n_domain = int(np.count_nonzero(local))

        if n_domain == 0:
            continue

        betas_local = data["betas"][:, :, local]
        residuals_local = data["residuals"][:, local]

        valid = local_valid_mask(
            betas_local,
            residuals_local,
        )

        n_valid = int(np.count_nonzero(valid))

        center_voxel = center["voxel_index"]
        xyz = data["world"][center_voxel]

        center_id = f"{args.session}_uv_{number:05d}"

        qc = {
            "session": args.session,
            "center_id": center_id,
            "u_mm": uc,
            "v_mm": vc,
            "x_mm": float(xyz[0]),
            "y_mm": float(xyz[1]),
            "z_mm": float(xyz[2]),
            "n_voxels_domain": n_domain,
            "n_valid_voxels": n_valid,
            "voxel_retention": (
                n_valid / n_domain if n_domain else np.nan
            ),
            "status": "PASS",
            "reason": "",
        }

        if n_valid < args.min_valid_voxels:
            qc["status"] = "SKIP"
            qc["reason"] = "too_few_valid_voxels"
            qc_rows.append(qc)
            continue

        try:
            matrix = crossnobis_rdm(
                betas_local[:, :, valid],
                residuals_local[:, valid],
                fingers,
                dof,
            )
        except Exception as exc:
            qc["status"] = "FAIL"
            qc["reason"] = f"{type(exc).__name__}: {exc}"
            qc_rows.append(qc)
            continue

        if matrix.shape != (N_FINGERS, N_FINGERS):
            qc["status"] = "FAIL"
            qc["reason"] = f"unexpected_rdm_shape_{matrix.shape}"
            qc_rows.append(qc)
            continue

        if not np.all(np.isfinite(matrix)):
            qc["status"] = "FAIL"
            qc["reason"] = "nonfinite_rdm"
            qc_rows.append(qc)
            continue

        qc_rows.append(qc)

        for finger_pair, distance in upper_rows(matrix, fingers):
            rdm_rows.append({
                "session": args.session,
                "center_id": center_id,
                "u_mm": uc,
                "v_mm": vc,
                "x_mm": float(xyz[0]),
                "y_mm": float(xyz[1]),
                "z_mm": float(xyz[2]),
                "finger_pair": finger_pair,
                "distance": distance,
                "n_voxels": n_valid,
                "neighborhood_radius_mm": args.neighborhood_radius_mm,
            })

    out = args.out_dir
    out.mkdir(parents=True, exist_ok=True)

    rdm_df = pd.DataFrame(rdm_rows)
    qc_df = pd.DataFrame(qc_rows)

    rdm_path = out / "local_rdms_uv.csv"
    qc_path = out / "local_centers_qc.csv"

    rdm_df.to_csv(rdm_path, index=False)
    qc_df.to_csv(qc_path, index=False)

    n_pass = int((qc_df["status"] == "PASS").sum()) if len(qc_df) else 0
    n_skip = int((qc_df["status"] == "SKIP").sum()) if len(qc_df) else 0
    n_fail = int((qc_df["status"] == "FAIL").sum()) if len(qc_df) else 0

    summary = out / "local_rdm_generation_summary.txt"
    with summary.open("w") as f:
        f.write("LOCAL U-V CROSSNOBIS RDM GENERATION\n")
        f.write("=" * 80 + "\n\n")
        f.write(f"session: {args.session}\n")
        f.write(f"reference_firstlevel_pkl: {args.reference_firstlevel_pkl}\n")
        f.write(f"model_dir: {model_dir}\n")
        f.write(f"uv_coordinates: {args.uv_coordinates}\n")
        f.write(f"domain_mask: {args.domain_mask}\n")
        f.write(f"effective_residual_dof: {dof}\n")
        f.write(f"finger_names: {fingers}\n")
        f.write(f"uv_domain_voxels: {len(data['u'])}\n")
        f.write(f"candidate_centers: {len(centers)}\n")
        f.write(f"neighborhood_radius_mm: {args.neighborhood_radius_mm}\n")
        f.write(f"center_spacing_mm: {args.center_spacing_mm}\n")
        f.write(f"minimum_valid_voxels: {args.min_valid_voxels}\n")
        f.write(f"PASS_centers: {n_pass}\n")
        f.write(f"SKIP_centers: {n_skip}\n")
        f.write(f"FAIL_centers: {n_fail}\n")
        f.write(f"RDM_table_rows: {len(rdm_df)}\n\n")
        f.write(
            "Numerical method:\n"
            "  rsatoolbox.data.noise.prec_from_residuals(..., "
            "method='shrinkage_diag')\n"
            "  rsatoolbox.rdm.calc_rdm(..., method='crossnobis', "
            "descriptor='condition', cv_descriptor='run_number')\n"
            "  raw negative Crossnobis distances retained\n"
        )

    print()
    print("=" * 80)
    print("LOCAL U-V RDM GENERATION COMPLETE")
    print("=" * 80)
    print(f"PASS centers: {n_pass}")
    print(f"SKIP centers: {n_skip}")
    print(f"FAIL centers: {n_fail}")
    print(f"RDM rows: {len(rdm_df)}")
    print(f"Table: {rdm_path}")
    print(f"QC: {qc_path}")
    print(f"Summary: {summary}")

    if n_pass == 0:
        raise SystemExit(
            "No local centers passed. Inspect local_centers_qc.csv."
        )


def parse_args():
    p = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )

    p.add_argument("--session", required=True)

    p.add_argument(
        "--reference-firstlevel-pkl",
        type=Path,
        required=True,
        help="Validated rsa_firstlevel.pkl from the same session.",
    )

    p.add_argument(
        "--uv-coordinates",
        type=Path,
        required=True,
        help="Beta-space 4D NIfTI with U and V in volumes 0 and 1.",
    )

    p.add_argument(
        "--domain-mask",
        type=Path,
        default=None,
        help="Optional binary anatomical/domain mask in beta space.",
    )

    p.add_argument(
        "--neighborhood-radius-mm",
        type=float,
        default=3.0,
        help="Radius in intrinsic U-V millimetres.",
    )

    p.add_argument(
        "--center-spacing-mm",
        type=float,
        default=1.5,
        help="Approximate spacing of local centers in U-V millimetres.",
    )

    p.add_argument(
        "--min-valid-voxels",
        type=int,
        default=20,
    )

    p.add_argument(
        "--out-dir",
        type=Path,
        required=True,
    )

    args = p.parse_args()

    if args.neighborhood_radius_mm <= 0:
        p.error("--neighborhood-radius-mm must be > 0")
    if args.center_spacing_mm <= 0:
        p.error("--center-spacing-mm must be > 0")
    if args.min_valid_voxels < 2:
        p.error("--min-valid-voxels must be >= 2")

    return args


if __name__ == "__main__":
    run(parse_args())





