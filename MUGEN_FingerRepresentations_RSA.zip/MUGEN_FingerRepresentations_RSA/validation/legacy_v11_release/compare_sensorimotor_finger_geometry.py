
#!/usr/bin/env python3
from __future__ import annotations
import argparse, math, pickle
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

ROIS = ["M1","M1_4a","M1_4p","S1","S1_3a","S1_3b","S1_1","S1_2"]
SESSIONS = ["ses19","ses20"]
FIRST = Path("results/first_level")
OUT = Path("results/roi_comparisons/sensorimotor_finger_geometry")

def load(path):
    with open(path,"rb") as f: return pickle.load(f)

def flpath(root, subject, ses, roi):
    return root/subject/ses/f"roi-{roi}"/"rsa_firstlevel.pkl"

def save(fig, base):
    fig.savefig(base.with_suffix(".png"),dpi=300,bbox_inches="tight")
    fig.savefig(base.with_suffix(".svg"),bbox_inches="tight")
    plt.close(fig)

def pearson(a,b):
    a=np.asarray(a,float); b=np.asarray(b,float)
    ok=np.isfinite(a)&np.isfinite(b); a=a[ok]; b=b[ok]
    if len(a)<2 or np.std(a)<1e-12 or np.std(b)<1e-12: return np.nan
    return float(np.corrcoef(a,b)[0,1])

def zscore(v):
    v=np.asarray(v,float); s=np.nanstd(v)
    return np.zeros_like(v) if s<1e-12 else (v-np.nanmean(v))/s

def mds(D):
    D=np.asarray(D,float); n=len(D)
    J=np.eye(n)-np.ones((n,n))/n
    B=-0.5*J@(D**2)@J
    vals,vecs=np.linalg.eigh(B)
    order=np.argsort(vals)[::-1]
    vals=np.clip(vals[order][:2],0,None)
    return vecs[:,order][:,:2]*np.sqrt(vals)

def collect(subject, rois, sessions, root):
    rows=[]; fingers=None
    for roi in rois:
        for ses in sessions:
            o=load(flpath(root,subject,ses,roi))
            fs=list(o["finger_names"])
            if fingers is None: fingers=fs
            elif fs!=fingers: raise ValueError("Finger labels differ across inputs")
            combo=o.get("full_combo_label","run1-6")
            r=o["rdms"][combo]
            r=np.asarray(r["raw"] if isinstance(r,dict) else r,float)
            for i in range(len(fs)):
                for j in range(i+1,len(fs)):
                    rows.append(dict(
                        roi=roi,session=ses,combo=combo,
                        finger_i=fs[i],finger_j=fs[j],
                        finger_pair=f"{fs[i]}–{fs[j]}",
                        distance=float(r[i,j])
                    ))
    return fingers,pd.DataFrame(rows)

def mean_profiles(df,rois):
    pairs=list(dict.fromkeys(df.finger_pair))
    wide=(df.groupby(["roi","finger_pair"]).distance.mean()
            .unstack("finger_pair").reindex(index=rois,columns=pairs))
    zwide=wide.copy()
    for roi in rois: zwide.loc[roi]=zscore(wide.loc[roi].values)
    return wide,zwide

def corr_tables(wide,rois):
    C=np.eye(len(rois)); rows=[]
    for i,a in enumerate(rois):
        for j,b in enumerate(rois):
            C[i,j]=pearson(wide.loc[a].values,wide.loc[b].values)
            if j>i: rows.append(dict(roi_a=a,roi_b=b,pearson_rdm_geometry=C[i,j]))
    return C,pd.DataFrame(rows)

def sessionwise(df,rois,sessions):
    rows=[]; pairs=list(dict.fromkeys(df.finger_pair))
    for ses in sessions:
        W=df[df.session==ses].pivot(index="roi",columns="finger_pair",values="distance").reindex(index=rois,columns=pairs)
        for i,a in enumerate(rois):
            for b in rois[i+1:]:
                rows.append(dict(session=ses,roi_a=a,roi_b=b,
                    pearson_rdm_geometry=pearson(W.loc[a],W.loc[b])))
    return pd.DataFrame(rows)

def reliability(df,rois,sessions):
    a,b=sessions; pairs=list(dict.fromkeys(df.finger_pair)); rows=[]
    for roi in rois:
        A=(df[(df.roi==roi)&(df.session==a)].set_index("finger_pair").reindex(pairs).distance.values)
        B=(df[(df.roi==roi)&(df.session==b)].set_index("finger_pair").reindex(pairs).distance.values)
        rows.append(dict(
            roi=roi,session_a=a,session_b=b,pearson=pearson(A,B),
            mean_distance_a=float(np.mean(A)),mean_distance_b=float(np.mean(B)),
            scale_ratio_b_over_a=float(np.mean(B)/np.mean(A))
        ))
    return pd.DataFrame(rows)

def variation(wide):
    rows=[]
    for p in wide.columns:
        v=wide[p]
        rows.append(dict(
            finger_pair=p,mean_across_rois=float(v.mean()),
            std_across_rois=float(v.std(ddof=0)),
            range_across_rois=float(v.max()-v.min()),
            roi_max=v.idxmax(),roi_min=v.idxmin()
        ))
    return pd.DataFrame(rows).sort_values("std_across_rois",ascending=False)

def heat(mat,rows,cols,title,cbar,base):
    fig,ax=plt.subplots(figsize=(12,6),layout="constrained")
    im=ax.imshow(np.asarray(mat,float),aspect="auto")
    ax.set_xticks(range(len(cols))); ax.set_xticklabels(cols,rotation=40,ha="right")
    ax.set_yticks(range(len(rows))); ax.set_yticklabels(rows)
    ax.set_title(title); fig.colorbar(im,ax=ax,label=cbar); save(fig,base)

def plot_corr(C,rois,base):
    fig,ax=plt.subplots(figsize=(8,7),layout="constrained")
    im=ax.imshow(C,vmin=-1,vmax=1)
    ax.set_xticks(range(len(rois))); ax.set_yticks(range(len(rois)))
    ax.set_xticklabels(rois,rotation=35,ha="right"); ax.set_yticklabels(rois)
    for i in range(len(rois)):
        for j in range(len(rois)): ax.text(j,i,f"{C[i,j]:.2f}",ha="center",va="center",fontsize=8)
    ax.set_title("Matched-resolution ROI geometry correlation")
    fig.colorbar(im,ax=ax,label="Pearson r"); save(fig,base)

def plot_mds(C,rois,base):
    D=np.sqrt(np.clip(2*(1-C),0,None)); xy=mds(D)
    fig,ax=plt.subplots(figsize=(8,6),layout="constrained")
    ax.scatter(xy[:,0],xy[:,1],s=70)
    for roi,(x,y) in zip(rois,xy): ax.annotate(roi,(x,y),xytext=(5,5),textcoords="offset points")
    ax.axhline(0,lw=.6); ax.axvline(0,lw=.6); ax.grid(alpha=.2)
    ax.set_title("ROI organization from finger-distance geometry")
    ax.set_xlabel("MDS dimension 1"); ax.set_ylabel("MDS dimension 2"); save(fig,base)

def plot_profiles(wide,rois,base):
    fig,ax=plt.subplots(figsize=(13,6),layout="constrained"); x=np.arange(len(wide.columns))
    for roi in rois: ax.plot(x,wide.loc[roi],marker="o",lw=1.5,label=roi)
    ax.set_xticks(x); ax.set_xticklabels(wide.columns,rotation=40,ha="right")
    ax.set_ylabel("Mean Crossnobis distance"); ax.set_title("Finger-pair profiles across sensorimotor ROIs")
    ax.legend(ncol=2); ax.grid(axis="y",alpha=.25); save(fig,base)

def plot_reliability(rel,base):
    fig,ax=plt.subplots(figsize=(10,5),layout="constrained")
    x=np.arange(len(rel)); ax.bar(x,rel.pearson)
    ax.set_xticks(x); ax.set_xticklabels(rel.roi); ax.set_ylim(-.1,1.05)
    ax.set_ylabel("Pearson correlation"); ax.set_title("ses19 ↔ ses20 finger-geometry reliability")
    ax.grid(axis="y",alpha=.25); save(fig,base)

def plot_variation(var,base):
    fig,ax=plt.subplots(figsize=(11,5),layout="constrained")
    x=np.arange(len(var)); ax.bar(x,var.std_across_rois)
    ax.set_xticks(x); ax.set_xticklabels(var.finger_pair,rotation=40,ha="right")
    ax.set_ylabel("SD across ROIs"); ax.set_title("Finger pairs with strongest regional differentiation")
    ax.grid(axis="y",alpha=.25); save(fig,base)

def plot_session_change(df,rois,sessions,base):
    a,b=sessions; pairs=list(dict.fromkeys(df.finger_pair)); M=[]
    for roi in rois:
        A=df[(df.roi==roi)&(df.session==a)].set_index("finger_pair").reindex(pairs).distance.values
        B=df[(df.roi==roi)&(df.session==b)].set_index("finger_pair").reindex(pairs).distance.values
        M.append(B/np.mean(B)-A/np.mean(A))
    heat(M,rois,pairs,f"Geometry change after removing global scale ({b} − {a})",
         "Normalized distance change",base)

def main():
    p=argparse.ArgumentParser()
    p.add_argument("--subject",default="sub-01")
    p.add_argument("--rois",nargs="+",default=ROIS)
    p.add_argument("--sessions",nargs=2,default=SESSIONS)
    p.add_argument("--first-level-root",type=Path,default=FIRST)
    p.add_argument("--out-dir",type=Path,default=OUT)
    a=p.parse_args(); rois=list(a.rois); sessions=list(a.sessions); a.out_dir.mkdir(parents=True,exist_ok=True)

    fingers,df=collect(a.subject,rois,sessions,a.first_level_root)
    wide,zwide=mean_profiles(df,rois); C,corr=corr_tables(wide,rois)
    sesscorr=sessionwise(df,rois,sessions); rel=reliability(df,rois,sessions); var=variation(wide)

    df.to_csv(a.out_dir/"roi_session_finger_pair_distances.csv",index=False)
    wide.reset_index().to_csv(a.out_dir/"roi_mean_finger_pair_distances.csv",index=False)
    zwide.reset_index().to_csv(a.out_dir/"roi_mean_finger_pair_zprofiles.csv",index=False)
    corr.to_csv(a.out_dir/"roi_geometry_correlations.csv",index=False)
    sesscorr.to_csv(a.out_dir/"roi_geometry_correlations_sessionwise.csv",index=False)
    rel.to_csv(a.out_dir/"roi_session_reliability.csv",index=False)
    var.to_csv(a.out_dir/"finger_pair_regional_variation.csv",index=False)

    heat(wide.values,rois,list(wide.columns),"Matched-resolution mean finger-pair distances",
         "Crossnobis distance",a.out_dir/"matched_resolution_pair_distance_heatmap")
    heat(zwide.values,rois,list(zwide.columns),"Within-ROI standardized finger-pair profiles",
         "Within-ROI z score",a.out_dir/"matched_resolution_pair_distance_zheatmap")
    plot_corr(C,rois,a.out_dir/"matched_resolution_roi_geometry_correlation")
    plot_mds(C,rois,a.out_dir/"matched_resolution_roi_mds")
    plot_reliability(rel,a.out_dir/"matched_resolution_session_reliability")
    plot_profiles(wide,rois,a.out_dir/"matched_resolution_finger_pair_profiles")
    plot_variation(var,a.out_dir/"matched_resolution_finger_pair_regional_variation")
    plot_session_change(df,rois,sessions,a.out_dir/"matched_resolution_session_difference_heatmap")

    with open(a.out_dir/"sensorimotor_geometry_summary.txt","w") as f:
        f.write("SENSORIMOTOR FINGER-GEOMETRY COMPARISON\n"+"="*80+"\n\n")
        f.write(f"Sessions: {sessions}\n")
        f.write("Matched-resolution descriptive analysis; no group-level inference.\n\n")
        f.write("SES19-SES20 ROI RELIABILITY\n"+"-"*80+"\n"+rel.to_string(index=False)+"\n\n")
        f.write("PAIRWISE ROI GEOMETRY CORRELATIONS\n"+"-"*80+"\n")
        f.write(corr.sort_values("pearson_rdm_geometry",ascending=False).to_string(index=False)+"\n\n")
        f.write("FINGER PAIRS WITH STRONGEST REGIONAL VARIATION\n"+"-"*80+"\n")
        f.write(var.to_string(index=False)+"\n")
    print("Sensorimotor finger-geometry comparison complete.")
    print("Output:",a.out_dir)

if __name__=="__main__":
    main()



