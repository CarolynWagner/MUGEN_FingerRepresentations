#!/usr/bin/env python3
from __future__ import annotations
import ast
import importlib
import importlib.metadata
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
STDLIB = set(getattr(sys, "stdlib_module_names", set()))
LOCAL = {"first_level", "second_level", "shared", "module_loader"}
DIST_MAP = {"sklearn": "scikit-learn", "rsatoolbox": "rsatoolbox", "future": "future"}

mods = set()
for folder_name in ("first_level", "second_level", "shared"):
    folder = ROOT / folder_name
    if not folder.exists():
        continue
    for path in folder.rglob("*.py"):
        try:
            tree = ast.parse(path.read_text())
        except Exception as exc:
            print(f"PARSE ERROR {path}: {exc}")
            continue
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for item in node.names:
                    mods.add(item.name.split(".")[0])
            elif isinstance(node, ast.ImportFrom) and node.module:
                mods.add(node.module.split(".")[0])

external = sorted(m for m in mods if m not in STDLIB and m not in LOCAL)
missing = []

print("\nExternal imports used by RSA v11:\n")
for name in external:
    try:
        importlib.import_module(name)
        dist = DIST_MAP.get(name, name)
        try:
            version = importlib.metadata.version(dist)
        except importlib.metadata.PackageNotFoundError:
            version = "unknown"
        print(f"OK       {name:20s} {version}")
    except Exception as exc:
        print(f"MISSING  {name:20s} {exc}")
        missing.append(name)

if missing:
    print("\nMissing imports:")
    for name in missing:
        print(f"  - {name}")
    raise SystemExit(1)

print("\nDependency audit passed.")

