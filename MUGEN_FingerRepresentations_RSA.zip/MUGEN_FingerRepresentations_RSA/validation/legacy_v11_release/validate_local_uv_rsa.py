#!/usr/bin/env python3
"""
validate_local_uv_rsa.py

Validation gate for generate_local_rdms_uv.py.

UPDATED NUMERICAL PARITY CONTRACT
---------------------------------
Whole-domain equivalence is classified as:

    EXACT
        allclose(atol=1e-12, rtol=1e-12)

    WITHIN_TOLERANCE
        allclose(configured tolerances; defaults atol=1e-9, rtol=1e-6)

    FAIL
        exceeds configured tolerances

The overall validation gate PASSES for both EXACT and WITHIN_TOLERANCE,
provided all structural/local-QC checks also pass.

This change affects validation classification only. It does NOT change the
local-RDM generator or any RSA numerical computation.

Example
-------
python validate_local_uv_rsa.py \
  --generator generate_local_rdms_uv.py \
  --session ses18 \
  --reference-firstlevel-pkl results/first_level/sub-01/ses18/roi-M1/rsa_firstlevel.pkl \
  --uv-coordinates /path/to/ses18_multilaterate_radius30_corrected_UV_coordinates.nii \
  --domain-mask /path/to/sub-01_ses18_roi-M1_space-beta.nii.gz \
  --local-qc results/roi_comparisons/uv_local_rdms/ses18/local_centers_qc.csv \
  --local-rdms results/roi_comparisons/uv_local_rdms/ses18/local_rdms_uv.csv \
  --out-dir results/roi_comparisons/uv_local_rdms/ses18/validation
"""

from __future__ import annotations

import argparse
import importlib.util
import json
import math
import pickle
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import nibabel as nib
import numpy as np
import pandas as pd


EXACT_ATOL = 1e-12
EXACT_RTOL = 1e-12
DEFAULT_ATOL = 1e-9
DEFAULT_RTOL = 1e-6


def load_pickle(path):
    with Path(path).open("rb") as f:
        return pickle.load(f)


def load_generator(path):
    path = Path(path).resolve()
    if not path.is_file():
        raise FileNotFoundError(path)
    spec = importlib.util.spec_from_file_location("uv_generator_under_test", str(path))
    if spec is None or spec.loader is None:
        raise ImportError(path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def save_fig(fig, base):
    base = Path(base)
    base.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(base.with_suffix(".png"), dpi=300, bbox_inches="tight")
    fig.savefig(base.with_suffix(".svg"), bbox_inches="tight")
    plt.close(fig)


def decode_rdm(value):
    if hasattr(value, "get_matrices"):
        arr = np.asarray(value.get_matrices(), dtype=float)
        if arr.ndim == 3 and arr.shape[0] >= 1:
            return arr[0]

    if isinstance(value, dict):
        for key in ("raw", "matrix", "rdm", "rdm_matrix", "dissimilarities", "data"):
            if key in value:
                out = decode_rdm(value[key])
                if out is not None:
                    return out

    arr = np.asarray(value)

    if arr.shape == (5, 5):
        return arr.astype(float)

    if arr.shape == (1, 10):
        arr = arr[0]

    if arr.ndim == 1 and arr.size == 10:
        m = np.zeros((5, 5), dtype=float)
        i, j = np.triu_indices(5, 1)
        m[i, j] = arr
        m[j, i] = arr
        return m

    return None


def reference_rdm(reference, combo):
    rdms = reference.get("rdms", {})
    if combo not in rdms:
        raise KeyError(f"RDM {combo!r} unavailable; keys={list(rdms)}")

    matrix = decode_rdm(rdms[combo])
    if matrix is None:
        raise TypeError(f"Could not decode reference RDM {combo}")

    matrix = 0.5 * (matrix + matrix.T)
    np.fill_diagonal(matrix, 0.0)
    return matrix


def write_matrix(matrix, fingers, path):
    pd.DataFrame(matrix, index=fingers, columns=fingers).to_csv(path)


def plot_rdm(matrix, fingers, title, base, difference=False):
    fig, ax = plt.subplots(figsize=(6.2, 5.4), layout="constrained")

    kwargs = {}
    if difference:
        lim = np.nanmax(np.abs(matrix))
        if not np.isfinite(lim) or lim == 0:
            lim = 1.0
        kwargs.update(vmin=-lim, vmax=lim)

    im = ax.imshow(matrix, **kwargs)
    ax.set_xticks(range(len(fingers)))
    ax.set_yticks(range(len(fingers)))
    ax.set_xticklabels(fingers, rotation=40, ha="right")
    ax.set_yticklabels(fingers)
    ax.set_title(title)
    fig.colorbar(im, ax=ax)

    save_fig(fig, base)


def domain_identity(generator, reference, uv_path, domain_mask):
    uv_img = nib.load(str(uv_path))
    uv = uv_img.get_fdata(dtype=np.float32)

    domain = np.isfinite(uv[..., 0]) & np.isfinite(uv[..., 1])

    if domain_mask:
        dimg = nib.load(str(domain_mask))
        generator.same_grid(uv_img, dimg, "U-V coordinates", "domain mask")
        domain &= dimg.get_fdata(dtype=np.float32) > 0

    roi = reference.get("roi", {})
    src = reference.get("source_paths", {})
    ref_mask_path = roi.get("mask_path") or src.get("roi_path")

    out = {
        "uv_domain_voxels": int(domain.sum()),
        "reference_mask_path": ref_mask_path,
        "reference_mask_available": False,
        "exact_spatial_identity": False,
    }

    if ref_mask_path and Path(ref_mask_path).is_file():
        rimg = nib.load(str(ref_mask_path))
        generator.same_grid(uv_img, rimg, "U-V coordinates", "validated ROI mask")
        rmask = rimg.get_fdata(dtype=np.float32) > 0

        out.update({
            "reference_mask_available": True,
            "reference_mask_voxels": int(rmask.sum()),
            "different_voxels": int(np.count_nonzero(domain != rmask)),
            "exact_spatial_identity": bool(np.array_equal(domain, rmask)),
        })

    validated_count = (
        roi.get("n_voxels_after_qc")
        or reference.get("qc", {}).get("n_valid_voxels")
    )

    if validated_count is not None:
        out["validated_voxel_count"] = int(validated_count)

    return out


def recompute_global(generator, args, reference):
    data = generator.load_full_data(
        generator.resolve_model_dir(reference),
        args.uv_coordinates,
        args.domain_mask,
    )

    valid = generator.local_valid_mask(
        data["betas"],
        data["residuals"],
    )

    n_domain = int(data["betas"].shape[2])
    n_valid = int(valid.sum())

    if n_valid < args.min_global_voxels:
        raise RuntimeError(f"Only {n_valid} valid voxels")

    matrix = generator.crossnobis_rdm(
        data["betas"][:, :, valid],
        data["residuals"][:, valid],
        generator.resolve_fingers(reference),
        generator.resolve_dof(reference),
    )

    return matrix, n_domain, n_valid


def local_table_qc(local_rdms, qc):
    counts = local_rdms.groupby("center_id")["finger_pair"].nunique()
    pass_ids = set(qc.loc[qc["status"] == "PASS", "center_id"].astype(str))
    rdm_ids = set(local_rdms["center_id"].astype(str))

    distances = pd.to_numeric(
        local_rdms["distance"],
        errors="coerce",
    ).to_numpy(float)

    return {
        "n_rows": int(len(local_rdms)),
        "n_centers": int(local_rdms["center_id"].nunique()),
        "all_centers_have_10_pairs": bool(len(counts) and (counts == 10).all()),
        "pass_centers_equal_rdm_centers": bool(pass_ids == rdm_ids),
        "all_distances_finite": bool(np.isfinite(distances).all()),
    }


def local_spatial_qc(qc, out_dir):
    q = qc.copy()

    u = q["u_mm"].to_numpy(float)
    v = q["v_mm"].to_numpy(float)

    q["approx_boundary_distance_mm"] = np.minimum.reduce([
        u - np.nanmin(u),
        np.nanmax(u) - u,
        v - np.nanmin(v),
        np.nanmax(v) - v,
    ])

    q.to_csv(out_dir / "local_centers_qc_augmented.csv", index=False)

    counts = {str(k): int(v) for k, v in q["status"].value_counts().items()}
    passed = q[q["status"] == "PASS"]
    nonpass = q[q["status"] != "PASS"]

    summary = {
        "n_centers": int(len(q)),
        "status_counts": counts,
        "pass_fraction": float(len(passed) / len(q)) if len(q) else math.nan,
        "nonpass_median_approx_boundary_distance_mm": (
            float(nonpass["approx_boundary_distance_mm"].median())
            if len(nonpass) else math.nan
        ),
        "pass_median_approx_boundary_distance_mm": (
            float(passed["approx_boundary_distance_mm"].median())
            if len(passed) else math.nan
        ),
    }

    fig, ax = plt.subplots(figsize=(8, 7), layout="constrained")
    for status, g in q.groupby("status"):
        ax.scatter(g["u_mm"], g["v_mm"], s=18, label=f"{status} (n={len(g)})")
    ax.set_aspect("equal")
    ax.set_xlabel("U (mm)")
    ax.set_ylabel("V (mm)")
    ax.set_title("Local-center QC status")
    ax.legend()
    save_fig(fig, out_dir / "figures" / "local_center_status_uv")

    return summary


def classify_numeric_equivalence(reference_vec, new_vec, atol, rtol):
    exact = bool(
        np.allclose(
            reference_vec,
            new_vec,
            atol=EXACT_ATOL,
            rtol=EXACT_RTOL,
            equal_nan=False,
        )
    )

    within = bool(
        np.allclose(
            reference_vec,
            new_vec,
            atol=atol,
            rtol=rtol,
            equal_nan=False,
        )
    )

    if exact:
        return "EXACT", "numerically_exact"
    if within:
        return "WITHIN_TOLERANCE", "numerically_equivalent_within_tolerance"
    return "FAIL", "numerical_difference"


def main():
    p = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )

    p.add_argument("--generator", type=Path, default=Path("generate_local_rdms_uv.py"))
    p.add_argument("--session", required=True)
    p.add_argument("--reference-firstlevel-pkl", type=Path, required=True)
    p.add_argument("--uv-coordinates", type=Path, required=True)
    p.add_argument("--domain-mask", type=Path, default=None)
    p.add_argument("--local-qc", type=Path, required=True)
    p.add_argument("--local-rdms", type=Path, required=True)
    p.add_argument("--combo", default="run1-6")
    p.add_argument("--atol", type=float, default=DEFAULT_ATOL)
    p.add_argument("--rtol", type=float, default=DEFAULT_RTOL)
    p.add_argument("--min-global-voxels", type=int, default=20)
    p.add_argument("--out-dir", type=Path, required=True)

    args = p.parse_args()
    args.out_dir.mkdir(parents=True, exist_ok=True)

    generator = load_generator(args.generator)
    reference = load_pickle(args.reference_firstlevel_pkl)

    ref_session = str(reference.get("session_id", ""))
    if ref_session and ref_session != args.session:
        raise ValueError(
            f"Session mismatch: CLI={args.session}, pickle={ref_session}"
        )

    qc = pd.read_csv(args.local_qc)
    local_rdms = pd.read_csv(args.local_rdms)

    table_qc = local_table_qc(local_rdms, qc)
    spatial_qc = local_spatial_qc(qc, args.out_dir)
    domain_check = domain_identity(
        generator,
        reference,
        args.uv_coordinates,
        args.domain_mask,
    )

    new_rdm, n_domain, n_valid = recompute_global(
        generator,
        args,
        reference,
    )

    fingers = generator.resolve_fingers(reference)

    write_matrix(
        new_rdm,
        fingers,
        args.out_dir / "global_rdm_new.csv",
    )
    plot_rdm(
        new_rdm,
        fingers,
        "Whole U-V domain: recomputed Crossnobis RDM",
        args.out_dir / "figures" / "global_rdm_new",
    )

    comparison = {
        "status": "NOT_COMPARABLE",
        "reason": "",
        "n_domain_voxels": n_domain,
        "n_valid_voxels_after_qc": n_valid,
        "exact_atol": EXACT_ATOL,
        "exact_rtol": EXACT_RTOL,
        "validation_atol": args.atol,
        "validation_rtol": args.rtol,
    }

    if domain_check["exact_spatial_identity"]:
        ref_rdm = reference_rdm(reference, args.combo)

        write_matrix(
            ref_rdm,
            fingers,
            args.out_dir / "global_rdm_reference.csv",
        )

        diff = new_rdm - ref_rdm

        write_matrix(
            diff,
            fingers,
            args.out_dir / "global_rdm_difference.csv",
        )

        plot_rdm(
            ref_rdm,
            fingers,
            f"Validated v11 RDM: {args.combo}",
            args.out_dir / "figures" / "global_rdm_reference",
        )
        plot_rdm(
            diff,
            fingers,
            "New local-module global RDM minus validated v11",
            args.out_dir / "figures" / "global_rdm_difference",
            difference=True,
        )

        i, j = np.triu_indices(5, 1)
        x = ref_rdm[i, j]
        y = new_rdm[i, j]

        absdiff = np.abs(x - y)
        denominator = np.maximum(np.abs(x), np.abs(y))
        reldiff = np.divide(
            absdiff,
            denominator,
            out=np.zeros_like(absdiff),
            where=denominator > 0,
        )

        status, reason = classify_numeric_equivalence(
            x,
            y,
            args.atol,
            args.rtol,
        )

        comparison.update({
            "status": status,
            "reason": reason,
            "max_abs_difference": float(np.max(absdiff)),
            "max_relative_difference": float(np.max(reldiff)),
            "pearson": (
                float(np.corrcoef(x, y)[0, 1])
                if np.std(x) > 0 and np.std(y) > 0
                else math.nan
            ),
        })

    else:
        comparison["reason"] = (
            "U-V/domain intersection is not identical to validated ROI mask"
        )

    structural_pass = all([
        table_qc["all_centers_have_10_pairs"],
        table_qc["pass_centers_equal_rdm_centers"],
        table_qc["all_distances_finite"],
        spatial_qc["status_counts"].get("FAIL", 0) == 0,
    ])

    numerical_pass = comparison["status"] in {
        "EXACT",
        "WITHIN_TOLERANCE",
    }

    if structural_pass and numerical_pass:
        verdict = "PASS"
    elif comparison["status"] == "FAIL" or not structural_pass:
        verdict = "FAIL"
    else:
        verdict = "INCONCLUSIVE_GLOBAL_EQUIVALENCE"

    report = {
        "analysis": "local_uv_rsa_validation",
        "session": args.session,
        "verdict": verdict,
        "local_table_qc": table_qc,
        "local_spatial_qc": spatial_qc,
        "domain_identity": domain_check,
        "global_equivalence": comparison,
    }

    json_path = args.out_dir / "validation_report.json"
    json_path.write_text(
        json.dumps(report, indent=2, allow_nan=True)
    )

    txt_path = args.out_dir / "validation_report.txt"
    with txt_path.open("w") as f:
        f.write("LOCAL U-V RSA VALIDATION GATE\n")
        f.write("=" * 80 + "\n\n")
        f.write(f"Session: {args.session}\n")
        f.write(f"OVERALL VERDICT: {verdict}\n\n")

        for title, obj in [
            ("LOCAL TABLE QC", table_qc),
            ("LOCAL SPATIAL QC", spatial_qc),
            ("DOMAIN IDENTITY", domain_check),
            ("GLOBAL NUMERICAL EQUIVALENCE", comparison),
        ]:
            f.write(title + "\n")
            f.write("-" * 80 + "\n")
            f.write(json.dumps(obj, indent=2, allow_nan=True))
            f.write("\n\n")

    print()
    print("=" * 80)
    print("LOCAL U-V RSA VALIDATION GATE")
    print("=" * 80)
    print("Session:", args.session)
    print("Center status:", spatial_qc["status_counts"])
    print("Domain exact spatial identity:", domain_check["exact_spatial_identity"])
    print(
        "Global equivalence:",
        comparison["status"],
        "-",
        comparison["reason"],
    )

    if "max_abs_difference" in comparison:
        print(
            "Max abs difference:",
            f"{comparison['max_abs_difference']:.3e}",
        )
        print(
            "Max rel difference:",
            f"{comparison['max_relative_difference']:.3e}",
        )
        print(
            "Validation tolerance:",
            f"atol={args.atol:.1e}, rtol={args.rtol:.1e}",
        )

    print("OVERALL VERDICT:", verdict)
    print("Report:", json_path)


if __name__ == "__main__":
    main()

