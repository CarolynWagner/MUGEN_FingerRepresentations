#!/usr/bin/env python3
from __future__ import annotations
import py_compile, shutil
from datetime import datetime
from pathlib import Path

ROOT=Path(__file__).resolve().parent
WRAPPER=ROOT/"run_pipeline.py"
REPORTER=ROOT/"reporting"/"generate_full_reports.py"
FIRST="# [FULL_REPORTING_V11_FIRST_LEVEL]"
SECOND="# [FULL_REPORTING_V11_SECOND_LEVEL]"

def fail(msg): raise SystemExit("ERROR: "+msg)

def main():
    if not WRAPPER.is_file(): fail(f"Missing wrapper: {WRAPPER}")
    if not REPORTER.is_file(): fail(f"Missing reporter: {REPORTER}")
    text=WRAPPER.read_text()
    if FIRST in text and SECOND in text:
        print("[REPORTING PATCH] Already installed."); return
    backup=ROOT/f"run_pipeline.pre_full_reporting_{datetime.now().strftime('%Y%m%d_%H%M%S')}.py"
    shutil.copy2(WRAPPER,backup); print("[REPORTING PATCH] Backup:",backup)

    if FIRST not in text:
        old = """        run_first_level(\n            selected_manifest,\n            first_level_out,\n            args.n_boot,\n        )\n"""
        new = old + """        # [FULL_REPORTING_V11_FIRST_LEVEL]\n        for row in selected:\n            firstlevel_pkl = (\n                first_level_out\n                / row[\"subject\"]\n                / row[\"session\"]\n                / f\"roi-{row['roi_name']}\"\n                / \"rsa_firstlevel.pkl\"\n            )\n            if not firstlevel_pkl.exists():\n                die(\"First-level reporting input missing:\\n  \" + str(firstlevel_pkl))\n            run_command([\n                str(VENV_PYTHON),\n                \"-m\",\n                \"reporting.generate_full_reports\",\n                \"--first-level-pkl\",\n                str(firstlevel_pkl),\n            ])\n"""
        if old not in text: fail("Could not locate first-level call; wrapper left unchanged.")
        text=text.replace(old,new,1)

    if SECOND not in text:
        old = """    run_command([\n        str(VENV_PYTHON),\n        \"-m\",\n        \"second_level.augment_legacy_diagnostics\",\n        str(secondlevel_pkl),\n        \"--backup\",\n    ])\n"""
        new = old + """    # [FULL_REPORTING_V11_SECOND_LEVEL]\n    run_command([\n        str(VENV_PYTHON),\n        \"-m\",\n        \"reporting.generate_full_reports\",\n        \"--second-level-pkl\",\n        str(secondlevel_pkl),\n    ])\n"""
        if old not in text: fail("Could not locate augmentation block; wrapper left unchanged.")
        text=text.replace(old,new,1)

    (ROOT/"reporting"/"__init__.py").touch(exist_ok=True)
    WRAPPER.write_text(text)
    try:
        py_compile.compile(str(REPORTER),doraise=True)
        py_compile.compile(str(WRAPPER),doraise=True)
    except Exception:
        shutil.copy2(backup,WRAPPER); raise
    print("[REPORTING PATCH] Installed successfully.")
    print("[REPORTING PATCH] Numerical analysis modules were not modified.")
    print("[REPORTING PATCH] Syntax check passed.")

if __name__=="__main__": main()
