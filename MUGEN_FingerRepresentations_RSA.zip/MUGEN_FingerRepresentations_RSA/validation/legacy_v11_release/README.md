# RSA v11.0 generalized Crossnobis pipeline

This package generalizes the frozen **v10.3-final-crossnobis** pilot pipeline without changing its numerical Crossnobis core.

## Architecture

**First level = one subject × one session × one ROI.** It computes voxel QA, residual precision, Crossnobis RDMs for all run combinations, raw FSI, overlapping run-subset stability, disjoint split reliability, and run-level uncertainty. It does not require another session or participant.

**Second level = comparisons among validated first-level objects.** It computes within-subject cross-session RDM similarity, between-subject similarity, within-subject ROI comparisons (e.g. M1_old vs M1_new vs S1), FSI summary tables, and genuine group RSA noise ceilings when a session/ROI cell contains enough independent participants.

ROI is an explicit dimension. Built-in conventions are `M1_old`, `M1_new`, `S1`, `S1_3a`, `S1_3b`, `S1_1`, and `S1_2`; custom ROI names are accepted.

## Frozen reference

The complete uploaded v10.3 source tree is preserved under `reference_v10_3/`. Numerical modules used by v11 are copied unchanged under `shared/frozen_algorithms/`.

## Manifest

One row represents one **subject × session × ROI**. See `examples/manifest_template.csv`.

Required columns: `subject, session, roi_name, model_dir, roi_path`.

Recommended metadata: `roi_family, roi_version, hemisphere, resolution_mm, group, instrument, roi_definition_method, roi_source_space, roi_analysis_space`.

## Run first level

```bash
python -m first_level.run_first_level \
  --manifest examples/manifest_template.csv \
  --out-root derivatives/rsa_first_level
```

For SLURM arrays:

```bash
python -m first_level.run_first_level \
  --manifest manifest.csv \
  --row "$SLURM_ARRAY_TASK_ID" \
  --out-root derivatives/rsa_first_level
```

Each unit writes:

```text
sub-001/ses-01/roi-M1_old/
  rsa_firstlevel.pkl
  firstlevel_report.txt
  qc.json
  figures/
```

## Run second level

```bash
python -m second_level.run_second_level \
  derivatives/rsa_first_level \
  --out-dir derivatives/rsa_second_level
```

The second level automatically classifies pairwise comparisons as:

- `within_subject_across_sessions`
- `between_subject_same_session_roi`
- `within_subject_roi_comparison`
- `other_pairwise`

A standard group RSA noise ceiling is estimated only across independent participants within the same session and ROI, by default requiring at least N=3.

## M1_old regression certification

Before v11 is certified on the pilot dataset, verify that the generalized first level reproduces frozen v10.3 for `M1_old`:

```bash
python tests/regression_against_v10_3.py \
  --v10 /path/to/v10.3/results/rsa_final_locked.pkl \
  --v11 derivatives/rsa_first_level/sub-01/ses18/roi-M1_old/rsa_firstlevel.pkl \
        derivatives/rsa_first_level/sub-01/ses19/roi-M1_old/rsa_firstlevel.pkl \
        derivatives/rsa_first_level/sub-01/ses20/roi-M1_old/rsa_firstlevel.pkl
```

This regression is the certification gate. v11 should not be described as numerically certified until it passes on the actual pilot files.

## Scientific boundary

The refactor changes architecture, not methodology. Raw Crossnobis RDMs remain the inferential representation. Normalized RDMs remain descriptive/visual only. `M1_old` is retained as the frozen benchmark; `M1_new` and S1 variants are additional ROI inputs analyzed by the identical core.

## Optional model RSA extensions

The frozen v10.3 candidate-model and empirical-Ejaz-model implementations are available through a compatibility adapter:

```bash
python -m extensions.run_models \
  derivatives/rsa_first_level/sub-001/ses-01/roi-M1_new/rsa_firstlevel.pkl \
  --out-dir derivatives/models/sub-001/ses-01/roi-M1_new \
  --candidate
```

For authoritative Ejaz empirical model values, add `--ejaz-csv /path/to/models.csv`.
