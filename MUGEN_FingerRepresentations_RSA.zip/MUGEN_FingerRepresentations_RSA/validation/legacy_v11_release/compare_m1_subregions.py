
#!/usr/bin/env python3
"""
compare_m1_subregions.py

Compare combined M1 with its BA4a / BA4p subdivisions using already-generated
RSA v11 first- and second-level outputs.

The script is deliberately ROI-name agnostic:
- pass the exact ROI names with --rois, OR
- let it discover candidate M1/4a/4p ROI names from participants.csv.

Outputs
-------
CSV tables:
  - roi_voxel_qc.csv
  - roi_fsi.csv
  - roi_independent_split_reliability.csv
  - roi_test_retest.csv
  - roi_rdm_geometry.csv

Figures (PNG + SVG):
  - compare_voxel_counts
  - compare_fsi_full_combo
  - compare_independent_split_reliability
  - compare_test_retest
  - compare_rdm_geometry

No RSA is recomputed. This only summarizes existing rsa_firstlevel.pkl and
rsa_secondlevel.pkl files.
"""

from __future__ import annotations

import argparse
import pickle
from pathlib import Path

import numpy as np
import pandas as pd

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt


SESSIONS = ("ses18", "ses19", "ses20")
DEFAULT_SUBJECT = "sub-01"
FULL_COMBO_FALLBACK = "run1-6"


def load_pickle(path: Path):
    if not path.exists():
        raise FileNotFoundError(path)
    with path.open("rb") as f:
        return pickle.load(f)


def upper_vec(rdm):
    arr = np.asarray(rdm, dtype=float)
    return arr[np.triu_indices(arr.shape[0], k=1)]


def pearson(a, b):
    a = np.asarray(a, dtype=float).ravel()
    b = np.asarray(b, dtype=float).ravel()
    ok = np.isfinite(a) & np.isfinite(b)
    a = a[ok]
    b = b[ok]
    if len(a) < 2 or np.std(a) == 0 or np.std(b) == 0:
        return np.nan
    return float(np.corrcoef(a, b)[0, 1])


def save_png_svg(fig, path_no_suffix: Path):
    path_no_suffix.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(path_no_suffix.with_suffix(".png"), dpi=300, bbox_inches="tight")
    fig.savefig(path_no_suffix.with_suffix(".svg"), bbox_inches="tight")
    plt.close(fig)


def discover_rois(manifest: Path, subject: str):
    df = pd.read_csv(manifest)
    x = df[df["subject"].astype(str) == subject].copy()

    if "roi_name" not in x.columns:
        raise KeyError("participants.csv has no `roi_name` column")

    names = list(dict.fromkeys(x["roi_name"].astype(str)))

    # Prefer exact combined M1 plus candidates containing 4a / 4p.
    combined = [n for n in names if n.lower() == "m1"]
    a4 = [n for n in names if "4a" in n.lower()]
    p4 = [n for n in names if "4p" in n.lower()]

    candidates = combined + a4 + p4
    candidates = list(dict.fromkeys(candidates))

    if len(candidates) < 3:
        raise RuntimeError(
            "Could not unambiguously discover combined M1 + 4a + 4p ROI names.\n"
            f"Available ROI names: {names}\n"
            "Run again with --rois EXACT_COMBINED EXACT_4A EXACT_4P"
        )

    return candidates[:3]


def firstlevel_path(root: Path, subject: str, session: str, roi: str):
    return root / subject / session / f"roi-{roi}" / "rsa_firstlevel.pkl"


def secondlevel_path(root: Path, subject: str, roi: str):
    return root / subject / f"roi-{roi}" / "rsa_secondlevel.pkl"


def collect(subject, rois, first_root, second_root):
    voxel_rows = []
    fsi_rows = []
    split_rows = []
    testretest_rows = []
    rdm_rows = []

    first = {}

    for roi in rois:
        first[roi] = {}

        for ses in SESSIONS:
            p = firstlevel_path(first_root, subject, ses, roi)
            obj = load_pickle(p)
            first[roi][ses] = obj

            roi_meta = obj.get("roi", {})
            qc = obj.get("qc", {})
            full_combo = obj.get("full_combo_label", FULL_COMBO_FALLBACK)

            voxel_rows.append({
                "roi": roi,
                "session": ses,
                "n_voxels_before_qc": roi_meta.get(
                    "n_voxels_before_qc",
                    qc.get("n_voxels_roi"),
                ),
                "n_voxels_after_qc": roi_meta.get(
                    "n_voxels_after_qc",
                    qc.get("n_valid_voxels"),
                ),
                "voxel_retention": qc.get("voxel_retention"),
                "resolution_mm": obj.get("acquisition", {}).get("resolution_mm"),
            })

            fsi_raw = obj.get("fsi_raw", {})
            if full_combo in fsi_raw:
                fsi_rows.append({
                    "roi": roi,
                    "session": ses,
                    "combo": full_combo,
                    "fsi_raw": float(fsi_raw[full_combo]),
                })

            indep = obj.get("independent_split_reliability", {})
            for split_name, item in indep.items():
                for metric in ("pearson", "spearman", "icc", "cosine", "fisherz"):
                    if metric in item:
                        split_rows.append({
                            "roi": roi,
                            "session": ses,
                            "split": split_name,
                            "metric": metric,
                            "value": float(item[metric]),
                        })

        second = load_pickle(secondlevel_path(second_root, subject, roi))
        ref = second.get("test_retest_consistency_reference", {})
        metrics = ref.get("metrics", {})

        for metric, value in metrics.items():
            if isinstance(value, (int, float, np.integer, np.floating)):
                testretest_rows.append({
                    "roi": roi,
                    "session_pair": "_vs_".join(ref.get("sessions", [])),
                    "combo": ref.get("combo", FULL_COMBO_FALLBACK),
                    "metric": metric,
                    "value": float(value),
                })

    # RDM geometry:
    # 1) cross-ROI similarity within each session
    # 2) ROI-vs-combined-M1 similarity if first ROI is combined M1
    combined_roi = rois[0]

    for ses in SESSIONS:
        for i, roi_a in enumerate(rois):
            obj_a = first[roi_a][ses]
            combo = obj_a.get("full_combo_label", FULL_COMBO_FALLBACK)
            a = upper_vec(obj_a["rdms"][combo]["raw"])

            for roi_b in rois[i + 1:]:
                obj_b = first[roi_b][ses]
                b = upper_vec(obj_b["rdms"][combo]["raw"])

                rdm_rows.append({
                    "session": ses,
                    "roi_a": roi_a,
                    "roi_b": roi_b,
                    "combo": combo,
                    "pearson_rdm_geometry": pearson(a, b),
                })

    return (
        pd.DataFrame(voxel_rows),
        pd.DataFrame(fsi_rows),
        pd.DataFrame(split_rows),
        pd.DataFrame(testretest_rows),
        pd.DataFrame(rdm_rows),
    )


def plot_voxels(df, rois, outdir):
    fig, ax = plt.subplots(figsize=(9, 5), layout="constrained")

    x = np.arange(len(rois))
    sessions = list(SESSIONS)
    width = 0.22

    for i, ses in enumerate(sessions):
        sub = df[df["session"] == ses].set_index("roi").reindex(rois)
        vals = sub["n_voxels_after_qc"].astype(float).values
        xpos = x + (i - (len(sessions)-1)/2) * width
        ax.bar(xpos, vals, width=width, label=ses)

    ax.set_xticks(x)
    ax.set_xticklabels(rois)
    ax.set_ylabel("Valid ROI voxels after QC")
    ax.set_title("ROI voxel counts")
    ax.legend()
    ax.grid(axis="y", alpha=0.25)

    save_png_svg(fig, outdir / "compare_voxel_counts")


def plot_fsi(df, rois, outdir):
    fig, ax = plt.subplots(figsize=(9, 5), layout="constrained")

    x = np.arange(len(rois))
    sessions = list(SESSIONS)
    width = 0.22

    for i, ses in enumerate(sessions):
        sub = df[df["session"] == ses].set_index("roi").reindex(rois)
        vals = sub["fsi_raw"].astype(float).values
        xpos = x + (i - (len(sessions)-1)/2) * width
        ax.bar(xpos, vals, width=width, label=ses)

    ax.set_xticks(x)
    ax.set_xticklabels(rois)
    ax.set_ylabel("Raw FSI (mean upper-triangle Crossnobis distance)")
    ax.set_title("Finger Separation Index — full run combination")
    ax.legend()
    ax.grid(axis="y", alpha=0.25)

    save_png_svg(fig, outdir / "compare_fsi_full_combo")


def plot_split_reliability(df, rois, outdir):
    d = df[df["metric"] == "pearson"].copy()

    if d.empty:
        return

    splits = list(dict.fromkeys(d["split"]))
    fig, axes = plt.subplots(
        len(splits),
        1,
        figsize=(10, 4.2 * len(splits)),
        layout="constrained",
    )
    axes = np.atleast_1d(axes)

    for ax, split in zip(axes, splits):
        sub = d[d["split"] == split]
        x = np.arange(len(rois))
        width = 0.22

        for i, ses in enumerate(SESSIONS):
            vals = (
                sub[sub["session"] == ses]
                .set_index("roi")
                .reindex(rois)["value"]
                .astype(float)
                .values
            )
            xpos = x + (i - (len(SESSIONS)-1)/2) * width
            ax.bar(xpos, vals, width=width, label=ses)

        ax.set_xticks(x)
        ax.set_xticklabels(rois)
        ax.set_ylabel("Pearson reliability")
        ax.set_title(split.replace("_", " "))
        ax.set_ylim(-0.1, 1.05)
        ax.grid(axis="y", alpha=0.25)
        ax.legend()

    save_png_svg(fig, outdir / "compare_independent_split_reliability")


def plot_testretest(df, rois, outdir):
    wanted = ["pearson", "spearman", "icc", "cosine"]
    d = df[df["metric"].isin(wanted)].copy()

    if d.empty:
        return

    fig, ax = plt.subplots(figsize=(10, 5), layout="constrained")

    x = np.arange(len(wanted))
    width = min(0.24, 0.75 / len(rois))

    for i, roi in enumerate(rois):
        sub = d[d["roi"] == roi].set_index("metric").reindex(wanted)
        vals = sub["value"].astype(float).values
        xpos = x + (i - (len(rois)-1)/2) * width
        ax.bar(xpos, vals, width=width, label=roi)

    ax.set_xticks(x)
    ax.set_xticklabels(["Pearson", "Spearman", "ICC(2,1)", "Cosine"])
    ax.set_ylabel("Agreement")
    ax.set_ylim(-0.1, 1.05)
    ax.set_title("Same-resolution test–retest consistency")
    ax.legend()
    ax.grid(axis="y", alpha=0.25)

    save_png_svg(fig, outdir / "compare_test_retest")


def plot_rdm_geometry(df, rois, outdir):
    if df.empty:
        return

    pairs = list(
        dict.fromkeys(
            f"{a} vs {b}"
            for a, b in zip(df["roi_a"], df["roi_b"])
        )
    )

    fig, ax = plt.subplots(figsize=(10, 5), layout="constrained")

    x = np.arange(len(pairs))
    width = 0.22

    for i, ses in enumerate(SESSIONS):
        sub = df[df["session"] == ses].copy()
        sub["pair"] = sub["roi_a"] + " vs " + sub["roi_b"]
        vals = (
            sub.set_index("pair")
            .reindex(pairs)["pearson_rdm_geometry"]
            .astype(float)
            .values
        )
        xpos = x + (i - (len(SESSIONS)-1)/2) * width
        ax.bar(xpos, vals, width=width, label=ses)

    ax.set_xticks(x)
    ax.set_xticklabels(pairs, rotation=25, ha="right")
    ax.set_ylabel("Pearson correlation of full-combo RDM vectors")
    ax.set_ylim(-0.1, 1.05)
    ax.set_title("Representational geometry similarity across ROIs")
    ax.legend()
    ax.grid(axis="y", alpha=0.25)

    save_png_svg(fig, outdir / "compare_rdm_geometry")


def main():
    p = argparse.ArgumentParser()

    p.add_argument(
        "--manifest",
        type=Path,
        default=Path("participants.csv"),
    )
    p.add_argument(
        "--subject",
        default=DEFAULT_SUBJECT,
    )
    p.add_argument(
        "--rois",
        nargs=3,
        default=None,
        metavar=("COMBINED_M1", "ROI_4A", "ROI_4P"),
        help=(
            "Exact ROI names from participants.csv. "
            "If omitted, candidates are discovered automatically."
        ),
    )
    p.add_argument(
        "--first-level-root",
        type=Path,
        default=Path("results/first_level"),
    )
    p.add_argument(
        "--second-level-root",
        type=Path,
        default=Path("results/second_level"),
    )
    p.add_argument(
        "--out-dir",
        type=Path,
        default=Path("results/roi_comparisons/M1_subregions"),
    )

    args = p.parse_args()

    rois = (
        list(args.rois)
        if args.rois
        else discover_rois(args.manifest, args.subject)
    )

    print("ROIs:", rois)

    (
        voxel_df,
        fsi_df,
        split_df,
        testretest_df,
        rdm_df,
    ) = collect(
        args.subject,
        rois,
        args.first_level_root,
        args.second_level_root,
    )

    args.out_dir.mkdir(parents=True, exist_ok=True)

    voxel_df.to_csv(args.out_dir / "roi_voxel_qc.csv", index=False)
    fsi_df.to_csv(args.out_dir / "roi_fsi.csv", index=False)
    split_df.to_csv(
        args.out_dir / "roi_independent_split_reliability.csv",
        index=False,
    )
    testretest_df.to_csv(
        args.out_dir / "roi_test_retest.csv",
        index=False,
    )
    rdm_df.to_csv(
        args.out_dir / "roi_rdm_geometry.csv",
        index=False,
    )

    plot_voxels(voxel_df, rois, args.out_dir)
    plot_fsi(fsi_df, rois, args.out_dir)
    plot_split_reliability(split_df, rois, args.out_dir)
    plot_testretest(testretest_df, rois, args.out_dir)
    plot_rdm_geometry(rdm_df, rois, args.out_dir)

    print()
    print("Comparison complete.")
    print("Output:", args.out_dir)


if __name__ == "__main__":
    main()



