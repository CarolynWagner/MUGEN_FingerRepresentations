
#!/usr/bin/env python3
"""
uv_local_geometry.py

Continuous cortical-coordinate RSA analysis in an LN2 U-V sheet.

This script intentionally does NOT reimplement the validated RSA numerical core.
Instead, it consumes local/searchlight RDMs that have already been computed by
the validated RSA machinery and combines them with LN2 U/V coordinates.

Required local-RDM table
------------------------
CSV with one row per local neighborhood x finger pair, containing:

    session
    center_id
    u_mm
    v_mm
    finger_pair
    distance

Optional columns:
    n_voxels
    roi
    x_mm, y_mm, z_mm

Typical example:

session,center_id,u_mm,v_mm,finger_pair,distance,n_voxels
ses19,12345,-12.1,7.2,thumb-index,0.031,48
ses19,12345,-12.1,7.2,thumb-middle,0.018,48
...
ses20,12345,-12.0,7.1,thumb-index,0.029,51

The script:
1. builds the common finger geometry separately in ses19 and ses20;
2. decomposes every local 10-element RDM vector into:
       d_local = alpha * d_common + residual
3. maps:
       alpha(U,V)
       residual RMS(U,V)
       residual PC scores(U,V)
       individual finger-pair residuals(U,V)
4. estimates ses19<->ses20 spatial test-retest reliability by matching local
   samples in U-V space with a nearest-neighbour tolerance;
5. performs PCA/SVD on residual geometry after scale removal;
6. writes CSV tables and PNG/SVG figures.

This is a descriptive single-subject cortical-coordinate analysis.
No group-level inference is performed.

Example
-------
python uv_local_geometry.py \
    local_rdms_uv.csv \
    --sessions ses19 ses20 \
    --match-radius-mm 2.0 \
    --grid-step-mm 1.5
"""

from __future__ import annotations

import argparse
import math
from pathlib import Path

import numpy as np
import pandas as pd

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt


DEFAULT_SESSIONS = ("ses19", "ses20")


# -------------------------------------------------------------------------
# Utilities
# -------------------------------------------------------------------------

def pearson_safe(a, b):
    a = np.asarray(a, dtype=float).ravel()
    b = np.asarray(b, dtype=float).ravel()
    n = min(a.size, b.size)
    a, b = a[:n], b[:n]
    ok = np.isfinite(a) & np.isfinite(b)
    a, b = a[ok], b[ok]

    if len(a) < 3 or np.std(a) < 1e-12 or np.std(b) < 1e-12:
        return math.nan

    return float(np.corrcoef(a, b)[0, 1])


def fit_scale(reference, observed):
    x = np.asarray(reference, dtype=float)
    y = np.asarray(observed, dtype=float)

    ok = np.isfinite(x) & np.isfinite(y)
    x, y = x[ok], y[ok]

    if len(x) == 0:
        return math.nan

    denom = float(np.dot(x, x))

    if abs(denom) < 1e-15:
        return math.nan

    return float(np.dot(x, y) / denom)


def save_png_svg(fig, base: Path):
    base.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(base.with_suffix(".png"), dpi=300, bbox_inches="tight")
    fig.savefig(base.with_suffix(".svg"), bbox_inches="tight")
    plt.close(fig)


def require_columns(df, names):
    missing = [c for c in names if c not in df.columns]
    if missing:
        raise ValueError(
            f"Missing required columns: {missing}\n"
            f"Available columns: {list(df.columns)}"
        )


def regular_grid(df, value_col, step_mm):
    """
    Bin irregular U/V samples onto a regular grid using nanmean within cells.

    No interpolation across empty bins is performed: unsupported cortical
    locations remain NaN.
    """

    u = df["u_mm"].to_numpy(float)
    v = df["v_mm"].to_numpy(float)
    z = df[value_col].to_numpy(float)

    good = np.isfinite(u) & np.isfinite(v) & np.isfinite(z)
    u, v, z = u[good], v[good], z[good]

    if len(u) == 0:
        raise ValueError(f"No finite data for {value_col}")

    u_edges = np.arange(
        np.floor(u.min() / step_mm) * step_mm,
        np.ceil(u.max() / step_mm) * step_mm + step_mm,
        step_mm,
    )
    v_edges = np.arange(
        np.floor(v.min() / step_mm) * step_mm,
        np.ceil(v.max() / step_mm) * step_mm + step_mm,
        step_mm,
    )

    ui = np.clip(np.digitize(u, u_edges) - 1, 0, len(u_edges) - 2)
    vi = np.clip(np.digitize(v, v_edges) - 1, 0, len(v_edges) - 2)

    sums = np.zeros((len(v_edges) - 1, len(u_edges) - 1), dtype=float)
    counts = np.zeros_like(sums)

    for x, y, value in zip(ui, vi, z):
        sums[y, x] += value
        counts[y, x] += 1

    grid = np.full_like(sums, np.nan)
    ok = counts > 0
    grid[ok] = sums[ok] / counts[ok]

    u_centers = (u_edges[:-1] + u_edges[1:]) / 2
    v_centers = (v_edges[:-1] + v_edges[1:]) / 2

    return u_centers, v_centers, grid, counts


def plot_uv_map(df, value_col, title, cbar, base, step_mm,
                symmetric=False, fixed_range=None):

    u, v, grid, _ = regular_grid(df, value_col, step_mm)

    fig, ax = plt.subplots(figsize=(9, 7), layout="constrained")

    kwargs = dict(
        origin="lower",
        aspect="equal",
        extent=[u.min(), u.max(), v.min(), v.max()],
    )

    if fixed_range is not None:
        kwargs["vmin"], kwargs["vmax"] = fixed_range
    elif symmetric:
        lim = np.nanmax(np.abs(grid))
        if not np.isfinite(lim) or lim == 0:
            lim = 1
        kwargs["vmin"], kwargs["vmax"] = -lim, lim

    im = ax.imshow(grid, **kwargs)

    ax.set_xlabel("U (mm)")
    ax.set_ylabel("V (mm)")
    ax.set_title(title)

    cb = fig.colorbar(im, ax=ax)
    cb.set_label(cbar)

    save_png_svg(fig, base)


# -------------------------------------------------------------------------
# Local RDM assembly
# -------------------------------------------------------------------------

def build_local_vectors(df, sessions):
    require_columns(
        df,
        [
            "session",
            "center_id",
            "u_mm",
            "v_mm",
            "finger_pair",
            "distance",
        ],
    )

    pair_order = list(dict.fromkeys(df["finger_pair"].astype(str)))

    if len(pair_order) != 10:
        print(
            f"[WARNING] Expected 10 finger-pair distances for five fingers, "
            f"found {len(pair_order)}."
        )

    rows = []

    optional = [
        c for c in ("n_voxels", "roi", "x_mm", "y_mm", "z_mm")
        if c in df.columns
    ]

    for session in sessions:
        d = df[df["session"] == session].copy()

        for center_id, g in d.groupby("center_id"):
            vector = (
                g.set_index("finger_pair")
                .reindex(pair_order)["distance"]
                .to_numpy(dtype=float)
            )

            if not np.all(np.isfinite(vector)):
                continue

            row = {
                "session": session,
                "center_id": center_id,
                "u_mm": float(np.nanmean(g["u_mm"])),
                "v_mm": float(np.nanmean(g["v_mm"])),
            }

            for c in optional:
                if c == "roi":
                    values = g[c].dropna().astype(str)
                    row[c] = values.iloc[0] if len(values) else None
                else:
                    row[c] = float(np.nanmean(g[c]))

            for pair, value in zip(pair_order, vector):
                row[f"dist__{pair}"] = float(value)

            rows.append(row)

    wide = pd.DataFrame(rows)

    return wide, pair_order


# -------------------------------------------------------------------------
# Scale / shape decomposition
# -------------------------------------------------------------------------

def decompose(wide, pair_order, sessions):
    dist_cols = [f"dist__{p}" for p in pair_order]

    common = {}
    rows = []
    residual_rows = []

    for session in sessions:
        d = wide[wide["session"] == session]

        X = d[dist_cols].to_numpy(dtype=float)
        common_vec = np.nanmean(X, axis=0)
        common[session] = common_vec

        for _, r in d.iterrows():
            observed = r[dist_cols].to_numpy(dtype=float)
            alpha = fit_scale(common_vec, observed)
            predicted = alpha * common_vec
            residual = observed - predicted

            observed_rms = float(np.sqrt(np.mean(observed ** 2)))
            residual_rms = float(np.sqrt(np.mean(residual ** 2)))

            explained = (
                1.0 - np.sum(residual ** 2) / np.sum(observed ** 2)
                if np.sum(observed ** 2) > 0
                else math.nan
            )

            base = {
                "session": session,
                "center_id": r["center_id"],
                "u_mm": float(r["u_mm"]),
                "v_mm": float(r["v_mm"]),
                "alpha": alpha,
                "residual_rms": residual_rms,
                "relative_residual_rms": (
                    residual_rms / observed_rms
                    if observed_rms > 0
                    else math.nan
                ),
                "scale_explained_fraction": explained,
                "geometry_r_to_common": pearson_safe(
                    observed,
                    common_vec,
                ),
            }

            for c in ("n_voxels", "roi", "x_mm", "y_mm", "z_mm"):
                if c in wide.columns:
                    base[c] = r[c]

            rows.append(base)

            for pair, obs, pred, resid in zip(
                pair_order,
                observed,
                predicted,
                residual,
            ):
                residual_rows.append({
                    "session": session,
                    "center_id": r["center_id"],
                    "u_mm": float(r["u_mm"]),
                    "v_mm": float(r["v_mm"]),
                    "finger_pair": pair,
                    "observed_distance": float(obs),
                    "scale_prediction": float(pred),
                    "residual": float(resid),
                })

    return (
        pd.DataFrame(rows),
        pd.DataFrame(residual_rows),
        common,
    )


# -------------------------------------------------------------------------
# PCA / SVD of residual geometry
# -------------------------------------------------------------------------

def residual_pca(residuals, pair_order, sessions, n_components):
    """
    PCA is fit jointly across both matched-resolution sessions after scale
    removal. This gives a common residual basis so ses19 and ses20 PC scores
    are directly comparable.
    """

    pivot = residuals.pivot_table(
        index=["session", "center_id", "u_mm", "v_mm"],
        columns="finger_pair",
        values="residual",
        aggfunc="mean",
    ).reindex(columns=pair_order)

    X = pivot.to_numpy(dtype=float)

    good = np.all(np.isfinite(X), axis=1)
    pivot = pivot.iloc[good]
    X = X[good]

    # Residual vectors are already centered in scale-space, but center each
    # finger-pair feature across cortical locations for PCA.
    feature_mean = X.mean(axis=0)
    Xc = X - feature_mean

    U, S, VT = np.linalg.svd(Xc, full_matrices=False)

    k = min(n_components, VT.shape[0])

    scores = U[:, :k] * S[:k]
    loadings = VT[:k]

    variance = S ** 2
    explained = variance / variance.sum()

    score_df = pivot.reset_index()[
        ["session", "center_id", "u_mm", "v_mm"]
    ].copy()

    for i in range(k):
        score_df[f"resid_pc{i+1}"] = scores[:, i]

    loading_rows = []
    for i in range(k):
        for pair, loading in zip(pair_order, loadings[i]):
            loading_rows.append({
                "component": i + 1,
                "finger_pair": pair,
                "loading": float(loading),
                "explained_variance_fraction": float(explained[i]),
            })

    return (
        score_df,
        pd.DataFrame(loading_rows),
        feature_mean,
    )


# -------------------------------------------------------------------------
# Cross-session U-V matching / reliability
# -------------------------------------------------------------------------

def nearest_uv_matches(a, b, radius_mm):
    """
    Greedy nearest-neighbour matching in U-V space.

    Each ses20 center can be used at most once. This avoids artificially
    inflating reliability through many-to-one matching.
    """

    A = a[["center_id", "u_mm", "v_mm"]].reset_index(drop=True)
    B = b[["center_id", "u_mm", "v_mm"]].reset_index(drop=True)

    used_b = set()
    rows = []

    for ia, ra in A.iterrows():
        du = B["u_mm"].to_numpy(float) - float(ra["u_mm"])
        dv = B["v_mm"].to_numpy(float) - float(ra["v_mm"])
        dist = np.sqrt(du ** 2 + dv ** 2)

        order = np.argsort(dist)

        chosen = None
        for ib in order:
            if int(ib) in used_b:
                continue
            if dist[ib] <= radius_mm:
                chosen = int(ib)
                break

        if chosen is None:
            continue

        used_b.add(chosen)
        rb = B.iloc[chosen]

        rows.append({
            "center_id_a": ra["center_id"],
            "center_id_b": rb["center_id"],
            "u_a": ra["u_mm"],
            "v_a": ra["v_mm"],
            "u_b": rb["u_mm"],
            "v_b": rb["v_mm"],
            "uv_distance_mm": float(dist[chosen]),
        })

    return pd.DataFrame(rows)


def spatial_reliability(metrics, pc_scores, sessions, radius_mm):
    if len(sessions) != 2:
        raise ValueError("Spatial reliability requires exactly two sessions.")

    sa, sb = sessions

    A = metrics[metrics["session"] == sa].copy()
    B = metrics[metrics["session"] == sb].copy()

    matches = nearest_uv_matches(A, B, radius_mm)

    if matches.empty:
        raise RuntimeError(
            "No cross-session U-V matches found. Increase --match-radius-mm."
        )

    Aidx = A.set_index("center_id")
    Bidx = B.set_index("center_id")

    value_cols = [
        "alpha",
        "residual_rms",
        "relative_residual_rms",
        "scale_explained_fraction",
        "geometry_r_to_common",
    ]

    pcs = [
        c for c in pc_scores.columns
        if c.startswith("resid_pc")
    ]

    PA = (
        pc_scores[pc_scores["session"] == sa]
        .set_index("center_id")
    )
    PB = (
        pc_scores[pc_scores["session"] == sb]
        .set_index("center_id")
    )

    rows = []

    for variable in value_cols:
        xa, xb = [], []

        for _, m in matches.iterrows():
            ca = m["center_id_a"]
            cb = m["center_id_b"]

            if ca in Aidx.index and cb in Bidx.index:
                xa.append(float(Aidx.loc[ca, variable]))
                xb.append(float(Bidx.loc[cb, variable]))

        rows.append({
            "variable": variable,
            "n_matches": len(xa),
            "pearson": pearson_safe(xa, xb),
        })

    for variable in pcs:
        xa, xb = [], []

        for _, m in matches.iterrows():
            ca = m["center_id_a"]
            cb = m["center_id_b"]

            if ca in PA.index and cb in PB.index:
                xa.append(float(PA.loc[ca, variable]))
                xb.append(float(PB.loc[cb, variable]))

        rows.append({
            "variable": variable,
            "n_matches": len(xa),
            "pearson": pearson_safe(xa, xb),
        })

    return matches, pd.DataFrame(rows)


def residual_profile_reliability(residuals, matches, pair_order, sessions):
    sa, sb = sessions

    A = (
        residuals[residuals["session"] == sa]
        .pivot_table(
            index="center_id",
            columns="finger_pair",
            values="residual",
        )
        .reindex(columns=pair_order)
    )

    B = (
        residuals[residuals["session"] == sb]
        .pivot_table(
            index="center_id",
            columns="finger_pair",
            values="residual",
        )
        .reindex(columns=pair_order)
    )

    rows = []

    for _, m in matches.iterrows():
        ca = m["center_id_a"]
        cb = m["center_id_b"]

        if ca not in A.index or cb not in B.index:
            continue

        va = A.loc[ca].to_numpy(float)
        vb = B.loc[cb].to_numpy(float)

        rows.append({
            "center_id_a": ca,
            "center_id_b": cb,
            "u_mid": (m["u_a"] + m["u_b"]) / 2,
            "v_mid": (m["v_a"] + m["v_b"]) / 2,
            "uv_distance_mm": m["uv_distance_mm"],
            "residual_profile_pearson": pearson_safe(va, vb),
        })

    return pd.DataFrame(rows)


# -------------------------------------------------------------------------
# Figures
# -------------------------------------------------------------------------

def make_maps(metrics, residuals, pc_scores, pair_order, sessions,
              out_dir, grid_step_mm):

    figures = out_dir / "figures"

    for session in sessions:
        m = metrics[metrics["session"] == session]

        plot_uv_map(
            m,
            "alpha",
            f"{session}: local representational scale α",
            "α",
            figures / f"{session}_uv_alpha",
            grid_step_mm,
        )

        plot_uv_map(
            m,
            "relative_residual_rms",
            f"{session}: scale-free geometric deformation magnitude",
            "Residual RMS / observed RMS",
            figures / f"{session}_uv_relative_deformation",
            grid_step_mm,
        )

        plot_uv_map(
            m,
            "geometry_r_to_common",
            f"{session}: similarity to common finger geometry",
            "Pearson r",
            figures / f"{session}_uv_geometry_to_common",
            grid_step_mm,
            fixed_range=(-1, 1),
        )

        p = pc_scores[pc_scores["session"] == session]

        for col in [
            c for c in p.columns
            if c.startswith("resid_pc")
        ]:
            plot_uv_map(
                p,
                col,
                f"{session}: residual geometry {col.upper()} score",
                f"{col.upper()} score",
                figures / f"{session}_uv_{col}",
                grid_step_mm,
                symmetric=True,
            )

        r = residuals[residuals["session"] == session]

        for pair in pair_order:
            rp = r[r["finger_pair"] == pair].copy()

            stem = (
                pair.replace("–", "_")
                .replace("-", "_")
                .replace(" ", "_")
            )

            plot_uv_map(
                rp,
                "residual",
                f"{session}: residual deformation — {pair}",
                "Residual Crossnobis distance",
                figures / f"{session}_residual_pair_{stem}",
                grid_step_mm,
                symmetric=True,
            )


def plot_pc_loadings(loadings, out_dir):
    figures = out_dir / "figures"

    for component, g in loadings.groupby("component"):
        g = g.copy()

        fig, ax = plt.subplots(figsize=(11, 5), layout="constrained")

        x = np.arange(len(g))

        ax.bar(x, g["loading"])

        ax.axhline(0, linewidth=0.8)

        ax.set_xticks(x)
        ax.set_xticklabels(
            g["finger_pair"],
            rotation=40,
            ha="right",
        )

        ev = g["explained_variance_fraction"].iloc[0]

        ax.set_ylabel("Loading")
        ax.set_title(
            f"Residual geometry PC{component} "
            f"(explained variance={ev:.3f})"
        )

        save_png_svg(
            fig,
            figures / f"residual_pc{component}_loadings",
        )


def plot_spatial_reliability(reliability, out_dir):
    fig, ax = plt.subplots(figsize=(10, 5), layout="constrained")

    x = np.arange(len(reliability))

    ax.bar(x, reliability["pearson"])

    ax.axhline(0, linewidth=0.8)

    ax.set_xticks(x)
    ax.set_xticklabels(
        reliability["variable"],
        rotation=35,
        ha="right",
    )

    ax.set_ylim(-1.05, 1.05)
    ax.set_ylabel("ses19 ↔ ses20 Pearson r")
    ax.set_title("Spatial test–retest reliability in U–V coordinates")

    save_png_svg(
        fig,
        out_dir / "figures" / "uv_spatial_test_retest_reliability",
    )


# -------------------------------------------------------------------------
# CLI
# -------------------------------------------------------------------------

def main():
    p = argparse.ArgumentParser()

    p.add_argument(
        "local_rdm_csv",
        type=Path,
        help=(
            "CSV with session, center_id, u_mm, v_mm, "
            "finger_pair, distance."
        ),
    )

    p.add_argument(
        "--sessions",
        nargs=2,
        default=list(DEFAULT_SESSIONS),
    )

    p.add_argument(
        "--match-radius-mm",
        type=float,
        default=2.0,
        help="Maximum U-V distance for ses19/ses20 center matching.",
    )

    p.add_argument(
        "--grid-step-mm",
        type=float,
        default=1.5,
        help="Display bin size for U-V maps.",
    )

    p.add_argument(
        "--n-residual-pcs",
        type=int,
        default=3,
    )

    p.add_argument(
        "--out-dir",
        type=Path,
        default=Path(
            "results/roi_comparisons/uv_local_geometry"
        ),
    )

    args = p.parse_args()
    sessions = list(args.sessions)

    df = pd.read_csv(args.local_rdm_csv)

    wide, pair_order = build_local_vectors(
        df,
        sessions,
    )

    metrics, residuals, common = decompose(
        wide,
        pair_order,
        sessions,
    )

    pc_scores, pc_loadings, feature_mean = residual_pca(
        residuals,
        pair_order,
        sessions,
        args.n_residual_pcs,
    )

    matches, spatial_rel = spatial_reliability(
        metrics,
        pc_scores,
        sessions,
        args.match_radius_mm,
    )

    residual_rel = residual_profile_reliability(
        residuals,
        matches,
        pair_order,
        sessions,
    )

    args.out_dir.mkdir(
        parents=True,
        exist_ok=True,
    )

    wide.to_csv(
        args.out_dir / "local_rdm_vectors.csv",
        index=False,
    )

    metrics.to_csv(
        args.out_dir / "local_scale_shape_metrics.csv",
        index=False,
    )

    residuals.to_csv(
        args.out_dir / "local_residual_geometry.csv",
        index=False,
    )

    pc_scores.to_csv(
        args.out_dir / "local_residual_pc_scores.csv",
        index=False,
    )

    pc_loadings.to_csv(
        args.out_dir / "local_residual_pc_loadings.csv",
        index=False,
    )

    matches.to_csv(
        args.out_dir / "uv_cross_session_matches.csv",
        index=False,
    )

    spatial_rel.to_csv(
        args.out_dir / "uv_spatial_test_retest.csv",
        index=False,
    )

    residual_rel.to_csv(
        args.out_dir / "uv_residual_profile_test_retest.csv",
        index=False,
    )

    common_df = pd.DataFrame(
        {
            "finger_pair": pair_order,
            **{
                session: common[session]
                for session in sessions
            },
        }
    )

    common_df.to_csv(
        args.out_dir / "uv_common_finger_geometry.csv",
        index=False,
    )

    make_maps(
        metrics,
        residuals,
        pc_scores,
        pair_order,
        sessions,
        args.out_dir,
        args.grid_step_mm,
    )

    plot_pc_loadings(
        pc_loadings,
        args.out_dir,
    )

    plot_spatial_reliability(
        spatial_rel,
        args.out_dir,
    )

    with (
        args.out_dir / "uv_local_geometry_summary.txt"
    ).open("w") as f:
        f.write("U-V LOCAL SENSORIMOTOR GEOMETRY ANALYSIS\n")
        f.write("=" * 80 + "\n\n")
        f.write(f"Sessions: {sessions}\n")
        f.write(
            f"Cross-session U-V match radius: "
            f"{args.match_radius_mm:.3f} mm\n"
        )
        f.write(
            f"Matched local centers: {len(matches)}\n\n"
        )

        f.write("MODEL\n")
        f.write("-" * 80 + "\n")
        f.write(
            "d_local,session = alpha_local,session * "
            "d_common,session + residual_local,session\n\n"
        )

        f.write("SPATIAL TEST-RETEST RELIABILITY\n")
        f.write("-" * 80 + "\n")
        f.write(
            spatial_rel.to_string(
                index=False
            )
        )
        f.write("\n\n")

        f.write(
            "LOCAL RESIDUAL-PROFILE TEST-RETEST\n"
        )
        f.write("-" * 80 + "\n")
        f.write(
            residual_rel[
                "residual_profile_pearson"
            ].describe().to_string()
        )
        f.write("\n\n")

        f.write("RESIDUAL PCA\n")
        f.write("-" * 80 + "\n")

        ev = (
            pc_loadings[
                ["component", "explained_variance_fraction"]
            ]
            .drop_duplicates()
            .sort_values("component")
        )

        f.write(ev.to_string(index=False))
        f.write("\n")

    print()
    print("=" * 80)
    print("U-V LOCAL SENSORIMOTOR GEOMETRY ANALYSIS")
    print("=" * 80)
    print("Input:", args.local_rdm_csv)
    print("Sessions:", sessions)
    print("Local centers:", len(wide))
    print("Finger pairs:", len(pair_order))
    print("Cross-session matched centers:", len(matches))
    print("Output:", args.out_dir)
    print()
    print("[DONE]")


if __name__ == "__main__":
    main()



