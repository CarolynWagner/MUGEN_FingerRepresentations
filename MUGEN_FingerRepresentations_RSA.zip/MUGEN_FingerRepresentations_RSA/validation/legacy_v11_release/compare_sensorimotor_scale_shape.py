#!/usr/bin/env python3
"""
compare_sensorimotor_scale_shape.py

Decompose sensorimotor finger-distance geometry into:

    d_roi,session = alpha_roi,session * d_common,session + residual_roi,session

where:
    alpha    = global representational scale relative to a common geometry
    residual = ROI-specific geometric deformation after removing scale

The script then quantifies:
    1. representational scale (alpha)
    2. proportion of geometry explained by scaling
    3. magnitude of residual deformation
    4. ses19 <-> ses20 reliability of residual deformation
    5. finger-pair-specific residual deformation
    6. similarity of residual deformation across ROIs

Designed for the matched-resolution ses19/ses20 sensorimotor comparison.

Expected input:
    results/sensorimotor_geometry/roi_session_finger_pair_distances.csv

Outputs:
    CSV tables
    PNG + SVG figures
    text summary

This is a descriptive single-subject analysis. No group-level inference is
performed here.
"""

from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt


DEFAULT_SESSIONS = ("ses19", "ses20")

DEFAULT_ROI_ORDER = [
    "M1",
    "M1_4a",
    "M1_4p",
    "S1",
    "S1_3a",
    "S1_3b",
    "S1_1",
    "S1_2",
]


# -------------------------------------------------------------------------
# Utilities
# -------------------------------------------------------------------------

def pearson_safe(x, y):
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)

    good = np.isfinite(x) & np.isfinite(y)
    x = x[good]
    y = y[good]

    if len(x) < 3:
        return np.nan

    if np.std(x) == 0 or np.std(y) == 0:
        return np.nan

    return float(np.corrcoef(x, y)[0, 1])


def cosine_safe(x, y):
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)

    good = np.isfinite(x) & np.isfinite(y)
    x = x[good]
    y = y[good]

    if len(x) == 0:
        return np.nan

    denom = np.linalg.norm(x) * np.linalg.norm(y)

    if denom == 0:
        return np.nan

    return float(np.dot(x, y) / denom)


def save_figure(fig, outdir, stem):
    outdir = Path(outdir)
    outdir.mkdir(parents=True, exist_ok=True)

    fig.savefig(
        outdir / f"{stem}.png",
        dpi=220,
        bbox_inches="tight",
    )

    fig.savefig(
        outdir / f"{stem}.svg",
        bbox_inches="tight",
    )

    plt.close(fig)


def identify_columns(df):
    """
    Allow a few sensible column-name variants.
    """

    candidates = {
        "roi": ["roi", "roi_name"],
        "session": ["session", "session_id"],
        "pair": ["finger_pair", "pair", "fingerpair"],
        "distance": [
            "distance",
            "crossnobis",
            "crossnobis_distance",
            "mean_distance",
            "rdm_distance",
        ],
    }

    found = {}

    for role, names in candidates.items():
        for name in names:
            if name in df.columns:
                found[role] = name
                break

    missing = [k for k in candidates if k not in found]

    if missing:
        raise ValueError(
            "Could not identify required columns "
            f"{missing}.\nAvailable columns:\n{list(df.columns)}"
        )

    return found


# -------------------------------------------------------------------------
# Construct ROI x finger-pair matrices
# -------------------------------------------------------------------------

def make_matrix(df, roi_col, session_col, pair_col, distance_col,
                session, roi_order, pair_order):

    d = df[df[session_col] == session].copy()

    pivot = d.pivot_table(
        index=roi_col,
        columns=pair_col,
        values=distance_col,
        aggfunc="mean",
    )

    rois = [r for r in roi_order if r in pivot.index]

    pivot = pivot.reindex(
        index=rois,
        columns=pair_order,
    )

    return pivot


# -------------------------------------------------------------------------
# Common geometry
# -------------------------------------------------------------------------

def compute_common_geometry(matrix, method="mean"):
    """
    Common geometry is estimated independently within each session.

    Default:
        arithmetic mean of the finger-pair distance vectors across ROIs.

    This intentionally preserves the absolute geometry before scale fitting.
    """

    X = matrix.to_numpy(dtype=float)

    if method == "mean":
        common = np.nanmean(X, axis=0)

    elif method == "median":
        common = np.nanmedian(X, axis=0)

    else:
        raise ValueError(f"Unknown common-geometry method: {method}")

    return common


# -------------------------------------------------------------------------
# Scale + shape decomposition
# -------------------------------------------------------------------------

def fit_scale(reference, observed):
    """
    Least-squares scaling through the origin:

        observed ~= alpha * reference

    alpha = (reference' observed) / (reference' reference)

    No intercept is fitted because zero Crossnobis distance has a meaningful
    zero point. An additive intercept would therefore obscure the intended
    scale-versus-shape decomposition.
    """

    reference = np.asarray(reference, dtype=float)
    observed = np.asarray(observed, dtype=float)

    good = np.isfinite(reference) & np.isfinite(observed)

    x = reference[good]
    y = observed[good]

    if len(x) == 0:
        return np.nan

    denom = np.dot(x, x)

    if denom == 0:
        return np.nan

    return float(np.dot(x, y) / denom)


def decompose_vector(reference, observed):
    reference = np.asarray(reference, dtype=float)
    observed = np.asarray(observed, dtype=float)

    alpha = fit_scale(reference, observed)

    predicted = alpha * reference
    residual = observed - predicted

    good = np.isfinite(observed) & np.isfinite(predicted)

    y = observed[good]
    yhat = predicted[good]
    resid = residual[good]

    ss_total_zero = np.sum(y ** 2)
    ss_resid = np.sum(resid ** 2)

    if ss_total_zero > 0:
        scale_explained_fraction = 1.0 - ss_resid / ss_total_zero
    else:
        scale_explained_fraction = np.nan

    residual_rms = np.sqrt(np.mean(resid ** 2))
    observed_rms = np.sqrt(np.mean(y ** 2))

    if observed_rms > 0:
        relative_residual_rms = residual_rms / observed_rms
    else:
        relative_residual_rms = np.nan

    return {
        "alpha": alpha,
        "predicted": predicted,
        "residual": residual,
        "scale_explained_fraction": scale_explained_fraction,
        "residual_rms": residual_rms,
        "relative_residual_rms": relative_residual_rms,
    }


# -------------------------------------------------------------------------
# Main analysis
# -------------------------------------------------------------------------

def run_analysis(df, sessions, roi_order, common_method):

    cols = identify_columns(df)

    roi_col = cols["roi"]
    session_col = cols["session"]
    pair_col = cols["pair"]
    distance_col = cols["distance"]

    available_sessions = set(df[session_col].astype(str))

    for ses in sessions:
        if ses not in available_sessions:
            raise ValueError(
                f"Requested session {ses!r} not present. "
                f"Available: {sorted(available_sessions)}"
            )

    # Preserve pair ordering from input.
    pair_order = list(dict.fromkeys(df[pair_col].astype(str)))

    matrices = {}
    common = {}

    for ses in sessions:
        matrices[ses] = make_matrix(
            df,
            roi_col,
            session_col,
            pair_col,
            distance_col,
            ses,
            roi_order,
            pair_order,
        )

        common[ses] = compute_common_geometry(
            matrices[ses],
            method=common_method,
        )

    # Only ROIs available in both matched-resolution sessions.
    common_rois = [
        roi for roi in roi_order
        if all(roi in matrices[s].index for s in sessions)
    ]

    decomposition_rows = []
    residual_rows = []

    for ses in sessions:

        matrix = matrices[ses]
        ref = common[ses]

        for roi in common_rois:

            observed = matrix.loc[roi].to_numpy(dtype=float)

            result = decompose_vector(ref, observed)

            decomposition_rows.append({
                "session": ses,
                "roi": roi,
                "alpha": result["alpha"],
                "scale_explained_fraction":
                    result["scale_explained_fraction"],
                "residual_rms":
                    result["residual_rms"],
                "relative_residual_rms":
                    result["relative_residual_rms"],
                "raw_geometry_correlation_with_common":
                    pearson_safe(observed, ref),
            })

            for pair, obs, pred, resid in zip(
                pair_order,
                observed,
                result["predicted"],
                result["residual"],
            ):
                residual_rows.append({
                    "session": ses,
                    "roi": roi,
                    "finger_pair": pair,
                    "observed_distance": obs,
                    "scale_prediction": pred,
                    "residual": resid,
                })

    decomposition = pd.DataFrame(decomposition_rows)
    residuals = pd.DataFrame(residual_rows)

    # -------------------------------------------------------------
    # Session reliability of ROI-specific residual geometry
    # -------------------------------------------------------------

    ses_a, ses_b = sessions

    reliability_rows = []

    for roi in common_rois:

        a = (
            residuals[
                (residuals["session"] == ses_a) &
                (residuals["roi"] == roi)
            ]
            .set_index("finger_pair")
            .reindex(pair_order)["residual"]
            .to_numpy(dtype=float)
        )

        b = (
            residuals[
                (residuals["session"] == ses_b) &
                (residuals["roi"] == roi)
            ]
            .set_index("finger_pair")
            .reindex(pair_order)["residual"]
            .to_numpy(dtype=float)
        )

        reliability_rows.append({
            "roi": roi,
            "session_a": ses_a,
            "session_b": ses_b,
            "residual_pearson": pearson_safe(a, b),
            "residual_cosine": cosine_safe(a, b),
            "residual_rms_session_a":
                float(np.sqrt(np.nanmean(a ** 2))),
            "residual_rms_session_b":
                float(np.sqrt(np.nanmean(b ** 2))),
        })

    reliability = pd.DataFrame(reliability_rows)

    # -------------------------------------------------------------
    # Mean residual profile across matched sessions
    # -------------------------------------------------------------

    mean_residual = (
        residuals
        .groupby(["roi", "finger_pair"], as_index=False)["residual"]
        .mean()
    )

    # -------------------------------------------------------------
    # Regional variability of residual geometry
    # -------------------------------------------------------------

    residual_pair_variation = (
        mean_residual
        .groupby("finger_pair")["residual"]
        .agg(["mean", "std", "min", "max"])
        .reset_index()
    )

    residual_pair_variation["range"] = (
        residual_pair_variation["max"] -
        residual_pair_variation["min"]
    )

    residual_pair_variation = residual_pair_variation.sort_values(
        "std",
        ascending=False,
    )

    # -------------------------------------------------------------
    # ROI-to-ROI similarity after scale removal
    # -------------------------------------------------------------

    residual_matrix = (
        mean_residual
        .pivot(
            index="roi",
            columns="finger_pair",
            values="residual",
        )
        .reindex(
            index=common_rois,
            columns=pair_order,
        )
    )

    residual_roi_corr = residual_matrix.T.corr(method="pearson")

    return {
        "columns": cols,
        "pair_order": pair_order,
        "roi_order": common_rois,
        "matrices": matrices,
        "common": common,
        "decomposition": decomposition,
        "residuals": residuals,
        "reliability": reliability,
        "mean_residual": mean_residual,
        "residual_pair_variation": residual_pair_variation,
        "residual_matrix": residual_matrix,
        "residual_roi_corr": residual_roi_corr,
    }


# -------------------------------------------------------------------------
# Figures
# -------------------------------------------------------------------------

def plot_scale(decomposition, sessions, roi_order, outdir):

    fig, ax = plt.subplots(figsize=(12, 6))

    x = np.arange(len(roi_order))
    width = 0.36

    for i, ses in enumerate(sessions):
        d = (
            decomposition[decomposition["session"] == ses]
            .set_index("roi")
            .reindex(roi_order)
        )

        ax.bar(
            x + (i - (len(sessions) - 1) / 2) * width,
            d["alpha"],
            width=width,
            label=ses,
        )

    ax.axhline(1.0, linestyle="--", linewidth=1)

    ax.set_xticks(x)
    ax.set_xticklabels(roi_order)
    ax.set_ylabel("Scale coefficient α")
    ax.set_title("Representational scale relative to common geometry")
    ax.legend()

    fig.tight_layout()

    save_figure(
        fig,
        outdir,
        "scale_coefficients",
    )


def plot_scale_explained(decomposition, sessions, roi_order, outdir):

    fig, ax = plt.subplots(figsize=(12, 6))

    x = np.arange(len(roi_order))
    width = 0.36

    for i, ses in enumerate(sessions):

        d = (
            decomposition[decomposition["session"] == ses]
            .set_index("roi")
            .reindex(roi_order)
        )

        ax.bar(
            x + (i - (len(sessions) - 1) / 2) * width,
            d["scale_explained_fraction"],
            width=width,
            label=ses,
        )

    ax.set_xticks(x)
    ax.set_xticklabels(roi_order)
    ax.set_ylabel("Fraction explained by scaling")
    ax.set_title(
        "How much of each ROI geometry is captured by global scaling"
    )
    ax.legend()

    fig.tight_layout()

    save_figure(
        fig,
        outdir,
        "scale_explained_fraction",
    )


def plot_relative_deformation(
    decomposition,
    sessions,
    roi_order,
    outdir,
):

    fig, ax = plt.subplots(figsize=(12, 6))

    x = np.arange(len(roi_order))
    width = 0.36

    for i, ses in enumerate(sessions):

        d = (
            decomposition[decomposition["session"] == ses]
            .set_index("roi")
            .reindex(roi_order)
        )

        ax.bar(
            x + (i - (len(sessions) - 1) / 2) * width,
            d["relative_residual_rms"],
            width=width,
            label=ses,
        )

    ax.set_xticks(x)
    ax.set_xticklabels(roi_order)
    ax.set_ylabel("Residual RMS / observed RMS")
    ax.set_title("ROI-specific geometric deformation after scale removal")
    ax.legend()

    fig.tight_layout()

    save_figure(
        fig,
        outdir,
        "relative_shape_deformation",
    )


def plot_residual_reliability(reliability, roi_order, outdir):

    d = reliability.set_index("roi").reindex(roi_order)

    fig, ax = plt.subplots(figsize=(12, 6))

    ax.bar(
        np.arange(len(roi_order)),
        d["residual_pearson"],
    )

    ax.axhline(0, linewidth=0.8)

    ax.set_xticks(np.arange(len(roi_order)))
    ax.set_xticklabels(roi_order)

    ax.set_ylim(-1.05, 1.05)

    ax.set_ylabel("Pearson correlation")
    ax.set_title(
        "ses19 ↔ ses20 reliability of residual ROI-specific geometry"
    )

    fig.tight_layout()

    save_figure(
        fig,
        outdir,
        "residual_geometry_session_reliability",
    )


def plot_residual_heatmap(
    residual_matrix,
    pair_order,
    roi_order,
    outdir,
):

    matrix = (
        residual_matrix
        .reindex(index=roi_order, columns=pair_order)
        .to_numpy(dtype=float)
    )

    vmax = np.nanmax(np.abs(matrix))

    if not np.isfinite(vmax) or vmax == 0:
        vmax = 1.0

    fig, ax = plt.subplots(figsize=(15, 7))

    im = ax.imshow(
        matrix,
        aspect="auto",
        cmap="coolwarm",
        vmin=-vmax,
        vmax=vmax,
    )

    ax.set_xticks(np.arange(len(pair_order)))
    ax.set_xticklabels(
        pair_order,
        rotation=45,
        ha="right",
    )

    ax.set_yticks(np.arange(len(roi_order)))
    ax.set_yticklabels(roi_order)

    ax.set_title(
        "ROI-specific finger-geometry deformation after removing scale"
    )

    cbar = fig.colorbar(im, ax=ax)
    cbar.set_label("Mean residual Crossnobis distance")

    fig.tight_layout()

    save_figure(
        fig,
        outdir,
        "residual_shape_heatmap",
    )


def plot_residual_roi_correlations(
    corr,
    roi_order,
    outdir,
):

    matrix = corr.reindex(
        index=roi_order,
        columns=roi_order,
    ).to_numpy(dtype=float)

    fig, ax = plt.subplots(figsize=(9, 8))

    im = ax.imshow(
        matrix,
        cmap="coolwarm",
        vmin=-1,
        vmax=1,
    )

    ax.set_xticks(np.arange(len(roi_order)))
    ax.set_xticklabels(
        roi_order,
        rotation=45,
        ha="right",
    )

    ax.set_yticks(np.arange(len(roi_order)))
    ax.set_yticklabels(roi_order)

    for i in range(len(roi_order)):
        for j in range(len(roi_order)):
            value = matrix[i, j]

            if np.isfinite(value):
                ax.text(
                    j,
                    i,
                    f"{value:.2f}",
                    ha="center",
                    va="center",
                    fontsize=9,
                )

    ax.set_title(
        "Similarity of ROI-specific deformations after scale removal"
    )

    cbar = fig.colorbar(im, ax=ax)
    cbar.set_label("Pearson r")

    fig.tight_layout()

    save_figure(
        fig,
        outdir,
        "residual_roi_geometry_correlation",
    )


def plot_pair_variation(pair_variation, outdir):

    d = pair_variation.sort_values(
        "std",
        ascending=False,
    )

    fig, ax = plt.subplots(figsize=(12, 6))

    ax.bar(
        np.arange(len(d)),
        d["std"],
    )

    ax.set_xticks(np.arange(len(d)))
    ax.set_xticklabels(
        d["finger_pair"],
        rotation=45,
        ha="right",
    )

    ax.set_ylabel("SD of residual across ROIs")

    ax.set_title(
        "Finger pairs with strongest regional deformation "
        "after scale removal"
    )

    fig.tight_layout()

    save_figure(
        fig,
        outdir,
        "residual_finger_pair_regional_variation",
    )


def plot_common_geometries(
    common,
    sessions,
    pair_order,
    outdir,
):

    fig, ax = plt.subplots(figsize=(13, 6))

    x = np.arange(len(pair_order))

    for ses in sessions:
        ax.plot(
            x,
            common[ses],
            marker="o",
            label=ses,
        )

    ax.set_xticks(x)
    ax.set_xticklabels(
        pair_order,
        rotation=45,
        ha="right",
    )

    ax.set_ylabel("Mean Crossnobis distance")
    ax.set_title("Common sensorimotor finger geometry")
    ax.legend()

    fig.tight_layout()

    save_figure(
        fig,
        outdir,
        "common_finger_geometry",
    )


# -------------------------------------------------------------------------
# Text report
# -------------------------------------------------------------------------

def write_report(results, sessions, outfile):

    decomposition = results["decomposition"]
    reliability = results["reliability"]
    variation = results["residual_pair_variation"]

    with open(outfile, "w") as f:

        f.write(
            "SENSORIMOTOR SCALE / SHAPE DECOMPOSITION\n"
        )
        f.write("=" * 80 + "\n\n")

        f.write(
            f"Matched-resolution sessions: {list(sessions)}\n"
        )
        f.write(
            "Descriptive single-subject analysis; "
            "no group-level inference.\n\n"
        )

        f.write(
            "MODEL\n"
            "-----\n"
            "d_roi,session = alpha_roi,session * "
            "d_common,session + residual_roi,session\n\n"
        )

        f.write(
            "alpha quantifies representational expansion/compression.\n"
        )
        f.write(
            "Residuals quantify finger-pair-specific geometric "
            "deformation after removing global scale.\n\n"
        )

        f.write(
            "SCALE AND DEFORMATION\n"
        )
        f.write("-" * 80 + "\n")

        show = decomposition[
            [
                "session",
                "roi",
                "alpha",
                "scale_explained_fraction",
                "relative_residual_rms",
                "raw_geometry_correlation_with_common",
            ]
        ]

        f.write(
            show.to_string(
                index=False,
                float_format=lambda x: f"{x:.6f}",
            )
        )

        f.write("\n\n")

        f.write(
            f"{sessions[0]}-{sessions[1]} "
            "RESIDUAL-GEOMETRY RELIABILITY\n"
        )
        f.write("-" * 80 + "\n")

        f.write(
            reliability.to_string(
                index=False,
                float_format=lambda x: f"{x:.6f}",
            )
        )

        f.write("\n\n")

        f.write(
            "FINGER PAIRS WITH STRONGEST REGIONAL "
            "DEFORMATION AFTER SCALE REMOVAL\n"
        )
        f.write("-" * 80 + "\n")

        f.write(
            variation.to_string(
                index=False,
                float_format=lambda x: f"{x:.6f}",
            )
        )

        f.write("\n")


# -------------------------------------------------------------------------
# CLI
# -------------------------------------------------------------------------

def main():

    parser = argparse.ArgumentParser(
        description=(
            "Decompose matched-resolution sensorimotor RDM geometry "
            "into global scale and ROI-specific shape deformation."
        )
    )

    parser.add_argument(
        "input_csv",
        help="roi_session_finger_pair_distances.csv",
    )

    parser.add_argument(
        "--out-dir",
        default="results/sensorimotor_scale_shape",
    )

    parser.add_argument(
        "--sessions",
        nargs=2,
        default=list(DEFAULT_SESSIONS),
        metavar=("SESSION_A", "SESSION_B"),
    )

    parser.add_argument(
        "--common-method",
        choices=["mean", "median"],
        default="mean",
    )

    args = parser.parse_args()

    input_csv = Path(args.input_csv)
    outdir = Path(args.out_dir)

    outdir.mkdir(
        parents=True,
        exist_ok=True,
    )

    figures_dir = outdir / "figures"

    df = pd.read_csv(input_csv)

    results = run_analysis(
        df=df,
        sessions=tuple(args.sessions),
        roi_order=DEFAULT_ROI_ORDER,
        common_method=args.common_method,
    )

    # -------------------------------------------------------------
    # Tables
    # -------------------------------------------------------------

    results["decomposition"].to_csv(
        outdir / "roi_scale_shape_decomposition.csv",
        index=False,
    )

    results["residuals"].to_csv(
        outdir / "roi_session_residual_geometry.csv",
        index=False,
    )

    results["reliability"].to_csv(
        outdir / "roi_residual_geometry_reliability.csv",
        index=False,
    )

    results["mean_residual"].to_csv(
        outdir / "roi_mean_residual_geometry.csv",
        index=False,
    )

    results["residual_pair_variation"].to_csv(
        outdir / "residual_finger_pair_regional_variation.csv",
        index=False,
    )

    results["residual_matrix"].to_csv(
        outdir / "roi_residual_geometry_matrix.csv",
    )

    results["residual_roi_corr"].to_csv(
        outdir / "roi_residual_geometry_correlations.csv",
    )

    # Common geometries
    common_df = pd.DataFrame(
        {
            "finger_pair": results["pair_order"],
            **{
                ses: results["common"][ses]
                for ses in args.sessions
            },
        }
    )

    common_df.to_csv(
        outdir / "common_finger_geometry.csv",
        index=False,
    )

    # -------------------------------------------------------------
    # Figures
    # -------------------------------------------------------------

    plot_scale(
        results["decomposition"],
        args.sessions,
        results["roi_order"],
        figures_dir,
    )

    plot_scale_explained(
        results["decomposition"],
        args.sessions,
        results["roi_order"],
        figures_dir,
    )

    plot_relative_deformation(
        results["decomposition"],
        args.sessions,
        results["roi_order"],
        figures_dir,
    )

    plot_residual_reliability(
        results["reliability"],
        results["roi_order"],
        figures_dir,
    )

    plot_residual_heatmap(
        results["residual_matrix"],
        results["pair_order"],
        results["roi_order"],
        figures_dir,
    )

    plot_residual_roi_correlations(
        results["residual_roi_corr"],
        results["roi_order"],
        figures_dir,
    )

    plot_pair_variation(
        results["residual_pair_variation"],
        figures_dir,
    )

    plot_common_geometries(
        results["common"],
        args.sessions,
        results["pair_order"],
        figures_dir,
    )

    # -------------------------------------------------------------
    # Report
    # -------------------------------------------------------------

    report_file = outdir / "sensorimotor_scale_shape_summary.txt"

    write_report(
        results,
        tuple(args.sessions),
        report_file,
    )

    print("=" * 79)
    print("SENSORIMOTOR SCALE / SHAPE DECOMPOSITION")
    print("=" * 79)
    print(f"Input: {input_csv}")
    print(f"Sessions: {args.sessions}")
    print(f"ROIs: {results['roi_order']}")
    print(f"Finger pairs: {len(results['pair_order'])}")
    print()
    print(f"Output directory: {outdir}")
    print(f"Figures: {figures_dir}")
    print(f"Report: {report_file}")
    print()
    print("[DONE]")


if __name__ == "__main__":
    main()
