#!/usr/bin/env python3
"""Production preflight for one v12 manifest."""
from __future__ import annotations
import argparse,csv
from pathlib import Path
import nibabel as nib
import pandas as pd

EXPECTED={"thumb","index","middle","ring","little"}

def main():
  ap=argparse.ArgumentParser(); ap.add_argument("manifest",type=Path); a=ap.parse_args()
  rows=list(csv.DictReader(a.manifest.open()))
  errors=[]
  for r in rows:
    tag=f"{r['subject']} {r['session']} {r['roi_name']}"
    md=Path(r["model_dir"]); lp=Path(r["beta_lookup"]); rp=Path(r["roi_path"])
    if not md.is_dir(): errors.append(f"{tag}: missing model_dir {md}"); continue
    if not lp.is_file(): errors.append(f"{tag}: missing beta_lookup {lp}"); continue
    if not rp.is_file(): errors.append(f"{tag}: missing ROI {rp}"); continue
    t=pd.read_csv(lp,sep="\t")
    req={"run","condition","beta_file"}
    if not req.issubset(t.columns):
      errors.append(f"{tag}: beta_lookup missing columns {sorted(req-set(t.columns))}"); continue
    cond=set(t["condition"].astype(str))
    if cond != EXPECTED: errors.append(f"{tag}: conditions={sorted(cond)} expected={sorted(EXPECTED)}")
    runs=sorted(t["run"].astype(int).unique())
    if runs != [1,2,3,4,5,6]: errors.append(f"{tag}: runs={runs}, expected 1..6")
    if len(t)!=30: errors.append(f"{tag}: beta_lookup has {len(t)} rows, expected 30")
    missing=[md/str(x) for x in t["beta_file"] if not (md/str(x)).is_file()]
    if missing: errors.append(f"{tag}: {len(missing)} beta files missing")
    residuals=list(md.glob("Res_*.nii"))+list(md.glob("Res_*.nii.gz"))
    if not residuals: errors.append(f"{tag}: no residual images")
    if not missing and len(t):
      b=nib.load(str(md/str(t.iloc[0]["beta_file"])))
      m=nib.load(str(rp))
      if b.shape[:3]!=m.shape[:3]: errors.append(f"{tag}: ROI/beta shape mismatch")
      import numpy as np
      if not np.allclose(b.affine,m.affine,atol=1e-4,rtol=0):
        errors.append(f"{tag}: ROI/beta affine mismatch")
  if errors:
    print("PREFLIGHT: FAIL")
    for e in errors: print(" -",e)
    raise SystemExit(2)
  print(f"PREFLIGHT: PASS ({len(rows)} manifest rows)")

if __name__=="__main__": main()
