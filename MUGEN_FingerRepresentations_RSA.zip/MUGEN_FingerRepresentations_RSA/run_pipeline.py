#!/usr/bin/env python3
"""MUGEN Finger RSA v12 orchestration wrapper.

v12 changes orchestration/I/O only. The certified v11 numerical packages must
be installed into first_level/, second_level/, shared/, reporting/ before
production RSA is allowed.
"""
from __future__ import annotations
import argparse,csv,os,subprocess,sys
from pathlib import Path
from adapters.mugen_inputs import normalize_subject, normalize_session

ROOT=Path(__file__).resolve().parent
VALID_ROIS=("M1","M1_legacy","M1_4a","M1_4p","S1","S1_3a","S1_3b","S1_1","S1_2")

def die(x): raise SystemExit("ERROR: "+x)

def require_core():
  required=[
    ROOT/"first_level"/"run_first_level.py",
    ROOT/"second_level"/"run_second_level.py",
    ROOT/"reporting"/"generate_full_reports.py",
  ]
  missing=[p for p in required if not p.is_file()]
  if missing:
    die("Certified numerical/reporting core is not installed:\n  "+"\n  ".join(map(str,missing))+
        "\nUse scripts/install_certified_v11_core.py against the COMPLETE certified v11 installation.")

def main():
  ap=argparse.ArgumentParser()
  st=ap.add_mutually_exclusive_group(required=True)
  st.add_argument("--first-level",action="store_true"); st.add_argument("--second-level",action="store_true")
  ap.add_argument("--mugen-root",type=Path,required=True)
  ap.add_argument("--subject",required=True); ap.add_argument("--session")
  ap.add_argument("--roi",choices=VALID_ROIS,required=True)
  ap.add_argument("--manifest",type=Path); ap.add_argument("--n-boot",type=int,default=2000)
  ap.add_argument("--dry-run",action="store_true")
  a=ap.parse_args()
  require_core()
  sub=normalize_subject(a.subject); ses=normalize_session(a.session) if a.session else None
  manifest=a.manifest or a.mugen_root/"finger"/"derivatives"/"rsa"/"manifests"/"participants_v12.csv"
  if not manifest.is_file(): die(f"Manifest not found: {manifest}")
  rows=list(csv.DictReader(manifest.open()))
  sel=[r for r in rows if r["subject"]==sub and r["roi_name"]==a.roi and (not ses or r["session"]==ses)]
  if not sel: die("No manifest rows match selection")
  out=a.mugen_root/"finger"/"derivatives"/"rsa"
  selected=out/"manifests"/"_selected_manifest.csv"; selected.parent.mkdir(parents=True,exist_ok=True)
  with selected.open("w",newline="") as f:
    w=csv.DictWriter(f,fieldnames=rows[0].keys()); w.writeheader(); w.writerows(sel)
  print(f"RSA v12 | subject={sub} roi={a.roi} sessions={[r['session'] for r in sel]}")
  print(f"Output root: {out}")
  if a.dry_run: return
  py=sys.executable
  if a.first_level:
    subprocess.run([py,"-m","first_level.run_first_level","--manifest",str(selected),
                    "--out-root",str(out/"first_level"),"--n-boot",str(a.n_boot)],check=True,cwd=ROOT)
  else:
    inputs=[]
    for r in sel:
      p=out/"first_level"/r["subject"]/r["session"]/f"roi-{r['roi_name']}"/"rsa_firstlevel.pkl"
      if not p.is_file(): die(f"Missing first-level input: {p}")
      inputs.append(str(p))
    scoped=out/"second_level"/sub/f"roi-{a.roi}"; scoped.mkdir(parents=True,exist_ok=True)
    subprocess.run([py,"-m","second_level.run_second_level",*inputs,"--out-dir",str(scoped)],check=True,cwd=ROOT)

if __name__=="__main__": main()
