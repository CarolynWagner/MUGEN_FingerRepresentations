"""Shared constants for RSA v11 generalized."""
PIPELINE_VERSION = "v11.0-generalized-crossnobis"
SCHEMA_VERSION_FIRST_LEVEL = "finger_rsa_firstlevel_v11.0"
SCHEMA_VERSION_SECOND_LEVEL = "finger_rsa_secondlevel_v11.0"
FINGER_NAMES = ["thumb", "index", "middle", "ring", "little"]
N_FINGERS = 5
N_MOTION = 6
N_COLS_PER_RUN = N_FINGERS + N_MOTION
N_RUNS_TOTAL = 6
RUN_COMBOS = {
    "run1-2": [1, 2],
    "run1-3": [1, 2, 3],
    "run1-4": [1, 2, 3, 4],
    "run1-5": [1, 2, 3, 4, 5],
    "run1-6": [1, 2, 3, 4, 5, 6],
    "run1_and_3": [1, 3],
    "run4-6": [4, 5, 6],
    "odd_runs-1-3-5": [1, 3, 5],
    "even_runs-2-4-6": [2, 4, 6],
}
INDEPENDENT_SPLITS = {
    "first_half_vs_second_half": ("run1-3", "run4-6"),
    "odd_vs_even": ("odd_runs-1-3-5", "even_runs-2-4-6"),
}
FULL_COMBO_LABEL = "run1-6"
RESIDUAL_STD_EPS = 1e-8
RANDOM_SEED = 20250622
N_RUN_PAIR_BOOTSTRAPS = 2000
