"""Load the frozen v10.3 numerical modules without renaming them."""
from __future__ import annotations
import importlib.util
from pathlib import Path

BASE = Path(__file__).resolve().parent / "frozen_algorithms"

def load(alias: str, filename: str):
    path = BASE / filename
    spec = importlib.util.spec_from_file_location(alias, path)
    if spec is None or spec.loader is None:
        raise ImportError(f"Cannot load {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module
