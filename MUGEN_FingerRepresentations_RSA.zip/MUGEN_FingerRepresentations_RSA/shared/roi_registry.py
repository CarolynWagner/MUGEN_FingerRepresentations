"""ROI metadata normalization.

ROI is an explicit analysis dimension. The built-in names are conventions only;
custom ROIs are supported without changing the numerical RSA implementation.
"""
from __future__ import annotations

BUILTIN = {
    "M1_old": {"family": "M1", "version": "legacy", "description": "Frozen v10.3 M1 hand-knob definition."},
    "M1_new": {"family": "M1", "version": "current", "description": "Current/improved M1 hand-knob definition."},
    "S1": {"family": "S1", "version": "composite", "description": "Composite primary somatosensory cortex ROI."},
    "S1_3a": {"family": "S1", "version": "current", "description": "S1 area 3a."},
    "S1_3b": {"family": "S1", "version": "current", "description": "S1 area 3b."},
    "S1_1": {"family": "S1", "version": "current", "description": "S1 area 1."},
    "S1_2": {"family": "S1", "version": "current", "description": "S1 area 2."},
}

def normalize_roi_metadata(row):
    name = str(row["roi_name"])
    meta = dict(BUILTIN.get(name, {}))
    meta["name"] = name
    meta["family"] = str(row.get("roi_family") or meta.get("family") or name)
    meta["version"] = str(row.get("roi_version") or meta.get("version") or "unspecified")
    meta["hemisphere"] = str(row.get("hemisphere") or "left")
    meta["definition_method"] = str(row.get("roi_definition_method") or "unspecified")
    meta["source_space"] = str(row.get("roi_source_space") or "unspecified")
    meta["analysis_space"] = str(row.get("roi_analysis_space") or "native_bold")
    meta["mask_path"] = str(row["roi_path"])
    return meta
