"""Metric wrappers reusing the frozen v10.3 definitions."""
from .module_loader import load
_m = load("v11_stability05", "05_run_subset_stability.py")
upper_vec = _m.upper_vec
pearson = _m.pearson
spearman = _m.spearman
fisherz_metric = _m.fisherz_metric
icc_2_1 = _m.icc_2_1
cosine = _m.cosine
metric_functions = _m.metric_functions
