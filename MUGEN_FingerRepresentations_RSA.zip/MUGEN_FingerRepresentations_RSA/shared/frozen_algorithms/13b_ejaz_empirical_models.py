"""Empirical Ejaz-model import, validation, and RSA fitting.

This module does not fabricate the empirical hand-use, muscle, or somatotopy
values. It consumes user-supplied source-data tables and converts them to 5x5
model RDMs in the package finger order.

Accepted CSV columns:
    finger_a,finger_b,value
Optional columns:
    model,value_type,transform,source
value_type: similarity | dissimilarity
transform for similarity: one_minus | negative | max_minus (default one_minus)
All ten unordered finger pairs must occur exactly once per model.
"""
from __future__ import annotations
from pathlib import Path
import json, os
import numpy as np
import pandas as pd

FINGERS=['thumb','index','middle','ring','little']
PAIR_SET={tuple(sorted(x)) for i,a in enumerate(FINGERS) for x in [(a,b) for b in FINGERS[i+1:]]}


def _canon(x):
    x=str(x).strip().lower(); aliases={'d1':'thumb','d2':'index','d3':'middle','d4':'ring','d5':'little','pinky':'little'}
    return aliases.get(x,x)


def validate_pair_table(df,model_name):
    req={'finger_a','finger_b','value'}
    missing=req-set(df.columns)
    if missing: raise ValueError(f'{model_name}: missing columns {sorted(missing)}')
    pairs=[]
    for _,r in df.iterrows():
        a,b=_canon(r.finger_a),_canon(r.finger_b)
        if a==b or a not in FINGERS or b not in FINGERS: raise ValueError(f'{model_name}: invalid pair {a},{b}')
        pairs.append(tuple(sorted((a,b))))
    if len(pairs)!=10 or set(pairs)!=PAIR_SET or len(set(pairs))!=10:
        raise ValueError(f'{model_name}: expected exactly the ten unique unordered finger pairs; got {len(pairs)} rows and {len(set(pairs))} unique pairs')
    if not np.isfinite(pd.to_numeric(df.value,errors='coerce')).all(): raise ValueError(f'{model_name}: nonnumeric/nonfinite values')


def table_to_rdm(df,model_name=None,value_type=None,transform=None):
    if model_name is None: model_name=str(df.model.iloc[0]) if 'model' in df else 'model'
    validate_pair_table(df,model_name)
    vt=(value_type or (str(df.value_type.iloc[0]) if 'value_type' in df else 'dissimilarity')).lower()
    tr=(transform or (str(df['transform'].iloc[0]) if 'transform' in df else 'one_minus')).lower()
    vals=pd.to_numeric(df.value).to_numpy(float)
    if vt=='similarity':
        if tr=='one_minus': vals=1.0-vals
        elif tr=='negative': vals=-vals
        elif tr=='max_minus': vals=np.max(vals)-vals
        else: raise ValueError(f'{model_name}: unknown similarity transform {tr}')
    elif vt!='dissimilarity': raise ValueError(f'{model_name}: value_type must be similarity or dissimilarity')
    mat=np.zeros((5,5),float); idx={f:i for i,f in enumerate(FINGERS)}
    for (_,r),v in zip(df.iterrows(),vals):
        i,j=idx[_canon(r.finger_a)],idx[_canon(r.finger_b)]; mat[i,j]=mat[j,i]=v
    return mat,{'model':model_name,'value_type':vt,'transform':tr,'finger_order':FINGERS}


def load_empirical_models(path):
    path=Path(path); df=pd.read_csv(path)
    if 'model' not in df: raise ValueError('Combined empirical-model CSV requires a model column')
    models={}; meta={}
    for name,g in df.groupby('model',sort=False): models[name],meta[name]=table_to_rdm(g.copy(),str(name))
    required={'hand_use','muscle','somatotopy'}
    missing=required-set(models)
    if missing: raise ValueError(f'Missing required empirical models: {sorted(missing)}')
    return models,meta


def upper_vec(x): return np.asarray(x,float)[np.triu_indices(5,1)]

def corr(a,b,kind='pearson'):
    a,b=upper_vec(a),upper_vec(b)
    if kind=='spearman':
        from scipy.stats import rankdata; a,b=rankdata(a),rankdata(b)
    if np.std(a)==0 or np.std(b)==0:return 0.0
    return float(np.corrcoef(a,b)[0,1])


def fit_empirical_models(contract,csv_path,out_dir):
    models,meta=load_empirical_models(csv_path); out_dir=Path(out_dir); out_dir.mkdir(parents=True,exist_ok=True)
    rows=[]
    for ses in contract['session_ids']:
        for combo in contract['run_combos']:
            neural=contract['rdms'][ses][combo]['raw']
            for name,m in models.items():
                rows.append({'session':ses,'combo':combo,'model':name,'pearson':corr(neural,m,'pearson'),'spearman':corr(neural,m,'spearman')})
    pd.DataFrame(rows).to_csv(out_dir/'ejaz_empirical_model_rsa.csv',index=False)
    np.savez(out_dir/'ejaz_empirical_model_rdms.npz',**models)
    (out_dir/'ejaz_empirical_model_metadata.json').write_text(json.dumps(meta,indent=2))
    return {'models':models,'metadata':meta,'results':pd.DataFrame(rows)}


def write_template(path):
    rows=[]
    for model in ['hand_use','muscle','somatotopy']:
        for i,a in enumerate(FINGERS):
            for b in FINGERS[i+1:]:
                rows.append({'model':model,'finger_a':a,'finger_b':b,'value':'','value_type':'dissimilarity','transform':'one_minus','source':''})
    pd.DataFrame(rows).to_csv(path,index=False)

if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser(); p.add_argument('--write-template'); p.add_argument('--validate')
    a=p.parse_args()
    if a.write_template: write_template(a.write_template); print(a.write_template)
    if a.validate:
        models,meta=load_empirical_models(a.validate); print('Validated:',', '.join(models))
