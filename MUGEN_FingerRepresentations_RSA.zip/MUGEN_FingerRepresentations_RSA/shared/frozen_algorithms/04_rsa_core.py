"""
04_rsa_core.py
rsatoolbox-native crossnobis RSA core.

This preserves the known-good diagnostic pathway:
    - load all betas/residuals from the same run1-6 model
    - remove bad voxels consistently
    - compute precision once from full residuals with shrinkage_diag
    - compute crossnobis RDMs using run_number as cv_descriptor
"""

from __future__ import annotations

import warnings
from typing import Dict, List

import numpy as np
import rsatoolbox as rsa


def build_dataset(betas_subset: np.ndarray, finger_names: List[str], run_indices_1based: List[int], roi_name: str = 'M1'):
    n_sel = betas_subset.shape[0]
    n_voxels = betas_subset.shape[2]
    measurements = np.asarray(betas_subset.reshape(n_sel * len(finger_names), n_voxels), dtype=np.float64)
    conditions = np.tile(finger_names, n_sel)
    run_labels = np.repeat(run_indices_1based, len(finger_names))

    if not np.isfinite(measurements).all():
        raise ValueError('Dataset measurements contain nonfinite values before RSA.')

    return rsa.data.Dataset(
        measurements,
        descriptors={'roi': roi_name},
        obs_descriptors={'condition': conditions, 'run_number': run_labels},
        channel_descriptors={'voxel': np.arange(n_voxels)},
    )


def stable_precision_fallback(residuals: np.ndarray, eps: float = 1e-10, ridge: float = 0.25) -> np.ndarray:
    res = np.asarray(residuals, dtype=np.float64)
    res = res - res.mean(axis=0, keepdims=True)
    cov = np.cov(res, rowvar=False)
    cov = 0.5 * (cov + cov.T)
    eigvals, eigvecs = np.linalg.eigh(cov)
    eigvals = np.clip(eigvals, eps, None)
    cov = eigvecs @ np.diag(eigvals) @ eigvecs.T
    cov += np.eye(cov.shape[0]) * (np.trace(cov) / cov.shape[0]) * ridge
    prec = np.linalg.pinv(cov)
    if not np.isfinite(prec).all():
        raise ValueError('Fallback precision matrix is nonfinite.')
    return prec


def compute_precision(residuals_clean: np.ndarray, dof: int, prefer_rsatoolbox: bool = True) -> Dict:
    if not np.isfinite(residuals_clean).all():
        raise ValueError('Residuals contain nonfinite values before precision estimation.')
    if dof <= 0:
        raise ValueError(f'Degrees of freedom must be positive, got {dof}')

    if prefer_rsatoolbox:
        try:
            with warnings.catch_warnings(record=True) as caught:
                warnings.filterwarnings('ignore', message='invalid value encountered in cast')
                prec = rsa.data.noise.prec_from_residuals(
                    residuals=residuals_clean,
                    dof=dof,
                    method='shrinkage_diag',
                )
            if np.isfinite(prec).all() and prec.shape == (residuals_clean.shape[1], residuals_clean.shape[1]):
                return {
                    'precision': np.asarray(prec, dtype=np.float64),
                    'method': 'rsatoolbox.prec_from_residuals.shrinkage_diag',
                    'warnings_suppressed': [str(w.message) for w in caught],
                }
        except Exception as exc:
            rsatoolbox_error = repr(exc)
        else:
            rsatoolbox_error = 'rsatoolbox precision was nonfinite or wrong shape'
    else:
        rsatoolbox_error = 'rsatoolbox precision disabled'

    prec = stable_precision_fallback(residuals_clean)
    return {
        'precision': prec,
        'method': 'fallback.eigen_clip_ridge_pinv',
        'rsatoolbox_error': rsatoolbox_error,
        'warnings_suppressed': [],
    }


def compute_crossnobis_rdm(
    betas_subset: np.ndarray,
    finger_names: List[str],
    run_indices: List[int],
    precision: np.ndarray,
    roi_name: str = 'M1',
) -> np.ndarray:
    dataset = build_dataset(betas_subset, finger_names, run_indices, roi_name=roi_name)
    if precision.shape != (dataset.measurements.shape[1], dataset.measurements.shape[1]):
        raise ValueError(
            f'Precision shape {precision.shape} does not match voxel count {dataset.measurements.shape[1]}'
        )

    with warnings.catch_warnings():
        # This suppresses the known harmless NumPy cast warning emitted inside rsatoolbox
        # only after all inputs have been validated as finite and the output is checked.
        warnings.filterwarnings('ignore', message='invalid value encountered in cast')
        rdm_obj = rsa.rdm.calc_rdm(
            dataset,
            method='crossnobis',
            descriptor='condition',
            noise=precision,
            cv_descriptor='run_number',
        )
    rdm = np.asarray(rdm_obj.get_matrices()[0], dtype=np.float64)
    rdm = 0.5 * (rdm + rdm.T)
    np.fill_diagonal(rdm, 0.0)

    if not np.isfinite(rdm).all():
        raise ValueError('Crossnobis RDM contains nonfinite values after computation.')
    return rdm
