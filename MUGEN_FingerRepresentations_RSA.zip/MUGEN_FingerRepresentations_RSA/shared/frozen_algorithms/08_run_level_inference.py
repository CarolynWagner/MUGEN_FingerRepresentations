"""Run-level uncertainty analysis for Crossnobis RDMs.

Corrects the former entry-wise bootstrap. Resampling operates on crossvalidated
run-pair contributions and recomputes complete RDMs. Also provides exhaustive
balanced split reliability for six runs.
"""
from __future__ import annotations
from itertools import combinations
import numpy as np


def upper_vec(rdm):
    rdm=np.asarray(rdm,float); return rdm[np.triu_indices(rdm.shape[0],1)]


def _metric(a,b,kind='pearson'):
    a=upper_vec(a) if np.asarray(a).ndim==2 else np.asarray(a,float)
    b=upper_vec(b) if np.asarray(b).ndim==2 else np.asarray(b,float)
    keep=np.isfinite(a)&np.isfinite(b); a=a[keep]; b=b[keep]
    if len(a)<2 or np.std(a)==0 or np.std(b)==0: return 0.0
    if kind=='pearson': return float(np.corrcoef(a,b)[0,1])
    if kind=='spearman':
        try:
            from scipy.stats import rankdata
            return float(np.corrcoef(rankdata(a),rankdata(b))[0,1])
        except Exception:
            return float(np.corrcoef(np.argsort(np.argsort(a)),np.argsort(np.argsort(b)))[0,1])
    raise ValueError(kind)


def run_pair_contributions(patterns, precision):
    """Return ordered distinct-run Crossnobis contributions.

    patterns: runs x conditions x voxels. Output: pairs x conditions x conditions.
    Each contribution is divided by voxel count, as in Crossnobis.
    """
    patterns=np.asarray(patterns,float); precision=np.asarray(precision,float)
    nr,nc,nv=patterns.shape; out=[]; labels=[]
    for a in range(nr):
        for b in range(nr):
            if a==b: continue
            rdm=np.zeros((nc,nc),float)
            for i in range(nc):
                for j in range(i+1,nc):
                    da=patterns[a,i]-patterns[a,j]; db=patterns[b,i]-patterns[b,j]
                    rdm[i,j]=rdm[j,i]=float(da@precision@db/nv)
            out.append(rdm); labels.append((a,b))
    return np.stack(out), labels


def bootstrap_rdm_from_run_pairs(patterns, precision, n_boot=2000, seed=0):
    """Bootstrap ordered run-pair contributions, returning complete RDMs.

    This preserves RDM symmetry and condition dependence and never resamples the
    ten dissimilarities independently. Because ordered run-pair terms share runs,
    it is labelled a run-pair contribution bootstrap rather than an iid bootstrap.
    """
    contrib,pairs=run_pair_contributions(patterns,precision); rng=np.random.default_rng(seed)
    n=len(contrib); draws=np.empty((n_boot,*contrib.shape[1:]),float)
    for k in range(n_boot): draws[k]=np.mean(contrib[rng.integers(0,n,size=n)],axis=0)
    return draws, pairs


def summarize_fsi_bootstrap(rdm_draws, ci=(2.5,97.5)):
    vals=np.array([np.mean(upper_vec(x)) for x in rdm_draws])
    return {'mean':float(vals.mean()),'sd':float(vals.std(ddof=1)),
            'ci_low':float(np.percentile(vals,ci[0])),'ci_high':float(np.percentile(vals,ci[1])),
            'n_boot':int(len(vals)),'unit':'ordered distinct-run Crossnobis contributions'}


def bootstrap_between_session(patterns_a,precision_a,patterns_b,precision_b,n_boot=2000,seed=0,metric='pearson'):
    da,_=bootstrap_rdm_from_run_pairs(patterns_a,precision_a,n_boot,seed)
    db,_=bootstrap_rdm_from_run_pairs(patterns_b,precision_b,n_boot,seed+1)
    vals=np.array([_metric(a,b,metric) for a,b in zip(da,db)])
    return {'metric':metric,'mean':float(vals.mean()),'sd':float(vals.std(ddof=1)),
            'ci_low':float(np.percentile(vals,2.5)),'ci_high':float(np.percentile(vals,97.5)),
            'n_boot':int(n_boot),'unit':'run-pair Crossnobis contributions, independently resampled by session'}


def _crossnobis(patterns,precision):
    c,_=run_pair_contributions(patterns,precision); return np.mean(c,axis=0)


def exhaustive_balanced_splits(patterns,precision,metric='pearson'):
    """Enumerate unique complementary balanced splits (e.g. 10 for six runs)."""
    patterns=np.asarray(patterns,float); nr=patterns.shape[0]
    if nr%2: raise ValueError('Balanced splits require an even run count')
    half=nr//2; seen=set(); rows=[]
    for A in combinations(range(nr),half):
        A=tuple(A); B=tuple(i for i in range(nr) if i not in A)
        key=tuple(sorted((A,B)))
        if key in seen: continue
        seen.add(key)
        ra=_crossnobis(patterns[list(A)],precision); rb=_crossnobis(patterns[list(B)],precision)
        rows.append({'runs_a':[x+1 for x in A],'runs_b':[x+1 for x in B],metric:_metric(ra,rb,metric)})
    vals=np.array([r[metric] for r in rows],float)
    return {'metric':metric,'splits':rows,'n_splits':len(rows),'mean':float(vals.mean()),
            'median':float(np.median(vals)),'min':float(vals.min()),'max':float(vals.max()),
            'interpretation':'Exhaustive complementary balanced-split stability; split estimates are not mutually independent.'}
