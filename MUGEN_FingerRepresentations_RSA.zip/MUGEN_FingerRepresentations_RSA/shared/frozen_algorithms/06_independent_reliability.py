"""Independent within-session reliability from disjoint run partitions.

This module complements, rather than replaces, the overlapping run-combination
stability matrices in 05_run_subset_stability.py.
"""
from __future__ import annotations
from typing import Dict, List
import numpy as np


def _load_metrics():
    import importlib.util
    from pathlib import Path
    p=Path(__file__).with_name('05_run_subset_stability.py')
    spec=importlib.util.spec_from_file_location('stability05', p)
    m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m); return m


def compute_independent_split_reliability(rdms: Dict, session_ids: List[str], independent_splits: Dict) -> Dict:
    metrics=_load_metrics(); funcs=metrics.metric_functions(); out={}
    for session in session_ids:
        out[session]={}
        for label,(combo_a,combo_b) in independent_splits.items():
            runs_a=set(rdms[session][combo_a]['run_indices']); runs_b=set(rdms[session][combo_b]['run_indices'])
            overlap=sorted(runs_a & runs_b)
            if overlap:
                raise ValueError(f"Independent split {label} overlaps in runs {overlap}: {combo_a} vs {combo_b}")
            a=metrics.upper_vec(rdms[session][combo_a]['raw']); b=metrics.upper_vec(rdms[session][combo_b]['raw'])
            out[session][label]={
                'combo_a':combo_a,'combo_b':combo_b,
                'runs_a':sorted(runs_a),'runs_b':sorted(runs_b),
                **{name:fn(a,b) for name,fn in funcs.items()},
                'interpretation':'Disjoint-run reliability estimate; no run contributes to both RDMs.'
            }
    return out
