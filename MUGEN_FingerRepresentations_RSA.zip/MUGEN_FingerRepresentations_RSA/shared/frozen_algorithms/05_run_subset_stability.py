"""
05_run_subset_stability.py
Inference metrics for RDM reliability and FSI.

v8.5:
- Full legacy-compatible API for run_pipeline.py.
- Returns all keys expected by the runner:
    within_session
    between_session
    fsi_raw
    fsi_normalized
    fsi_norm_details
    correlation_audit
- Computes all correlations from raw upper-triangular RDM entries only.
- Excludes diagonal and duplicate lower-triangle entries.
- Uses tie-aware Spearman if scipy is available.
- Provides corrected Pearson, Spearman, Fisher-Z, ICC(2,1), and cosine.
"""

from __future__ import annotations

from typing import Dict, List, Tuple

import numpy as np

try:
    from scipy.stats import rankdata
except Exception:  # pragma: no cover
    rankdata = None

EPS = 1e-12


# ============================================================
# Vectorization and safe helpers
# ============================================================

def upper_vec(rdm: np.ndarray) -> np.ndarray:
    rdm = np.asarray(rdm, dtype=np.float64)
    if rdm.ndim != 2 or rdm.shape[0] != rdm.shape[1]:
        raise ValueError(f"RDM must be square, got {rdm.shape}")
    return rdm[np.triu_indices(rdm.shape[0], k=1)]


def finite_pair(a: np.ndarray, b: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
    a = np.asarray(a, dtype=np.float64).ravel()
    b = np.asarray(b, dtype=np.float64).ravel()
    if a.size != b.size:
        raise ValueError(f"Vector length mismatch: {a.size} vs {b.size}")
    keep = np.isfinite(a) & np.isfinite(b)
    return a[keep], b[keep]


def clip_corr(x: float) -> float:
    if not np.isfinite(x):
        return 0.0
    return float(np.clip(x, -1.0, 1.0))


# ============================================================
# Correlation/reliability metrics
# ============================================================

def pearson(a: np.ndarray, b: np.ndarray) -> float:
    a, b = finite_pair(a, b)
    if a.size <= 1:
        return 0.0
    if np.std(a) < EPS or np.std(b) < EPS:
        return 0.0
    return clip_corr(np.corrcoef(a, b)[0, 1])


def spearman(a: np.ndarray, b: np.ndarray) -> float:
    a, b = finite_pair(a, b)
    if a.size <= 1:
        return 0.0
    if np.std(a) < EPS or np.std(b) < EPS:
        return 0.0

    if rankdata is not None:
        ra = rankdata(a, method="average")
        rb = rankdata(b, method="average")
    else:
        # Fallback without exact tie handling.
        ra = np.argsort(np.argsort(a))
        rb = np.argsort(np.argsort(b))

    return pearson(ra, rb)


def fisherz_from_r(r: float) -> float:
    r = np.clip(float(r), -0.9999, 0.9999)
    return float(np.arctanh(r))


def fisherz_metric(a: np.ndarray, b: np.ndarray) -> float:
    return fisherz_from_r(pearson(a, b))


def cosine(a: np.ndarray, b: np.ndarray) -> float:
    a, b = finite_pair(a, b)
    if a.size <= 1:
        return 0.0
    denom = np.linalg.norm(a) * np.linalg.norm(b)
    if denom < EPS:
        return 0.0
    return clip_corr(float(np.dot(a, b) / denom))


def icc_2_1(a: np.ndarray, b: np.ndarray) -> float:
    """
    ICC(2,1) over RDM entries as targets and two sessions as raters.
    """
    a, b = finite_pair(a, b)
    if a.size <= 1:
        return 0.0

    X = np.column_stack([a, b])
    if np.std(X.ravel()) < EPS:
        return 0.0

    n, k = X.shape
    grand = X.mean()
    row_means = X.mean(axis=1)
    col_means = X.mean(axis=0)

    ss_rows = k * np.sum((row_means - grand) ** 2)
    ss_cols = n * np.sum((col_means - grand) ** 2)
    ss_total = np.sum((X - grand) ** 2)
    ss_err = ss_total - ss_rows - ss_cols

    ms_rows = ss_rows / max(n - 1, 1)
    ms_cols = ss_cols / max(k - 1, 1)
    ms_err = ss_err / max((n - 1) * (k - 1), 1)

    denom = ms_rows + (k - 1) * ms_err + (k * (ms_cols - ms_err) / max(n, 1))
    if abs(denom) < EPS:
        return 0.0

    return clip_corr((ms_rows - ms_err) / denom)


def metric_functions():
    return {
        "pearson": pearson,
        "spearman": spearman,
        "fisherz": fisherz_metric,
        "icc": icc_2_1,
        "cosine": cosine,
    }


# ============================================================
# Within- and between-session reliability
# ============================================================

def compute_within_session(rdms: Dict, session_id: str, combos: List[str]) -> Dict:
    out = {"combos": combos}
    funcs = metric_functions()

    for metric, fn in funcs.items():
        mat = np.zeros((len(combos), len(combos)), dtype=np.float64)
        for i, c1 in enumerate(combos):
            for j, c2 in enumerate(combos):
                v1 = upper_vec(rdms[session_id][c1]["raw"])
                v2 = upper_vec(rdms[session_id][c2]["raw"])
                mat[i, j] = fn(v1, v2)
        out[metric] = mat

    return out


def compute_between_session(rdms: Dict, session_ids: List[str], combos: List[str]) -> Dict:
    out = {}
    funcs = metric_functions()

    for combo in combos:
        out[combo] = {metric: {} for metric in funcs}

        for i, s1 in enumerate(session_ids):
            for s2 in session_ids[i + 1:]:
                pair_label = f"{s1}_vs_{s2}"

                v1 = upper_vec(rdms[s1][combo]["raw"])
                v2 = upper_vec(rdms[s2][combo]["raw"])

                for metric, fn in funcs.items():
                    out[combo][metric][pair_label] = fn(v1, v2)

    return out


def audit_between_session(between_session: Dict) -> Dict:
    audit = {}

    for metric in ["pearson", "spearman", "fisherz", "icc", "cosine"]:
        vals = []
        for combo, by_metric in between_session.items():
            vals.extend(list(by_metric.get(metric, {}).values()))
        vals = np.asarray(vals, dtype=np.float64)
        vals = vals[np.isfinite(vals)]

        if vals.size == 0:
            audit[metric] = {"n": 0, "min": None, "max": None}
        else:
            audit[metric] = {
                "n": int(vals.size),
                "min": float(vals.min()),
                "max": float(vals.max()),
            }

    return audit




def compute_independent_split_reliability(rdms: Dict, session_ids: List[str], independent_splits: Dict) -> Dict:
    """Reliability from disjoint run subsets only.

    Each split maps a label to two RDM-combo names whose run sets must not
    overlap. Overlap is rejected to prevent circularly inflated reliability.
    """
    funcs = metric_functions()
    out = {}
    for session in session_ids:
        out[session] = {}
        for split_label, (combo_a, combo_b) in independent_splits.items():
            runs_a = set(rdms[session][combo_a]['run_indices'])
            runs_b = set(rdms[session][combo_b]['run_indices'])
            overlap = sorted(runs_a & runs_b)
            if overlap:
                raise ValueError(
                    f"Independent split {split_label} overlaps in runs {overlap}: "
                    f"{combo_a} vs {combo_b}"
                )
            v1 = upper_vec(rdms[session][combo_a]['raw'])
            v2 = upper_vec(rdms[session][combo_b]['raw'])
            out[session][split_label] = {
                'combo_a': combo_a,
                'combo_b': combo_b,
                'runs_a': sorted(runs_a),
                'runs_b': sorted(runs_b),
                **{metric: fn(v1, v2) for metric, fn in funcs.items()},
            }
    return out


# ============================================================
# FSI
# ============================================================

def fsi_from_raw_rdm(raw_rdm: np.ndarray) -> float:
    """
    Finger Separation Index:
    mean of the unique off-diagonal raw Crossnobis distances.
    """
    return float(np.mean(upper_vec(raw_rdm)))


def compute_fsi(rdms: Dict, session_ids: List[str], combos: List[str]) -> Dict[str, Dict[str, float]]:
    fsi = {}
    for s in session_ids:
        fsi[s] = {}
        for c in combos:
            fsi[s][c] = fsi_from_raw_rdm(rdms[s][c]["raw"])
    return fsi


def normalize_fsi_across_sessions_per_combo(
    fsi_raw: Dict[str, Dict[str, float]],
    session_ids: List[str],
    combos: List[str],
) -> Tuple[Dict[str, Dict[str, float]], Dict[str, Dict]]:
    """
    Legacy normalization expected by the plotting/reporting layers.

    For each run-combo:
        normalized FSI(session, combo) = raw FSI(session, combo) /
                                         mean raw FSI(all sessions, combo)

    Returns:
        fsi_normalized
        fsi_norm_details
    """
    fsi_normalized = {s: {} for s in session_ids}
    details = {}

    for c in combos:
        raw_vals = np.asarray([fsi_raw[s][c] for s in session_ids], dtype=np.float64)
        finite_vals = raw_vals[np.isfinite(raw_vals)]
        denom = float(np.mean(finite_vals)) if finite_vals.size else 0.0

        if abs(denom) < EPS:
            denom_safe = 1.0
            warning = "Mean FSI denominator was zero/near-zero; used 1.0"
        else:
            denom_safe = denom
            warning = None

        for s in session_ids:
            fsi_normalized[s][c] = float(fsi_raw[s][c] / denom_safe)

        details[c] = {
            "normalization": "raw_fsi_divided_by_mean_raw_fsi_across_sessions_for_this_combo",
            "mean_raw_fsi_across_sessions": float(denom),
            "denominator_used": float(denom_safe),
            "sessions": list(session_ids),
            "raw_values": {s: float(fsi_raw[s][c]) for s in session_ids},
            "normalized_values": {s: float(fsi_normalized[s][c]) for s in session_ids},
            "warning": warning,
        }

    return fsi_normalized, details


# ============================================================
# Full public API expected by run_pipeline.py
# ============================================================

def compute_all_inference(rdms: Dict, session_ids: List[str], run_combos: Dict, independent_splits: Dict | None = None) -> Dict:
    combos = list(run_combos.keys())

    within = {s: compute_within_session(rdms, s, combos) for s in session_ids}
    between = compute_between_session(rdms, session_ids, combos)
    independent = compute_independent_split_reliability(rdms, session_ids, independent_splits or {})

    fsi_raw = compute_fsi(rdms, session_ids, combos)
    fsi_normalized, fsi_norm_details = normalize_fsi_across_sessions_per_combo(
        fsi_raw=fsi_raw,
        session_ids=session_ids,
        combos=combos,
    )

    return {
        "within_session": within,
        "between_session": between,
        "independent_split_reliability": independent,
        "within_session_interpretation": "Full combo-by-combo matrices are descriptive data-quantity stability summaries; inferential within-session reliability is restricted to disjoint run splits.",
        "fsi_raw": fsi_raw,
        "fsi_normalized": fsi_normalized,
        "fsi_norm_details": fsi_norm_details,
        "correlation_audit": audit_between_session(between),
    }


def build_all_inference(
    rdms: Dict,
    session_ids: List[str],
    run_combos: Dict,
    full_combo_label: str | None = None,
    independent_splits: Dict | None = None,
) -> Dict:
    """
    Backward-compatible API expected by run_pipeline.py.
    """
    return compute_all_inference(rdms, session_ids, run_combos, independent_splits=independent_splits)
