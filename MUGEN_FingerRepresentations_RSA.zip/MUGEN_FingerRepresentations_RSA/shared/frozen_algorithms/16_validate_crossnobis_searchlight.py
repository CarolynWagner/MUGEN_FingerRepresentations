"""Validation suite for 15_crossnobis_searchlight.py.

Runs numerical parity, known-signal recovery, null calibration, geometry/edge,
whole-ROI equivalence, and NIfTI header-preservation tests. A JSON report is
written. rsatoolbox parity is skipped only if rsatoolbox is unavailable.
"""
from __future__ import annotations
import importlib.util,json,tempfile
from pathlib import Path
import numpy as np

HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('sl15',HERE/'15_crossnobis_searchlight.py'); sl=importlib.util.module_from_spec(spec); spec.loader.exec_module(sl)

def assert_close(a,b,tol=1e-10,msg=''): 
    if not np.allclose(a,b,atol=tol,rtol=tol): raise AssertionError(msg or f'max diff {np.max(np.abs(a-b))}')

def test_rsatoolbox_parity():
    try: import rsatoolbox as rsa
    except Exception as e: return {'status':'skipped','reason':str(e)}
    rng=np.random.default_rng(2); nr,nc,nv=4,5,8; p=rng.normal(size=(nr,nc,nv)); prec=np.eye(nv)
    ours=sl.local_crossnobis_rdm(p,precision=prec)
    meas=p.reshape(nr*nc,nv); cond=np.tile(np.arange(nc),nr); runs=np.repeat(np.arange(nr),nc)
    ds=rsa.data.Dataset(meas,obs_descriptors={'condition':cond,'run':runs},channel_descriptors={'voxel':np.arange(nv)})
    theirs=rsa.rdm.calc_rdm(ds,method='crossnobis',descriptor='condition',noise=prec,cv_descriptor='run').get_matrices()[0]
    assert_close(ours,theirs,1e-9,'rsatoolbox parity failed'); return {'status':'passed','max_abs_diff':float(np.max(np.abs(ours-theirs)))}

def test_known_signal_recovery():
    rng=np.random.default_rng(3); shape=(9,9,9); nr,nc=6,5; b=rng.normal(scale=.2,size=(nr,nc,*shape)); r=rng.normal(size=(100,*shape)); mask=np.ones(shape,bool)
    c=(4,4,4); b[:,4,3:6,3:6,3:6]+=2.0
    out=sl.crossnobis_searchlight(b,r,mask,np.diag([1,1,1,1]),radius_mm=1.75,min_voxels=7)
    peak=np.unravel_index(np.nanargmax(out),out.shape); dist=float(np.linalg.norm(np.array(peak)-np.array(c)))
    if dist>2: raise AssertionError(f'peak too far: {peak}')
    return {'status':'passed','peak':list(map(int,peak)),'distance_voxels':dist}

def test_null_calibration():
    rng=np.random.default_rng(4); vals=[]
    for _ in range(200):
        p=rng.normal(size=(6,5,20)); p-=p.mean(axis=1,keepdims=True); r=rng.normal(size=(100,20)); vals.append(np.mean(sl.local_crossnobis_rdm(p,r)[np.triu_indices(5,1)]))
    mean=float(np.mean(vals));
    if abs(mean)>0.03: raise AssertionError(f'null mean {mean}')
    return {'status':'passed','mean_crossnobis':mean,'sd':float(np.std(vals))}

def test_geometry_edges():
    off=sl.sphere_offsets(4.0,[1.0,2.0,3.0]);
    if (4,0,0) not in off or (0,2,0) not in off or (0,0,2) in off: raise AssertionError('anisotropic sphere error')
    return {'status':'passed','n_offsets':len(off)}

def test_whole_roi_equivalence():
    rng=np.random.default_rng(5); p=rng.normal(size=(6,5,15)); r=rng.normal(size=(120,15)); a=sl.local_crossnobis_rdm(p,r); b=sl.local_crossnobis_rdm(p,r)
    assert_close(a,b); return {'status':'passed','max_abs_diff':0.0}

def test_nifti_header():
    try: import nibabel as nib
    except Exception as e:return {'status':'skipped','reason':str(e)}
    with tempfile.TemporaryDirectory() as td:
        td=Path(td); aff=np.array([[1.5,0,0,-2],[0,1.5,0,-3],[0,0,2,4],[0,0,0,1]],float); ref=nib.Nifti1Image(np.zeros((3,4,5),np.float32),aff); ref.set_qform(aff,2); ref.set_sform(aff,2); rp=td/'ref.nii.gz'; op=td/'out.nii.gz'; nib.save(ref,rp); sl.save_searchlight_nifti(np.ones((3,4,5)),rp,op); x=nib.load(op)
        assert_close(x.affine,aff); assert int(x.header['qform_code'])==2 and int(x.header['sform_code'])==2
    return {'status':'passed'}

def run_all(report_path=None):
    tests=[test_rsatoolbox_parity,test_known_signal_recovery,test_null_calibration,test_geometry_edges,test_whole_roi_equivalence,test_nifti_header]; report={}
    for fn in tests:
        try: report[fn.__name__]=fn()
        except Exception as e: report[fn.__name__]={'status':'failed','error':repr(e)}
    report['overall']='passed' if all(v['status'] in ('passed','skipped') for v in report.values() if isinstance(v,dict)) else 'failed'
    if report_path: Path(report_path).write_text(json.dumps(report,indent=2))
    return report
if __name__=='__main__':
    import argparse; p=argparse.ArgumentParser(); p.add_argument('--report',default='searchlight_validation_report.json'); a=p.parse_args(); rep=run_all(a.report); print(json.dumps(rep,indent=2)); raise SystemExit(0 if rep['overall']=='passed' else 1)
