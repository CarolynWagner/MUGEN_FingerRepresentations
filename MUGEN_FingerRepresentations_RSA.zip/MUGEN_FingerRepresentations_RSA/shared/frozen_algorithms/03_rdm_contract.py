"""
03_rdm_contract.py
Locked RDM contract layer.

RDMs are stored as plain dictionaries to avoid pickle/module-name fragility.
The contract enforces explicit separation of:
    raw      -> inference/statistics only
    vis01    -> visualization only, min-max normalized to [0, 1]
    mean_norm -> session/combo-specific mean-off-diagonal normalized RDM
                 i.e. raw RDM divided by that RDM's own off-diagonal mean.
                 For the full-combo figure, this means each session's run1-6
                 RDM is normalized to its own session mean.
"""

from __future__ import annotations

from typing import Dict, List, Optional

import numpy as np

EPS = 1e-12


def _upper_tri_values(rdm: np.ndarray) -> np.ndarray:
    return rdm[np.triu_indices(rdm.shape[0], k=1)]


def _sanitize_raw(raw: np.ndarray) -> np.ndarray:
    rdm = np.asarray(raw, dtype=np.float64)
    if not np.isfinite(rdm).all():
        raise ValueError('Cannot create RDM contract from nonfinite RDM.')
    if rdm.shape[0] != rdm.shape[1]:
        raise ValueError(f'RDM must be square, got {rdm.shape}')
    rdm = 0.5 * (rdm + rdm.T)
    np.fill_diagonal(rdm, 0.0)
    if not np.isfinite(rdm).all():
        raise ValueError('RDM became nonfinite after sanitization.')
    return rdm


def _normalize_01(raw: np.ndarray) -> np.ndarray:
    """Min-max normalize off-diagonal RDM values to [0, 1].

    Crossnobis estimates may legitimately be negative. The zero diagonal is
    self-dissimilarity rather than an empirical pairwise estimate, so it is
    excluded from the scaling range and explicitly restored to zero.
    """
    rdm = np.asarray(raw, dtype=np.float64)
    vals = _upper_tri_values(rdm)
    vals = vals[np.isfinite(vals)]
    if vals.size == 0:
        return np.zeros_like(rdm, dtype=np.float64)
    mn = float(np.min(vals))
    mx = float(np.max(vals))
    if mx - mn < EPS:
        return np.zeros_like(rdm, dtype=np.float64)
    out = (rdm - mn) / (mx - mn)
    np.fill_diagonal(out, 0.0)
    return out


def _mean_normalize(raw: np.ndarray) -> np.ndarray:
    vals = _upper_tri_values(raw)
    denom = float(np.mean(vals))
    if abs(denom) < EPS:
        return np.zeros_like(raw, dtype=np.float64)
    return raw / denom


def create_rdm_contract(
    raw: np.ndarray,
    session: str,
    combo: str,
    run_indices: List[int],
    n_voxels: int,
    meta: Optional[Dict] = None,
) -> Dict:
    raw_clean = _sanitize_raw(raw)
    return {
        'type': 'locked_rdm_contract_v1',
        'session': session,
        'combo': combo,
        'run_indices': list(run_indices),
        'n_voxels': int(n_voxels),
        'raw': raw_clean,
        'vis01': _normalize_01(raw_clean),
        'mean_norm': _mean_normalize(raw_clean),
        'meta': meta or {},
    }


def get_inference(rdm_obj: Dict) -> np.ndarray:
    return rdm_obj['raw']


def get_visualization(rdm_obj: Dict) -> np.ndarray:
    return rdm_obj['vis01']


def get_mean_normalized(rdm_obj: Dict) -> np.ndarray:
    return rdm_obj['mean_norm']


def vectorize_rdm(rdm_or_obj, use: str = 'raw') -> np.ndarray:
    if isinstance(rdm_or_obj, dict) and 'raw' in rdm_or_obj:
        if use == 'raw':
            rdm = rdm_or_obj['raw']
        elif use == 'vis01':
            rdm = rdm_or_obj['vis01']
        elif use == 'mean_norm':
            rdm = rdm_or_obj['mean_norm']
        else:
            raise ValueError(f'Unknown RDM representation: {use}')
    else:
        rdm = np.asarray(rdm_or_obj, dtype=np.float64)
    return _upper_tri_values(rdm)


def legacy_matrix(rdm_obj: Dict) -> np.ndarray:
    return rdm_obj['raw']
