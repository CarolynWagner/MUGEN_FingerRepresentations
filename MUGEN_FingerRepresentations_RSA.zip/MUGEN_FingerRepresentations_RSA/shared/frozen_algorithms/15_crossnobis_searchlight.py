"""Crossnobis searchlight implementation under explicit validation.

The original exploratory correlation scaffold is preserved separately as
14_searchlight_original_scaffold.py. This module implements local Crossnobis.
"""
from __future__ import annotations
import numpy as np


def sphere_offsets(radius_mm,voxel_sizes):
    voxel_sizes=np.asarray(voxel_sizes,float); steps=np.ceil(radius_mm/voxel_sizes).astype(int); out=[]
    for dx in range(-steps[0],steps[0]+1):
      for dy in range(-steps[1],steps[1]+1):
       for dz in range(-steps[2],steps[2]+1):
        if np.linalg.norm(np.array([dx,dy,dz])*voxel_sizes)<=radius_mm+1e-9: out.append((dx,dy,dz))
    return out


def shrinkage_diag_precision(residuals,ridge=1e-6,shrinkage=0.5):
    r=np.asarray(residuals,float); r=r-r.mean(0,keepdims=True); cov=np.atleast_2d(np.cov(r,rowvar=False)); diag=np.diag(np.diag(cov))
    c=(1-shrinkage)*cov+shrinkage*diag; scale=np.trace(c)/max(c.shape[0],1); c+=np.eye(c.shape[0])*max(scale*ridge,ridge)
    return np.linalg.pinv(c)


def local_crossnobis_rdm(patterns,residuals=None,precision=None,divide_by_voxels=True):
    p=np.asarray(patterns,float)
    if p.ndim!=3 or p.shape[0]<2: raise ValueError('patterns must be runs x conditions x voxels with >=2 runs')
    if not np.isfinite(p).all(): raise ValueError('nonfinite patterns')
    nv=p.shape[2]
    if precision is None:
        if residuals is None: raise ValueError('provide residuals or precision')
        r=np.asarray(residuals,float)
        if r.ndim!=2 or r.shape[1]!=nv or not np.isfinite(r).all(): raise ValueError('invalid residuals')
        precision=shrinkage_diag_precision(r)
    precision=np.asarray(precision,float)
    if precision.shape!=(nv,nv): raise ValueError('precision shape mismatch')
    nr,nc,_=p.shape; out=np.zeros((nc,nc),float); denom=nr*(nr-1)*(nv if divide_by_voxels else 1)
    for i in range(nc):
      for j in range(i+1,nc):
        d=p[:,i]-p[:,j]; total=sum(float(d[a]@precision@d[b]) for a in range(nr) for b in range(nr) if a!=b)
        out[i,j]=out[j,i]=total/denom
    return out


def crossnobis_searchlight(betas,residuals,mask,affine,radius_mm=6,min_voxels=20,max_centers=None):
    b=np.asarray(betas,float); r=np.asarray(residuals,float); mask=np.asarray(mask,bool)
    if b.ndim!=5 or r.ndim!=4 or b.shape[2:]!=mask.shape or r.shape[1:]!=mask.shape: raise ValueError('spatial/input shape mismatch')
    vox=np.sqrt(np.sum(np.asarray(affine)[:3,:3]**2,axis=0)); offsets=np.asarray(sphere_offsets(radius_mm,vox)); out=np.full(mask.shape,np.nan,np.float32)
    centers=np.argwhere(mask); centers=centers if max_centers is None else centers[:int(max_centers)]; shape=np.array(mask.shape)
    for c in centers:
        xyz=c+offsets; xyz=xyz[np.all((xyz>=0)&(xyz<shape),axis=1)]; xyz=xyz[mask[tuple(xyz.T)]]
        if len(xyz)<min_voxels: continue
        x,y,z=xyz.T; lb=b[:,:,x,y,z]; lr=r[:,x,y,z]; valid=np.isfinite(lb).all((0,1))&np.isfinite(lr).all(0)
        if valid.sum()<min_voxels: continue
        rdm=local_crossnobis_rdm(lb[:,:,valid],lr[:,valid]); out[tuple(c)]=np.mean(rdm[np.triu_indices(rdm.shape[0],1)])
    return out


def save_searchlight_nifti(data,reference,out_path):
    import nibabel as nib
    ref=nib.load(reference); hdr=ref.header.copy(); hdr.set_data_dtype(np.float32)
    img=nib.Nifti1Image(np.asarray(data,np.float32),ref.affine,hdr)
    q,qc=ref.get_qform(coded=True); s,sc=ref.get_sform(coded=True); img.set_qform(q,int(qc)); img.set_sform(s,int(sc)); nib.save(img,out_path)
