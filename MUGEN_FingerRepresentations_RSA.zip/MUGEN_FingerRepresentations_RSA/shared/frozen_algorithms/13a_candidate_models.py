
"""
13a_candidate_models.py
Candidate model RSA and little-finger isolation layer.

This module consumes the validated v6.1/v7.0 contract and does not recompute
Crossnobis RDMs. All inference uses contract['rdms'][...]['raw'] only.
"""

from __future__ import annotations

import os
from typing import Dict, List

import numpy as np
import pandas as pd

try:
    from scipy.stats import spearmanr, pearsonr
except Exception:  # pragma: no cover
    spearmanr = None
    pearsonr = None

EPS = 1e-12


def upper_vec(rdm: np.ndarray) -> np.ndarray:
    return rdm[np.triu_indices(rdm.shape[0], k=1)]


def safe_pearson(a: np.ndarray, b: np.ndarray) -> float:
    a = np.asarray(a, dtype=np.float64)
    b = np.asarray(b, dtype=np.float64)
    if a.std() < EPS or b.std() < EPS:
        return 0.0
    if pearsonr is not None:
        r, _ = pearsonr(a, b)
        return 0.0 if not np.isfinite(r) else float(r)
    return float(np.corrcoef(a, b)[0, 1])


def safe_spearman(a: np.ndarray, b: np.ndarray) -> float:
    a = np.asarray(a, dtype=np.float64)
    b = np.asarray(b, dtype=np.float64)
    if a.std() < EPS or b.std() < EPS:
        return 0.0
    if spearmanr is not None:
        r, _ = spearmanr(a, b)
        return 0.0 if not np.isfinite(r) else float(r)
    ra = np.argsort(np.argsort(a))
    rb = np.argsort(np.argsort(b))
    return safe_pearson(ra, rb)


def cosine(a: np.ndarray, b: np.ndarray) -> float:
    a = np.asarray(a, dtype=np.float64)
    b = np.asarray(b, dtype=np.float64)
    denom = np.linalg.norm(a) * np.linalg.norm(b)
    if denom < EPS:
        return 0.0
    return float(np.dot(a, b) / denom)


def fisherz(r: float) -> float:
    return float(np.arctanh(np.clip(r, -0.9999, 0.9999)))


def build_model_rdms(finger_names: List[str]) -> Dict[str, np.ndarray]:
    """Candidate explanatory model RDMs for finger geometry."""
    n = len(finger_names)
    idx = {name: i for i, name in enumerate(finger_names)}
    models = {}

    anatomical = np.zeros((n, n), dtype=float)
    for i in range(n):
        for j in range(n):
            anatomical[i, j] = abs(i - j)
    models['anatomical_digit_order'] = anatomical

    nonadjacent = np.zeros((n, n), dtype=float)
    for i in range(n):
        for j in range(n):
            nonadjacent[i, j] = 0 if abs(i - j) <= 1 else 1
    models['nonadjacent_binary'] = nonadjacent

    little = np.zeros((n, n), dtype=float)
    little_idx = idx['little']
    for i in range(n):
        for j in range(n):
            if i != j and (i == little_idx or j == little_idx):
                little[i, j] = 1
    models['little_isolation'] = little

    thumb = np.zeros((n, n), dtype=float)
    thumb_idx = idx['thumb']
    for i in range(n):
        for j in range(n):
            if i != j and (i == thumb_idx or j == thumb_idx):
                thumb[i, j] = 1
    models['thumb_specialization'] = thumb

    radial_ulnar = np.zeros((n, n), dtype=float)
    radial = {idx['thumb'], idx['index'], idx['middle']}
    ulnar = {idx['ring'], idx['little']}
    for i in range(n):
        for j in range(n):
            if (i in radial and j in ulnar) or (i in ulnar and j in radial):
                radial_ulnar[i, j] = 1
    models['radial_ulnar_grouping'] = radial_ulnar

    for key, mat in list(models.items()):
        mat = 0.5 * (mat + mat.T)
        np.fill_diagonal(mat, 0)
        models[key] = mat

    return models


def little_isolation_index(raw_rdm: np.ndarray, finger_names: List[str]) -> float:
    little_idx = finger_names.index('little')
    all_idx = np.arange(len(finger_names))
    non_little = all_idx[all_idx != little_idx]
    little_dist = float(np.mean(raw_rdm[little_idx, non_little]))
    other = raw_rdm[np.ix_(non_little, non_little)]
    other_dist = float(np.mean(other[np.triu_indices(len(non_little), k=1)]))
    return little_dist - other_dist


def fit_multiple_model(neural_vec: np.ndarray, model_vectors: List[np.ndarray]) -> tuple:
    def z(v):
        v = np.asarray(v, dtype=np.float64)
        sd = v.std()
        if sd < EPS:
            return np.zeros_like(v)
        return (v - v.mean()) / sd

    y = z(neural_vec)
    X = np.column_stack([z(v) for v in model_vectors])
    X = np.column_stack([np.ones(len(y)), X])
    beta, *_ = np.linalg.lstsq(X, y, rcond=None)
    pred = X @ beta
    ss_res = np.sum((y - pred) ** 2)
    ss_tot = np.sum((y - y.mean()) ** 2)
    r2 = 1 - ss_res / (ss_tot + EPS)
    return beta[1:], float(r2)


def run_model_rsa(contract: dict, out_dir: str) -> dict:
    os.makedirs(out_dir, exist_ok=True)

    finger_names = contract['finger_names']
    models = build_model_rdms(finger_names)
    model_vecs = {k: upper_vec(v) for k, v in models.items()}

    rows = []
    little_rows = []
    mult_rows = []

    for ses in contract['session_ids']:
        for combo in contract['run_combos']:
            raw = contract['rdms'][ses][combo]['raw']
            neural = upper_vec(raw)

            little_rows.append({
                'session': ses,
                'combo': combo,
                'little_isolation_index': little_isolation_index(raw, finger_names),
            })

            for model_name, model_vec in model_vecs.items():
                pr = safe_pearson(neural, model_vec)
                sr = safe_spearman(neural, model_vec)
                rows.append({
                    'session': ses,
                    'combo': combo,
                    'model': model_name,
                    'pearson': pr,
                    'spearman': sr,
                    'fisherz_pearson': fisherz(pr),
                    'cosine': cosine(neural, model_vec),
                })

            betas, r2 = fit_multiple_model(neural, list(model_vecs.values()))
            for model_name, beta in zip(model_vecs.keys(), betas):
                mult_rows.append({
                    'session': ses,
                    'combo': combo,
                    'model': model_name,
                    'standardized_beta': float(beta),
                    'multiple_model_r2': r2,
                })

    model_df = pd.DataFrame(rows)
    little_df = pd.DataFrame(little_rows)
    multiple_df = pd.DataFrame(mult_rows)

    model_df.to_csv(os.path.join(out_dir, 'model_rsa.csv'), index=False)
    little_df.to_csv(os.path.join(out_dir, 'little_isolation_index.csv'), index=False)
    multiple_df.to_csv(os.path.join(out_dir, 'multiple_model_rsa.csv'), index=False)

    return {
        'models': models,
        'model_rsa': model_df,
        'little_isolation': little_df,
        'multiple_model_rsa': multiple_df,
    }
