"""
02_preprocess_qc.py
Numerical stability and voxel-level QA layer.

v8.0:
- Finite-first voxel filtering.
- Residual variance is computed only after residual-finite columns are identified.
- Downstream Crossnobis/precision estimation receives only finite betas and residuals.
"""

from __future__ import annotations

from typing import Dict, Tuple

import numpy as np


def count_nonfinite(x: np.ndarray) -> int:
    return int((~np.isfinite(x)).sum())


def build_valid_voxel_mask(
    betas_full: np.ndarray,
    residuals: np.ndarray,
    residual_std_eps: float = 1e-8,
) -> Tuple[np.ndarray, Dict]:
    """
    A voxel is valid iff:
      1. all beta values are finite,
      2. all residual values are finite,
      3. residual standard deviation is above residual_std_eps.

    Standard deviation is computed only for columns that contain no NaN/Inf.
    """

    betas_full = np.asarray(betas_full, dtype=np.float64)
    residuals = np.asarray(residuals, dtype=np.float64)

    if betas_full.ndim != 3:
        raise ValueError(f"Expected betas_full shape (runs, fingers, voxels), got {betas_full.shape}")
    if residuals.ndim != 2:
        raise ValueError(f"Expected residuals shape (timepoints, voxels), got {residuals.shape}")
    if betas_full.shape[2] != residuals.shape[1]:
        raise ValueError(
            f"Voxel dimension mismatch: betas have {betas_full.shape[2]}, residuals have {residuals.shape[1]}"
        )

    finite_betas = np.isfinite(betas_full).all(axis=(0, 1))
    finite_residuals = np.isfinite(residuals).all(axis=0)

    residual_std = np.zeros(residuals.shape[1], dtype=np.float64)
    if finite_residuals.any():
        residual_std[finite_residuals] = np.std(
            residuals[:, finite_residuals],
            axis=0,
            ddof=0,
        )

    stable_residual_variance = finite_residuals & (residual_std > residual_std_eps)
    valid = finite_betas & finite_residuals & stable_residual_variance

    if valid.any():
        residual_std_min_valid = float(np.min(residual_std[valid]))
        residual_std_max_valid = float(np.max(residual_std[valid]))
    else:
        residual_std_min_valid = float("nan")
        residual_std_max_valid = float("nan")

    qa = {
        "n_voxels_roi": int(betas_full.shape[2]),
        "n_valid_voxels": int(valid.sum()),
        "n_removed_voxels": int((~valid).sum()),
        "n_bad_beta_voxels": int((~finite_betas).sum()),
        "n_bad_residual_voxels": int((~finite_residuals).sum()),
        "n_low_variance_residual_voxels": int((finite_residuals & ~stable_residual_variance).sum()),
        "n_nonfinite_beta_values": count_nonfinite(betas_full),
        "n_nonfinite_residual_values": count_nonfinite(residuals),
        "residual_std_min_valid": residual_std_min_valid,
        "residual_std_max_valid": residual_std_max_valid,
        "voxel_retention": float(valid.mean()),
        "qa_method": "finite-first residual standard-deviation filter",
    }

    if valid.sum() < 2:
        raise ValueError("Fewer than 2 valid voxels after QA; cannot compute RSA.")

    return valid, qa


def clean_session_data(
    betas_full: np.ndarray,
    residuals: np.ndarray,
    residual_std_eps: float = 1e-8,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray, Dict]:
    valid, qa = build_valid_voxel_mask(
        betas_full=betas_full,
        residuals=residuals,
        residual_std_eps=residual_std_eps,
    )

    betas_clean = np.asarray(betas_full[:, :, valid], dtype=np.float64)
    residuals_clean = np.asarray(residuals[:, valid], dtype=np.float64)

    if not np.isfinite(betas_clean).all():
        raise ValueError("Nonfinite beta values remain after voxel QA.")
    if not np.isfinite(residuals_clean).all():
        raise ValueError("Nonfinite residual values remain after voxel QA.")

    return betas_clean, residuals_clean, valid, qa


def write_qc_report(qc_by_session: Dict, out_path: str) -> None:
    with open(out_path, "w") as f:
        f.write("QC REPORT - Ejaz/Diedrichsen locked RSA pipeline\n")
        f.write("=" * 70 + "\n\n")
        for ses, qa in qc_by_session.items():
            f.write(f"{ses}\n")
            f.write("-" * 70 + "\n")
            for k, v in qa.items():
                f.write(f"{k}: {v}\n")
            f.write("\n")
