"""01_data_loader.py

Loads beta images, residual images, ROI masks and SPM's effective residual
degrees of freedom. Beta indexing follows the six-session SPM first-level model:
    beta_num = run * n_cols_per_run + finger + 1
with zero-based Python indices.
"""

from __future__ import annotations

import os
from typing import Dict, Tuple, List

import nibabel as nib
import numpy as np


def as_float_array(x) -> np.ndarray:
    return np.asarray(x, dtype=np.float64)


def load_roi(roi_path: str) -> np.ndarray:
    if not os.path.exists(roi_path):
        raise FileNotFoundError(f"ROI file not found: {roi_path}")
    roi_img = nib.load(roi_path)
    roi_mask = np.asanyarray(roi_img.dataobj) > 0
    if int(roi_mask.sum()) == 0:
        raise ValueError(f"ROI mask is empty: {roi_path}")
    return roi_mask


def beta_path_for(model_dir: str, beta_num: int) -> str:
    nii = os.path.join(model_dir, f'beta_{beta_num:04d}.nii')
    niigz = nii + '.gz'
    if os.path.exists(nii):
        return nii
    if os.path.exists(niigz):
        return niigz
    raise FileNotFoundError(f"Missing beta image: expected {nii} or {niigz}")


def _assert_same_spatial_shape(path: str, roi_mask: np.ndarray) -> nib.spatialimages.SpatialImage:
    img = nib.load(path)
    if img.shape[:3] != roi_mask.shape:
        raise ValueError(
            f"Spatial shape mismatch for {path}: image={img.shape[:3]}, ROI={roi_mask.shape}"
        )
    return img


def load_all_betas(model_dir: str, roi_mask: np.ndarray, n_runs_total: int,
                   n_fingers: int, n_cols_per_run: int) -> np.ndarray:
    if not os.path.isdir(model_dir):
        raise FileNotFoundError(f"Model directory not found: {model_dir}")
    n_vox = int(roi_mask.sum())
    betas = np.zeros((n_runs_total, n_fingers, n_vox), dtype=np.float64)
    for run in range(n_runs_total):
        for finger in range(n_fingers):
            beta_num = run * n_cols_per_run + finger + 1
            path = beta_path_for(model_dir, beta_num)
            img = _assert_same_spatial_shape(path, roi_mask)
            betas[run, finger, :] = as_float_array(np.asanyarray(img.dataobj)[roi_mask])
    return betas


def list_residual_files(model_dir: str) -> List[str]:
    if not os.path.isdir(model_dir):
        raise FileNotFoundError(f"Model directory not found: {model_dir}")
    files = sorted(
        f for f in os.listdir(model_dir)
        if f.startswith('Res_') and (f.endswith('.nii') or f.endswith('.nii.gz'))
    )
    if not files:
        raise FileNotFoundError(f"No residual NIfTI files starting with 'Res_' found in {model_dir}")
    return files


def load_residuals(model_dir: str, roi_mask: np.ndarray) -> Tuple[np.ndarray, int, List[str]]:
    res_files = list_residual_files(model_dir)
    residuals = np.zeros((len(res_files), int(roi_mask.sum())), dtype=np.float64)
    for t, fname in enumerate(res_files):
        path = os.path.join(model_dir, fname)
        img = _assert_same_spatial_shape(path, roi_mask)
        residuals[t, :] = as_float_array(np.asanyarray(img.dataobj)[roi_mask])
    return residuals, len(res_files), res_files


def load_spm_effective_dof(model_dir: str, explicit_dof=None) -> Tuple[float, str]:
    """Read SPM.xX.erdf from SPM.mat.

    `SPM.xX.erdf` is SPM's effective residual degrees of freedom and accounts for
    the fitted design and temporal covariance model. A nominal
    `n_timepoints - n_regressors` shortcut is deliberately not used.
    """
    if explicit_dof is not None:
        dof = float(explicit_dof)
        if not np.isfinite(dof) or dof <= 0:
            raise ValueError(f"Invalid explicit residual_dof: {explicit_dof}")
        return dof, 'session_config.residual_dof'

    spm_path = os.path.join(model_dir, 'SPM.mat')
    if not os.path.exists(spm_path):
        raise FileNotFoundError(
            f"SPM.mat not found in {model_dir}. Add session_cfg['residual_dof'] only if "
            "the effective SPM.xX.erdf has been verified independently."
        )

    try:
        from scipy.io import loadmat
        mat = loadmat(spm_path, simplify_cells=True)
        spm = mat['SPM']
        dof = float(np.asarray(spm['xX']['erdf']).squeeze())
    except Exception as exc:
        raise RuntimeError(
            f"Could not read SPM.xX.erdf from {spm_path}: {exc!r}. "
            "Save SPM.mat in MATLAB v7 format or provide the verified effective "
            "degrees of freedom as session_cfg['residual_dof']."
        ) from exc

    if not np.isfinite(dof) or dof <= 0:
        raise ValueError(f"Invalid SPM.xX.erdf in {spm_path}: {dof}")
    return dof, 'SPM.xX.erdf'


def load_session_inputs(session_id: str, session_cfg: Dict, cfg) -> Dict:
    roi_mask = load_roi(session_cfg['roi_path'])
    betas_full = load_all_betas(
        session_cfg['model_dir'], roi_mask, cfg.N_RUNS_TOTAL,
        cfg.N_FINGERS, cfg.N_COLS_PER_RUN,
    )
    residuals, n_timepoints, res_files = load_residuals(session_cfg['model_dir'], roi_mask)
    residual_dof, dof_source = load_spm_effective_dof(
        session_cfg['model_dir'], session_cfg.get('residual_dof')
    )
    return {
        'session_id': session_id,
        'model_dir': session_cfg['model_dir'],
        'roi_path': session_cfg['roi_path'],
        'roi_mask': roi_mask,
        'betas_full': betas_full,
        'residuals': residuals,
        'n_timepoints': n_timepoints,
        'residual_files': res_files,
        'residual_dof': residual_dof,
        'residual_dof_source': dof_source,
    }
