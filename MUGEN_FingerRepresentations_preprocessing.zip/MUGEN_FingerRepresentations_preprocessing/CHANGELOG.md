# Changelog

## v9 — FreeSurfer/fMRIPrep integration and required fsnative↔T1w transform

- Integrated the previously missing anatomical fMRIPrep dependency step required by the Finger ROI/RSA workflow.
- Added `scripts/run_fmriprep_anat_only.sh` as a guarded ensure/repair step. It exits immediately if `sub-XX_ses-XX_from-fsnative_to-T1w_mode-image_xfm.txt` already exists; otherwise it runs only the anatomical fMRIPrep workflow.
- The anatomical-only wrapper uses the canonical BIDS T1w and reuses the completed standalone FreeSurfer reconstruction.
- For the validated existing FreeSurfer layout `derivatives/freesurfer/sub-XX_ses-XX`, the wrapper creates a temporary fMRIPrep-compatible `SUBJECTS_DIR` with a `sub-XX` symlink. The real reconstruction is never moved or renamed.
- Both fMRIPrep wrappers also recognize the alternative `derivatives/freesurfer/ses-XX/sub-XX` layout for compatibility.
- Updated `run_fmriprep.sh` to use the same symlink integration, so full fMRIPrep can reuse the actual existing session-specific FreeSurfer reconstruction and generate the required transform directly.
- Updated `run_freesurfer.sh` to write the validated existing layout `derivatives/freesurfer/sub-XX_ses-XX` and to skip work if `recon-all.done` already exists.
- Corrected pipeline order: FreeSurfer must complete before fMRIPrep surface integration.
- Updated `check_roi_dependencies.sh` to recognize both FreeSurfer layouts and explicitly require the fsnative→T1w transform.
- `migrate_freesurfer_layout.sh` is retained only as an optional legacy helper; migration is no longer required.
- No changes to DICOM conversion, manual selection, BIDS construction, TOPUP logic, MRIQC, or study-specific acquisition rules.

## v8 — study-agnostic MUGEN TOPUP and selection model

- Removed all study-specific `topup_mode` branches from the controller and JSON configurations.
- Replaced `fmap_ap` / `fmap_pa` as common user roles with a single generic `reverse_pe` role.
- The same TOPUP rule applies to Finger, EWM, Cognitive Representations, and future MUGEN fMRI studies: median selected BOLD volume + median selected opposite-PE volume.
- BOLD phase-encoding direction is derived from JSON `PhaseEncodingDirection`; filename AP/PA tokens are fallback only.
- `TotalReadoutTime` is read independently from BOLD and reverse-PE JSON sidecars.
- Retained study-specific anatomical validation only where justified, notably Finger's 3D MP2RAGE UNI requirement.

For the detailed v4-v8 history, see the previous v8 changelog.
