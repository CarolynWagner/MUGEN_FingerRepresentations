#!/bin/bash
#SBATCH --job-name=mugen_freesurfer
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=16
#SBATCH --mem=64G
#SBATCH --time=36:00:00
#SBATCH --output=/mnt/beegfs/workspace/2025-0422-Musicians7T/logs/freesurfer_%j.out
#SBATCH --error=/mnt/beegfs/workspace/2025-0422-Musicians7T/logs/freesurfer_%j.err

set -euo pipefail

STUDY="${1:?study required: finger|ewm|cognitive}"
SUB="${2:?subject required, e.g. 11}"
SES="${3:?session required, e.g. 01}"

WS="${WS:-/mnt/beegfs/workspace/2025-0422-Musicians7T}"
MUGEN_ROOT="${MUGEN_ROOT:-${WS}/MUGEN_data}"

module load FreeSurfer/7.4.1-centos8_x86_64

FS_LICENSE="${FS_LICENSE:-${WS}/license.txt}"
BIDS_DIR="${MUGEN_ROOT}/${STUDY}/BIDS"
FS_BASE="${MUGEN_ROOT}/${STUDY}/derivatives/freesurfer"

# Canonical MUGEN layout, matching the existing validated reconstructions:
#   derivatives/freesurfer/sub-11_ses-01
SUBJECTS_DIR="${FS_BASE}"
FS_SUBJECT="sub-${SUB}_ses-${SES}"
T1W="${BIDS_DIR}/sub-${SUB}/ses-${SES}/anat/sub-${SUB}_ses-${SES}_T1w.nii.gz"

mkdir -p "${WS}/logs" "${SUBJECTS_DIR}"

[[ -f "${FS_LICENSE}" ]] || { echo "FreeSurfer license not found: ${FS_LICENSE}" >&2; exit 1; }
[[ -f "${T1W}" ]] || { echo "3D T1w not found: ${T1W}" >&2; exit 1; }
command -v recon-all >/dev/null 2>&1 || { echo "recon-all not on PATH after loading FreeSurfer module." >&2; exit 1; }

export SUBJECTS_DIR
export FS_LICENSE

HIRES_ARGS=()
if [[ "${FS_HIRES:-1}" == "1" ]]; then HIRES_ARGS=(-hires); fi

DONE="${SUBJECTS_DIR}/${FS_SUBJECT}/scripts/recon-all.done"
if [[ -f "${DONE}" ]]; then
    echo "FreeSurfer already complete: ${SUBJECTS_DIR}/${FS_SUBJECT}"
    exit 0
fi

echo "FreeSurfer input T1w : ${T1W}"
echo "FreeSurfer SUBJECTS_DIR: ${SUBJECTS_DIR}"
echo "FreeSurfer subject ID  : ${FS_SUBJECT}"

recon-all \
  -subject "${FS_SUBJECT}" \
  -i "${T1W}" \
  -all \
  "${HIRES_ARGS[@]}" \
  -openmp "${SLURM_CPUS_PER_TASK:-16}"

[[ -f "${DONE}" ]] || { echo "ERROR: recon-all completion marker missing: ${DONE}" >&2; exit 1; }

echo "FreeSurfer complete: ${SUBJECTS_DIR}/${FS_SUBJECT}"
