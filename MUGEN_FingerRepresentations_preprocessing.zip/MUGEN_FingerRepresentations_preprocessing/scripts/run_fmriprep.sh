#!/bin/bash
#SBATCH --job-name=mugen_fmriprep
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=16
#SBATCH --mem=64G
#SBATCH --time=24:00:00
#SBATCH --output=/mnt/beegfs/workspace/2025-0422-Musicians7T/logs/fmriprep_%j.out
#SBATCH --error=/mnt/beegfs/workspace/2025-0422-Musicians7T/logs/fmriprep_%j.err

set -euo pipefail

STUDY="${1:?study required: finger|ewm|cognitive}"
SUB="${2:?subject required, e.g. 11}"
SES="${3:?session required, e.g. 01}"

WS="${WS:-/mnt/beegfs/workspace/2025-0422-Musicians7T}"
MUGEN_ROOT="${MUGEN_ROOT:-${WS}/MUGEN_data}"

IMG="${FMRIPREP_IMG:-${WS}/fmriprep/fmriprep-25.2.4.simg}"
FS_LICENSE_HOST="${FS_LICENSE_HOST:-${WS}/license.txt}"

BIDS_DIR="${MUGEN_ROOT}/${STUDY}/BIDS_TopUp"
OUT_DIR="${MUGEN_ROOT}/${STUDY}/derivatives/fmriprep"
FS_BASE="${MUGEN_ROOT}/${STUDY}/derivatives/freesurfer"

# Resolve both the validated existing MUGEN layout and the temporary newer layout.
FS_SOURCE_OLD="${FS_BASE}/sub-${SUB}_ses-${SES}"
FS_SOURCE_NEW="${FS_BASE}/ses-${SES}/sub-${SUB}"
if [[ -f "${FS_SOURCE_OLD}/scripts/recon-all.done" ]]; then
    FS_SOURCE="${FS_SOURCE_OLD}"
elif [[ -f "${FS_SOURCE_NEW}/scripts/recon-all.done" ]]; then
    FS_SOURCE="${FS_SOURCE_NEW}"
else
    echo "Completed FreeSurfer reconstruction required before fMRIPrep." >&2
    echo "Checked:" >&2
    echo "  ${FS_SOURCE_OLD}/scripts/recon-all.done" >&2
    echo "  ${FS_SOURCE_NEW}/scripts/recon-all.done" >&2
    exit 1
fi

# fMRIPrep expects a FreeSurfer subject called sub-<participant>; expose the existing
# session-specific reconstruction through a temporary symlink without touching it.
FS_SUBJECTS_DIR="${WS}/work/freesurfer_for_fmriprep_${STUDY}_sub-${SUB}_ses-${SES}"
FS_LINK="${FS_SUBJECTS_DIR}/sub-${SUB}"

TF_CACHE_HOST="${WS}/templateflow"
WORK_DIR="${WS}/work/fmriprep_${STUDY}_sub-${SUB}_ses-${SES}"

NPROCS="${SLURM_CPUS_PER_TASK:-16}"
OMP_NTHREADS="${OMP_NTHREADS:-8}"

mkdir -p "${WS}/logs" "${OUT_DIR}" "${TF_CACHE_HOST}" "${WORK_DIR}" "${FS_SUBJECTS_DIR}"

[[ -f "${IMG}" ]] || { echo "fMRIPrep image not found: ${IMG}" >&2; exit 1; }
[[ -f "${FS_LICENSE_HOST}" ]] || { echo "FreeSurfer license not found: ${FS_LICENSE_HOST}" >&2; exit 1; }
[[ -d "${BIDS_DIR}/sub-${SUB}/ses-${SES}" ]] || { echo "Curated TOPUP BIDS session missing: ${BIDS_DIR}/sub-${SUB}/ses-${SES}" >&2; exit 1; }

if [[ -L "${FS_LINK}" ]]; then
    rm -f "${FS_LINK}"
elif [[ -e "${FS_LINK}" ]]; then
    echo "ERROR: ${FS_LINK} exists and is not a symlink." >&2
    exit 1
fi
ln -s "${FS_SOURCE}" "${FS_LINK}"

[[ -f "${FS_LINK}/scripts/recon-all.done" ]] || {
    echo "ERROR: temporary FreeSurfer symlink is invalid: ${FS_LINK}" >&2
    exit 1
}

singularity run --cleanenv \
  -B "${WS}:${WS}" \
  -B "${MUGEN_ROOT}:${MUGEN_ROOT}" \
  -B "${TF_CACHE_HOST}:/templateflow" \
  -B "${FS_LICENSE_HOST}:/license.txt:ro" \
  "${IMG}" \
  "${BIDS_DIR}" \
  "${OUT_DIR}" \
  participant \
  --participant-label "${SUB}" \
  --session-label "${SES}" \
  --skip-bids-validation \
  --output-layout bids \
  --output-spaces T1w \
  --ignore fieldmaps \
  --fs-subjects-dir "${FS_SUBJECTS_DIR}" \
  --fs-license-file "/license.txt" \
  --nprocs "${NPROCS}" \
  --omp-nthreads "${OMP_NTHREADS}" \
  -w "${WORK_DIR}"

XFM="${OUT_DIR}/sub-${SUB}/ses-${SES}/anat/sub-${SUB}_ses-${SES}_from-fsnative_to-T1w_mode-image_xfm.txt"
if [[ ! -f "${XFM}" ]]; then
  echo "ERROR: fMRIPrep completed but required fsnative -> T1w transform is missing:" >&2
  echo "  ${XFM}" >&2
  echo "Run scripts/run_fmriprep_anat_only.sh to repair/ensure this dependency." >&2
  exit 1
fi

echo "fMRIPrep complete: ${OUT_DIR}/sub-${SUB}/ses-${SES}"
echo "Required fsnative -> T1w transform verified: ${XFM}"
