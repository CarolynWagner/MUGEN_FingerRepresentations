#!/bin/bash
set -euo pipefail

STUDY="${1:?study required}"
SUB="${2:?subject required}"
SES="${3:?session required}"

WS="${WS:-/mnt/beegfs/workspace/2025-0422-Musicians7T}"
MUGEN_ROOT="${MUGEN_ROOT:-${WS}/MUGEN_data}"

FS_BASE="${MUGEN_ROOT}/${STUDY}/derivatives/freesurfer"
FS_OLD="${FS_BASE}/sub-${SUB}_ses-${SES}"
FS_NEW="${FS_BASE}/ses-${SES}/sub-${SUB}"
FMRIPREP_DIR="${MUGEN_ROOT}/${STUDY}/derivatives/fmriprep/sub-${SUB}/ses-${SES}"
XFM="${FMRIPREP_DIR}/anat/sub-${SUB}_ses-${SES}_from-fsnative_to-T1w_mode-image_xfm.txt"
INV_XFM="${FMRIPREP_DIR}/anat/sub-${SUB}_ses-${SES}_from-T1w_to-fsnative_mode-image_xfm.txt"

fail=0

if [[ -f "${FS_OLD}/scripts/recon-all.done" ]]; then
  echo "PASS FreeSurfer: ${FS_OLD}/scripts/recon-all.done"
elif [[ -f "${FS_NEW}/scripts/recon-all.done" ]]; then
  echo "PASS FreeSurfer: ${FS_NEW}/scripts/recon-all.done"
else
  echo "FAIL FreeSurfer completion marker missing." >&2
  echo "Checked:" >&2
  echo "  ${FS_OLD}/scripts/recon-all.done" >&2
  echo "  ${FS_NEW}/scripts/recon-all.done" >&2
  fail=1
fi

if [[ -f "${XFM}" ]]; then
  echo "PASS fsnative -> T1w transform: ${XFM}"
else
  echo "FAIL required fsnative -> T1w transform missing: ${XFM}" >&2
  echo "Repair with: sbatch scripts/run_fmriprep_anat_only.sh ${STUDY} ${SUB} ${SES}" >&2
  fail=1
fi

if [[ -f "${INV_XFM}" ]]; then
  echo "PASS T1w -> fsnative inverse transform: ${INV_XFM}"
else
  echo "INFO inverse transform not present: ${INV_XFM}"
fi

exit "${fail}"
