#!/bin/bash
#SBATCH --job-name=mugen_fmriprep_anat
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=16
#SBATCH --mem=64G
#SBATCH --time=08:00:00
#SBATCH --output=/mnt/beegfs/workspace/2025-0422-Musicians7T/logs/fmriprep_anat_%j.out
#SBATCH --error=/mnt/beegfs/workspace/2025-0422-Musicians7T/logs/fmriprep_anat_%j.err

set -euo pipefail

STUDY="${1:?study required: finger|ewm|cognitive}"
SUB="${2:?subject required, e.g. 11}"
SES="${3:?session required, e.g. 01}"

WS="${WS:-/mnt/beegfs/workspace/2025-0422-Musicians7T}"
MUGEN_ROOT="${MUGEN_ROOT:-${WS}/MUGEN_data}"

IMG="${FMRIPREP_IMG:-${WS}/fmriprep/fmriprep-25.2.4.simg}"
FS_LICENSE_HOST="${FS_LICENSE_HOST:-${WS}/license.txt}"

# Anatomical-only fMRIPrep uses the canonical BIDS T1w, not the TOPUP copy.
BIDS_DIR="${MUGEN_ROOT}/${STUDY}/BIDS"
OUT_DIR="${MUGEN_ROOT}/${STUDY}/derivatives/fmriprep"
FS_BASE="${MUGEN_ROOT}/${STUDY}/derivatives/freesurfer"

# Existing validated MUGEN layout.
FS_SOURCE_OLD="${FS_BASE}/sub-${SUB}_ses-${SES}"
# Compatibility with the briefly proposed ses-XX/sub-XX layout.
FS_SOURCE_NEW="${FS_BASE}/ses-${SES}/sub-${SUB}"

if [[ -f "${FS_SOURCE_OLD}/scripts/recon-all.done" ]]; then
    FS_SOURCE="${FS_SOURCE_OLD}"
elif [[ -f "${FS_SOURCE_NEW}/scripts/recon-all.done" ]]; then
    FS_SOURCE="${FS_SOURCE_NEW}"
else
    echo "ERROR: no completed FreeSurfer reconstruction found." >&2
    echo "Checked:" >&2
    echo "  ${FS_SOURCE_OLD}/scripts/recon-all.done" >&2
    echo "  ${FS_SOURCE_NEW}/scripts/recon-all.done" >&2
    exit 1
fi

# fMRIPrep expects the FreeSurfer subject to be named sub-<participant>.
# Create an isolated compatibility SUBJECTS_DIR and symlink the real reconstruction.
# The actual reconstruction is never moved or modified by this wrapper.
FS_SUBJECTS_DIR="${WS}/work/freesurfer_for_fmriprep_${STUDY}_sub-${SUB}_ses-${SES}"
FS_LINK="${FS_SUBJECTS_DIR}/sub-${SUB}"

TF_CACHE_HOST="${WS}/templateflow"
WORK_DIR="${WS}/work/fmriprep_anatonly_${STUDY}_sub-${SUB}_ses-${SES}"

NPROCS="${SLURM_CPUS_PER_TASK:-16}"
OMP_NTHREADS="${OMP_NTHREADS:-8}"

T1W="${BIDS_DIR}/sub-${SUB}/ses-${SES}/anat/sub-${SUB}_ses-${SES}_T1w.nii.gz"
XFM="${OUT_DIR}/sub-${SUB}/ses-${SES}/anat/sub-${SUB}_ses-${SES}_from-fsnative_to-T1w_mode-image_xfm.txt"
INV_XFM="${OUT_DIR}/sub-${SUB}/ses-${SES}/anat/sub-${SUB}_ses-${SES}_from-T1w_to-fsnative_mode-image_xfm.txt"

mkdir -p "${WS}/logs" "${OUT_DIR}" "${TF_CACHE_HOST}" "${WORK_DIR}" "${FS_SUBJECTS_DIR}"

[[ -f "${IMG}" ]] || { echo "ERROR: fMRIPrep image not found: ${IMG}" >&2; exit 1; }
[[ -f "${FS_LICENSE_HOST}" ]] || { echo "ERROR: FreeSurfer license not found: ${FS_LICENSE_HOST}" >&2; exit 1; }
[[ -f "${T1W}" ]] || { echo "ERROR: canonical BIDS T1w not found: ${T1W}" >&2; exit 1; }

# This is an ensure/repair step: do no work if the required transform already exists.
if [[ -f "${XFM}" ]]; then
    echo "Required fsnative -> T1w transform already exists:"
    echo "  ${XFM}"
    exit 0
fi

if [[ -L "${FS_LINK}" ]]; then
    rm -f "${FS_LINK}"
elif [[ -e "${FS_LINK}" ]]; then
    echo "ERROR: ${FS_LINK} exists and is not a symlink." >&2
    exit 1
fi
ln -s "${FS_SOURCE}" "${FS_LINK}"

[[ -f "${FS_LINK}/scripts/recon-all.done" ]] || {
    echo "ERROR: temporary FreeSurfer symlink is invalid: ${FS_LINK}" >&2
    exit 1
}

echo "============================================================"
echo "MUGEN fMRIPrep anatomical transform ensure step"
echo "Study:              ${STUDY}"
echo "Subject/session:    sub-${SUB}/ses-${SES}"
echo "T1w:                ${T1W}"
echo "FreeSurfer source:  ${FS_SOURCE}"
echo "Compatibility link: ${FS_LINK}"
echo "Expected transform: ${XFM}"
echo "============================================================"

singularity run --cleanenv \
  -B "${WS}:${WS}" \
  -B "${MUGEN_ROOT}:${MUGEN_ROOT}" \
  -B "${TF_CACHE_HOST}:/templateflow" \
  -B "${FS_LICENSE_HOST}:/license.txt:ro" \
  "${IMG}" \
  "${BIDS_DIR}" \
  "${OUT_DIR}" \
  participant \
  --participant-label "${SUB}" \
  --session-label "${SES}" \
  --anat-only \
  --skip-bids-validation \
  --output-layout bids \
  --output-spaces T1w \
  --fs-subjects-dir "${FS_SUBJECTS_DIR}" \
  --fs-license-file "/license.txt" \
  --nprocs "${NPROCS}" \
  --omp-nthreads "${OMP_NTHREADS}" \
  -w "${WORK_DIR}"

if [[ -f "${XFM}" ]]; then
    echo "PASS: required fsnative -> T1w transform created:"
    echo "  ${XFM}"
else
    echo "ERROR: fMRIPrep finished but required transform is missing:" >&2
    echo "  ${XFM}" >&2
    exit 1
fi

if [[ -f "${INV_XFM}" ]]; then
    echo "PASS: inverse transform also present:"
    echo "  ${INV_XFM}"
fi
