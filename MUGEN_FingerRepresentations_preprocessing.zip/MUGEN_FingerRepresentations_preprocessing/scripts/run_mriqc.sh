#!/bin/bash
#SBATCH --job-name=mugen_mriqc
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=8
#SBATCH --mem=32G
#SBATCH --time=08:00:00
#SBATCH --output=/mnt/beegfs/workspace/2025-0422-Musicians7T/logs/mriqc_%j.out
#SBATCH --error=/mnt/beegfs/workspace/2025-0422-Musicians7T/logs/mriqc_%j.err
set -euo pipefail

# Usage: sbatch run_mriqc.sh STUDY SUBJECT [SESSION]
# Example: sbatch run_mriqc.sh finger 01 18

STUDY="${1:?study required: finger|ewm|cognitive}"
SUB="${2:?subject required, e.g. 01}"
SES="${3:-}"
WS="${WS:-/mnt/beegfs/workspace/2025-0422-Musicians7T}"
MUGEN_ROOT="${MUGEN_ROOT:-${WS}/MUGEN_data}"
IMG="${MRIQC_IMG:-${WS}/MRIQC/mriqc.simg}"
BIDS_DIR="${MUGEN_ROOT}/${STUDY}/BIDS_TopUp"
OUT_DIR="${MUGEN_ROOT}/${STUDY}/derivatives/mriqc"
WORK_DIR="${WS}/work/mriqc_${STUDY}_sub-${SUB}${SES:+_ses-${SES}}"

mkdir -p "${WS}/logs" "${OUT_DIR}" "${WORK_DIR}"
[[ -f "${IMG}" ]] || { echo "MRIQC image not found: ${IMG}" >&2; exit 1; }
[[ -d "${BIDS_DIR}" ]] || { echo "TOPUP BIDS dataset not found: ${BIDS_DIR}" >&2; exit 1; }

ARGS=(participant --participant-label "${SUB}" --nprocs "${SLURM_CPUS_PER_TASK:-8}" --omp-nthreads 8 -w "${WORK_DIR}" --no-sub)
if [[ -n "${SES}" ]]; then
  # Current MRIQC releases may or may not expose session filtering consistently.
  # Keep the complete subject dataset as the safe common input; BIDS_TopUp itself
  # contains only curated runs.
  echo "MRIQC: processing curated subject sub-${SUB}; requested session ses-${SES} is retained in the dataset structure."
fi

singularity run --cleanenv \
  -B "${WS}:${WS}" \
  -B "${MUGEN_ROOT}:${MUGEN_ROOT}" \
  "${IMG}" \
  "${BIDS_DIR}" \
  "${OUT_DIR}" \
  "${ARGS[@]}"

echo "MRIQC complete: ${OUT_DIR}"
