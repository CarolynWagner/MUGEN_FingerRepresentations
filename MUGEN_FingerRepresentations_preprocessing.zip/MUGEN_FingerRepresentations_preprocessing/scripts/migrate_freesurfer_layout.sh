#!/bin/bash
set -euo pipefail

# One-time helper for reconstructions made by the previous wrapper.
# Run ONLY after the old FreeSurfer job has completed successfully.

STUDY="${1:?study required}"
SUB="${2:?subject required}"
SES="${3:?session required}"

WS="${WS:-/mnt/beegfs/workspace/2025-0422-Musicians7T}"
MUGEN_ROOT="${MUGEN_ROOT:-${WS}/MUGEN_data}"
FS_BASE="${MUGEN_ROOT}/${STUDY}/derivatives/freesurfer"

OLD="${FS_BASE}/sub-${SUB}_ses-${SES}"
NEW_PARENT="${FS_BASE}/ses-${SES}"
NEW="${NEW_PARENT}/sub-${SUB}"

[[ -d "${OLD}" ]] || { echo "Old FreeSurfer directory not found: ${OLD}" >&2; exit 1; }
[[ -f "${OLD}/scripts/recon-all.done" ]] || { echo "Refusing migration: recon-all.done missing in ${OLD}" >&2; exit 1; }
[[ ! -e "${NEW}" ]] || { echo "Refusing migration: destination already exists: ${NEW}" >&2; exit 1; }

mkdir -p "${NEW_PARENT}"
mv "${OLD}" "${NEW}"

echo "Migrated:"
echo "  ${OLD}"
echo "to:"
echo "  ${NEW}"
