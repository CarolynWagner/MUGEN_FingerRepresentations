# MUGEN common fMRI data-preparation pipeline — v9

This package implements the **common data-preparation layer for all MUGEN fMRI studies**:

**DICOM → verified NIfTI → manual acquisition confirmation → BIDS → TOPUP → MRIQC → FreeSurfer → fMRIPrep → dependency check**

It deliberately stops before study-specific scientific analysis. Finger/Diedrichsen/Huber, EWM, and Cognitive Representations consume the common outputs but do not change the core conversion/TOPUP logic.

## Core design

The preprocessing code is study-agnostic. The same three manual roles are used for every MUGEN fMRI study:

- `t1w` — selected anatomical T1w
- `bold` — selected task BOLD run
- `reverse_pe` — selected opposite-phase-encoding acquisition paired with that BOLD run

Study configuration contains only genuine study-specific constraints. Finger Representations requires the validated 3D MP2RAGE UNI/combined T1w; EWM and Cognitive Representations prefer it but do not hard-require it.

## Common TOPUP rule

For every selected BOLD run, the pipeline requires exactly one `reverse_pe` acquisition with the same `task` and `run` values. It verifies that the two JSON `PhaseEncodingDirection` values are opposites along the same axis.

TOPUP uses the zero-based median volume `floor(N/2)` from the selected BOLD and from its reverse-PE acquisition. `acqparams.txt` is generated from each JSON sidecar's `PhaseEncodingDirection` and `TotalReadoutTime`; row 1 is the selected BOLD direction, so `applytopup --inindex=1` is deterministic.

## Directory layout

Default root:

```text
/mnt/beegfs/workspace/2025-0422-Musicians7T/MUGEN_data
```

Canonical BIDS:

```text
MUGEN_data/<study>/BIDS/sub-XX/ses-XX/
```

TOPUP-corrected BIDS:

```text
MUGEN_data/<study>/BIDS_TopUp/sub-XX/ses-XX/
```

Derivatives:

```text
MUGEN_data/<study>/derivatives/
    topup/
    mriqc/
    fmriprep/
    freesurfer/
```

The validated existing FreeSurfer layout is:

```text
MUGEN_data/<study>/derivatives/freesurfer/sub-XX_ses-XX/
```

The fMRIPrep wrappers also recognize the briefly proposed `freesurfer/ses-XX/sub-XX/` layout, so existing reconstructions do not need to be moved.

## 1. Convert DICOM → NIfTI

```bash
module load dcm2niix/1.0.20230411-GCCcore-12.2.0
python mugen_pipeline.py convert \
  --study finger \
  --dicom-dir "/mnt/beegfs/workspace/2025-0422-Musicians7T/rawdata-from-CoBIC/ACTUAL_COBIC_FOLDER"
```

The source conversion layer is preserved. The pipeline then stops for manual acquisition confirmation.

## 2. Generate and curate `selection.tsv`

```bash
python mugen_pipeline.py init-selection --study finger --subject 11 --session 01 --force
```

Check scanning notes and set `use=1` only for valid acquisitions. Editable columns are `use`, `role`, `task`, `run`, and optional `acq`.

## 3. Construct canonical BIDS

```bash
python mugen_pipeline.py make-bids --study finger --subject 11 --session 01
```

Checks include one 3D T1w, genuinely 4D BOLD, exactly one opposite-PE acquisition per selected BOLD task/run, and the Finger MP2RAGE UNI requirement.

## 4. TOPUP

```bash
module load FSL
python mugen_pipeline.py topup --study finger --subject 11 --session 01
```

The TOPUP-corrected BOLD is written to `BIDS_TopUp` with the `TU` acquisition marker.

## 5. MRIQC

```bash
sbatch scripts/run_mriqc.sh finger 11 01
```

Input: `BIDS_TopUp`.

## 6. FreeSurfer

FreeSurfer must complete **before fMRIPrep surface integration**, because the downstream ROI/RSA workflow requires fMRIPrep's explicit FreeSurfer-native ↔ T1w transforms.

```bash
sbatch scripts/run_freesurfer.sh finger 11 01
```

The wrapper writes the validated session-specific reconstruction as:

```text
.../derivatives/freesurfer/sub-11_ses-01
```

## 7. Full fMRIPrep

```bash
sbatch scripts/run_fmriprep.sh finger 11 01
```

Input: `BIDS_TopUp`. The wrapper:

- uses `--ignore fieldmaps` because TOPUP has already been applied;
- reuses the completed standalone FreeSurfer reconstruction;
- creates a temporary fMRIPrep-compatible `SUBJECTS_DIR` containing a `sub-11` symlink to the real `sub-11_ses-01` reconstruction, leaving the reconstruction itself untouched;
- requires T1w output space;
- verifies the required `fsnative → T1w` transform at the end.

Required downstream transform:

```text
.../derivatives/fmriprep/sub-11/ses-01/anat/
sub-11_ses-01_from-fsnative_to-T1w_mode-image_xfm.txt
```

## 8. Ensure/repair the FreeSurfer-native → T1w transform

This is the step that was missing from the earlier pipeline. It is now integrated as a guarded dependency step:

```bash
sbatch scripts/run_fmriprep_anat_only.sh finger 11 01
```

The script first checks whether the required transform already exists. If it does, it exits immediately without rerunning fMRIPrep. If it is missing, it runs **only the anatomical fMRIPrep workflow**, reusing the completed FreeSurfer reconstruction through the temporary `sub-11` symlink, and explicitly requires:

```text
/mnt/beegfs/workspace/2025-0422-Musicians7T/MUGEN_data/finger/derivatives/fmriprep/sub-11/ses-01/anat/sub-11_ses-01_from-fsnative_to-T1w_mode-image_xfm.txt
```

This transform is required by the Finger ROI/RSA procedure to bring FreeSurfer-native ROI volumes into T1w/beta space.

## 9. Verify downstream ROI dependencies

```bash
scripts/check_roi_dependencies.sh finger 11 01
```

The check requires:

1. completed FreeSurfer reconstruction (`recon-all.done`), and
2. `sub-XX_ses-XX_from-fsnative_to-T1w_mode-image_xfm.txt`.

Only after these pass should the study-specific Finger ROI/RSA pipeline start.

## Why the anatomical-only step is conditional

A correctly integrated full fMRIPrep run should normally create the transform itself. Therefore the anatomical-only wrapper is **not intended as an unconditional second full preprocessing run**. It is an explicit ensure/repair stage: cheap when the transform already exists, and limited to anatomical fMRIPrep if it does not.

## Migration note

The old reconstruction layout `freesurfer/sub-XX_ses-XX/` is now supported directly and is the layout written by `run_freesurfer.sh`. The wrappers also recognize `freesurfer/ses-XX/sub-XX/`. Therefore `migrate_freesurfer_layout.sh` is optional and should not be run merely to satisfy fMRIPrep.

## Scope boundary

The package supplies common files for downstream MUGEN analyses. It intentionally does not perform first-level GLMs, RSA, WTA, pRF, cortical-depth/laminar analysis, ROI construction, or other study-specific scientific analyses.
