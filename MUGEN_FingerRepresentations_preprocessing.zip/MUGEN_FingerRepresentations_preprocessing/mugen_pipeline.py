#!/usr/bin/env python3
"""MUGEN common fMRI data-preparation controller.

Scope (and only scope):
DICOM -> verified NIfTI -> manual selection -> BIDS -> TOPUP -> MRIQC -> FreeSurfer -> fMRIPrep.

The controller deliberately stops after conversion and requires a manually curated
selection TSV before constructing BIDS. TOPUP acquisition parameters are derived from
JSON metadata. For Finger Representations, TOPUP reproduces the established workflow:
the median volume of the selected AP BOLD run is paired with the median volume of the
selected reverse-PE PA series, using zero-based index floor(N/2).
"""
from __future__ import annotations

import argparse
import csv
import gzip
import json
import os
import re
import shutil
import struct
import subprocess
import sys
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Tuple

DEFAULT_ROOT = Path(os.environ.get("MUGEN_ROOT", "/mnt/beegfs/workspace/2025-0422-Musicians7T/MUGEN_data"))
CONFIG_DIR = Path(__file__).resolve().parent / "config"


def run(cmd: List[str], *, cwd: Optional[Path] = None) -> None:
    print("+", " ".join(str(x) for x in cmd), flush=True)
    subprocess.run(cmd, cwd=str(cwd) if cwd else None, check=True)


def norm_sub(value: str, width: int = 2) -> str:
    value = str(value).replace("sub-", "").replace("sub", "")
    return f"sub-{int(value):0{width}d}" if value.isdigit() else f"sub-{value}"


def norm_ses(value: str, width: int = 2) -> str:
    value = str(value).replace("ses-", "").replace("ses", "")
    return f"ses-{int(value):0{width}d}" if value.isdigit() else f"ses-{value}"


def parse_cobic_ids(folder: str) -> Tuple[Optional[str], Optional[str]]:
    m = re.search(r"Psub(\d+)ses(\d+)", folder, flags=re.I)
    if not m:
        return None, None
    return m.group(1), m.group(2)


def load_config(study: str) -> Dict:
    path = CONFIG_DIR / f"{study}.json"
    if not path.exists():
        raise SystemExit(f"Unknown study '{study}'. Expected config: {path}")
    with path.open() as f:
        return json.load(f)


def open_binary(path: Path):
    return gzip.open(path, "rb") if path.suffix == ".gz" else path.open("rb")


def nifti_info(path: Path) -> Dict:
    """Read enough of a NIfTI-1/2 header to validate dimensions without nibabel."""
    with open_binary(path) as f:
        header = f.read(560)
    if len(header) < 348:
        raise ValueError("file is too small to contain a NIfTI header")

    le = struct.unpack("<I", header[:4])[0]
    be = struct.unpack(">I", header[:4])[0]
    if le in (348, 540):
        endian = "<"; hsize = le
    elif be in (348, 540):
        endian = ">"; hsize = be
    else:
        raise ValueError("not a recognizable NIfTI-1/2 file")

    if hsize == 348:
        dims = struct.unpack(endian + "8h", header[40:56])
        pixdim = struct.unpack(endian + "8f", header[76:108])
    else:
        dims = struct.unpack(endian + "8q", header[16:80])
        pixdim = struct.unpack(endian + "8d", header[104:168])

    ndim = int(dims[0])
    shape = tuple(int(x) for x in dims[1:1 + max(1, ndim)])
    dim4 = int(dims[4]) if len(dims) > 4 and int(dims[4]) > 0 else 1
    vox = tuple(float(abs(x)) for x in pixdim[1:4])
    return {"ndim": ndim, "shape": shape, "dim4": dim4, "voxel_size": vox}


def paired_json(nii: Path) -> Path:
    name = nii.name
    if name.endswith(".nii.gz"):
        return nii.with_name(name[:-7] + ".json")
    return nii.with_suffix(".json")


def base_without_nii(path: Path) -> str:
    n = path.name
    return n[:-7] if n.endswith(".nii.gz") else n[:-4] if n.endswith(".nii") else path.stem


def json_load(path: Path) -> Dict:
    if not path.exists():
        return {}
    with path.open() as f:
        return json.load(f)


def json_dump(path: Path, obj: Dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w") as f:
        json.dump(obj, f, indent=2, sort_keys=True)
        f.write("\n")


def acquisition_text(name: str, meta: Dict) -> str:
    """Combine filename and useful DICOM-derived metadata for conservative classification."""
    parts = [
        name,
        str(meta.get("ProtocolName", "")),
        str(meta.get("SeriesDescription", "")),
        str(meta.get("SequenceName", "")),
        str(meta.get("PulseSequenceDetails", "")),
        str(meta.get("ImageType", "")),
        str(meta.get("ImageComments", "")),
        str(meta.get("ComplexImageComponent", "")),
    ]
    return " ".join(parts).lower()


def is_mp2rage(text: str) -> bool:
    return bool(re.search(r"mp[_ -]?2[_ -]?rage|mp2rage", text, flags=re.I))


def is_mp2rage_uni(name: str, meta: Dict, info: Optional[Dict] = None) -> bool:
    """Identify a usable MP2RAGE combined T1w/UNI image conservatively.

    CoBIC/Siemens/dcm2niix naming is not uniform. Some combined MP2RAGE
    reconstructions are explicitly labelled UNI/UNIT1, while others are split
    into REAL/IMAG components or carry the relevant information only in JSON.
    INV1/INV2 are always excluded. A 3D MP2RAGE image without INV1/INV2 is
    accepted as a UNI/T1w candidate only when metadata/filename indicate a
    combined or REAL image rather than an inversion image.
    """
    text = acquisition_text(name, meta)
    if not is_mp2rage(text):
        return False
    if re.search(r"inv[_ -]?[12]", text, flags=re.I):
        return False
    if info is not None and info.get("dim4", 1) != 1:
        return False

    # Strong explicit labels.
    if re.search(r"(^|[^a-z0-9])(uni|unit1)([^a-z0-9]|$)", text, flags=re.I):
        return True

    # Siemens/dcm2niix variants may expose the combined image as REAL.
    image_type = " ".join(str(x) for x in meta.get("ImageType", [])) if isinstance(meta.get("ImageType"), list) else str(meta.get("ImageType", ""))
    component = str(meta.get("ComplexImageComponent", ""))
    if re.search(r"(^|[_ -])real($|[_ -])", name, flags=re.I) or "REAL" in image_type.upper() or component.upper() == "REAL":
        return True

    # A plain 3D MP2RAGE series with no inversion/component tag is retained as
    # a candidate; the inventory makes this visible for manual confirmation.
    forbidden = re.search(r"(^|[^a-z0-9])(imag|imaginary|phase|inv1|inv2)([^a-z0-9]|$)", text, flags=re.I)
    return info is not None and info.get("dim4", 1) == 1 and not forbidden

def anatomical_kind(name: str, meta: Dict, info: Dict) -> str:
    text = acquisition_text(name, meta)
    if is_mp2rage_uni(name, meta, info):
        return "mp2rage_uni"
    if is_mp2rage(text) and re.search(r"inv[_ -]?1", text, flags=re.I):
        return "mp2rage_inv1"
    if is_mp2rage(text) and re.search(r"inv[_ -]?2", text, flags=re.I):
        return "mp2rage_inv2"
    if any(k in text for k in ("mprage", "t1w", "t1_")) and info["dim4"] == 1:
        return "other_t1w"
    return ""


def inferred_task_run_acq(name: str, meta: Dict) -> Dict[str, str]:
    """Infer display-only task/run/acquisition suggestions from CoBIC naming.

    These values are never treated as authoritative: selection.tsv keeps separate
    editable task/run/acq columns and the operator confirms them against scanning notes.
    """
    text = base_without_nii(Path(name))
    task = ""
    run_no = ""
    acq = ""

    m = re.search(r"(?P<task>[A-Za-z0-9]+)_run(?P<run>\d+)", text, flags=re.I)
    if m:
        task = m.group("task")
        run_no = m.group("run")

    # Common MUGEN CoBIC resolution strings: 1.5_iso, 1.1_iso, 0.8_iso, etc.
    m = re.search(r"(?<!\d)(\d+)[._](\d+)_iso", text, flags=re.I)
    if m:
        acq = f"{m.group(1)}p{m.group(2)}mm"

    return {"task": task, "run": run_no, "acq": acq}


def suggested_role(name: str, meta: Dict, info: Dict) -> Tuple[str, str]:
    """Return a conservative *individual-file* role suggestion.

    Large multi-volume functional series can be identified as BOLD from the file itself.
    Short PE-polarity acquisitions are labelled only as ``pe_candidate`` here because
    whether they are the required reverse-PE partner depends on the selected BOLD for
    the same task/run. ``cmd_init_selection`` resolves that relationship generically
    from JSON PhaseEncodingDirection (with filename AP/PA as a fallback).
    """
    text = acquisition_text(name, meta)
    base = base_without_nii(Path(name))
    akind = anatomical_kind(name, meta, info)
    nvol = int(info.get("dim4", 1) or 1)

    if akind == "mp2rage_uni":
        return "t1w", "3D MP2RAGE combined/UNI candidate"
    if akind in ("mp2rage_inv1", "mp2rage_inv2"):
        return "", f"{akind} is source-only"
    if akind == "other_t1w":
        return "t1w", "3D T1w candidate (study-specific anatomical rules still apply)"

    if re.search(r"_\d+[A-Za-z]+$", base):
        return "", "auxiliary/split filename; inspect manually"

    functional_text = ("bold" in text) or ("cmrr" in text)
    if functional_text and nvol >= 20:
        return "bold", f"multi-volume functional series ({nvol} volumes)"

    if functional_text and nvol < 20:
        return "pe_candidate", f"short functional/PE series ({nvol} volumes); reverse relationship resolved per BOLD"

    if any(k in text for k in ("se_epi", "se-epi", "spin_echo", "spinecho")):
        return "pe_candidate", "spin-echo/EPI PE candidate; reverse relationship resolved per BOLD"

    return "", ""

def guess_candidate(name: str, meta: Dict, info: Dict) -> str:
    role, reason = suggested_role(name, meta, info)
    if role:
        return f"candidate_{role}"
    akind = anatomical_kind(name, meta, info)
    if akind in ("mp2rage_inv1", "mp2rage_inv2"):
        return f"source_only_{akind}"
    return reason

def find_niftis(folder: Path) -> List[Path]:
    return sorted([p for p in folder.iterdir() if p.is_file() and (p.name.endswith(".nii") or p.name.endswith(".nii.gz"))])


def conversion_dir(root: Path, study: str, sub: str, ses: str) -> Path:
    return root / study / sub / ses / "data"


def bids_dir(root: Path, study: str) -> Path:
    return root / study / "BIDS"


def topup_bids_dir(root: Path, study: str) -> Path:
    return root / study / "BIDS_TopUp"


def derivatives_dir(root: Path, study: str) -> Path:
    return root / study / "derivatives"


def cmd_convert(args) -> None:
    cfg = load_config(args.study)
    dicom = Path(args.dicom_dir).resolve()
    if not dicom.is_dir():
        raise SystemExit(f"DICOM directory does not exist: {dicom}")

    parsed_sub, parsed_ses = parse_cobic_ids(dicom.name)
    sub_raw = args.subject or parsed_sub
    ses_raw = args.session or parsed_ses
    if not sub_raw or not ses_raw:
        raise SystemExit("Could not infer subject/session from CoBIC folder. Supply --subject and --session.")
    sub = norm_sub(sub_raw, cfg.get("subject_width", 2))
    ses = norm_ses(ses_raw, cfg.get("session_width", 2))
    out = conversion_dir(args.root, args.study, sub, ses)
    out.mkdir(parents=True, exist_ok=True)

    if not shutil.which("dcm2niix"):
        raise SystemExit("dcm2niix is not on PATH. Load the CoBIC dcm2niix module first.")

    # Do NOT force merging (-m y). Automatic merge behavior prevents accidental
    # creation of multi-volume structural files from heterogeneous acquisitions.
    run(["dcm2niix", "-m", "2", "-z", "y", "-b", "y", "-x", "i",
         "-o", str(out), "-f", "%p_%4s", str(dicom)])
    inventory_path = make_inventory(out)

    print("\n" + "=" * 72)
    print("MUGEN CONVERSION COMPLETE")
    print(f"Study:   {cfg['display_name']}")
    print(f"Subject: {sub}    Session: {ses}")
    print(f"NIfTI/JSON: {out}")
    print(f"Inventory:  {inventory_path}")
    print("\nSTOP: DO NOT CONTINUE AUTOMATICALLY.")
    print("The converted acquisitions must now be checked against the acquisition notes.")
    print("Run 'init-selection', edit selection.tsv manually, then run 'make-bids'.")
    print("=" * 72)


def pe_axis_sign(meta: Dict) -> Optional[Tuple[str, int]]:
    """Return (axis, sign) from BIDS PhaseEncodingDirection, or None if unavailable."""
    pe = str(meta.get("PhaseEncodingDirection", "") or "")
    if pe not in ("i", "i-", "j", "j-", "k", "k-"):
        return None
    return pe[0], (-1 if pe.endswith("-") else 1)


def filename_pe_label(name: str) -> str:
    """Return AP/PA from a CoBIC filename when explicitly present, else empty."""
    base = base_without_nii(Path(name))
    if re.search(r"(^|_)AP(_|$)", base, flags=re.I):
        return "AP"
    if re.search(r"(^|_)PA(_|$)", base, flags=re.I):
        return "PA"
    return ""


def is_opposite_pe(meta_a: Dict, meta_b: Dict, name_a: str = "", name_b: str = "") -> Optional[bool]:
    """Determine whether two acquisitions have opposite PE directions.

    JSON PhaseEncodingDirection is authoritative. If unavailable in either file, fall
    back conservatively to explicit AP/PA tokens in CoBIC filenames. None means that the
    relationship cannot be determined automatically.
    """
    a = pe_axis_sign(meta_a); b = pe_axis_sign(meta_b)
    if a and b:
        return a[0] == b[0] and a[1] == -b[1]
    la, lb = filename_pe_label(name_a), filename_pe_label(name_b)
    if la and lb:
        return {la, lb} == {"AP", "PA"}
    return None


def reverse_dir_label(source_name: str, meta: Dict) -> str:
    """Human-readable BIDS dir label; actual PE vector remains in JSON."""
    lab = filename_pe_label(source_name)
    if lab:
        return lab
    pe = str(meta.get("PhaseEncodingDirection", "") or "")
    return clean_label(pe.replace("-", "minus")) or "rev"


def make_inventory(folder: Path) -> Path:
    fields = [
        "source_base", "file_size_mb", "dimensions", "n_volumes",
        "suggested_role", "suggested_task", "suggested_run", "suggested_acq",
        "suggestion_reason", "candidate", "anatomical_kind",
        "ndim", "dim1", "dim2", "dim3", "dim4",
        "vox_x", "vox_y", "vox_z", "ProtocolName", "SeriesDescription",
        "MRAcquisitionType", "SeriesNumber", "PhaseEncodingDirection",
        "TotalReadoutTime", "RepetitionTime", "EchoTime"
    ]
    out = folder / "inventory.tsv"
    rows = []
    for nii in find_niftis(folder):
        try:
            info = nifti_info(nii)
        except Exception as e:
            print(f"WARNING: cannot read header {nii.name}: {e}")
            continue
        meta = json_load(paired_json(nii))
        sh = list(info["shape"]) + [1, 1, 1, 1]
        role, reason = suggested_role(nii.name, meta, info)
        inferred = inferred_task_run_acq(nii.name, meta)
        dims3 = f"{sh[0]}x{sh[1]}x{sh[2]}"
        dimensions = dims3 if info["dim4"] <= 1 else f"{dims3}x{info['dim4']}"
        rows.append({
            "source_base": base_without_nii(nii),
            "file_size_mb": f"{nii.stat().st_size / (1024*1024):.2f}",
            "dimensions": dimensions,
            "n_volumes": info["dim4"],
            "suggested_role": role,
            "suggested_task": inferred["task"],
            "suggested_run": inferred["run"],
            "suggested_acq": inferred["acq"],
            "suggestion_reason": reason,
            "candidate": guess_candidate(nii.name, meta, info),
            "anatomical_kind": anatomical_kind(nii.name, meta, info),
            "ndim": info["ndim"], "dim1": sh[0], "dim2": sh[1], "dim3": sh[2], "dim4": info["dim4"],
            "vox_x": f"{info['voxel_size'][0]:.6g}", "vox_y": f"{info['voxel_size'][1]:.6g}", "vox_z": f"{info['voxel_size'][2]:.6g}",
            "ProtocolName": meta.get("ProtocolName", ""), "SeriesDescription": meta.get("SeriesDescription", ""),
            "MRAcquisitionType": meta.get("MRAcquisitionType", ""), "SeriesNumber": meta.get("SeriesNumber", ""),
            "PhaseEncodingDirection": meta.get("PhaseEncodingDirection", ""),
            "TotalReadoutTime": meta.get("TotalReadoutTime", ""),
            "RepetitionTime": meta.get("RepetitionTime", ""),
            "EchoTime": meta.get("EchoTime", ""),
        })
    with out.open("w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fields, delimiter="\t")
        w.writeheader()
        w.writerows(rows)
    return out

def cmd_init_selection(args) -> None:
    cfg = load_config(args.study)
    sub = norm_sub(args.subject, cfg.get("subject_width", 2))
    ses = norm_ses(args.session, cfg.get("session_width", 2))
    folder = conversion_dir(args.root, args.study, sub, ses)
    if not folder.exists():
        raise SystemExit(f"Missing converted data directory: {folder}. Run convert first.")

    inv = make_inventory(folder)
    out = folder / "selection.tsv"
    if out.exists() and not args.force:
        raise SystemExit(f"Selection already exists: {out}. Use --force to overwrite it.")

    with inv.open() as f:
        rows = list(csv.DictReader(f, delimiter="\t"))

    # Resolve reverse-PE suggestions *relative to each likely BOLD*, not from a
    # study-specific AP/PA convention. JSON PE direction is preferred; AP/PA filename
    # tokens are only a fallback. This works identically for Finger, EWM, Cognitive, etc.
    by_key: Dict[Tuple[str, str], List[Dict]] = {}
    for r in rows:
        key = ((r.get("suggested_task", "") or "").strip(), (r.get("suggested_run", "") or "").strip())
        if key != ("", ""):
            by_key.setdefault(key, []).append(r)

    for key, group in by_key.items():
        bolds = [r for r in group if (r.get("suggested_role", "") or "").strip() == "bold"]
        if len(bolds) != 1:
            continue
        br = bolds[0]
        bmeta = {
            "PhaseEncodingDirection": br.get("PhaseEncodingDirection", ""),
            "TotalReadoutTime": br.get("TotalReadoutTime", ""),
        }
        for r in group:
            if (r.get("suggested_role", "") or "").strip() != "pe_candidate":
                continue
            rmeta = {
                "PhaseEncodingDirection": r.get("PhaseEncodingDirection", ""),
                "TotalReadoutTime": r.get("TotalReadoutTime", ""),
            }
            opposite = is_opposite_pe(bmeta, rmeta, br.get("source_base", ""), r.get("source_base", ""))
            if opposite is True:
                r["suggested_role"] = "reverse_pe"
                r["suggestion_reason"] = (r.get("suggestion_reason", "") + " | opposite PE to suggested BOLD").strip(" |")
            elif opposite is False:
                r["suggested_role"] = ""
                r["suggestion_reason"] = (r.get("suggestion_reason", "") + " | same PE as suggested BOLD; not reverse-PE partner").strip(" |")
            else:
                r["suggested_role"] = ""
                r["suggestion_reason"] = (r.get("suggestion_reason", "") + " | PE relationship unresolved; inspect notes/JSON").strip(" |")

    fields = [
        "source_base", "file_size_mb", "dimensions", "n_volumes",
        "use", "role", "task", "run", "acq",
        "suggested_role", "suggested_task", "suggested_run", "suggested_acq",
        "suggestion_reason", "allowed_roles", "instructions", "notes"
    ]
    with out.open("w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fields, delimiter="\t")
        w.writeheader()
        for r in rows:
            candidate = r.get("candidate", "")
            kind = r.get("anatomical_kind", "")
            srole = (r.get("suggested_role", "") or "").strip()
            # pe_candidate is intentionally not a valid user role.
            if srole == "pe_candidate":
                srole = ""
            stask = (r.get("suggested_task", "") or "").strip()
            srun = (r.get("suggested_run", "") or "").strip()
            sacq = (r.get("suggested_acq", "") or "").strip()
            instruction = (
                "Check scanning notes. Set use=1 only if this is the correct acquisition. "
                "role/task/run/acq are pre-filled suggestions; edit them if the notes disagree. "
                "For each BOLD run select exactly one opposite-PE acquisition as reverse_pe."
            )
            w.writerow({
                "source_base": r["source_base"],
                "file_size_mb": r.get("file_size_mb", ""),
                "dimensions": r.get("dimensions", ""),
                "n_volumes": r.get("n_volumes", r.get("dim4", "")),
                "use": "", "role": srole, "task": stask, "run": srun, "acq": sacq,
                "suggested_role": srole,
                "suggested_task": stask, "suggested_run": srun, "suggested_acq": sacq,
                "suggestion_reason": r.get("suggestion_reason", ""),
                "allowed_roles": "t1w | bold | reverse_pe",
                "instructions": instruction,
                "notes": " | ".join(x for x in (candidate, kind) if x),
            })

    print(f"Refreshed inventory: {inv}")
    print(f"Created manual selection sheet: {out}")
    print("Common MUGEN roles: t1w, bold, reverse_pe.")
    print("role/task/run/acq are pre-filled conservatively; check scanning notes and set use=1 only for valid acquisitions.")
    print("Each selected BOLD run requires exactly one selected reverse_pe acquisition with opposite PhaseEncodingDirection.")
    if cfg.get("require_mp2rage_uni_t1w", False):
        print("Study-specific T1w rule: the selected T1w must be the 3D MP2RAGE UNI/UNIT1 image.")
    print("TOPUP uses median BOLD volume + median reverse-PE volume, index=floor(N/2), for every MUGEN study.")

def locate_source(folder: Path, base: str) -> Path:
    for suffix in (".nii.gz", ".nii"):
        p = folder / (base + suffix)
        if p.exists(): return p
    raise FileNotFoundError(f"Cannot find NIfTI for {base} in {folder}")


def copy_pair(src_nii: Path, dst_nii: Path, *, updated_json: Optional[Dict] = None) -> None:
    dst_nii.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src_nii, dst_nii)
    src_json = paired_json(src_nii); dst_json = paired_json(dst_nii)
    if src_json.exists():
        meta = json_load(src_json)
        if updated_json: meta.update(updated_json)
        json_dump(dst_json, meta)
    elif updated_json:
        json_dump(dst_json, updated_json)


def clean_label(s: str) -> str:
    return re.sub(r"[^A-Za-z0-9]", "", s)


def bids_bold_name(sub: str, ses: str, task: str, run_no: str, acq: str = "") -> str:
    bits = [sub, ses, f"task-{clean_label(task)}", f"run-{int(run_no)}"]
    if acq: bits.append(f"acq-{clean_label(acq)}")
    return "_".join(bits) + "_bold.nii.gz"


def bids_reverse_pe_name(sub: str, ses: str, task: str, run_no: str, direction_label: str) -> str:
    acq = clean_label(f"{task}Run{int(run_no)}")
    return f"{sub}_{ses}_acq-{acq}_dir-{clean_label(direction_label)}_epi.nii.gz"

def cmd_make_bids(args) -> None:
    cfg = load_config(args.study)
    sub = norm_sub(args.subject, cfg.get("subject_width", 2)); ses = norm_ses(args.session, cfg.get("session_width", 2))
    source_dir = conversion_dir(args.root, args.study, sub, ses)
    selection = Path(args.selection) if args.selection else source_dir / "selection.tsv"
    if not selection.exists(): raise SystemExit(f"Missing selection sheet: {selection}")
    with selection.open() as f:
        all_rows = list(csv.DictReader(f, delimiter="\t"))

    selected = []
    editable = ("source_base", "use", "role", "task", "run", "acq")
    legacy_role_map = {"fmap_ap": "reverse_pe", "fmap_pa": "reverse_pe"}
    for row in all_rows:
        for key in editable:
            row[key] = (row.get(key, "") or "").strip()
        row["role"] = legacy_role_map.get(row["role"].lower(), row["role"].lower())
        if row["use"].lower() in ("1", "y", "yes", "true", "x"):
            selected.append(row)
    if not selected: raise SystemExit("No rows marked use=1 in selection.tsv")

    valid_roles = {"t1w", "bold", "reverse_pe"}
    for r in selected:
        if r["role"] not in valid_roles:
            raise SystemExit(f"Invalid role '{r['role']}' for {r['source_base']}. Allowed: t1w, bold, reverse_pe")

    t1s = [r for r in selected if r["role"] == "t1w"]
    if len(t1s) != 1: raise SystemExit(f"Exactly one T1w must be selected per session; found {len(t1s)}")
    t1src = locate_source(source_dir, t1s[0]["source_base"]); t1info = nifti_info(t1src)
    if t1info["dim4"] != 1:
        raise SystemExit(f"HARD STOP: selected T1w is not 3D (dim4={t1info['dim4']}): {t1src}")
    t1meta = json_load(paired_json(t1src)); t1kind = anatomical_kind(t1src.name, t1meta, t1info)
    if cfg.get("require_mp2rage_uni_t1w", False) and t1kind != "mp2rage_uni":
        raise SystemExit(
            "HARD STOP: this study requires the MP2RAGE UNI/UNIT1 image as T1w.\n"
            f"Selected source: {t1src.name}\nDetected anatomical kind: {t1kind or 'unknown'}"
        )
    if cfg.get("prefer_mp2rage_uni_t1w", False) and t1kind != "mp2rage_uni":
        print(f"WARNING: selected T1w is {t1kind or 'unclassified'}, not MP2RAGE UNI/UNIT1.")

    bdir = bids_dir(args.root, args.study); sdir = bdir / sub / ses
    (sdir / "anat").mkdir(parents=True, exist_ok=True); (sdir / "func").mkdir(exist_ok=True); (sdir / "fmap").mkdir(exist_ok=True)
    desc = bdir / "dataset_description.json"
    if not desc.exists():
        json_dump(desc, {"Name": f"MUGEN - {cfg['display_name']}", "BIDSVersion": "1.10.0", "DatasetType": "raw"})

    t1dst = sdir / "anat" / f"{sub}_{ses}_T1w.nii.gz"; copy_pair(t1src, t1dst)
    print(f"T1w OK (3D, {t1kind or 'unclassified'}): {t1info['shape']} -> {t1dst}")

    bold_rows = [r for r in selected if r["role"] == "bold"]
    reverse_rows = [r for r in selected if r["role"] == "reverse_pe"]
    if not bold_rows:
        suggested = [r for r in all_rows if (r.get("suggested_role", "") or "").strip().lower() == "bold"]
        msg = "At least one BOLD run must be selected."
        if suggested:
            msg += "\nLikely BOLD candidates:\n  - " + "\n  - ".join((r.get("source_base", "") or "").strip() for r in suggested)
        raise SystemExit(msg)

    topup_manifest = derivatives_dir(args.root, args.study) / "topup_manifest.tsv"
    topup_manifest.parent.mkdir(parents=True, exist_ok=True)
    existing = []
    if topup_manifest.exists():
        with topup_manifest.open() as f: existing = list(csv.DictReader(f, delimiter="\t"))
    existing = [r for r in existing if not (r.get("subject") == sub and r.get("session") == ses)]

    for br in bold_rows:
        if not br["task"] or not br["run"]: raise SystemExit(f"BOLD row needs task/run: {br['source_base']}")
        src = locate_source(source_dir, br["source_base"]); info = nifti_info(src)
        if info["dim4"] <= 1: raise SystemExit(f"HARD STOP: BOLD must be 4D: {src} (dim4={info['dim4']})")
        dst_name = bids_bold_name(sub, ses, br["task"], br["run"], br.get("acq", ""))
        dst = sdir / "func" / dst_name; copy_pair(src, dst)
        print(f"BOLD OK (4D, {info['dim4']} vols): {dst}")

        candidates = [r for r in reverse_rows if r.get("task") == br["task"] and r.get("run") == br["run"]]
        if len(candidates) != 1:
            raise SystemExit(f"Run {br['task']} {br['run']}: require exactly one reverse_pe acquisition; found {len(candidates)}")
        rr = candidates[0]
        rev_src = locate_source(source_dir, rr["source_base"])
        rev_info = nifti_info(rev_src)
        bold_meta = json_load(paired_json(src)); rev_meta = json_load(paired_json(rev_src))
        opposite = is_opposite_pe(bold_meta, rev_meta, src.name, rev_src.name)
        if opposite is not True:
            raise SystemExit(
                f"Run {br['task']} {br['run']}: selected reverse_pe is not demonstrably opposite to BOLD.\n"
                f"BOLD PE={bold_meta.get('PhaseEncodingDirection')!r}; reverse PE={rev_meta.get('PhaseEncodingDirection')!r}."
            )
        dir_label = reverse_dir_label(rev_src.name, rev_meta)
        rev_name = bids_reverse_pe_name(sub, ses, br["task"], br["run"], dir_label)
        rev_dst = sdir / "fmap" / rev_name
        intended = f"{ses}/func/{dst_name}"
        copy_pair(rev_src, rev_dst, updated_json={"IntendedFor": [intended]})

        bold_volume = info["dim4"] // 2
        reverse_volume = rev_info["dim4"] // 2
        print(f"TOPUP pair: BOLD median={bold_volume}/{info['dim4']} | reverse-PE median={reverse_volume}/{rev_info['dim4']} | dir={dir_label}")
        existing.append({
            "subject": sub, "session": ses, "task": br["task"], "run": str(int(br["run"])), "acq": br.get("acq", ""),
            "bold": str(dst.relative_to(bdir)), "reverse_pe": str(rev_dst.relative_to(bdir)),
            "bold_volume": str(bold_volume), "reverse_volume": str(reverse_volume),
            "bold_nvols": str(info["dim4"]), "reverse_nvols": str(rev_info["dim4"]),
        })

    fields = ["subject", "session", "task", "run", "acq", "bold", "reverse_pe",
              "bold_volume", "reverse_volume", "bold_nvols", "reverse_nvols"]
    with topup_manifest.open("w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fields, delimiter="\t", extrasaction="ignore"); w.writeheader(); w.writerows(existing)
    print(f"\nBIDS dataset prepared: {bdir}")
    print(f"TOPUP manifest: {topup_manifest}")
    print("Common TOPUP rule: median selected BOLD volume + median selected reverse-PE volume.")
    print("Manual selection is preserved; converted source files were copied, never moved.")

def pe_vector(meta: Dict) -> Tuple[int, int, int, float]:
    pe = meta.get("PhaseEncodingDirection")
    trot = meta.get("TotalReadoutTime")
    if pe not in ("i", "i-", "j", "j-", "k", "k-"):
        raise ValueError(f"missing/invalid PhaseEncodingDirection: {pe!r}")
    if trot in (None, ""):
        raise ValueError("missing TotalReadoutTime")
    sign = -1 if pe.endswith("-") else 1
    axis = pe[0]; vec = {"i": [sign, 0, 0], "j": [0, sign, 0], "k": [0, 0, sign]}[axis]
    return vec[0], vec[1], vec[2], float(trot)


def add_tu_to_name(name: str) -> str:
    if not name.endswith("_bold.nii.gz"): raise ValueError(name)
    stem = name[:-12]  # remove _bold.nii.gz
    m = re.search(r"_acq-([A-Za-z0-9]+)$", stem)
    if m:
        return stem[:m.start()] + f"_acq-{m.group(1)}TU_bold.nii.gz"
    return stem + "_acq-TU_bold.nii.gz"


def cmd_topup(args) -> None:
    cfg = load_config(args.study)
    sub = norm_sub(args.subject, cfg.get("subject_width", 2)); ses = norm_ses(args.session, cfg.get("session_width", 2))
    if not shutil.which("topup") or not shutil.which("applytopup") or not shutil.which("fslroi") or not shutil.which("fslmerge"):
        raise SystemExit("FSL commands not found. Run 'module load FSL' first.")
    src_bids = bids_dir(args.root, args.study); out_bids = topup_bids_dir(args.root, args.study)
    manifest = derivatives_dir(args.root, args.study) / "topup_manifest.tsv"
    if not manifest.exists(): raise SystemExit(f"Missing {manifest}; run make-bids first.")
    with manifest.open() as f:
        rows = [r for r in csv.DictReader(f, delimiter="\t") if r.get("subject") == sub and r.get("session") == ses]
    if not rows: raise SystemExit(f"No TOPUP rows for {sub} {ses}")

    # Reject legacy manifests cleanly; regenerate Step 3 with v8 rather than guessing.
    if "reverse_pe" not in rows[0]:
        raise SystemExit("Legacy TOPUP manifest detected. Re-run 'make-bids' with v8 to generate the generic bold+reverse_pe manifest.")

    out_bids.mkdir(parents=True, exist_ok=True)
    src_desc = src_bids / "dataset_description.json"
    if src_desc.exists(): shutil.copy2(src_desc, out_bids / "dataset_description.json")
    src_session = src_bids / sub / ses; out_session = out_bids / sub / ses
    if out_session.exists(): shutil.rmtree(out_session)
    shutil.copytree(src_session, out_session)

    work = derivatives_dir(args.root, args.study) / "topup" / sub / ses
    work.mkdir(parents=True, exist_ok=True)

    for r in rows:
        bold_src = src_bids / r["bold"]; rev_src = src_bids / r["reverse_pe"]
        if not bold_src.exists(): raise SystemExit(f"Missing BOLD: {bold_src}")
        if not rev_src.exists(): raise SystemExit(f"Missing reverse-PE acquisition: {rev_src}")
        bold_meta = json_load(paired_json(bold_src)); rev_meta = json_load(paired_json(rev_src))
        bold_vec = pe_vector(bold_meta); rev_vec = pe_vector(rev_meta)
        if tuple(bold_vec[:3]) != tuple(-x for x in rev_vec[:3]):
            raise SystemExit(
                f"TOPUP PE directions are not opposites for {r['task']} run {r['run']}: "
                f"BOLD={bold_meta.get('PhaseEncodingDirection')!r}, reverse={rev_meta.get('PhaseEncodingDirection')!r}"
            )

        bold_info = nifti_info(bold_src); rev_info = nifti_info(rev_src)
        bold_volume = bold_info["dim4"] // 2
        reverse_volume = rev_info["dim4"] // 2
        # Manifest values are provenance only; recompute and verify to prevent stale indices.
        if r.get("bold_volume") not in (None, "", str(bold_volume)) or r.get("reverse_volume") not in (None, "", str(reverse_volume)):
            raise SystemExit(f"TOPUP manifest indices are stale for {r['task']} run {r['run']}; re-run make-bids.")

        tag = f"task-{clean_label(r['task'])}_run-{int(r['run'])}"
        bold0 = work / f"{tag}_bold_median.nii.gz"
        rev0 = work / f"{tag}_reverse_median.nii.gz"
        merged = work / f"{tag}_bold_reverse.nii.gz"
        print(f"TOPUP median indices: BOLD={bold_volume} of {bold_info['dim4']} | reverse-PE={reverse_volume} of {rev_info['dim4']}")
        run(["fslroi", str(bold_src), str(bold0), str(bold_volume), "1"])
        run(["fslroi", str(rev_src), str(rev0), str(reverse_volume), "1"])
        run(["fslmerge", "-t", str(merged), str(bold0), str(rev0)])

        acq = work / f"{tag}_acqparams.txt"
        with acq.open("w") as f:
            f.write("%d %d %d %.10g\n" % bold_vec)
            f.write("%d %d %d %.10g\n" % rev_vec)
        topbase = work / f"{tag}_topup"
        run(["topup", f"--imain={merged}", f"--datain={acq}", f"--config={args.topup_config}",
             f"--out={topbase}", f"--iout={work / (tag + '_corrected_refs')}", f"--fout={work / (tag + '_fieldmap_Hz')}"])

        out_rel_dir = Path(r["bold"]).parent; old_in_copy = out_bids / r["bold"]
        new_name = add_tu_to_name(bold_src.name); corrected = out_bids / out_rel_dir / new_name
        corrected.parent.mkdir(parents=True, exist_ok=True)
        # Row 1 of acqparams is always the BOLD direction by construction.
        run(["applytopup", f"--imain={bold_src}", "--inindex=1", "--method=jac",
             f"--datain={acq}", f"--topup={topbase}", f"--out={corrected}"])
        if not corrected.exists() and Path(str(corrected) + ".nii.gz").exists():
            Path(str(corrected) + ".nii.gz").rename(corrected)

        meta = dict(bold_meta)
        meta["MUGENTopUpApplied"] = True
        meta["MUGENTopUpMode"] = "bold_plus_reverse_pe"
        meta["MUGENTopUpMedianIndices"] = {"BOLD": bold_volume, "ReversePE": reverse_volume}
        meta["MUGENTopUpSources"] = [r["bold"], r["reverse_pe"]]
        json_dump(paired_json(corrected), meta)

        if old_in_copy.exists() and old_in_copy != corrected: old_in_copy.unlink()
        old_json = paired_json(old_in_copy)
        if old_json.exists(): old_json.unlink()

        intended = f"{ses}/func/{new_name}"
        rev_json = paired_json(out_bids / r["reverse_pe"])
        fm = json_load(rev_json); fm["IntendedFor"] = [intended]; json_dump(rev_json, fm)
        print(f"TOPUP corrected: {corrected}")

    desc = json_load(out_bids / "dataset_description.json")
    desc["Name"] = desc.get("Name", "MUGEN") + " - TOPUP corrected"
    desc["GeneratedBy"] = [{"Name": "FSL TOPUP/applytopup", "Description": "MUGEN common BOLD + reverse-PE median-volume susceptibility correction"}]
    json_dump(out_bids / "dataset_description.json", desc)
    print(f"\nTOPUP BIDS-like dataset ready for MRIQC/fMRIPrep: {out_bids}")

def cmd_check(args) -> None:
    cfg = load_config(args.study)
    sub = norm_sub(args.subject, cfg.get("subject_width", 2)); ses = norm_ses(args.session, cfg.get("session_width", 2))
    root = topup_bids_dir(args.root, args.study) if args.topup else bids_dir(args.root, args.study)
    sdir = root / sub / ses
    t1s = list((sdir / "anat").glob("*_T1w.nii*")); bolds = list((sdir / "func").glob("*_bold.nii*"))
    errors = 0
    if len(t1s) != 1: print(f"ERROR: expected one T1w, found {len(t1s)}"); errors += 1
    for p in t1s:
        inf = nifti_info(p)
        meta = json_load(paired_json(p))
        kind = anatomical_kind(p.name, meta, inf)
        ok = inf["dim4"] == 1
        if cfg.get("require_mp2rage_uni_t1w", False):
            ok = ok and kind == "mp2rage_uni"
        print(f"{'OK' if ok else 'ERROR'} T1w {p.name}: shape={inf['shape']}, dim4={inf['dim4']}, kind={kind or 'unknown'}")
        errors += 0 if ok else 1
    if not bolds: print("ERROR: no BOLD files found"); errors += 1
    for p in bolds:
        inf = nifti_info(p); ok = inf["dim4"] > 1; print(f"{'OK' if ok else 'ERROR'} BOLD {p.name}: shape={inf['shape']}, dim4={inf['dim4']}"); errors += 0 if ok else 1
    if errors: raise SystemExit(f"Validation failed with {errors} error(s).")
    print("Common MUGEN image validation passed.")


def main() -> None:
    p = argparse.ArgumentParser(description="MUGEN common fMRI data-preparation controller")
    p.add_argument("--root", type=Path, default=DEFAULT_ROOT, help=f"MUGEN data root (default: {DEFAULT_ROOT})")
    sp = p.add_subparsers(dest="command", required=True)

    c = sp.add_parser("convert", help="DICOM -> CoBIC-named NIfTI/JSON + inventory, then STOP")
    c.add_argument("--study", required=True); c.add_argument("--dicom-dir", required=True); c.add_argument("--subject"); c.add_argument("--session"); c.set_defaults(func=cmd_convert)
    s = sp.add_parser("init-selection", help="Create the manual selection.tsv from inventory.tsv")
    s.add_argument("--study", required=True); s.add_argument("--subject", required=True); s.add_argument("--session", required=True); s.add_argument("--force", action="store_true"); s.set_defaults(func=cmd_init_selection)
    b = sp.add_parser("make-bids", help="Copy manually selected files into BIDS and validate T1w/BOLD dimensionality")
    b.add_argument("--study", required=True); b.add_argument("--subject", required=True); b.add_argument("--session", required=True); b.add_argument("--selection"); b.set_defaults(func=cmd_make_bids)
    t = sp.add_parser("topup", help="Run explicit TOPUP/applytopup and create BIDS_TopUp dataset")
    t.add_argument("--study", required=True); t.add_argument("--subject", required=True); t.add_argument("--session", required=True); t.add_argument("--topup-config", default="b02b0.cnf"); t.set_defaults(func=cmd_topup)
    k = sp.add_parser("check", help="Hard check common T1w/BOLD dimensionality")
    k.add_argument("--study", required=True); k.add_argument("--subject", required=True); k.add_argument("--session", required=True); k.add_argument("--topup", action="store_true"); k.set_defaults(func=cmd_check)
    args = p.parse_args(); args.root = args.root.resolve(); args.func(args)


if __name__ == "__main__":
    main()
